package com.tk.learn.snowflakedemo.transactions.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Builder;

@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
public record SenderAccntItem(
        @JsonProperty("amnt_credited") int amntCredited,
        @JsonProperty("accnt_no") int accntNo
) {}