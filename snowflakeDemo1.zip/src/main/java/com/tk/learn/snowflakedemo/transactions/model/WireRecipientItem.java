package com.tk.learn.snowflakedemo.transactions.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;
import lombok.Builder;

@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
public record WireRecipientItem(
        @JsonProperty("swift_no") String swiftNo,
        Address address,
        @JsonProperty("amnt_credited") BigDecimal amntCredited,
        @JsonProperty("wire_accnt_no") int wireAccntNo,
        @JsonProperty("recipient_name") String recipientName
) {}