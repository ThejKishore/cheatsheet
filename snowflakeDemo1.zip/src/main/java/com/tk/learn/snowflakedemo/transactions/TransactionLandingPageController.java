package com.tk.learn.snowflakedemo.transactions;

import com.tk.learn.snowflakedemo.transactions.model.TranLandingPage;
import com.tk.learn.snowflakedemo.transactions.model.TranLandingPageResponse;
import org.apache.commons.lang3.StringUtils;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.stream.Collectors;

@RestController
@ConditionalOnBean(TransactionService.class)
@RequestMapping(path = "/api/transactions")
public class TransactionLandingPageController {

    private final TransactionService transactionService;

    public TransactionLandingPageController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    @GetMapping(produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<TranLandingPageResponse> getLandingTransactions(
            @RequestParam(name = "page", defaultValue = "0") int page,
            @RequestParam(name = "size", defaultValue = "20") int size,
            @RequestParam(name = "filterField", required = false) String filterField,
            @RequestParam(name = "filterValue", required = false) String filterValue
    ) {
        // Basic validation and sane defaults
        if (page < 0) page = 0;
        if (size <= 0) size = 20;
        if (size > 200) size = 200; // avoid overly large page sizes

        TranLandingPageResponse all = transactionService.listValidTransactions();
        List<TranLandingPage> items = new ArrayList<>(all.transactions() != null ? all.transactions() : Collections.emptyList());

        // Filtering
        if (StringUtils.isNotBlank(filterField) && StringUtils.isNotBlank(filterValue)) {
            final String fieldNorm = normalizeField(filterField);
            final String valNorm = filterValue.trim().toLowerCase(Locale.ROOT);
            items = items.stream()
                    .filter(Objects::nonNull)
                    .filter(t -> containsFieldValue(t, fieldNorm, valNorm))
                    .collect(Collectors.toList());
        }

        // Pagination
        int start = Math.min(page * size, Math.max(0, items.size()));
        int end = Math.min(start + size, items.size());
        List<TranLandingPage> paged = start >= end ? Collections.emptyList() : items.subList(start, end);

        return ResponseEntity.ok(new TranLandingPageResponse(paged));
    }

    private static String normalizeField(String field) {
        String f = field.trim().toLowerCase(Locale.ROOT);
        // remove underscores for easier matching
        return f.replace("_", "");
    }

    private static boolean containsFieldValue(TranLandingPage t, String fieldNorm, String valueNorm) {
        String candidate;
        switch (fieldNorm) {
            case "transactionidentifier":
                candidate = t.transactionIdentifier() == null ? "" : String.valueOf(t.transactionIdentifier());
                break;
            case "transactionname":
                candidate = StringUtils.defaultString(t.transactionName());
                break;
            case "transactiondescription":
                candidate = StringUtils.defaultString(t.transactionDescription());
                break;
            case "transactiontype":
                candidate = StringUtils.defaultString(t.transactionType());
                break;
            case "transactionamount":
                candidate = t.transactionAmount() == null ? "" : t.transactionAmount().toPlainString();
                break;
            case "fromaccnts":
                candidate = t.fromAccnts() == null ? "" : t.fromAccnts().stream().map(String::valueOf).collect(Collectors.joining(","));
                break;
            default:
                // Unknown field -> do not filter out anything by default for unknown; return true
                return true;
        }
        return candidate.toLowerCase(Locale.ROOT).contains(valueNorm);
    }
}
