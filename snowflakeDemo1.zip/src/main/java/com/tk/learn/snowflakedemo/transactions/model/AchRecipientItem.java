package com.tk.learn.snowflakedemo.transactions.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;
import lombok.Builder;

@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
public record AchRecipientItem(
        @JsonProperty("amnt_credited") BigDecimal amntCredited,
        @JsonProperty("ach_routing_no") String achRoutingNo,
        @JsonProperty("ach_accnt_no") long achAccntNo
) {}