package com.tk.learn.snowflakedemo.transactions.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;
import java.util.List;
import lombok.Builder;

@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
public record Transaction(
        @JsonProperty("ach_recipient")
        @JsonInclude(JsonInclude.Include.NON_NULL)
        List<AchRecipientItem> achRecipient,

        @JsonProperty("transaction_identifier")
        int transactionIdentifier,

        @JsonProperty("from_accnts")
        List<FromAccntsItem> fromAccnts,

        @JsonProperty("transaction_name")
        String transactionName,

        @JsonProperty("transaction_description")
        String transactionDescription,

        @JsonProperty("transaction_type")
        String transactionType,

        @JsonProperty("transaction_amnt")
        BigDecimal transactionAmnt,

        @JsonProperty("sender_accnt")
        @JsonInclude(JsonInclude.Include.NON_NULL)
        List<SenderAccntItem> senderAccnt,

        @JsonProperty("wire_recipient")
        @JsonInclude(JsonInclude.Include.NON_NULL)
        List<WireRecipientItem> wireRecipient
) {}