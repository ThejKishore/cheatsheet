package com.tk.learn.snowflakedemo.transactions.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.math.BigDecimal;
import java.util.List;
import lombok.Builder;

@Builder
public record TranLandingPage(
        @JsonProperty("transaction_identifier") Integer transactionIdentifier,
        @JsonProperty("transaction_name") String transactionName,
        @JsonProperty("transaction_description") String transactionDescription,
        @JsonProperty("transaction_type") String transactionType,
        @JsonProperty("transaction_amount") BigDecimal transactionAmount,
        @JsonProperty("from_accnts") List<Long> fromAccnts
) {}
