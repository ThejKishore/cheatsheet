package com.tk.learn.snowflakedemo.transactions.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import java.util.List;
import lombok.Builder;

@Builder
public record TranLandingPageResponse(
        @JsonProperty("transactions") List<TranLandingPage> transactions
) {}
