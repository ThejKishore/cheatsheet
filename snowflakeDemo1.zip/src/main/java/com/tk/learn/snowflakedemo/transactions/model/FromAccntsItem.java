package com.tk.learn.snowflakedemo.transactions.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;
import lombok.Builder;

@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
public record FromAccntsItem(
        @JsonProperty("amnt_debited") BigDecimal amntDebited,
        @JsonProperty("accnt_no") long accntNo
) {}