package com.tk.learn.snowflakedemo.transactions;

import com.tk.learn.snowflakedemo.transactions.model.Transaction;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;

import java.net.URI;
import java.util.Optional;

@RestController
@ConditionalOnBean(TransactionService.class)
@RequestMapping(path = "/api/transactions")
public class TransactionController {

    private final TransactionService transactionService;

    public TransactionController(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    @GetMapping(path = "/{transactionIdentifier}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Transaction> getTransactionData(@PathVariable("transactionIdentifier") String transactionIdentifier) {
        Optional<Transaction> result = transactionService.getTransactionData(transactionIdentifier);
        return result.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build());
    }


    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> createTransaction(@RequestBody Transaction transaction) {
        int rows = transactionService.insertTransaction(transaction);
        if (rows > 0) {
            URI location = URI.create("/api/transactions/" + transaction.transactionIdentifier());
            return ResponseEntity.created(location).build();
        }
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
    }

    @PutMapping(path = "/{transactionIdentifier}", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> updateTransaction(@PathVariable String transactionIdentifier,
                                                  @RequestBody Transaction transaction) {
        int rows = transactionService.updateTransaction(transactionIdentifier, transaction);
        if (rows == 0) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).build();
        }
        return ResponseEntity.noContent().build();
    }
}
