package com.tk.learn.snowflakedemo.transactions;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tk.learn.snowflakedemo.transactions.model.TranLandingPage;
import com.tk.learn.snowflakedemo.transactions.model.TranLandingPageResponse;
import org.springframework.jdbc.core.RowMapper;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * RowMapper implementation tailored for Snowflake JDBC peculiarities that maps a row
 * into a TranLandingPageResponse containing a single TranLandingPage item.
 * - Normalizes JDBC Array values (e.g., Snowflake ARRAY) into standard Java List instances.
 */
public class SnowflakeColumnMapRowMapper implements RowMapper<TranLandingPageResponse> {

    @Override
    public TranLandingPageResponse mapRow(ResultSet rs, int rowNum) throws SQLException {
        Integer transactionIdentifier = rs.getInt("TRANSACTION_IDENTIFIER");
        String transactionName = rs.getString("TRANSACTION_NAME");
        String transactionDescription = rs.getString("TRANSACTION_DESCRIPTION");
        String transactionType = rs.getString("TRANSACTION_TYPE");
        BigDecimal transactionAmount = rs.getBigDecimal("TRANSACTION_AMOUNT");
        List<Long> fromAccnts = getLongList(rs, "FROM_ACCNTS");

        TranLandingPage item= TranLandingPage.builder().transactionAmount(transactionAmount)
                .fromAccnts(fromAccnts)
                .transactionIdentifier(transactionIdentifier)
                .transactionName(transactionName)
                .transactionDescription(transactionDescription)
                .transactionType(transactionType)
                .build();
        List<TranLandingPage> items = new ArrayList<>();
        items.add(item);
        return new TranLandingPageResponse(items);
    }

    /**
     * Concise conversion for JSON array column to List<Long> using Jackson ObjectMapper.
     * Returns null when the source is null/blank or parsing fails.
     */
    private List<Long> getLongList(ResultSet rs, String column) throws SQLException {
        String jsonString = rs.getString(column);
        if (StringUtils.isBlank(jsonString)) return Collections.emptyList();
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.readValue(jsonString, new TypeReference<List<Long>>() {});
        } catch (Exception e) {
            // If not valid JSON, return null to avoid breaking the mapper
            return Collections.emptyList();
        }
    }
}
