package com.tk.learn.snowflakedemo.snowflake.conf;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.apache.commons.lang3.StringUtils;

import javax.sql.DataSource;
import java.util.ArrayList;
import java.util.List;

/**
 * Explicit Snowflake DataSource configuration.
 * This bean will be created only if no other DataSource bean is defined.
 */
@Configuration
public class SnowflakeDataSourceConfig {

    private static final Logger log = LoggerFactory.getLogger(SnowflakeDataSourceConfig.class);

    @Bean
    @ConditionalOnMissingBean(DataSource.class)
    @ConditionalOnProperty(name = "spring.datasource.url")
    public DataSource snowflakeDataSource(
            @Value("${spring.datasource.url}") String url,
            @Value("${spring.datasource.username:}") String username,
            @Value("${spring.datasource.password:}") String password,
            @Value("${spring.datasource.driver-class-name:net.snowflake.client.jdbc.SnowflakeDriver}") String driverClassName,
            // Optional Snowflake session properties
            @Value("${spring.datasource.snowflake.warehouse:}") String warehouse,
            @Value("${spring.datasource.snowflake.db:}") String database,
            @Value("${spring.datasource.snowflake.schema:}") String schema,
            @Value("${spring.datasource.snowflake.role:}") String role,
            @Value("${spring.datasource.snowflake.client-session-keep-alive:false}") boolean clientSessionKeepAlive
    ) {
        // Identify and log missing properties for easier diagnostics
        List<String> missingRequired = new ArrayList<>();
        if (StringUtils.isBlank(url)) missingRequired.add("spring.datasource.url");
        if (StringUtils.isBlank(username)) missingRequired.add("spring.datasource.username");
        if (StringUtils.isBlank(password)) missingRequired.add("spring.datasource.password");
        if (StringUtils.isBlank(driverClassName)) missingRequired.add("spring.datasource.driver-class-name");
        if (!missingRequired.isEmpty()) {
            log.error("Missing required datasource properties: {}", String.join(", ", missingRequired));
        }

        List<String> missingOptional = new ArrayList<>();
        if (StringUtils.isBlank(warehouse)) missingOptional.add("spring.datasource.snowflake.warehouse");
        if (StringUtils.isBlank(database)) missingOptional.add("spring.datasource.snowflake.db");
        if (StringUtils.isBlank(schema)) missingOptional.add("spring.datasource.snowflake.schema");
        if (StringUtils.isBlank(role)) missingOptional.add("spring.datasource.snowflake.role");
        if (!missingOptional.isEmpty()) {
            log.warn("Optional Snowflake properties not provided: {}", String.join(", ", missingOptional));
        }

        HikariConfig config = new HikariConfig();
        config.setDriverClassName(driverClassName);
        config.setJdbcUrl(url);
        if (username != null) config.setUsername(username);
        if (password != null) config.setPassword(password);

        // Snowflake-specific properties. These can also be provided in the JDBC URL;
        // here we pass them explicitly if provided.
        if (StringUtils.isNotBlank(warehouse)) {
            config.addDataSourceProperty("warehouse", warehouse);
        }
        if (StringUtils.isNotBlank(database)) {
            config.addDataSourceProperty("db", database);
        }
        if (StringUtils.isNotBlank(schema)) {
            config.addDataSourceProperty("schema", schema);
        }
        if (StringUtils.isNotBlank(role)) {
            config.addDataSourceProperty("role", role);
        }
        config.addDataSourceProperty("client_session_keep_alive", clientSessionKeepAlive);

        // A couple of sensible Hikari defaults for Snowflake
        config.setMaximumPoolSize(5);
        config.setMinimumIdle(0);
        config.setPoolName("snowflake-hikari-pool");
        // Do not fail application context if initial connection cannot be established
        config.setInitializationFailTimeout(-1);

        return new HikariDataSource(config);
    }

    @Bean
    @ConditionalOnBean(DataSource.class)
    @ConditionalOnMissingBean(JdbcClient.class)
    public JdbcClient jdbcClient(DataSource dataSource) {
        return JdbcClient.create(dataSource);
    }
}
