package com.tk.learn.snowflakedemo.transactions;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tk.learn.snowflakedemo.transactions.model.TranLandingPage;
import com.tk.learn.snowflakedemo.transactions.model.TranLandingPageResponse;
import com.tk.learn.snowflakedemo.transactions.model.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Service;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.apache.commons.lang3.StringUtils;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Service
@ConditionalOnBean(JdbcClient.class)
public class TransactionService {

    private static final Logger log = LoggerFactory.getLogger(TransactionService.class);

    private final JdbcClient jdbcClient;
    private final ObjectMapper objectMapper;
    private final String queryById;
    private final String insertSql;
    private final String updateSql;
    private final String validQuery;

    public TransactionService(JdbcClient jdbcClient,
                              ObjectMapper objectMapper,
                              @Value("${app.snowflake.queryByTransactionIdentifier}") String queryById,
                              @Value("${app.snowflake.insertTransaction}") String insertSql,
                              @Value("${app.snowflake.updateTransaction}") String updateSql,
                              @Value("${app.snowflake.query}") String validQuery) {
        this.jdbcClient = jdbcClient;
        this.objectMapper = objectMapper;
        this.queryById = queryById;
        this.insertSql = insertSql;
        this.updateSql = updateSql;
        this.validQuery = validQuery;
    }

    /**
     * Fetches transaction_data JSON for the given transaction identifier.
     * Returns Optional.empty() if no row found.
     */
    public Optional<Transaction> getTransactionData(String transactionIdentifier) {
        try {
            Optional<String> jsonTextOpt = jdbcClient
                    .sql(queryById)
                    .param("transactionIdentifier", transactionIdentifier)
                    .query(String.class)
                    .optional();

            if (jsonTextOpt.isEmpty()) {
                return Optional.empty();
            }

            String jsonText = jsonTextOpt.get();
            if (StringUtils.isBlank(jsonText)) {
                // If the column is NULL or blank, treat as not found/empty
                return Optional.empty();
            }

            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            Transaction transaction = objectMapper.readValue(jsonText, Transaction.class);
            return Optional.of(transaction);

        } catch (Exception e) {
            log.error("Error fetching transaction_data for {}: {}", transactionIdentifier, e.getMessage(), e);
            throw new RuntimeException("Failed to fetch transaction data", e);
        }
    }

    /**
     * Executes the configured valid transactions query and returns a wrapper containing a list of TranLandingPage DTOs.
     */
    public TranLandingPageResponse listValidTransactions() {
        try {
            List<TranLandingPageResponse> rows = jdbcClient.sql(validQuery)
                    .query(new SnowflakeColumnMapRowMapper())
                    .list();

            java.util.List<TranLandingPage> items = new java.util.ArrayList<>();
            for (TranLandingPageResponse r : rows) {
                if (r != null && r.transactions() != null) {
                    items.addAll(r.transactions());
                }
            }
            return new TranLandingPageResponse(items);
        } catch (Exception e) {
            log.error("Error executing valid transactions query: {}", e.getMessage(), e);
            throw new RuntimeException("Failed to execute valid transactions query", e);
        }
    }




    /**
     * Inserts a new transaction row using the configured SQL. Returns rows affected.
     */
    public int insertTransaction(Transaction tx) {
        try {
            String id = String.valueOf(tx.transactionIdentifier());
            String json = objectMapper.writeValueAsString(tx);
            return jdbcClient.sql(insertSql)
                    .param("transactionIdentifier", id)
                    .param("transactionData", json)
                    .update();
        } catch (Exception e) {
            log.error("Error inserting transaction {}: {}", tx.transactionIdentifier(), e.getMessage(), e);
            throw new RuntimeException("Failed to insert transaction", e);
        }
    }

    /**
     * Updates an existing transaction row. Returns rows affected.
     */
    public int updateTransaction(String transactionIdentifier, Transaction tx) {
        try {
            // Ensure the JSON contains the latest identifier consistent with path variable
            Transaction txUpdated = new Transaction(
                    tx.achRecipient(),
                    Integer.parseInt(transactionIdentifier),
                    tx.fromAccnts(),
                    tx.transactionName(),
                    tx.transactionDescription(),
                    tx.transactionType(),
                    tx.transactionAmnt(),
                    tx.senderAccnt(),
                    tx.wireRecipient()
            );
            String json = objectMapper.writeValueAsString(txUpdated);
            return jdbcClient.sql(updateSql)
                    .param("transactionIdentifier", transactionIdentifier)
                    .param("transactionData", json)
                    .update();
        } catch (Exception e) {
            log.error("Error updating transaction {}: {}", transactionIdentifier, e.getMessage(), e);
            throw new RuntimeException("Failed to update transaction", e);
        }
    }
}
