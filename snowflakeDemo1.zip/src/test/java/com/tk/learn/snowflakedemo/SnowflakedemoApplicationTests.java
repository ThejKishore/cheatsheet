package com.tk.learn.snowflakedemo;

import com.tk.learn.snowflakedemo.transactions.model.TranLandingPage;
import com.tk.learn.snowflakedemo.transactions.model.TranLandingPageResponse;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class SnowflakedemoApplicationTests {

    @Test
    void builderWorksForRecords() {
        try {
            System.out.println("[DEBUG_LOG] Starting builderWorksForRecords test");
            TranLandingPage page = TranLandingPage.builder()
                    .transactionIdentifier(123)
                    .transactionName("Test Txn")
                    .transactionAmount(new BigDecimal("10.50"))
                    .build();
            System.out.println("[DEBUG_LOG] Built TranLandingPage: id=" + page.transactionIdentifier() + ", name=" + page.transactionName());
            assertNotNull(page);
            assertEquals(123, page.transactionIdentifier());
            assertEquals("Test Txn", page.transactionName());

            TranLandingPageResponse response = TranLandingPageResponse.builder()
                    .transactions(List.of(page))
                    .build();
            System.out.println("[DEBUG_LOG] Built TranLandingPageResponse, size=" + (response.transactions() == null ? -1 : response.transactions().size()));
            assertNotNull(response);
            assertEquals(1, response.transactions().size());
        } catch (Throwable t) {
            System.out.println("[DEBUG_LOG] Test failed with exception: " + t);
            for (StackTraceElement ste : t.getStackTrace()) {
                System.out.println("[DEBUG_LOG] at " + ste);
            }
            throw t;
        }
    }
}
