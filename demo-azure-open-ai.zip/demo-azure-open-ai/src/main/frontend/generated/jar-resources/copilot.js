import { at as t, as as a } from "./copilot/copilot-D2iWengO.js";
export {
  t as _createChildrenDefinitions,
  a as _registerImporter
};
