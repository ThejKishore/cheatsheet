export { _registerImporter, _createChildrenDefinitions } from './copilot/figma-public/figma-api';
export type { FigmaNode, ImportMetadata } from './copilot/figma-public/figma-api';
export type { ComponentDefinition, ComponentDefinitionProperties } from './copilot/shared/flow-utils';
