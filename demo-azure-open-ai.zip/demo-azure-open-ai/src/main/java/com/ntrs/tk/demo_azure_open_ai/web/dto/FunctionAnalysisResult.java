package com.ntrs.tk.demo_azure_open_ai.web.dto;

public class FunctionAnalysisResult {
    private String name;
    private String type;
    private String aiResponse;

    public FunctionAnalysisResult() {}

    public FunctionAnalysisResult(String name, String type, String aiResponse) {
        this.name = name;
        this.type = type;
        this.aiResponse = aiResponse;
    }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getAiResponse() { return aiResponse; }
    public void setAiResponse(String aiResponse) { this.aiResponse = aiResponse; }
}
