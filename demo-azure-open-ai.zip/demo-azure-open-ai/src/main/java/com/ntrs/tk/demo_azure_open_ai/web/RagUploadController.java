package com.ntrs.tk.demo_azure_open_ai.web;

import com.ntrs.tk.demo_azure_open_ai.service.PlsqlPdfService;
import org.springframework.ai.document.Document;
import org.springframework.ai.reader.tika.TikaDocumentReader;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.*;

@RestController
@RequestMapping
public class RagUploadController {

    private final PlsqlPdfService plsqlPdfService;
    private final VectorStore vectorStore;

    public RagUploadController(PlsqlPdfService plsqlPdfService, VectorStore vectorStore) {
        this.plsqlPdfService = plsqlPdfService;
        this.vectorStore = vectorStore;
    }

    @PostMapping(path = "/rag-upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> upload(@RequestParam("file") MultipartFile file) {
        if (file == null || file.isEmpty()) {
            return ResponseEntity.badRequest().body(Map.of("error", "No file provided"));
        }
        String fileName = file.getOriginalFilename();
        String contentType = file.getContentType();
        try {
            int count = ingest(fileName, contentType, file);
            return ResponseEntity.ok(Map.of(
                    "filename", fileName,
                    "contentType", contentType,
                    "count", count
            ));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    private int ingest(String fileName, String contentType, MultipartFile multipartFile) throws IOException {
        String lower = (fileName != null ? fileName.toLowerCase() : "");
        boolean isPdf = lower.endsWith(".pdf") || (contentType != null && contentType.contains("pdf"));
        boolean isMd = lower.endsWith(".md") || lower.endsWith(".markdown") || (contentType != null && contentType.contains("markdown"));

        Path tmp = null;
        try {
            String ext = ".bin";
            if (StringUtils.hasText(fileName) && fileName.lastIndexOf('.') > -1) {
                ext = fileName.substring(fileName.lastIndexOf('.'));
            }
            tmp = Files.createTempFile("upload-", ext);
            multipartFile.transferTo(tmp);

            if (isPdf) {
                plsqlPdfService.readFunctionsAsDocuments(tmp);
            }

            TikaDocumentReader reader = new TikaDocumentReader(tmp.toString());
            List<Document> docs = new ArrayList<>();
            for (Document d : reader.get()) {
                Map<String, Object> meta = new HashMap<>(d.getMetadata());
                meta.put("source", fileName != null ? fileName : tmp.toString());
                meta.put("uploaded_at", LocalDateTime.now().toString());
                meta.put("type", isMd ? "markdown" : "text");
                docs.add(new Document(d.getText(), meta));
            }
            vectorStore.add(docs);
            return docs.size();
        } finally {
            if (tmp != null) {
                try { Files.deleteIfExists(tmp); } catch (Exception ignore) {}
            }
        }
    }
}
