package com.ntrs.tk.demo_azure_open_ai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoAzureOpenAiApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoAzureOpenAiApplication.class, args);
	}

}
