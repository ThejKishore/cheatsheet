package com.ntrs.tk.demo_azure_open_ai.web;

import com.ntrs.tk.demo_azure_open_ai.service.AnalysisService;
import com.vaadin.flow.component.Key;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.checkbox.Checkbox;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.orderedlayout.FlexComponent;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextArea;
import com.vaadin.flow.router.PageTitle;

@PageTitle("ChatGPT")
public class ChatGptView extends VerticalLayout {

    private final AnalysisService analysisService;

    private final VerticalLayout messages = new VerticalLayout();
    private final TextArea input = new TextArea();
    private final Checkbox addContext = new Checkbox("Add context");
    private final Button send = new Button("Send");

    public ChatGptView(AnalysisService analysisService) {
        this.analysisService = analysisService;

        setSizeFull();
        setPadding(true);
        setSpacing(true);

        messages.setSizeFull();
        messages.getStyle().set("border", "1px solid var(--lumo-contrast-10pct)");
        messages.getStyle().set("border-radius", "var(--lumo-border-radius-m)");
        messages.getStyle().set("padding", "var(--lumo-space-m)");
        messages.getStyle().set("overflow", "auto");

        input.setWidthFull();
        input.setMinHeight("120px");
        input.setMaxHeight("240px");
        input.setPlaceholder("Ask anything...");

        addContext.getStyle().set("margin-right", "auto");

        send.addClickListener(e -> handleSend());
        send.addClickShortcut(Key.ENTER);

        HorizontalLayout composer = new HorizontalLayout(input, addContext, send);
        composer.setWidthFull();
        composer.setDefaultVerticalComponentAlignment(FlexComponent.Alignment.END);
        composer.expand(input);

        add(messages, composer);
        expand(messages);
    }

    private void handleSend() {
        String prompt = input.getValue();
        if (prompt == null || prompt.isBlank()) return;
        appendMessage(prompt, true);
        input.clear();
        send.setEnabled(false);
        try {
            boolean useCtx = Boolean.TRUE.equals(addContext.getValue());
            String response = analysisService.chat(prompt, useCtx);
            appendMessage(response != null ? response : "(no response)", false);
        } catch (Exception ex) {
            appendMessage("Error: " + ex.getMessage(), false);
        } finally {
            send.setEnabled(true);
        }
    }

    private void appendMessage(String text, boolean user) {
        Div bubble = new Div();
        bubble.getStyle().set("padding", "var(--lumo-space-m)");
        bubble.getStyle().set("border-radius", "var(--lumo-border-radius-m)");
        bubble.getStyle().set("max-width", "70%");
        bubble.getStyle().set("white-space", "pre-wrap");
        bubble.add(new Span(text));

        HorizontalLayout row = new HorizontalLayout(bubble);
        row.setWidthFull();
        if (user) {
            bubble.getStyle().set("background-color", "var(--lumo-primary-color-10pct)");
            row.setJustifyContentMode(JustifyContentMode.END);
        } else {
            bubble.getStyle().set("background-color", "var(--lumo-contrast-10pct)");
            row.setJustifyContentMode(JustifyContentMode.START);
        }
        messages.add(row);
        messages.getElement().executeJs("this.scrollTop = this.scrollHeight");
    }
}
