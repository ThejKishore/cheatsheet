package com.ntrs.tk.demo_azure_open_ai.service;

import com.ntrs.tk.demo_azure_open_ai.web.dto.FunctionAnalysisResult;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.document.Document;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AnalysisService {

    private final ChatClient chatClient;
    private final VectorStore vectorStore;
    private final Environment env;

    public AnalysisService(ChatModel chatModel, VectorStore vectorStore, Environment env) {
        this.chatClient = ChatClient.create(chatModel);
        this.vectorStore = vectorStore;
        this.env = env;
    }

    public String chat(String prompt) {
        return chat(prompt, false);
    }

    public String chat(String prompt, boolean useContext) {
        if (prompt == null || prompt.isBlank()) return "";
        if (!useContext) {
            return chatClient.prompt()
                    .system("You are a helpful assistant. Answer concisely and clearly.")
                    .user(prompt)
                    .call()
                    .content();
        }

        // Retrieve relevant documents from pgvector and include as context
        List<Document> hits = vectorStore.similaritySearch(prompt);

        String context = hits == null || hits.isEmpty() ? "" : hits.stream()
                .map(d -> {
                    String src = String.valueOf(d.getMetadata().getOrDefault("source", "unknown"));
                    String name = String.valueOf(d.getMetadata().getOrDefault("function_name", ""));
                    String type = String.valueOf(d.getMetadata().getOrDefault("type", ""));
                    String header = (name != null && !name.isBlank()) ? ("[" + type + "] " + name + " (source: " + src + ")\n") : ("(source: " + src + ")\n");
                    // Keep each chunk reasonably sized
                    String body = d.getText();
                    if (body != null && body.length() > 2000) {
                        body = body.substring(0, 2000) + "...";
                    }
                    return header + body;
                })
                .collect(Collectors.joining("\n\n---\n\n"));

        String system = "You are a helpful assistant. Use the provided context to answer the user's question. " +
                "If the answer is not present in the context, say you don't know. Prefer quoting exact passages when helpful.";

        return chatClient.prompt()
                .system(system)
                .user("Context:\n" + (context.isBlank() ? "(no additional context found)" : context))
                .user("Question:\n" + prompt)
                .call()
                .content();
    }

    public List<FunctionAnalysisResult> analyzeFunctions(List<Document> functionDocs) {
        List<FunctionAnalysisResult> results = new ArrayList<>();
        if (functionDocs == null) return results;
        for (Document d : functionDocs) {
            String functionName = String.valueOf(d.getMetadata().getOrDefault("function_name", "unknown"));
            String type = String.valueOf(d.getMetadata().getOrDefault("type", "plsql"));
            String body = d.getText();

            String system = "You are an expert data engineer skilled in PL/SQL and Snowflake SQL. " +
                    "Given a PL/SQL function or procedure, produce:\n" +
                    "1) Concise documentation: purpose, parameters, return value, exceptions, dependencies, and side effects.\n" +
                    "2) An equivalent Snowflake SQL/procedural implementation. If not fully convertible, explain limitations and provide closest alternative.";

            String user = "PL/SQL " + type + " name: " + functionName + "\n\n" +
                    "Code:\n" +
                    "" + body + "\n\n" +
                    "Respond in JSON with fields: documentation (markdown), snowflakeQuery (code block).";

            String response = chatClient.prompt()
                    .system(system)
                    .user(user)
                    .call()
                    .content();

            results.add(new FunctionAnalysisResult(functionName, type, response));
        }
        return results;
    }

}
