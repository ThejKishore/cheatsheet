package com.ntrs.tk.demo_azure_open_ai.service;

import com.ntrs.tk.demo_azure_open_ai.util.PlsqlFunctionExtractor;
import org.springframework.ai.document.Document;
import org.springframework.ai.reader.tika.TikaDocumentReader;
import org.springframework.ai.transformer.splitter.TokenTextSplitter;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.core.io.FileSystemResource;
import org.springframework.stereotype.Service;

import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class PlsqlPdfService {

    private final VectorStore vectorStore;
    private final PlsqlFunctionExtractor extractor = new PlsqlFunctionExtractor();
    private final org.springframework.core.env.Environment env;

    public PlsqlPdfService(VectorStore vectorStore, org.springframework.core.env.Environment env) {
        this.vectorStore = vectorStore;
        this.env = env;
    }

    public void readFunctionsAsDocuments(Path pdfPath) {
        ensureEmbeddingConfigured();
        TikaDocumentReader reader = new TikaDocumentReader(new FileSystemResource(pdfPath));
        TokenTextSplitter textSplitter = new TokenTextSplitter();
        try {
            vectorStore.accept(textSplitter.apply(reader.get()));
        } catch (RuntimeException e) {
            throw wrapIfDeploymentNotFound(e);
        }
    }

    public void ingestToVectorStore(List<Document> docs) {
        if (docs == null || docs.isEmpty()) return;
        ensureEmbeddingConfigured();
        List<Document> chunks = new ArrayList<>();
        for (Document d : docs) {
            chunks.addAll(splitIntoChunks(d));
        }
        try {
            vectorStore.add(chunks);
        } catch (RuntimeException e) {
            throw wrapIfDeploymentNotFound(e);
        }
    }

    private static final int MAX_CHARS_PER_CHUNK = 8000;
    private static final int CHUNK_OVERLAP = 200;

    private void ensureEmbeddingConfigured() {
        String dep = env.getProperty("spring.ai.azure.openai.embedding.options.deployment-name");
        if (dep == null || dep.isBlank()) {
            String msg = "Azure OpenAI Embeddings deployment is not configured. " +
                    "Set environment variable AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT to your Azure deployment name " +
                    "or set spring.ai.azure.openai.embedding.options.deployment-name in application.properties.";
            throw new IllegalStateException(msg);
        }
        // Fail fast if it looks like a model name instead of an Azure deployment name
        String depLower = dep.trim().toLowerCase();
        // Common mistakes: using model names like 'text-embedding-3-large' or shorthand 'embed-3-large'
        if (depLower.equals("embed-3-large") || depLower.equals("text-embedding-3-large") || depLower.startsWith("text-embedding-") || depLower.startsWith("embed-")) {
            String guidance = "It looks like you configured the embeddings deployment as '" + dep + "', which appears to be a model name. " +
                    "In Azure OpenAI you must create a Deployment and use its deployment name (the custom name you chose), not the model name.\n" +
                    "Fix: In Azure Portal > Azure OpenAI Resource > Deployments: create (or find) a deployment for the desired model, then set:\n" +
                    "  AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT=<your-deployment-name>\n" +
                    "or spring.ai.azure.openai.embedding.options.deployment-name=<your-deployment-name>.";
            throw new IllegalStateException(guidance);
        }
    }

    private RuntimeException wrapIfDeploymentNotFound(RuntimeException e) {
        Throwable t = e;
        while (t != null) {
            String m = t.getMessage();
            if (m != null && m.contains("DeploymentNotFound")) {
                String dep = env.getProperty("spring.ai.azure.openai.embedding.options.deployment-name", "<unset>");
                String enhanced = "Azure OpenAI returned DeploymentNotFound for embeddings deployment '" + dep + "'. " +
                        "Ensure the Azure deployment exists and matches exactly. If created recently, wait a few minutes and retry.\n" +
                        "Tip: Do not use the model name here (e.g., 'embed-3-large' or 'text-embedding-3-large'). Use your Azure deployment name.\n" +
                        "Set AZURE_OPENAI_EMBEDDINGS_DEPLOYMENT=<your-deployment-name> or configure spring.ai.azure.openai.embedding.options.deployment-name accordingly.";
                return new IllegalStateException(enhanced, e);
            }
            t = t.getCause();
        }
        return e;
    }

    private List<Document> splitIntoChunks(Document original) {
        String text = original.getText();
        List<Document> parts = new ArrayList<>();
        if (text == null) {
            parts.add(original);
            return parts;
        }
        int n = text.length();
        if (n <= MAX_CHARS_PER_CHUNK) {
            parts.add(original);
            return parts;
        }
        int start = 0;
        List<int[]> ranges = new ArrayList<>();
        while (start < n) {
            int end = Math.min(n, start + MAX_CHARS_PER_CHUNK);
            ranges.add(new int[]{start, end});
            if (end >= n) break;
            start = Math.max(end - CHUNK_OVERLAP, 0);
        }
        int total = ranges.size();
        for (int i = 0; i < total; i++) {
            int[] r = ranges.get(i);
            String chunkText = text.substring(r[0], r[1]);
            Map<String, Object> meta = new HashMap<>(original.getMetadata());
            meta.put("chunk_index", i);
            meta.put("chunk_total", total);
            parts.add(new Document(chunkText, meta));
        }
        return parts;
    }
}
