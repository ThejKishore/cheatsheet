package com.ntrs.tk.demo_azure_open_ai.web;

import com.ntrs.tk.demo_azure_open_ai.service.AnalysisService;
import com.ntrs.tk.demo_azure_open_ai.service.PlsqlPdfService;
import com.vaadin.flow.component.Component;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.tabs.Tab;
import com.vaadin.flow.component.tabs.Tabs;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.HashMap;
import java.util.Map;

@PageTitle("Master View")
@Route("")
public class MasterView extends VerticalLayout {

    private final Tabs tabs = new Tabs();
    private final Map<Tab, Component> contents = new HashMap<>();

    @Autowired
    public MasterView(PlsqlPdfService plsqlPdfService, VectorStore vectorStore, AnalysisService analysisService) {
        setSizeFull();
        setPadding(true);
        setSpacing(false);

        H2 title = new H2("AI Toolkit");

        UploadView uploadView = new UploadView(plsqlPdfService, vectorStore);
        uploadView.setSizeFull();

        ChatGptView chatGptView = new ChatGptView(analysisService);
        chatGptView.setSizeFull();

        Tab uploadTab = new Tab("Upload");
        Tab chatTab = new Tab("ChatGPT");

        tabs.add(uploadTab, chatTab);
        tabs.setWidthFull();

        contents.put(uploadTab, uploadView);
        contents.put(chatTab, chatGptView);

        // initial selection
        tabs.setSelectedTab(uploadTab);
        setContentVisible(uploadTab);

        tabs.addSelectedChangeListener(e -> setContentVisible(e.getSelectedTab()));

        add(title, tabs, uploadView, chatGptView);
        setFlexGrow(1, uploadView, chatGptView);
    }

    private void setContentVisible(Tab active) {
        contents.forEach((tab, comp) -> comp.setVisible(tab.equals(active)));
    }
}
