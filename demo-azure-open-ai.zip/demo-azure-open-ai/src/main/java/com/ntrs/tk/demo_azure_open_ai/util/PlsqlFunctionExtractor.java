package com.ntrs.tk.demo_azure_open_ai.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Utility to extract PL/SQL functions and procedures from text.
 * It uses simple regex heuristics to find CREATE [OR REPLACE] FUNCTION/PROCEDURE blocks.
 */
public class PlsqlFunctionExtractor {

    private static final Pattern CREATE_BLOCK = Pattern.compile(
            "(?is)\\bcreate\\s+(or\\s+replace\\s+)?(function|procedure)\\s+([a-zA-Z0-9_\"]+)\\s*[\\s\\S]*?\\bend\\s*;",
            Pattern.CASE_INSENSITIVE | Pattern.DOTALL);

    public List<PlsqlItem> extract(String text) {
        List<PlsqlItem> items = new ArrayList<>();
        if (text == null || text.isBlank()) {
            return items;
        }
        Matcher m = CREATE_BLOCK.matcher(text);
        while (m.find()) {
            String type = m.group(2);
            String name = cleanupName(m.group(3));
            String body = m.group(0); // entire matched block including END;
            items.add(new PlsqlItem(name, type == null ? "function" : type.toLowerCase(Locale.ROOT), body));
        }
        // If nothing matched, consider the whole text one item (fallback)
        if (items.isEmpty()) {
            items.add(new PlsqlItem("unknown_block", "plsql", text));
        }
        return items;
    }

    private String cleanupName(String raw) {
        if (raw == null) return "";
        String s = raw.trim();
        if (s.startsWith("\"") && s.endsWith("\"")) {
            s = s.substring(1, s.length() - 1);
        }
        return s;
    }

    public record PlsqlItem(String name, String type, String body) {}
}
