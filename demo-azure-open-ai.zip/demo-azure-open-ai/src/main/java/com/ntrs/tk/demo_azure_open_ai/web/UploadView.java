package com.ntrs.tk.demo_azure_open_ai.web;

import com.ntrs.tk.demo_azure_open_ai.service.PlsqlPdfService;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.upload.Upload;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import org.springframework.ai.document.Document;
import org.springframework.ai.reader.tika.TikaDocumentReader;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.FileSystemResource;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@PageTitle("AI RAG Uploader")
@Route("upload")
public class UploadView extends VerticalLayout {

    private static final int MAX_CHARS_PER_CHUNK = 8000; // conservative safe size
    private static final int CHUNK_OVERLAP = 200;

    private final PlsqlPdfService plsqlPdfService;
    private final VectorStore vectorStore;

    private final Paragraph status = new Paragraph("Upload a PDF or Markdown file to ingest into the vector store.");

    private transient Path currentTempFile;

    @Autowired
    public UploadView(PlsqlPdfService plsqlPdfService, VectorStore vectorStore) {
        this.plsqlPdfService = plsqlPdfService;
        this.vectorStore = vectorStore;

        setSizeFull();
        setPadding(true);
        setSpacing(true);

        add(new H2("RAG File Uploader"));

        Upload upload = new Upload();
        upload.setAcceptedFileTypes(".pdf", ".md", ".markdown", "text/markdown", "application/pdf");
        upload.setMaxFiles(1);
        upload.setDropLabel(new Paragraph("Drop a .pdf or .md/.markdown file here"));
        upload.setMaxFileSize(50 * 1024 * 1024); // 50MB safety limit
        upload.setAutoUpload(true);

        // Use Vaadin's streaming UploadHandler instead of FileBuffer
        upload.setUploadHandler(event -> {
            String fileName = event.getFileName();
            String mimeType = null; // MIME type not provided by UploadEvent API; infer from filename later
            try (InputStream is = event.getInputStream()) {
                int count = handleIngestion(fileName, mimeType, is);
                getUI().ifPresent(ui -> ui.access(() -> {
                    Notification n = Notification.show("Upload finished (" + count + " docs): " + fileName);
                    n.setDuration(4000);
                    n.addThemeVariants(NotificationVariant.LUMO_SUCCESS);
                    status.setText("Last upload finished at " + LocalDateTime.now() + " for file: " + fileName);
                }));
            } catch (Exception e) {
                getUI().ifPresent(ui -> ui.access(() -> {
                    Notification n = Notification.show("Processing failed: " + e.getMessage());
                    n.setDuration(8000);
                    n.addThemeVariants(NotificationVariant.LUMO_ERROR);
                }));
                // Do not rethrow to avoid breaking the Vaadin upload flow; error already shown to user.
            }
        });

        upload.addFileRejectedListener(event -> {
            Notification n = Notification.show("File rejected: " + event.getErrorMessage());
            n.setDuration(5000);
            n.addThemeVariants(NotificationVariant.LUMO_ERROR);
        });


        Button clearBtn = new Button("Clear", e -> status.setText("Upload a PDF or Markdown file to ingest into the vector store."));
        HorizontalLayout controls = new HorizontalLayout(clearBtn);

        add(upload, controls, status);
    }

    private int handleIngestion(String fileName, String contentType, InputStream is) throws IOException {
        String lower = (fileName != null ? fileName.toLowerCase() : "");
        boolean isPdf = lower.endsWith(".pdf") || (contentType != null && contentType.contains("pdf"));
        boolean isMd = lower.endsWith(".md") || lower.endsWith(".markdown") || (contentType != null && contentType.contains("markdown"));

        if (isPdf) {
            // Write to a temporary file so existing PDF pipeline can be reused
            Path tmp = Files.createTempFile("upload-", ".pdf");
            Files.copy(is, tmp, java.nio.file.StandardCopyOption.REPLACE_EXISTING);
             plsqlPdfService.readFunctionsAsDocuments(tmp);
//            plsqlPdfService.ingestToVectorStore(docs);
            try { Files.deleteIfExists(tmp); } catch (Exception ignored) {}
            return 1;
        }

        // Fallback for Markdown (and other text-like content): use Tika to extract text into one or more Documents
        // If it's not strictly markdown, Tika will still read the text reasonably well.
        Path tmp = Files.createTempFile("upload-", StringUtils.getFilenameExtension(fileName) != null ? ("." + StringUtils.getFilenameExtension(fileName)) : ".txt");
        Files.copy(is, tmp, java.nio.file.StandardCopyOption.REPLACE_EXISTING);

        TikaDocumentReader reader = new TikaDocumentReader(new FileSystemResource(tmp));
        List<Document> docs = new ArrayList<>();
        for (Document d : reader.get()) {
            Map<String, Object> meta = new HashMap<>(d.getMetadata());
            meta.put("source", fileName != null ? fileName : tmp.toString());
            meta.put("uploaded_at", LocalDateTime.now().toString());
            meta.put("type", isMd ? "markdown" : "text");
            // Split into safe chunks to avoid exceeding model input token limits
            docs.addAll(splitIntoChunks(new Document(d.getText(), meta)));
        }
        // Centralize ingestion and configuration checks in service
        plsqlPdfService.ingestToVectorStore(docs);
        try { Files.deleteIfExists(tmp); } catch (Exception ignored) {}
        return docs.size();
    }
    private List<Document> splitIntoChunks(Document original) {
        String text = original.getText();
        Map<String, Object> baseMeta = new HashMap<>(original.getMetadata());
        List<Document> parts = new ArrayList<>();
        if (text == null) {
            parts.add(original);
            return parts;
        }
        int n = text.length();
        if (n <= MAX_CHARS_PER_CHUNK) {
            parts.add(original);
            return parts;
        }
        int start = 0;
        int chunkIndex = 0;
        List<int[]> ranges = new ArrayList<>();
        while (start < n) {
            int end = Math.min(n, start + MAX_CHARS_PER_CHUNK);
            ranges.add(new int[]{start, end});
            if (end >= n) break;
            start = Math.max(end - CHUNK_OVERLAP, 0);
            chunkIndex++;
        }
        int total = ranges.size();
        for (int i = 0; i < total; i++) {
            int[] r = ranges.get(i);
            String chunkText = text.substring(r[0], r[1]);
            Map<String, Object> meta = new HashMap<>(baseMeta);
            meta.put("chunk_index", i);
            meta.put("chunk_total", total);
            parts.add(new Document(chunkText, meta));
        }
        return parts;
    }
}
