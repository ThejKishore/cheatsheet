package com.ntrs.tk.demo_azure_open_ai;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoAzureOpenAiApplicationTests {

	@Test
	void contextLoads() {
	}

}
