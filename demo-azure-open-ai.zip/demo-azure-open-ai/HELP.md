# Read Me First
The following was discovered as part of building this project:

* The original package name 'com.ntrs.tk.demo-azure-open-ai' is invalid and this project uses 'com.ntrs.tk.demo_azure_open_ai' instead.

# Getting Started

### Reference Documentation
For further reference, please consider the following sections:

* [Official Gradle documentation](https://docs.gradle.org)
* [Spring Boot Gradle Plugin Reference Guide](https://docs.spring.io/spring-boot/3.5.4/gradle-plugin)
* [Create an OCI image](https://docs.spring.io/spring-boot/3.5.4/gradle-plugin/packaging-oci-image.html)
* [Tika Document Reader](https://docs.spring.io/spring-ai/reference/api/etl-pipeline.html#_tika_docx_pptx_html)
* [Markdown Document Reader](https://docs.spring.io/spring-ai/reference/api/etl-pipeline.html#_markdown)
* [PGvector Vector Database](https://docs.spring.io/spring-ai/reference/api/vectordbs/pgvector.html)
* [Azure OpenAI](https://docs.spring.io/spring-ai/reference/api/chat/azure-openai-chat.html)
* [Docker Compose Support](https://docs.spring.io/spring-boot/3.5.4/reference/features/dev-services.html#features.dev-services.docker-compose)
* [Vaadin](https://vaadin.com/docs)

### Guides
The following guides illustrate how to use some features concretely:

* [Creating CRUD UI with Vaadin](https://spring.io/guides/gs/crud-with-vaadin/)

### Additional Links
These additional references should also help you:

* [Gradle Build Scans – insights for your project's build](https://scans.gradle.com#gradle)

### Docker Compose support
This project contains a Docker Compose file named `compose.yaml`.
In this file, the following services have been defined:

* pgvector: [`pgvector/pgvector:pg16`](https://hub.docker.com/r/pgvector/pgvector)

Please review the tags of the used images and set them to the same as you're running in production.

### Ingest PL/SQL from PDF and Analyze with Azure OpenAI
1. Start pgvector via Docker Compose or provide your own Postgres with pgvector extension.
   - Using Spring Boot Dev Services: `./gradlew bootRun` will auto-start compose service if available.
2. Configure Azure OpenAI properties (environment variables or application.properties):
   - spring.ai.azure.openai.endpoint
   - spring.ai.azure.openai.api-key
   - spring.ai.azure.openai.chat.options.deployment-name
   - spring.ai.azure.openai.embedding.options.deployment-name
3. Run the application and call the endpoint:
   - POST http://localhost:8080/ingest-and-analyze?pdfPath=/absolute/path/to/your.pdf
4. The endpoint will:
   - Read the PDF using Tika
   - Extract PL/SQL functions/procedures
   - Store embeddings in pgvector via Spring AI VectorStore
   - Call Azure OpenAI to produce documentation and Snowflake alternatives
5. Response is JSON with a results array for each function.

