package com.tk.learn;

import com.tk.learn.pdf.PdfGenerator;
import com.tk.learn.person.Person;

import java.util.*;

public class Main {
    public static void main(String[] args) {
        List<Person> people = Arrays.asList(
                new Person("Alice", 30, "alice@example.com"),
                new Person("Bob", 25, "bob@example.com"),
                new Person("Charlie", 35, "charlie@example.com")
        );

        try {
            List<Map.Entry<String, String>> data = people.stream()
                    .map(Main::getPersonData)
                    .map(Map::entrySet)
                    .flatMap(Set::stream)
                    .map(Main::introduceLineBreakInValueWithAtSpecialChar)
                    .toList();
            PdfGenerator.generateReport(data, "people_report.pdf");
            System.out.println("PDF report created successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private static Map<String,String> getPersonData(Person person){
        Map<String,String> data = new HashMap<>();
        data.put("name",person.getName());
        data.put("age",String.valueOf(person.getAge()));
        data.put("email",person.getEmail());
        return data;
    }
    
    private static Map.Entry<String, String> introduceLineBreakInValueWithAtSpecialChar(Map.Entry<String, String> e) {
        return Map.entry(e.getKey(), e.getValue().replaceAll("@", "@\n"));
    }
}