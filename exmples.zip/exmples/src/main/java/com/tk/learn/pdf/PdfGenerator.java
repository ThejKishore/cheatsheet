package com.tk.learn.pdf;

import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.vandeseer.easytable.TableDrawer;
import org.vandeseer.easytable.structure.Row;
import org.vandeseer.easytable.structure.Table;
import org.vandeseer.easytable.structure.cell.TextCell;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

import static org.apache.pdfbox.pdmodel.font.Standard14Fonts.FontName.HELVETICA;
import static org.apache.pdfbox.pdmodel.font.Standard14Fonts.FontName.HELVETICA_BOLD;
import static org.vandeseer.easytable.settings.HorizontalAlignment.*;

public class PdfGenerator {
    private PdfGenerator(){}

    public static void generateReport(List<Map.Entry<String, String>> data, String filePath) throws IOException {
        if (data == null || data.isEmpty()) {
            throw new IllegalArgumentException("Data list cannot be null or empty");
        }

        PDDocument document = new PDDocument();
        PDPage page = new PDPage(PDRectangle.A4);
        document.addPage(page);

        float startY = page.getMediaBox().getHeight() - 50;
        float margin = 50;

        Table.TableBuilder tableBuilder = Table.builder()
                .addColumnsOfWidth(150, 300)
                .fontSize(11)
                .padding(2f)
                .borderColor(Color.WHITE);  // White border to visually remove it


        data.forEach(entry -> {
            String key = entry.getKey();
            String value = entry.getValue();
            Row.RowBuilder rowBuilder = Row.builder()
                    .add(TextCell.builder()
                            .text(key)
                            .font(HELVETICA_BOLD)
                            .borderWidth(2)
                            .paddingBottom(15)
                            .horizontalAlignment(LEFT)
                            .build())
                    .add(TextCell.builder()
                            .text(value == null ? "" : value)
                            .font(HELVETICA)
                            .borderWidth(2)
                            .paddingBottom(35)
                            .horizontalAlignment(CENTER)
                            .build());

            tableBuilder.addRow(rowBuilder.build());
        });
        Table table = tableBuilder.build();
        try (PDPageContentStream contentStream = new PDPageContentStream(document, page)) {
            TableDrawer drawer = TableDrawer.builder()
                    .contentStream(contentStream)
                    .startX(margin)
                    .startY(startY)
                    .table(table)
                    .build();
            drawer.draw();
        }
        document.save(new File(filePath));
        document.close();
    }
}
