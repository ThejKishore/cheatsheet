package com.learn.jpa.service;

import com.learn.jpa.domain.TransactionReview;
import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing {@link com.learn.jpa.domain.TransactionReview}.
 */
public interface TransactionReviewService {
    /**
     * Save a transactionReview.
     *
     * @param transactionReview the entity to save.
     * @return the persisted entity.
     */
    TransactionReview save(TransactionReview transactionReview);

    /**
     * Updates a transactionReview.
     *
     * @param transactionReview the entity to update.
     * @return the persisted entity.
     */
    TransactionReview update(TransactionReview transactionReview);

    /**
     * Partially updates a transactionReview.
     *
     * @param transactionReview the entity to update partially.
     * @return the persisted entity.
     */
    Optional<TransactionReview> partialUpdate(TransactionReview transactionReview);

    /**
     * Get all the transactionReviews.
     *
     * @return the list of entities.
     */
    List<TransactionReview> findAll();

    /**
     * Get all the TransactionReview where Transaction is {@code null}.
     *
     * @return the {@link List} of entities.
     */
    List<TransactionReview> findAllWhereTransactionIsNull();

    /**
     * Get the "id" transactionReview.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<TransactionReview> findOne(Long id);

    /**
     * Delete the "id" transactionReview.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
