package com.learn.jpa.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.time.ZonedDateTime;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * A TransactionReview.
 */
@Entity
@Table(name = "transaction_review")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@SuppressWarnings("common-java:DuplicatedBlocks")
public class TransactionReview implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "id")
    private Long id;

    @NotNull
    @Column(name = "tran_id", nullable = false, unique = true)
    private Long tranId;

    @Column(name = "first_pledge_reviewer_accept")
    private String firstPledgeReviewerAccept;

    @Column(name = "first_pledge_reviewed_accept_date")
    private ZonedDateTime firstPledgeReviewedAcceptDate;

    @Column(name = "first_pledge_reviewer_reject")
    private String firstPledgeReviewerReject;

    @Column(name = "first_pledge_reviewer_reject_reason")
    private String firstPledgeReviewerRejectReason;

    @Column(name = "first_pledge_reviewed_rejected_date")
    private ZonedDateTime firstPledgeReviewedRejectedDate;

    @Column(name = "second_pledge_reviewer_accept")
    private String secondPledgeReviewerAccept;

    @Column(name = "second_pledge_reviewed_accept_date")
    private ZonedDateTime secondPledgeReviewedAcceptDate;

    @Column(name = "second_pledge_reviewer_reject")
    private String secondPledgeReviewerReject;

    @Column(name = "second_pledge_reviewer_reject_reason")
    private String secondPledgeReviewerRejectReason;

    @Column(name = "second_pledge_reviewed_rejected_date")
    private ZonedDateTime secondPledgeReviewedRejectedDate;

    @Column(name = "first_fiducary_reviewer_accept")
    private String firstFiducaryReviewerAccept;

    @Column(name = "first_fiducary_reviewed_accept_date")
    private ZonedDateTime firstFiducaryReviewedAcceptDate;

    @Column(name = "first_fiducary_reviewer_reject")
    private String firstFiducaryReviewerReject;

    @Column(name = "first_fiducary_reviewer_reject_reason")
    private String firstFiducaryReviewerRejectReason;

    @Column(name = "first_fiducary_reviewed_rejected_date")
    private ZonedDateTime firstFiducaryReviewedRejectedDate;

    @Column(name = "second_fiducary_reviewer_accept")
    private String secondFiducaryReviewerAccept;

    @Column(name = "second_p_fiducary_reviewed_accept_date")
    private ZonedDateTime secondPFiducaryReviewedAcceptDate;

    @Column(name = "second_fiducary_reviewer_reject")
    private String secondFiducaryReviewerReject;

    @Column(name = "second_fiducary_reviewer_reject_reason")
    private String secondFiducaryReviewerRejectReason;

    @Column(name = "second_fiducary_reviewed_rejected_date")
    private ZonedDateTime secondFiducaryReviewedRejectedDate;

    @Column(name = "first_over_draft_reviewer_accept")
    private String firstOverDraftReviewerAccept;

    @Column(name = "first_over_draft_reviewed_accept_date")
    private ZonedDateTime firstOverDraftReviewedAcceptDate;

    @Column(name = "first_over_draft_reviewer_reject")
    private String firstOverDraftReviewerReject;

    @Column(name = "first_over_draft_reviewer_reject_reason")
    private String firstOverDraftReviewerRejectReason;

    @Column(name = "first_over_draft_reviewed_rejected_date")
    private ZonedDateTime firstOverDraftReviewedRejectedDate;

    @Column(name = "second_over_draft_reviewer_accept")
    private String secondOverDraftReviewerAccept;

    @Column(name = "second_over_draft_reviewed_accept_date")
    private ZonedDateTime secondOverDraftReviewedAcceptDate;

    @Column(name = "second_over_draft_reviewer_reject")
    private String secondOverDraftReviewerReject;

    @Column(name = "second_over_draft_reviewer_reject_reason")
    private String secondOverDraftReviewerRejectReason;

    @Column(name = "second_over_draft_reviewed_rejected_date")
    private ZonedDateTime secondOverDraftReviewedRejectedDate;

    @JsonIgnoreProperties(value = { "transactionMapping", "transactionApproval", "transactionReview" }, allowSetters = true)
    @OneToOne(fetch = FetchType.LAZY, mappedBy = "transactionReview")
    private Transaction transaction;

    // jhipster-needle-entity-add-field - JHipster will add fields here

    public Long getId() {
        return this.id;
    }

    public TransactionReview id(Long id) {
        this.setId(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getTranId() {
        return this.tranId;
    }

    public TransactionReview tranId(Long tranId) {
        this.setTranId(tranId);
        return this;
    }

    public void setTranId(Long tranId) {
        this.tranId = tranId;
    }

    public String getFirstPledgeReviewerAccept() {
        return this.firstPledgeReviewerAccept;
    }

    public TransactionReview firstPledgeReviewerAccept(String firstPledgeReviewerAccept) {
        this.setFirstPledgeReviewerAccept(firstPledgeReviewerAccept);
        return this;
    }

    public void setFirstPledgeReviewerAccept(String firstPledgeReviewerAccept) {
        this.firstPledgeReviewerAccept = firstPledgeReviewerAccept;
    }

    public ZonedDateTime getFirstPledgeReviewedAcceptDate() {
        return this.firstPledgeReviewedAcceptDate;
    }

    public TransactionReview firstPledgeReviewedAcceptDate(ZonedDateTime firstPledgeReviewedAcceptDate) {
        this.setFirstPledgeReviewedAcceptDate(firstPledgeReviewedAcceptDate);
        return this;
    }

    public void setFirstPledgeReviewedAcceptDate(ZonedDateTime firstPledgeReviewedAcceptDate) {
        this.firstPledgeReviewedAcceptDate = firstPledgeReviewedAcceptDate;
    }

    public String getFirstPledgeReviewerReject() {
        return this.firstPledgeReviewerReject;
    }

    public TransactionReview firstPledgeReviewerReject(String firstPledgeReviewerReject) {
        this.setFirstPledgeReviewerReject(firstPledgeReviewerReject);
        return this;
    }

    public void setFirstPledgeReviewerReject(String firstPledgeReviewerReject) {
        this.firstPledgeReviewerReject = firstPledgeReviewerReject;
    }

    public String getFirstPledgeReviewerRejectReason() {
        return this.firstPledgeReviewerRejectReason;
    }

    public TransactionReview firstPledgeReviewerRejectReason(String firstPledgeReviewerRejectReason) {
        this.setFirstPledgeReviewerRejectReason(firstPledgeReviewerRejectReason);
        return this;
    }

    public void setFirstPledgeReviewerRejectReason(String firstPledgeReviewerRejectReason) {
        this.firstPledgeReviewerRejectReason = firstPledgeReviewerRejectReason;
    }

    public ZonedDateTime getFirstPledgeReviewedRejectedDate() {
        return this.firstPledgeReviewedRejectedDate;
    }

    public TransactionReview firstPledgeReviewedRejectedDate(ZonedDateTime firstPledgeReviewedRejectedDate) {
        this.setFirstPledgeReviewedRejectedDate(firstPledgeReviewedRejectedDate);
        return this;
    }

    public void setFirstPledgeReviewedRejectedDate(ZonedDateTime firstPledgeReviewedRejectedDate) {
        this.firstPledgeReviewedRejectedDate = firstPledgeReviewedRejectedDate;
    }

    public String getSecondPledgeReviewerAccept() {
        return this.secondPledgeReviewerAccept;
    }

    public TransactionReview secondPledgeReviewerAccept(String secondPledgeReviewerAccept) {
        this.setSecondPledgeReviewerAccept(secondPledgeReviewerAccept);
        return this;
    }

    public void setSecondPledgeReviewerAccept(String secondPledgeReviewerAccept) {
        this.secondPledgeReviewerAccept = secondPledgeReviewerAccept;
    }

    public ZonedDateTime getSecondPledgeReviewedAcceptDate() {
        return this.secondPledgeReviewedAcceptDate;
    }

    public TransactionReview secondPledgeReviewedAcceptDate(ZonedDateTime secondPledgeReviewedAcceptDate) {
        this.setSecondPledgeReviewedAcceptDate(secondPledgeReviewedAcceptDate);
        return this;
    }

    public void setSecondPledgeReviewedAcceptDate(ZonedDateTime secondPledgeReviewedAcceptDate) {
        this.secondPledgeReviewedAcceptDate = secondPledgeReviewedAcceptDate;
    }

    public String getSecondPledgeReviewerReject() {
        return this.secondPledgeReviewerReject;
    }

    public TransactionReview secondPledgeReviewerReject(String secondPledgeReviewerReject) {
        this.setSecondPledgeReviewerReject(secondPledgeReviewerReject);
        return this;
    }

    public void setSecondPledgeReviewerReject(String secondPledgeReviewerReject) {
        this.secondPledgeReviewerReject = secondPledgeReviewerReject;
    }

    public String getSecondPledgeReviewerRejectReason() {
        return this.secondPledgeReviewerRejectReason;
    }

    public TransactionReview secondPledgeReviewerRejectReason(String secondPledgeReviewerRejectReason) {
        this.setSecondPledgeReviewerRejectReason(secondPledgeReviewerRejectReason);
        return this;
    }

    public void setSecondPledgeReviewerRejectReason(String secondPledgeReviewerRejectReason) {
        this.secondPledgeReviewerRejectReason = secondPledgeReviewerRejectReason;
    }

    public ZonedDateTime getSecondPledgeReviewedRejectedDate() {
        return this.secondPledgeReviewedRejectedDate;
    }

    public TransactionReview secondPledgeReviewedRejectedDate(ZonedDateTime secondPledgeReviewedRejectedDate) {
        this.setSecondPledgeReviewedRejectedDate(secondPledgeReviewedRejectedDate);
        return this;
    }

    public void setSecondPledgeReviewedRejectedDate(ZonedDateTime secondPledgeReviewedRejectedDate) {
        this.secondPledgeReviewedRejectedDate = secondPledgeReviewedRejectedDate;
    }

    public String getFirstFiducaryReviewerAccept() {
        return this.firstFiducaryReviewerAccept;
    }

    public TransactionReview firstFiducaryReviewerAccept(String firstFiducaryReviewerAccept) {
        this.setFirstFiducaryReviewerAccept(firstFiducaryReviewerAccept);
        return this;
    }

    public void setFirstFiducaryReviewerAccept(String firstFiducaryReviewerAccept) {
        this.firstFiducaryReviewerAccept = firstFiducaryReviewerAccept;
    }

    public ZonedDateTime getFirstFiducaryReviewedAcceptDate() {
        return this.firstFiducaryReviewedAcceptDate;
    }

    public TransactionReview firstFiducaryReviewedAcceptDate(ZonedDateTime firstFiducaryReviewedAcceptDate) {
        this.setFirstFiducaryReviewedAcceptDate(firstFiducaryReviewedAcceptDate);
        return this;
    }

    public void setFirstFiducaryReviewedAcceptDate(ZonedDateTime firstFiducaryReviewedAcceptDate) {
        this.firstFiducaryReviewedAcceptDate = firstFiducaryReviewedAcceptDate;
    }

    public String getFirstFiducaryReviewerReject() {
        return this.firstFiducaryReviewerReject;
    }

    public TransactionReview firstFiducaryReviewerReject(String firstFiducaryReviewerReject) {
        this.setFirstFiducaryReviewerReject(firstFiducaryReviewerReject);
        return this;
    }

    public void setFirstFiducaryReviewerReject(String firstFiducaryReviewerReject) {
        this.firstFiducaryReviewerReject = firstFiducaryReviewerReject;
    }

    public String getFirstFiducaryReviewerRejectReason() {
        return this.firstFiducaryReviewerRejectReason;
    }

    public TransactionReview firstFiducaryReviewerRejectReason(String firstFiducaryReviewerRejectReason) {
        this.setFirstFiducaryReviewerRejectReason(firstFiducaryReviewerRejectReason);
        return this;
    }

    public void setFirstFiducaryReviewerRejectReason(String firstFiducaryReviewerRejectReason) {
        this.firstFiducaryReviewerRejectReason = firstFiducaryReviewerRejectReason;
    }

    public ZonedDateTime getFirstFiducaryReviewedRejectedDate() {
        return this.firstFiducaryReviewedRejectedDate;
    }

    public TransactionReview firstFiducaryReviewedRejectedDate(ZonedDateTime firstFiducaryReviewedRejectedDate) {
        this.setFirstFiducaryReviewedRejectedDate(firstFiducaryReviewedRejectedDate);
        return this;
    }

    public void setFirstFiducaryReviewedRejectedDate(ZonedDateTime firstFiducaryReviewedRejectedDate) {
        this.firstFiducaryReviewedRejectedDate = firstFiducaryReviewedRejectedDate;
    }

    public String getSecondFiducaryReviewerAccept() {
        return this.secondFiducaryReviewerAccept;
    }

    public TransactionReview secondFiducaryReviewerAccept(String secondFiducaryReviewerAccept) {
        this.setSecondFiducaryReviewerAccept(secondFiducaryReviewerAccept);
        return this;
    }

    public void setSecondFiducaryReviewerAccept(String secondFiducaryReviewerAccept) {
        this.secondFiducaryReviewerAccept = secondFiducaryReviewerAccept;
    }

    public ZonedDateTime getSecondPFiducaryReviewedAcceptDate() {
        return this.secondPFiducaryReviewedAcceptDate;
    }

    public TransactionReview secondPFiducaryReviewedAcceptDate(ZonedDateTime secondPFiducaryReviewedAcceptDate) {
        this.setSecondPFiducaryReviewedAcceptDate(secondPFiducaryReviewedAcceptDate);
        return this;
    }

    public void setSecondPFiducaryReviewedAcceptDate(ZonedDateTime secondPFiducaryReviewedAcceptDate) {
        this.secondPFiducaryReviewedAcceptDate = secondPFiducaryReviewedAcceptDate;
    }

    public String getSecondFiducaryReviewerReject() {
        return this.secondFiducaryReviewerReject;
    }

    public TransactionReview secondFiducaryReviewerReject(String secondFiducaryReviewerReject) {
        this.setSecondFiducaryReviewerReject(secondFiducaryReviewerReject);
        return this;
    }

    public void setSecondFiducaryReviewerReject(String secondFiducaryReviewerReject) {
        this.secondFiducaryReviewerReject = secondFiducaryReviewerReject;
    }

    public String getSecondFiducaryReviewerRejectReason() {
        return this.secondFiducaryReviewerRejectReason;
    }

    public TransactionReview secondFiducaryReviewerRejectReason(String secondFiducaryReviewerRejectReason) {
        this.setSecondFiducaryReviewerRejectReason(secondFiducaryReviewerRejectReason);
        return this;
    }

    public void setSecondFiducaryReviewerRejectReason(String secondFiducaryReviewerRejectReason) {
        this.secondFiducaryReviewerRejectReason = secondFiducaryReviewerRejectReason;
    }

    public ZonedDateTime getSecondFiducaryReviewedRejectedDate() {
        return this.secondFiducaryReviewedRejectedDate;
    }

    public TransactionReview secondFiducaryReviewedRejectedDate(ZonedDateTime secondFiducaryReviewedRejectedDate) {
        this.setSecondFiducaryReviewedRejectedDate(secondFiducaryReviewedRejectedDate);
        return this;
    }

    public void setSecondFiducaryReviewedRejectedDate(ZonedDateTime secondFiducaryReviewedRejectedDate) {
        this.secondFiducaryReviewedRejectedDate = secondFiducaryReviewedRejectedDate;
    }

    public String getFirstOverDraftReviewerAccept() {
        return this.firstOverDraftReviewerAccept;
    }

    public TransactionReview firstOverDraftReviewerAccept(String firstOverDraftReviewerAccept) {
        this.setFirstOverDraftReviewerAccept(firstOverDraftReviewerAccept);
        return this;
    }

    public void setFirstOverDraftReviewerAccept(String firstOverDraftReviewerAccept) {
        this.firstOverDraftReviewerAccept = firstOverDraftReviewerAccept;
    }

    public ZonedDateTime getFirstOverDraftReviewedAcceptDate() {
        return this.firstOverDraftReviewedAcceptDate;
    }

    public TransactionReview firstOverDraftReviewedAcceptDate(ZonedDateTime firstOverDraftReviewedAcceptDate) {
        this.setFirstOverDraftReviewedAcceptDate(firstOverDraftReviewedAcceptDate);
        return this;
    }

    public void setFirstOverDraftReviewedAcceptDate(ZonedDateTime firstOverDraftReviewedAcceptDate) {
        this.firstOverDraftReviewedAcceptDate = firstOverDraftReviewedAcceptDate;
    }

    public String getFirstOverDraftReviewerReject() {
        return this.firstOverDraftReviewerReject;
    }

    public TransactionReview firstOverDraftReviewerReject(String firstOverDraftReviewerReject) {
        this.setFirstOverDraftReviewerReject(firstOverDraftReviewerReject);
        return this;
    }

    public void setFirstOverDraftReviewerReject(String firstOverDraftReviewerReject) {
        this.firstOverDraftReviewerReject = firstOverDraftReviewerReject;
    }

    public String getFirstOverDraftReviewerRejectReason() {
        return this.firstOverDraftReviewerRejectReason;
    }

    public TransactionReview firstOverDraftReviewerRejectReason(String firstOverDraftReviewerRejectReason) {
        this.setFirstOverDraftReviewerRejectReason(firstOverDraftReviewerRejectReason);
        return this;
    }

    public void setFirstOverDraftReviewerRejectReason(String firstOverDraftReviewerRejectReason) {
        this.firstOverDraftReviewerRejectReason = firstOverDraftReviewerRejectReason;
    }

    public ZonedDateTime getFirstOverDraftReviewedRejectedDate() {
        return this.firstOverDraftReviewedRejectedDate;
    }

    public TransactionReview firstOverDraftReviewedRejectedDate(ZonedDateTime firstOverDraftReviewedRejectedDate) {
        this.setFirstOverDraftReviewedRejectedDate(firstOverDraftReviewedRejectedDate);
        return this;
    }

    public void setFirstOverDraftReviewedRejectedDate(ZonedDateTime firstOverDraftReviewedRejectedDate) {
        this.firstOverDraftReviewedRejectedDate = firstOverDraftReviewedRejectedDate;
    }

    public String getSecondOverDraftReviewerAccept() {
        return this.secondOverDraftReviewerAccept;
    }

    public TransactionReview secondOverDraftReviewerAccept(String secondOverDraftReviewerAccept) {
        this.setSecondOverDraftReviewerAccept(secondOverDraftReviewerAccept);
        return this;
    }

    public void setSecondOverDraftReviewerAccept(String secondOverDraftReviewerAccept) {
        this.secondOverDraftReviewerAccept = secondOverDraftReviewerAccept;
    }

    public ZonedDateTime getSecondOverDraftReviewedAcceptDate() {
        return this.secondOverDraftReviewedAcceptDate;
    }

    public TransactionReview secondOverDraftReviewedAcceptDate(ZonedDateTime secondOverDraftReviewedAcceptDate) {
        this.setSecondOverDraftReviewedAcceptDate(secondOverDraftReviewedAcceptDate);
        return this;
    }

    public void setSecondOverDraftReviewedAcceptDate(ZonedDateTime secondOverDraftReviewedAcceptDate) {
        this.secondOverDraftReviewedAcceptDate = secondOverDraftReviewedAcceptDate;
    }

    public String getSecondOverDraftReviewerReject() {
        return this.secondOverDraftReviewerReject;
    }

    public TransactionReview secondOverDraftReviewerReject(String secondOverDraftReviewerReject) {
        this.setSecondOverDraftReviewerReject(secondOverDraftReviewerReject);
        return this;
    }

    public void setSecondOverDraftReviewerReject(String secondOverDraftReviewerReject) {
        this.secondOverDraftReviewerReject = secondOverDraftReviewerReject;
    }

    public String getSecondOverDraftReviewerRejectReason() {
        return this.secondOverDraftReviewerRejectReason;
    }

    public TransactionReview secondOverDraftReviewerRejectReason(String secondOverDraftReviewerRejectReason) {
        this.setSecondOverDraftReviewerRejectReason(secondOverDraftReviewerRejectReason);
        return this;
    }

    public void setSecondOverDraftReviewerRejectReason(String secondOverDraftReviewerRejectReason) {
        this.secondOverDraftReviewerRejectReason = secondOverDraftReviewerRejectReason;
    }

    public ZonedDateTime getSecondOverDraftReviewedRejectedDate() {
        return this.secondOverDraftReviewedRejectedDate;
    }

    public TransactionReview secondOverDraftReviewedRejectedDate(ZonedDateTime secondOverDraftReviewedRejectedDate) {
        this.setSecondOverDraftReviewedRejectedDate(secondOverDraftReviewedRejectedDate);
        return this;
    }

    public void setSecondOverDraftReviewedRejectedDate(ZonedDateTime secondOverDraftReviewedRejectedDate) {
        this.secondOverDraftReviewedRejectedDate = secondOverDraftReviewedRejectedDate;
    }

    public Transaction getTransaction() {
        return this.transaction;
    }

    public void setTransaction(Transaction transaction) {
        if (this.transaction != null) {
            this.transaction.setTransactionReview(null);
        }
        if (transaction != null) {
            transaction.setTransactionReview(this);
        }
        this.transaction = transaction;
    }

    public TransactionReview transaction(Transaction transaction) {
        this.setTransaction(transaction);
        return this;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TransactionReview)) {
            return false;
        }
        return getId() != null && getId().equals(((TransactionReview) o).getId());
    }

    @Override
    public int hashCode() {
        // see https://vladmihalcea.com/how-to-implement-equals-and-hashcode-using-the-jpa-entity-identifier/
        return getClass().hashCode();
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "TransactionReview{" +
            "id=" + getId() +
            ", tranId=" + getTranId() +
            ", firstPledgeReviewerAccept='" + getFirstPledgeReviewerAccept() + "'" +
            ", firstPledgeReviewedAcceptDate='" + getFirstPledgeReviewedAcceptDate() + "'" +
            ", firstPledgeReviewerReject='" + getFirstPledgeReviewerReject() + "'" +
            ", firstPledgeReviewerRejectReason='" + getFirstPledgeReviewerRejectReason() + "'" +
            ", firstPledgeReviewedRejectedDate='" + getFirstPledgeReviewedRejectedDate() + "'" +
            ", secondPledgeReviewerAccept='" + getSecondPledgeReviewerAccept() + "'" +
            ", secondPledgeReviewedAcceptDate='" + getSecondPledgeReviewedAcceptDate() + "'" +
            ", secondPledgeReviewerReject='" + getSecondPledgeReviewerReject() + "'" +
            ", secondPledgeReviewerRejectReason='" + getSecondPledgeReviewerRejectReason() + "'" +
            ", secondPledgeReviewedRejectedDate='" + getSecondPledgeReviewedRejectedDate() + "'" +
            ", firstFiducaryReviewerAccept='" + getFirstFiducaryReviewerAccept() + "'" +
            ", firstFiducaryReviewedAcceptDate='" + getFirstFiducaryReviewedAcceptDate() + "'" +
            ", firstFiducaryReviewerReject='" + getFirstFiducaryReviewerReject() + "'" +
            ", firstFiducaryReviewerRejectReason='" + getFirstFiducaryReviewerRejectReason() + "'" +
            ", firstFiducaryReviewedRejectedDate='" + getFirstFiducaryReviewedRejectedDate() + "'" +
            ", secondFiducaryReviewerAccept='" + getSecondFiducaryReviewerAccept() + "'" +
            ", secondPFiducaryReviewedAcceptDate='" + getSecondPFiducaryReviewedAcceptDate() + "'" +
            ", secondFiducaryReviewerReject='" + getSecondFiducaryReviewerReject() + "'" +
            ", secondFiducaryReviewerRejectReason='" + getSecondFiducaryReviewerRejectReason() + "'" +
            ", secondFiducaryReviewedRejectedDate='" + getSecondFiducaryReviewedRejectedDate() + "'" +
            ", firstOverDraftReviewerAccept='" + getFirstOverDraftReviewerAccept() + "'" +
            ", firstOverDraftReviewedAcceptDate='" + getFirstOverDraftReviewedAcceptDate() + "'" +
            ", firstOverDraftReviewerReject='" + getFirstOverDraftReviewerReject() + "'" +
            ", firstOverDraftReviewerRejectReason='" + getFirstOverDraftReviewerRejectReason() + "'" +
            ", firstOverDraftReviewedRejectedDate='" + getFirstOverDraftReviewedRejectedDate() + "'" +
            ", secondOverDraftReviewerAccept='" + getSecondOverDraftReviewerAccept() + "'" +
            ", secondOverDraftReviewedAcceptDate='" + getSecondOverDraftReviewedAcceptDate() + "'" +
            ", secondOverDraftReviewerReject='" + getSecondOverDraftReviewerReject() + "'" +
            ", secondOverDraftReviewerRejectReason='" + getSecondOverDraftReviewerRejectReason() + "'" +
            ", secondOverDraftReviewedRejectedDate='" + getSecondOverDraftReviewedRejectedDate() + "'" +
            "}";
    }
}
