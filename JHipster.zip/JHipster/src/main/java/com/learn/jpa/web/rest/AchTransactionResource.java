package com.learn.jpa.web.rest;

import com.learn.jpa.domain.AchTransaction;
import com.learn.jpa.repository.AchTransactionRepository;
import com.learn.jpa.service.AchTransactionService;
import com.learn.jpa.web.rest.errors.BadRequestAlertException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tech.jhipster.web.util.HeaderUtil;
import tech.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.learn.jpa.domain.AchTransaction}.
 */
@RestController
@RequestMapping("/api/ach-transactions")
public class AchTransactionResource {

    private final Logger log = LoggerFactory.getLogger(AchTransactionResource.class);

    private static final String ENTITY_NAME = "achTransaction";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final AchTransactionService achTransactionService;

    private final AchTransactionRepository achTransactionRepository;

    public AchTransactionResource(AchTransactionService achTransactionService, AchTransactionRepository achTransactionRepository) {
        this.achTransactionService = achTransactionService;
        this.achTransactionRepository = achTransactionRepository;
    }

    /**
     * {@code POST  /ach-transactions} : Create a new achTransaction.
     *
     * @param achTransaction the achTransaction to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new achTransaction, or with status {@code 400 (Bad Request)} if the achTransaction has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("")
    public ResponseEntity<AchTransaction> createAchTransaction(@Valid @RequestBody AchTransaction achTransaction)
        throws URISyntaxException {
        log.debug("REST request to save AchTransaction : {}", achTransaction);
        if (achTransaction.getId() != null) {
            throw new BadRequestAlertException("A new achTransaction cannot already have an ID", ENTITY_NAME, "idexists");
        }
        AchTransaction result = achTransactionService.save(achTransaction);
        return ResponseEntity
            .created(new URI("/api/ach-transactions/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /ach-transactions/:id} : Updates an existing achTransaction.
     *
     * @param id the id of the achTransaction to save.
     * @param achTransaction the achTransaction to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated achTransaction,
     * or with status {@code 400 (Bad Request)} if the achTransaction is not valid,
     * or with status {@code 500 (Internal Server Error)} if the achTransaction couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/{id}")
    public ResponseEntity<AchTransaction> updateAchTransaction(
        @PathVariable(value = "id", required = false) final Long id,
        @Valid @RequestBody AchTransaction achTransaction
    ) throws URISyntaxException {
        log.debug("REST request to update AchTransaction : {}, {}", id, achTransaction);
        if (achTransaction.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, achTransaction.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!achTransactionRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        AchTransaction result = achTransactionService.update(achTransaction);
        return ResponseEntity
            .ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, achTransaction.getId().toString()))
            .body(result);
    }

    /**
     * {@code PATCH  /ach-transactions/:id} : Partial updates given fields of an existing achTransaction, field will ignore if it is null
     *
     * @param id the id of the achTransaction to save.
     * @param achTransaction the achTransaction to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated achTransaction,
     * or with status {@code 400 (Bad Request)} if the achTransaction is not valid,
     * or with status {@code 404 (Not Found)} if the achTransaction is not found,
     * or with status {@code 500 (Internal Server Error)} if the achTransaction couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PatchMapping(value = "/{id}", consumes = { "application/json", "application/merge-patch+json" })
    public ResponseEntity<AchTransaction> partialUpdateAchTransaction(
        @PathVariable(value = "id", required = false) final Long id,
        @NotNull @RequestBody AchTransaction achTransaction
    ) throws URISyntaxException {
        log.debug("REST request to partial update AchTransaction partially : {}, {}", id, achTransaction);
        if (achTransaction.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, achTransaction.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!achTransactionRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        Optional<AchTransaction> result = achTransactionService.partialUpdate(achTransaction);

        return ResponseUtil.wrapOrNotFound(
            result,
            HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, achTransaction.getId().toString())
        );
    }

    /**
     * {@code GET  /ach-transactions} : get all the achTransactions.
     *
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of achTransactions in body.
     */
    @GetMapping("")
    public List<AchTransaction> getAllAchTransactions() {
        log.debug("REST request to get all AchTransactions");
        return achTransactionService.findAll();
    }

    /**
     * {@code GET  /ach-transactions/:id} : get the "id" achTransaction.
     *
     * @param id the id of the achTransaction to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the achTransaction, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/{id}")
    public ResponseEntity<AchTransaction> getAchTransaction(@PathVariable("id") Long id) {
        log.debug("REST request to get AchTransaction : {}", id);
        Optional<AchTransaction> achTransaction = achTransactionService.findOne(id);
        return ResponseUtil.wrapOrNotFound(achTransaction);
    }

    /**
     * {@code DELETE  /ach-transactions/:id} : delete the "id" achTransaction.
     *
     * @param id the id of the achTransaction to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAchTransaction(@PathVariable("id") Long id) {
        log.debug("REST request to delete AchTransaction : {}", id);
        achTransactionService.delete(id);
        return ResponseEntity
            .noContent()
            .headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString()))
            .build();
    }
}
