package com.learn.jpa.service.impl;

import com.learn.jpa.domain.WireFromAccnt;
import com.learn.jpa.repository.WireFromAccntRepository;
import com.learn.jpa.service.WireFromAccntService;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.WireFromAccnt}.
 */
@Service
@Transactional
public class WireFromAccntServiceImpl implements WireFromAccntService {

    private final Logger log = LoggerFactory.getLogger(WireFromAccntServiceImpl.class);

    private final WireFromAccntRepository wireFromAccntRepository;

    public WireFromAccntServiceImpl(WireFromAccntRepository wireFromAccntRepository) {
        this.wireFromAccntRepository = wireFromAccntRepository;
    }

    @Override
    public WireFromAccnt save(WireFromAccnt wireFromAccnt) {
        log.debug("Request to save WireFromAccnt : {}", wireFromAccnt);
        return wireFromAccntRepository.save(wireFromAccnt);
    }

    @Override
    public WireFromAccnt update(WireFromAccnt wireFromAccnt) {
        log.debug("Request to update WireFromAccnt : {}", wireFromAccnt);
        return wireFromAccntRepository.save(wireFromAccnt);
    }

    @Override
    public Optional<WireFromAccnt> partialUpdate(WireFromAccnt wireFromAccnt) {
        log.debug("Request to partially update WireFromAccnt : {}", wireFromAccnt);

        return wireFromAccntRepository
            .findById(wireFromAccnt.getId())
            .map(existingWireFromAccnt -> {
                if (wireFromAccnt.getFromAccntID() != null) {
                    existingWireFromAccnt.setFromAccntID(wireFromAccnt.getFromAccntID());
                }
                if (wireFromAccnt.getFromAccntSk() != null) {
                    existingWireFromAccnt.setFromAccntSk(wireFromAccnt.getFromAccntSk());
                }
                if (wireFromAccnt.getFromAccntName() != null) {
                    existingWireFromAccnt.setFromAccntName(wireFromAccnt.getFromAccntName());
                }
                if (wireFromAccnt.getFromAccntAmnt() != null) {
                    existingWireFromAccnt.setFromAccntAmnt(wireFromAccnt.getFromAccntAmnt());
                }

                return existingWireFromAccnt;
            })
            .map(wireFromAccntRepository::save);
    }

    @Override
    @Transactional(readOnly = true)
    public List<WireFromAccnt> findAll() {
        log.debug("Request to get all WireFromAccnts");
        return wireFromAccntRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<WireFromAccnt> findOne(Long id) {
        log.debug("Request to get WireFromAccnt : {}", id);
        return wireFromAccntRepository.findById(id);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete WireFromAccnt : {}", id);
        wireFromAccntRepository.deleteById(id);
    }
}
