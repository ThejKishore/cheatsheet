package com.learn.jpa.repository;

import com.learn.jpa.domain.TransferTransaction;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the TransferTransaction entity.
 */
@SuppressWarnings("unused")
@Repository
public interface TransferTransactionRepository extends JpaRepository<TransferTransaction, Long> {}
