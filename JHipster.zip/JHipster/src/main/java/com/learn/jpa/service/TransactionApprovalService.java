package com.learn.jpa.service;

import com.learn.jpa.domain.TransactionApproval;
import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing {@link com.learn.jpa.domain.TransactionApproval}.
 */
public interface TransactionApprovalService {
    /**
     * Save a transactionApproval.
     *
     * @param transactionApproval the entity to save.
     * @return the persisted entity.
     */
    TransactionApproval save(TransactionApproval transactionApproval);

    /**
     * Updates a transactionApproval.
     *
     * @param transactionApproval the entity to update.
     * @return the persisted entity.
     */
    TransactionApproval update(TransactionApproval transactionApproval);

    /**
     * Partially updates a transactionApproval.
     *
     * @param transactionApproval the entity to update partially.
     * @return the persisted entity.
     */
    Optional<TransactionApproval> partialUpdate(TransactionApproval transactionApproval);

    /**
     * Get all the transactionApprovals.
     *
     * @return the list of entities.
     */
    List<TransactionApproval> findAll();

    /**
     * Get all the TransactionApproval where Transaction is {@code null}.
     *
     * @return the {@link List} of entities.
     */
    List<TransactionApproval> findAllWhereTransactionIsNull();

    /**
     * Get the "id" transactionApproval.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<TransactionApproval> findOne(Long id);

    /**
     * Delete the "id" transactionApproval.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
