package com.learn.jpa.service.impl;

import com.learn.jpa.domain.AchRecipient;
import com.learn.jpa.repository.AchRecipientRepository;
import com.learn.jpa.service.AchRecipientService;
import java.util.List;
import java.util.Optional;
import java.util.stream.StreamSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.AchRecipient}.
 */
@Service
@Transactional
public class AchRecipientServiceImpl implements AchRecipientService {

    private final Logger log = LoggerFactory.getLogger(AchRecipientServiceImpl.class);

    private final AchRecipientRepository achRecipientRepository;

    public AchRecipientServiceImpl(AchRecipientRepository achRecipientRepository) {
        this.achRecipientRepository = achRecipientRepository;
    }

    @Override
    public AchRecipient save(AchRecipient achRecipient) {
        log.debug("Request to save AchRecipient : {}", achRecipient);
        return achRecipientRepository.save(achRecipient);
    }

    @Override
    public AchRecipient update(AchRecipient achRecipient) {
        log.debug("Request to update AchRecipient : {}", achRecipient);
        return achRecipientRepository.save(achRecipient);
    }

    @Override
    public Optional<AchRecipient> partialUpdate(AchRecipient achRecipient) {
        log.debug("Request to partially update AchRecipient : {}", achRecipient);

        return achRecipientRepository
            .findById(achRecipient.getId())
            .map(existingAchRecipient -> {
                if (achRecipient.getRecipientId() != null) {
                    existingAchRecipient.setRecipientId(achRecipient.getRecipientId());
                }
                if (achRecipient.getRecipeintName() != null) {
                    existingAchRecipient.setRecipeintName(achRecipient.getRecipeintName());
                }
                if (achRecipient.getRecipientAddress() != null) {
                    existingAchRecipient.setRecipientAddress(achRecipient.getRecipientAddress());
                }
                if (achRecipient.getRecipientCountry() != null) {
                    existingAchRecipient.setRecipientCountry(achRecipient.getRecipientCountry());
                }
                if (achRecipient.getRecipientState() != null) {
                    existingAchRecipient.setRecipientState(achRecipient.getRecipientState());
                }
                if (achRecipient.getRecipientCity() != null) {
                    existingAchRecipient.setRecipientCity(achRecipient.getRecipientCity());
                }

                return existingAchRecipient;
            })
            .map(achRecipientRepository::save);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AchRecipient> findAll() {
        log.debug("Request to get all AchRecipients");
        return achRecipientRepository.findAll();
    }

    /**
     *  Get all the achRecipients where AchTransaction is {@code null}.
     *  @return the list of entities.
     */
    @Transactional(readOnly = true)
    public List<AchRecipient> findAllWhereAchTransactionIsNull() {
        log.debug("Request to get all achRecipients where AchTransaction is null");
        return StreamSupport
            .stream(achRecipientRepository.findAll().spliterator(), false)
            .filter(achRecipient -> achRecipient.getAchTransaction() == null)
            .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<AchRecipient> findOne(Long id) {
        log.debug("Request to get AchRecipient : {}", id);
        return achRecipientRepository.findById(id);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete AchRecipient : {}", id);
        achRecipientRepository.deleteById(id);
    }
}
