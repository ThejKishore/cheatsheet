package com.learn.jpa.service;

import com.learn.jpa.domain.WireFromAccnt;
import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing {@link com.learn.jpa.domain.WireFromAccnt}.
 */
public interface WireFromAccntService {
    /**
     * Save a wireFromAccnt.
     *
     * @param wireFromAccnt the entity to save.
     * @return the persisted entity.
     */
    WireFromAccnt save(WireFromAccnt wireFromAccnt);

    /**
     * Updates a wireFromAccnt.
     *
     * @param wireFromAccnt the entity to update.
     * @return the persisted entity.
     */
    WireFromAccnt update(WireFromAccnt wireFromAccnt);

    /**
     * Partially updates a wireFromAccnt.
     *
     * @param wireFromAccnt the entity to update partially.
     * @return the persisted entity.
     */
    Optional<WireFromAccnt> partialUpdate(WireFromAccnt wireFromAccnt);

    /**
     * Get all the wireFromAccnts.
     *
     * @return the list of entities.
     */
    List<WireFromAccnt> findAll();

    /**
     * Get the "id" wireFromAccnt.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<WireFromAccnt> findOne(Long id);

    /**
     * Delete the "id" wireFromAccnt.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
