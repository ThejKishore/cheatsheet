/**
 * Rest layer.
 */
package com.learn.jpa.web.rest;
