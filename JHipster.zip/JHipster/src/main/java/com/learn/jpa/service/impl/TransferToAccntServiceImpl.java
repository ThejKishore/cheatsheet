package com.learn.jpa.service.impl;

import com.learn.jpa.domain.TransferToAccnt;
import com.learn.jpa.repository.TransferToAccntRepository;
import com.learn.jpa.service.TransferToAccntService;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.TransferToAccnt}.
 */
@Service
@Transactional
public class TransferToAccntServiceImpl implements TransferToAccntService {

    private final Logger log = LoggerFactory.getLogger(TransferToAccntServiceImpl.class);

    private final TransferToAccntRepository transferToAccntRepository;

    public TransferToAccntServiceImpl(TransferToAccntRepository transferToAccntRepository) {
        this.transferToAccntRepository = transferToAccntRepository;
    }

    @Override
    public TransferToAccnt save(TransferToAccnt transferToAccnt) {
        log.debug("Request to save TransferToAccnt : {}", transferToAccnt);
        return transferToAccntRepository.save(transferToAccnt);
    }

    @Override
    public TransferToAccnt update(TransferToAccnt transferToAccnt) {
        log.debug("Request to update TransferToAccnt : {}", transferToAccnt);
        return transferToAccntRepository.save(transferToAccnt);
    }

    @Override
    public Optional<TransferToAccnt> partialUpdate(TransferToAccnt transferToAccnt) {
        log.debug("Request to partially update TransferToAccnt : {}", transferToAccnt);

        return transferToAccntRepository
            .findById(transferToAccnt.getId())
            .map(existingTransferToAccnt -> {
                if (transferToAccnt.getToAccntID() != null) {
                    existingTransferToAccnt.setToAccntID(transferToAccnt.getToAccntID());
                }
                if (transferToAccnt.getToAccntSk() != null) {
                    existingTransferToAccnt.setToAccntSk(transferToAccnt.getToAccntSk());
                }
                if (transferToAccnt.getToAccntName() != null) {
                    existingTransferToAccnt.setToAccntName(transferToAccnt.getToAccntName());
                }
                if (transferToAccnt.getToAccntAmnt() != null) {
                    existingTransferToAccnt.setToAccntAmnt(transferToAccnt.getToAccntAmnt());
                }

                return existingTransferToAccnt;
            })
            .map(transferToAccntRepository::save);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TransferToAccnt> findAll() {
        log.debug("Request to get all TransferToAccnts");
        return transferToAccntRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<TransferToAccnt> findOne(Long id) {
        log.debug("Request to get TransferToAccnt : {}", id);
        return transferToAccntRepository.findById(id);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete TransferToAccnt : {}", id);
        transferToAccntRepository.deleteById(id);
    }
}
