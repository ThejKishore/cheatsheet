package com.learn.jpa.repository;

import com.learn.jpa.domain.TransferToAccnt;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the TransferToAccnt entity.
 */
@SuppressWarnings("unused")
@Repository
public interface TransferToAccntRepository extends JpaRepository<TransferToAccnt, Long> {}
