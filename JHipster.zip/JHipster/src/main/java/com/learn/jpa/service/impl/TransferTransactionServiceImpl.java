package com.learn.jpa.service.impl;

import com.learn.jpa.domain.TransferTransaction;
import com.learn.jpa.repository.TransferTransactionRepository;
import com.learn.jpa.service.TransferTransactionService;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.TransferTransaction}.
 */
@Service
@Transactional
public class TransferTransactionServiceImpl implements TransferTransactionService {

    private final Logger log = LoggerFactory.getLogger(TransferTransactionServiceImpl.class);

    private final TransferTransactionRepository transferTransactionRepository;

    public TransferTransactionServiceImpl(TransferTransactionRepository transferTransactionRepository) {
        this.transferTransactionRepository = transferTransactionRepository;
    }

    @Override
    public TransferTransaction save(TransferTransaction transferTransaction) {
        log.debug("Request to save TransferTransaction : {}", transferTransaction);
        return transferTransactionRepository.save(transferTransaction);
    }

    @Override
    public TransferTransaction update(TransferTransaction transferTransaction) {
        log.debug("Request to update TransferTransaction : {}", transferTransaction);
        return transferTransactionRepository.save(transferTransaction);
    }

    @Override
    public Optional<TransferTransaction> partialUpdate(TransferTransaction transferTransaction) {
        log.debug("Request to partially update TransferTransaction : {}", transferTransaction);

        return transferTransactionRepository
            .findById(transferTransaction.getId())
            .map(existingTransferTransaction -> {
                if (transferTransaction.getTransferTranId() != null) {
                    existingTransferTransaction.setTransferTranId(transferTransaction.getTransferTranId());
                }

                return existingTransferTransaction;
            })
            .map(transferTransactionRepository::save);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TransferTransaction> findAll() {
        log.debug("Request to get all TransferTransactions");
        return transferTransactionRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<TransferTransaction> findOne(Long id) {
        log.debug("Request to get TransferTransaction : {}", id);
        return transferTransactionRepository.findById(id);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete TransferTransaction : {}", id);
        transferTransactionRepository.deleteById(id);
    }
}
