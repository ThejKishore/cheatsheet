package com.learn.jpa.service;

import com.learn.jpa.domain.TransactionMapping;
import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing {@link com.learn.jpa.domain.TransactionMapping}.
 */
public interface TransactionMappingService {
    /**
     * Save a transactionMapping.
     *
     * @param transactionMapping the entity to save.
     * @return the persisted entity.
     */
    TransactionMapping save(TransactionMapping transactionMapping);

    /**
     * Updates a transactionMapping.
     *
     * @param transactionMapping the entity to update.
     * @return the persisted entity.
     */
    TransactionMapping update(TransactionMapping transactionMapping);

    /**
     * Partially updates a transactionMapping.
     *
     * @param transactionMapping the entity to update partially.
     * @return the persisted entity.
     */
    Optional<TransactionMapping> partialUpdate(TransactionMapping transactionMapping);

    /**
     * Get all the transactionMappings.
     *
     * @return the list of entities.
     */
    List<TransactionMapping> findAll();

    /**
     * Get all the TransactionMapping where Transaction is {@code null}.
     *
     * @return the {@link List} of entities.
     */
    List<TransactionMapping> findAllWhereTransactionIsNull();
    /**
     * Get all the TransactionMapping where AchTransaction is {@code null}.
     *
     * @return the {@link List} of entities.
     */
    List<TransactionMapping> findAllWhereAchTransactionIsNull();
    /**
     * Get all the TransactionMapping where WireTransaction is {@code null}.
     *
     * @return the {@link List} of entities.
     */
    List<TransactionMapping> findAllWhereWireTransactionIsNull();
    /**
     * Get all the TransactionMapping where TransferTransaction is {@code null}.
     *
     * @return the {@link List} of entities.
     */
    List<TransactionMapping> findAllWhereTransferTransactionIsNull();

    /**
     * Get the "id" transactionMapping.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<TransactionMapping> findOne(Long id);

    /**
     * Delete the "id" transactionMapping.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
