package com.learn.jpa.repository;

import com.learn.jpa.domain.AchRecipient;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the AchRecipient entity.
 */
@SuppressWarnings("unused")
@Repository
public interface AchRecipientRepository extends JpaRepository<AchRecipient, Long> {}
