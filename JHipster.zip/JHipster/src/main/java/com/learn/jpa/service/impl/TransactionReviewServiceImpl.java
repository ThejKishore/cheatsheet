package com.learn.jpa.service.impl;

import com.learn.jpa.domain.TransactionReview;
import com.learn.jpa.repository.TransactionReviewRepository;
import com.learn.jpa.service.TransactionReviewService;
import java.util.List;
import java.util.Optional;
import java.util.stream.StreamSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.TransactionReview}.
 */
@Service
@Transactional
public class TransactionReviewServiceImpl implements TransactionReviewService {

    private final Logger log = LoggerFactory.getLogger(TransactionReviewServiceImpl.class);

    private final TransactionReviewRepository transactionReviewRepository;

    public TransactionReviewServiceImpl(TransactionReviewRepository transactionReviewRepository) {
        this.transactionReviewRepository = transactionReviewRepository;
    }

    @Override
    public TransactionReview save(TransactionReview transactionReview) {
        log.debug("Request to save TransactionReview : {}", transactionReview);
        return transactionReviewRepository.save(transactionReview);
    }

    @Override
    public TransactionReview update(TransactionReview transactionReview) {
        log.debug("Request to update TransactionReview : {}", transactionReview);
        return transactionReviewRepository.save(transactionReview);
    }

    @Override
    public Optional<TransactionReview> partialUpdate(TransactionReview transactionReview) {
        log.debug("Request to partially update TransactionReview : {}", transactionReview);

        return transactionReviewRepository
            .findById(transactionReview.getId())
            .map(existingTransactionReview -> {
                if (transactionReview.getTranId() != null) {
                    existingTransactionReview.setTranId(transactionReview.getTranId());
                }
                if (transactionReview.getFirstPledgeReviewerAccept() != null) {
                    existingTransactionReview.setFirstPledgeReviewerAccept(transactionReview.getFirstPledgeReviewerAccept());
                }
                if (transactionReview.getFirstPledgeReviewedAcceptDate() != null) {
                    existingTransactionReview.setFirstPledgeReviewedAcceptDate(transactionReview.getFirstPledgeReviewedAcceptDate());
                }
                if (transactionReview.getFirstPledgeReviewerReject() != null) {
                    existingTransactionReview.setFirstPledgeReviewerReject(transactionReview.getFirstPledgeReviewerReject());
                }
                if (transactionReview.getFirstPledgeReviewerRejectReason() != null) {
                    existingTransactionReview.setFirstPledgeReviewerRejectReason(transactionReview.getFirstPledgeReviewerRejectReason());
                }
                if (transactionReview.getFirstPledgeReviewedRejectedDate() != null) {
                    existingTransactionReview.setFirstPledgeReviewedRejectedDate(transactionReview.getFirstPledgeReviewedRejectedDate());
                }
                if (transactionReview.getSecondPledgeReviewerAccept() != null) {
                    existingTransactionReview.setSecondPledgeReviewerAccept(transactionReview.getSecondPledgeReviewerAccept());
                }
                if (transactionReview.getSecondPledgeReviewedAcceptDate() != null) {
                    existingTransactionReview.setSecondPledgeReviewedAcceptDate(transactionReview.getSecondPledgeReviewedAcceptDate());
                }
                if (transactionReview.getSecondPledgeReviewerReject() != null) {
                    existingTransactionReview.setSecondPledgeReviewerReject(transactionReview.getSecondPledgeReviewerReject());
                }
                if (transactionReview.getSecondPledgeReviewerRejectReason() != null) {
                    existingTransactionReview.setSecondPledgeReviewerRejectReason(transactionReview.getSecondPledgeReviewerRejectReason());
                }
                if (transactionReview.getSecondPledgeReviewedRejectedDate() != null) {
                    existingTransactionReview.setSecondPledgeReviewedRejectedDate(transactionReview.getSecondPledgeReviewedRejectedDate());
                }
                if (transactionReview.getFirstFiducaryReviewerAccept() != null) {
                    existingTransactionReview.setFirstFiducaryReviewerAccept(transactionReview.getFirstFiducaryReviewerAccept());
                }
                if (transactionReview.getFirstFiducaryReviewedAcceptDate() != null) {
                    existingTransactionReview.setFirstFiducaryReviewedAcceptDate(transactionReview.getFirstFiducaryReviewedAcceptDate());
                }
                if (transactionReview.getFirstFiducaryReviewerReject() != null) {
                    existingTransactionReview.setFirstFiducaryReviewerReject(transactionReview.getFirstFiducaryReviewerReject());
                }
                if (transactionReview.getFirstFiducaryReviewerRejectReason() != null) {
                    existingTransactionReview.setFirstFiducaryReviewerRejectReason(
                        transactionReview.getFirstFiducaryReviewerRejectReason()
                    );
                }
                if (transactionReview.getFirstFiducaryReviewedRejectedDate() != null) {
                    existingTransactionReview.setFirstFiducaryReviewedRejectedDate(
                        transactionReview.getFirstFiducaryReviewedRejectedDate()
                    );
                }
                if (transactionReview.getSecondFiducaryReviewerAccept() != null) {
                    existingTransactionReview.setSecondFiducaryReviewerAccept(transactionReview.getSecondFiducaryReviewerAccept());
                }
                if (transactionReview.getSecondPFiducaryReviewedAcceptDate() != null) {
                    existingTransactionReview.setSecondPFiducaryReviewedAcceptDate(
                        transactionReview.getSecondPFiducaryReviewedAcceptDate()
                    );
                }
                if (transactionReview.getSecondFiducaryReviewerReject() != null) {
                    existingTransactionReview.setSecondFiducaryReviewerReject(transactionReview.getSecondFiducaryReviewerReject());
                }
                if (transactionReview.getSecondFiducaryReviewerRejectReason() != null) {
                    existingTransactionReview.setSecondFiducaryReviewerRejectReason(
                        transactionReview.getSecondFiducaryReviewerRejectReason()
                    );
                }
                if (transactionReview.getSecondFiducaryReviewedRejectedDate() != null) {
                    existingTransactionReview.setSecondFiducaryReviewedRejectedDate(
                        transactionReview.getSecondFiducaryReviewedRejectedDate()
                    );
                }
                if (transactionReview.getFirstOverDraftReviewerAccept() != null) {
                    existingTransactionReview.setFirstOverDraftReviewerAccept(transactionReview.getFirstOverDraftReviewerAccept());
                }
                if (transactionReview.getFirstOverDraftReviewedAcceptDate() != null) {
                    existingTransactionReview.setFirstOverDraftReviewedAcceptDate(transactionReview.getFirstOverDraftReviewedAcceptDate());
                }
                if (transactionReview.getFirstOverDraftReviewerReject() != null) {
                    existingTransactionReview.setFirstOverDraftReviewerReject(transactionReview.getFirstOverDraftReviewerReject());
                }
                if (transactionReview.getFirstOverDraftReviewerRejectReason() != null) {
                    existingTransactionReview.setFirstOverDraftReviewerRejectReason(
                        transactionReview.getFirstOverDraftReviewerRejectReason()
                    );
                }
                if (transactionReview.getFirstOverDraftReviewedRejectedDate() != null) {
                    existingTransactionReview.setFirstOverDraftReviewedRejectedDate(
                        transactionReview.getFirstOverDraftReviewedRejectedDate()
                    );
                }
                if (transactionReview.getSecondOverDraftReviewerAccept() != null) {
                    existingTransactionReview.setSecondOverDraftReviewerAccept(transactionReview.getSecondOverDraftReviewerAccept());
                }
                if (transactionReview.getSecondOverDraftReviewedAcceptDate() != null) {
                    existingTransactionReview.setSecondOverDraftReviewedAcceptDate(
                        transactionReview.getSecondOverDraftReviewedAcceptDate()
                    );
                }
                if (transactionReview.getSecondOverDraftReviewerReject() != null) {
                    existingTransactionReview.setSecondOverDraftReviewerReject(transactionReview.getSecondOverDraftReviewerReject());
                }
                if (transactionReview.getSecondOverDraftReviewerRejectReason() != null) {
                    existingTransactionReview.setSecondOverDraftReviewerRejectReason(
                        transactionReview.getSecondOverDraftReviewerRejectReason()
                    );
                }
                if (transactionReview.getSecondOverDraftReviewedRejectedDate() != null) {
                    existingTransactionReview.setSecondOverDraftReviewedRejectedDate(
                        transactionReview.getSecondOverDraftReviewedRejectedDate()
                    );
                }

                return existingTransactionReview;
            })
            .map(transactionReviewRepository::save);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TransactionReview> findAll() {
        log.debug("Request to get all TransactionReviews");
        return transactionReviewRepository.findAll();
    }

    /**
     *  Get all the transactionReviews where Transaction is {@code null}.
     *  @return the list of entities.
     */
    @Transactional(readOnly = true)
    public List<TransactionReview> findAllWhereTransactionIsNull() {
        log.debug("Request to get all transactionReviews where Transaction is null");
        return StreamSupport
            .stream(transactionReviewRepository.findAll().spliterator(), false)
            .filter(transactionReview -> transactionReview.getTransaction() == null)
            .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<TransactionReview> findOne(Long id) {
        log.debug("Request to get TransactionReview : {}", id);
        return transactionReviewRepository.findById(id);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete TransactionReview : {}", id);
        transactionReviewRepository.deleteById(id);
    }
}
