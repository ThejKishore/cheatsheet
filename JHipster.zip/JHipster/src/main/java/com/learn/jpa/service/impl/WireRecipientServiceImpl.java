package com.learn.jpa.service.impl;

import com.learn.jpa.domain.WireRecipient;
import com.learn.jpa.repository.WireRecipientRepository;
import com.learn.jpa.service.WireRecipientService;
import java.util.List;
import java.util.Optional;
import java.util.stream.StreamSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.WireRecipient}.
 */
@Service
@Transactional
public class WireRecipientServiceImpl implements WireRecipientService {

    private final Logger log = LoggerFactory.getLogger(WireRecipientServiceImpl.class);

    private final WireRecipientRepository wireRecipientRepository;

    public WireRecipientServiceImpl(WireRecipientRepository wireRecipientRepository) {
        this.wireRecipientRepository = wireRecipientRepository;
    }

    @Override
    public WireRecipient save(WireRecipient wireRecipient) {
        log.debug("Request to save WireRecipient : {}", wireRecipient);
        return wireRecipientRepository.save(wireRecipient);
    }

    @Override
    public WireRecipient update(WireRecipient wireRecipient) {
        log.debug("Request to update WireRecipient : {}", wireRecipient);
        return wireRecipientRepository.save(wireRecipient);
    }

    @Override
    public Optional<WireRecipient> partialUpdate(WireRecipient wireRecipient) {
        log.debug("Request to partially update WireRecipient : {}", wireRecipient);

        return wireRecipientRepository
            .findById(wireRecipient.getId())
            .map(existingWireRecipient -> {
                if (wireRecipient.getRecipientId() != null) {
                    existingWireRecipient.setRecipientId(wireRecipient.getRecipientId());
                }
                if (wireRecipient.getRecipeintName() != null) {
                    existingWireRecipient.setRecipeintName(wireRecipient.getRecipeintName());
                }
                if (wireRecipient.getRecipientAddress() != null) {
                    existingWireRecipient.setRecipientAddress(wireRecipient.getRecipientAddress());
                }
                if (wireRecipient.getRecipientCountry() != null) {
                    existingWireRecipient.setRecipientCountry(wireRecipient.getRecipientCountry());
                }
                if (wireRecipient.getRecipientState() != null) {
                    existingWireRecipient.setRecipientState(wireRecipient.getRecipientState());
                }
                if (wireRecipient.getRecipientCity() != null) {
                    existingWireRecipient.setRecipientCity(wireRecipient.getRecipientCity());
                }

                return existingWireRecipient;
            })
            .map(wireRecipientRepository::save);
    }

    @Override
    @Transactional(readOnly = true)
    public List<WireRecipient> findAll() {
        log.debug("Request to get all WireRecipients");
        return wireRecipientRepository.findAll();
    }

    /**
     *  Get all the wireRecipients where WireTransaction is {@code null}.
     *  @return the list of entities.
     */
    @Transactional(readOnly = true)
    public List<WireRecipient> findAllWhereWireTransactionIsNull() {
        log.debug("Request to get all wireRecipients where WireTransaction is null");
        return StreamSupport
            .stream(wireRecipientRepository.findAll().spliterator(), false)
            .filter(wireRecipient -> wireRecipient.getWireTransaction() == null)
            .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<WireRecipient> findOne(Long id) {
        log.debug("Request to get WireRecipient : {}", id);
        return wireRecipientRepository.findById(id);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete WireRecipient : {}", id);
        wireRecipientRepository.deleteById(id);
    }
}
