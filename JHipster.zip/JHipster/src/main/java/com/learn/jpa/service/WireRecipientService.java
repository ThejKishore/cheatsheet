package com.learn.jpa.service;

import com.learn.jpa.domain.WireRecipient;
import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing {@link com.learn.jpa.domain.WireRecipient}.
 */
public interface WireRecipientService {
    /**
     * Save a wireRecipient.
     *
     * @param wireRecipient the entity to save.
     * @return the persisted entity.
     */
    WireRecipient save(WireRecipient wireRecipient);

    /**
     * Updates a wireRecipient.
     *
     * @param wireRecipient the entity to update.
     * @return the persisted entity.
     */
    WireRecipient update(WireRecipient wireRecipient);

    /**
     * Partially updates a wireRecipient.
     *
     * @param wireRecipient the entity to update partially.
     * @return the persisted entity.
     */
    Optional<WireRecipient> partialUpdate(WireRecipient wireRecipient);

    /**
     * Get all the wireRecipients.
     *
     * @return the list of entities.
     */
    List<WireRecipient> findAll();

    /**
     * Get all the WireRecipient where WireTransaction is {@code null}.
     *
     * @return the {@link List} of entities.
     */
    List<WireRecipient> findAllWhereWireTransactionIsNull();

    /**
     * Get the "id" wireRecipient.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<WireRecipient> findOne(Long id);

    /**
     * Delete the "id" wireRecipient.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
