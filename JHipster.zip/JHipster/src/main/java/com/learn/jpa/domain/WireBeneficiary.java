package com.learn.jpa.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.io.Serializable;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * A WireBeneficiary.
 */
@Entity
@Table(name = "wire_beneficiary")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@SuppressWarnings("common-java:DuplicatedBlocks")
public class WireBeneficiary implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "id")
    private Long id;

    @NotNull
    @Column(name = "beneficiary_id", nullable = false, unique = true)
    private Long beneficiaryId;

    @Column(name = "beneficiary_name")
    private String beneficiaryName;

    @Column(name = "beneficiary_type")
    private String beneficiaryType;

    @ManyToOne(fetch = FetchType.LAZY)
    @JsonIgnoreProperties(value = { "wireBeneficiaries", "wireTransaction" }, allowSetters = true)
    private WireRecipient wireRecipient;

    // jhipster-needle-entity-add-field - JHipster will add fields here

    public Long getId() {
        return this.id;
    }

    public WireBeneficiary id(Long id) {
        this.setId(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBeneficiaryId() {
        return this.beneficiaryId;
    }

    public WireBeneficiary beneficiaryId(Long beneficiaryId) {
        this.setBeneficiaryId(beneficiaryId);
        return this;
    }

    public void setBeneficiaryId(Long beneficiaryId) {
        this.beneficiaryId = beneficiaryId;
    }

    public String getBeneficiaryName() {
        return this.beneficiaryName;
    }

    public WireBeneficiary beneficiaryName(String beneficiaryName) {
        this.setBeneficiaryName(beneficiaryName);
        return this;
    }

    public void setBeneficiaryName(String beneficiaryName) {
        this.beneficiaryName = beneficiaryName;
    }

    public String getBeneficiaryType() {
        return this.beneficiaryType;
    }

    public WireBeneficiary beneficiaryType(String beneficiaryType) {
        this.setBeneficiaryType(beneficiaryType);
        return this;
    }

    public void setBeneficiaryType(String beneficiaryType) {
        this.beneficiaryType = beneficiaryType;
    }

    public WireRecipient getWireRecipient() {
        return this.wireRecipient;
    }

    public void setWireRecipient(WireRecipient wireRecipient) {
        this.wireRecipient = wireRecipient;
    }

    public WireBeneficiary wireRecipient(WireRecipient wireRecipient) {
        this.setWireRecipient(wireRecipient);
        return this;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof WireBeneficiary)) {
            return false;
        }
        return getId() != null && getId().equals(((WireBeneficiary) o).getId());
    }

    @Override
    public int hashCode() {
        // see https://vladmihalcea.com/how-to-implement-equals-and-hashcode-using-the-jpa-entity-identifier/
        return getClass().hashCode();
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "WireBeneficiary{" +
            "id=" + getId() +
            ", beneficiaryId=" + getBeneficiaryId() +
            ", beneficiaryName='" + getBeneficiaryName() + "'" +
            ", beneficiaryType='" + getBeneficiaryType() + "'" +
            "}";
    }
}
