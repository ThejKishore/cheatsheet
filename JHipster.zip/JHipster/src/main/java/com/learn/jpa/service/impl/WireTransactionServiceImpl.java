package com.learn.jpa.service.impl;

import com.learn.jpa.domain.WireTransaction;
import com.learn.jpa.repository.WireTransactionRepository;
import com.learn.jpa.service.WireTransactionService;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.WireTransaction}.
 */
@Service
@Transactional
public class WireTransactionServiceImpl implements WireTransactionService {

    private final Logger log = LoggerFactory.getLogger(WireTransactionServiceImpl.class);

    private final WireTransactionRepository wireTransactionRepository;

    public WireTransactionServiceImpl(WireTransactionRepository wireTransactionRepository) {
        this.wireTransactionRepository = wireTransactionRepository;
    }

    @Override
    public WireTransaction save(WireTransaction wireTransaction) {
        log.debug("Request to save WireTransaction : {}", wireTransaction);
        return wireTransactionRepository.save(wireTransaction);
    }

    @Override
    public WireTransaction update(WireTransaction wireTransaction) {
        log.debug("Request to update WireTransaction : {}", wireTransaction);
        return wireTransactionRepository.save(wireTransaction);
    }

    @Override
    public Optional<WireTransaction> partialUpdate(WireTransaction wireTransaction) {
        log.debug("Request to partially update WireTransaction : {}", wireTransaction);

        return wireTransactionRepository
            .findById(wireTransaction.getId())
            .map(existingWireTransaction -> {
                if (wireTransaction.getWireTranId() != null) {
                    existingWireTransaction.setWireTranId(wireTransaction.getWireTranId());
                }

                return existingWireTransaction;
            })
            .map(wireTransactionRepository::save);
    }

    @Override
    @Transactional(readOnly = true)
    public List<WireTransaction> findAll() {
        log.debug("Request to get all WireTransactions");
        return wireTransactionRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<WireTransaction> findOne(Long id) {
        log.debug("Request to get WireTransaction : {}", id);
        return wireTransactionRepository.findById(id);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete WireTransaction : {}", id);
        wireTransactionRepository.deleteById(id);
    }
}
