package com.learn.jpa.repository;

import com.learn.jpa.domain.WireRecipient;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the WireRecipient entity.
 */
@SuppressWarnings("unused")
@Repository
public interface WireRecipientRepository extends JpaRepository<WireRecipient, Long> {}
