package com.learn.jpa.service.impl;

import com.learn.jpa.domain.TransactionMapping;
import com.learn.jpa.repository.TransactionMappingRepository;
import com.learn.jpa.service.TransactionMappingService;
import java.util.List;
import java.util.Optional;
import java.util.stream.StreamSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.TransactionMapping}.
 */
@Service
@Transactional
public class TransactionMappingServiceImpl implements TransactionMappingService {

    private final Logger log = LoggerFactory.getLogger(TransactionMappingServiceImpl.class);

    private final TransactionMappingRepository transactionMappingRepository;

    public TransactionMappingServiceImpl(TransactionMappingRepository transactionMappingRepository) {
        this.transactionMappingRepository = transactionMappingRepository;
    }

    @Override
    public TransactionMapping save(TransactionMapping transactionMapping) {
        log.debug("Request to save TransactionMapping : {}", transactionMapping);
        return transactionMappingRepository.save(transactionMapping);
    }

    @Override
    public TransactionMapping update(TransactionMapping transactionMapping) {
        log.debug("Request to update TransactionMapping : {}", transactionMapping);
        return transactionMappingRepository.save(transactionMapping);
    }

    @Override
    public Optional<TransactionMapping> partialUpdate(TransactionMapping transactionMapping) {
        log.debug("Request to partially update TransactionMapping : {}", transactionMapping);

        return transactionMappingRepository
            .findById(transactionMapping.getId())
            .map(existingTransactionMapping -> {
                if (transactionMapping.getMappingId() != null) {
                    existingTransactionMapping.setMappingId(transactionMapping.getMappingId());
                }
                if (transactionMapping.getTranId() != null) {
                    existingTransactionMapping.setTranId(transactionMapping.getTranId());
                }
                if (transactionMapping.getTranTypeId() != null) {
                    existingTransactionMapping.setTranTypeId(transactionMapping.getTranTypeId());
                }
                if (transactionMapping.getTranType() != null) {
                    existingTransactionMapping.setTranType(transactionMapping.getTranType());
                }

                return existingTransactionMapping;
            })
            .map(transactionMappingRepository::save);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TransactionMapping> findAll() {
        log.debug("Request to get all TransactionMappings");
        return transactionMappingRepository.findAll();
    }

    /**
     *  Get all the transactionMappings where Transaction is {@code null}.
     *  @return the list of entities.
     */
    @Transactional(readOnly = true)
    public List<TransactionMapping> findAllWhereTransactionIsNull() {
        log.debug("Request to get all transactionMappings where Transaction is null");
        return StreamSupport
            .stream(transactionMappingRepository.findAll().spliterator(), false)
            .filter(transactionMapping -> transactionMapping.getTransaction() == null)
            .toList();
    }

    /**
     *  Get all the transactionMappings where AchTransaction is {@code null}.
     *  @return the list of entities.
     */
    @Transactional(readOnly = true)
    public List<TransactionMapping> findAllWhereAchTransactionIsNull() {
        log.debug("Request to get all transactionMappings where AchTransaction is null");
        return StreamSupport
            .stream(transactionMappingRepository.findAll().spliterator(), false)
            .filter(transactionMapping -> transactionMapping.getAchTransaction() == null)
            .toList();
    }

    /**
     *  Get all the transactionMappings where WireTransaction is {@code null}.
     *  @return the list of entities.
     */
    @Transactional(readOnly = true)
    public List<TransactionMapping> findAllWhereWireTransactionIsNull() {
        log.debug("Request to get all transactionMappings where WireTransaction is null");
        return StreamSupport
            .stream(transactionMappingRepository.findAll().spliterator(), false)
            .filter(transactionMapping -> transactionMapping.getWireTransaction() == null)
            .toList();
    }

    /**
     *  Get all the transactionMappings where TransferTransaction is {@code null}.
     *  @return the list of entities.
     */
    @Transactional(readOnly = true)
    public List<TransactionMapping> findAllWhereTransferTransactionIsNull() {
        log.debug("Request to get all transactionMappings where TransferTransaction is null");
        return StreamSupport
            .stream(transactionMappingRepository.findAll().spliterator(), false)
            .filter(transactionMapping -> transactionMapping.getTransferTransaction() == null)
            .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<TransactionMapping> findOne(Long id) {
        log.debug("Request to get TransactionMapping : {}", id);
        return transactionMappingRepository.findById(id);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete TransactionMapping : {}", id);
        transactionMappingRepository.deleteById(id);
    }
}
