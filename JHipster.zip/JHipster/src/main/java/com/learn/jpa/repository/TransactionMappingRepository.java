package com.learn.jpa.repository;

import com.learn.jpa.domain.TransactionMapping;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the TransactionMapping entity.
 */
@SuppressWarnings("unused")
@Repository
public interface TransactionMappingRepository extends JpaRepository<TransactionMapping, Long> {}
