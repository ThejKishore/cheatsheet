/**
 * Application security utilities.
 */
package com.learn.jpa.security;
