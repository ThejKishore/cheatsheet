/**
 * Data transfer objects for rest mapping.
 */
package com.learn.jpa.service.dto;
