package com.learn.jpa.service.impl;

import com.learn.jpa.domain.TransferFromAccnt;
import com.learn.jpa.repository.TransferFromAccntRepository;
import com.learn.jpa.service.TransferFromAccntService;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.TransferFromAccnt}.
 */
@Service
@Transactional
public class TransferFromAccntServiceImpl implements TransferFromAccntService {

    private final Logger log = LoggerFactory.getLogger(TransferFromAccntServiceImpl.class);

    private final TransferFromAccntRepository transferFromAccntRepository;

    public TransferFromAccntServiceImpl(TransferFromAccntRepository transferFromAccntRepository) {
        this.transferFromAccntRepository = transferFromAccntRepository;
    }

    @Override
    public TransferFromAccnt save(TransferFromAccnt transferFromAccnt) {
        log.debug("Request to save TransferFromAccnt : {}", transferFromAccnt);
        return transferFromAccntRepository.save(transferFromAccnt);
    }

    @Override
    public TransferFromAccnt update(TransferFromAccnt transferFromAccnt) {
        log.debug("Request to update TransferFromAccnt : {}", transferFromAccnt);
        return transferFromAccntRepository.save(transferFromAccnt);
    }

    @Override
    public Optional<TransferFromAccnt> partialUpdate(TransferFromAccnt transferFromAccnt) {
        log.debug("Request to partially update TransferFromAccnt : {}", transferFromAccnt);

        return transferFromAccntRepository
            .findById(transferFromAccnt.getId())
            .map(existingTransferFromAccnt -> {
                if (transferFromAccnt.getFromAccntID() != null) {
                    existingTransferFromAccnt.setFromAccntID(transferFromAccnt.getFromAccntID());
                }
                if (transferFromAccnt.getFromAccntSk() != null) {
                    existingTransferFromAccnt.setFromAccntSk(transferFromAccnt.getFromAccntSk());
                }
                if (transferFromAccnt.getFromAccntName() != null) {
                    existingTransferFromAccnt.setFromAccntName(transferFromAccnt.getFromAccntName());
                }
                if (transferFromAccnt.getFromAccntAmnt() != null) {
                    existingTransferFromAccnt.setFromAccntAmnt(transferFromAccnt.getFromAccntAmnt());
                }

                return existingTransferFromAccnt;
            })
            .map(transferFromAccntRepository::save);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TransferFromAccnt> findAll() {
        log.debug("Request to get all TransferFromAccnts");
        return transferFromAccntRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<TransferFromAccnt> findOne(Long id) {
        log.debug("Request to get TransferFromAccnt : {}", id);
        return transferFromAccntRepository.findById(id);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete TransferFromAccnt : {}", id);
        transferFromAccntRepository.deleteById(id);
    }
}
