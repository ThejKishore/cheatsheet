/**
 * Application root.
 */
package com.learn.jpa;
