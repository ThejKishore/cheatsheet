package com.learn.jpa.service.impl;

import com.learn.jpa.domain.AchTransaction;
import com.learn.jpa.repository.AchTransactionRepository;
import com.learn.jpa.service.AchTransactionService;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.AchTransaction}.
 */
@Service
@Transactional
public class AchTransactionServiceImpl implements AchTransactionService {

    private final Logger log = LoggerFactory.getLogger(AchTransactionServiceImpl.class);

    private final AchTransactionRepository achTransactionRepository;

    public AchTransactionServiceImpl(AchTransactionRepository achTransactionRepository) {
        this.achTransactionRepository = achTransactionRepository;
    }

    @Override
    public AchTransaction save(AchTransaction achTransaction) {
        log.debug("Request to save AchTransaction : {}", achTransaction);
        return achTransactionRepository.save(achTransaction);
    }

    @Override
    public AchTransaction update(AchTransaction achTransaction) {
        log.debug("Request to update AchTransaction : {}", achTransaction);
        return achTransactionRepository.save(achTransaction);
    }

    @Override
    public Optional<AchTransaction> partialUpdate(AchTransaction achTransaction) {
        log.debug("Request to partially update AchTransaction : {}", achTransaction);

        return achTransactionRepository
            .findById(achTransaction.getId())
            .map(existingAchTransaction -> {
                if (achTransaction.getAchTranId() != null) {
                    existingAchTransaction.setAchTranId(achTransaction.getAchTranId());
                }

                return existingAchTransaction;
            })
            .map(achTransactionRepository::save);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AchTransaction> findAll() {
        log.debug("Request to get all AchTransactions");
        return achTransactionRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<AchTransaction> findOne(Long id) {
        log.debug("Request to get AchTransaction : {}", id);
        return achTransactionRepository.findById(id);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete AchTransaction : {}", id);
        achTransactionRepository.deleteById(id);
    }
}
