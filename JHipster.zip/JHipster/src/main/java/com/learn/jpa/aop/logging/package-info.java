/**
 * Logging aspect.
 */
package com.learn.jpa.aop.logging;
