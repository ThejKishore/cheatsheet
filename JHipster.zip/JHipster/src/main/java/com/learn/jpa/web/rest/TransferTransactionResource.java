package com.learn.jpa.web.rest;

import com.learn.jpa.domain.TransferTransaction;
import com.learn.jpa.repository.TransferTransactionRepository;
import com.learn.jpa.service.TransferTransactionService;
import com.learn.jpa.web.rest.errors.BadRequestAlertException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tech.jhipster.web.util.HeaderUtil;
import tech.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.learn.jpa.domain.TransferTransaction}.
 */
@RestController
@RequestMapping("/api/transfer-transactions")
public class TransferTransactionResource {

    private final Logger log = LoggerFactory.getLogger(TransferTransactionResource.class);

    private static final String ENTITY_NAME = "transferTransaction";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final TransferTransactionService transferTransactionService;

    private final TransferTransactionRepository transferTransactionRepository;

    public TransferTransactionResource(
        TransferTransactionService transferTransactionService,
        TransferTransactionRepository transferTransactionRepository
    ) {
        this.transferTransactionService = transferTransactionService;
        this.transferTransactionRepository = transferTransactionRepository;
    }

    /**
     * {@code POST  /transfer-transactions} : Create a new transferTransaction.
     *
     * @param transferTransaction the transferTransaction to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new transferTransaction, or with status {@code 400 (Bad Request)} if the transferTransaction has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("")
    public ResponseEntity<TransferTransaction> createTransferTransaction(@Valid @RequestBody TransferTransaction transferTransaction)
        throws URISyntaxException {
        log.debug("REST request to save TransferTransaction : {}", transferTransaction);
        if (transferTransaction.getId() != null) {
            throw new BadRequestAlertException("A new transferTransaction cannot already have an ID", ENTITY_NAME, "idexists");
        }
        TransferTransaction result = transferTransactionService.save(transferTransaction);
        return ResponseEntity
            .created(new URI("/api/transfer-transactions/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /transfer-transactions/:id} : Updates an existing transferTransaction.
     *
     * @param id the id of the transferTransaction to save.
     * @param transferTransaction the transferTransaction to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated transferTransaction,
     * or with status {@code 400 (Bad Request)} if the transferTransaction is not valid,
     * or with status {@code 500 (Internal Server Error)} if the transferTransaction couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/{id}")
    public ResponseEntity<TransferTransaction> updateTransferTransaction(
        @PathVariable(value = "id", required = false) final Long id,
        @Valid @RequestBody TransferTransaction transferTransaction
    ) throws URISyntaxException {
        log.debug("REST request to update TransferTransaction : {}, {}", id, transferTransaction);
        if (transferTransaction.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, transferTransaction.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!transferTransactionRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        TransferTransaction result = transferTransactionService.update(transferTransaction);
        return ResponseEntity
            .ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, transferTransaction.getId().toString()))
            .body(result);
    }

    /**
     * {@code PATCH  /transfer-transactions/:id} : Partial updates given fields of an existing transferTransaction, field will ignore if it is null
     *
     * @param id the id of the transferTransaction to save.
     * @param transferTransaction the transferTransaction to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated transferTransaction,
     * or with status {@code 400 (Bad Request)} if the transferTransaction is not valid,
     * or with status {@code 404 (Not Found)} if the transferTransaction is not found,
     * or with status {@code 500 (Internal Server Error)} if the transferTransaction couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PatchMapping(value = "/{id}", consumes = { "application/json", "application/merge-patch+json" })
    public ResponseEntity<TransferTransaction> partialUpdateTransferTransaction(
        @PathVariable(value = "id", required = false) final Long id,
        @NotNull @RequestBody TransferTransaction transferTransaction
    ) throws URISyntaxException {
        log.debug("REST request to partial update TransferTransaction partially : {}, {}", id, transferTransaction);
        if (transferTransaction.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, transferTransaction.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!transferTransactionRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        Optional<TransferTransaction> result = transferTransactionService.partialUpdate(transferTransaction);

        return ResponseUtil.wrapOrNotFound(
            result,
            HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, transferTransaction.getId().toString())
        );
    }

    /**
     * {@code GET  /transfer-transactions} : get all the transferTransactions.
     *
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of transferTransactions in body.
     */
    @GetMapping("")
    public List<TransferTransaction> getAllTransferTransactions() {
        log.debug("REST request to get all TransferTransactions");
        return transferTransactionService.findAll();
    }

    /**
     * {@code GET  /transfer-transactions/:id} : get the "id" transferTransaction.
     *
     * @param id the id of the transferTransaction to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the transferTransaction, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/{id}")
    public ResponseEntity<TransferTransaction> getTransferTransaction(@PathVariable("id") Long id) {
        log.debug("REST request to get TransferTransaction : {}", id);
        Optional<TransferTransaction> transferTransaction = transferTransactionService.findOne(id);
        return ResponseUtil.wrapOrNotFound(transferTransaction);
    }

    /**
     * {@code DELETE  /transfer-transactions/:id} : delete the "id" transferTransaction.
     *
     * @param id the id of the transferTransaction to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTransferTransaction(@PathVariable("id") Long id) {
        log.debug("REST request to delete TransferTransaction : {}", id);
        transferTransactionService.delete(id);
        return ResponseEntity
            .noContent()
            .headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString()))
            .build();
    }
}
