package com.learn.jpa.web.rest;

import com.learn.jpa.domain.TransferFromAccnt;
import com.learn.jpa.repository.TransferFromAccntRepository;
import com.learn.jpa.service.TransferFromAccntService;
import com.learn.jpa.web.rest.errors.BadRequestAlertException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tech.jhipster.web.util.HeaderUtil;
import tech.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.learn.jpa.domain.TransferFromAccnt}.
 */
@RestController
@RequestMapping("/api/transfer-from-accnts")
public class TransferFromAccntResource {

    private final Logger log = LoggerFactory.getLogger(TransferFromAccntResource.class);

    private static final String ENTITY_NAME = "transferFromAccnt";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final TransferFromAccntService transferFromAccntService;

    private final TransferFromAccntRepository transferFromAccntRepository;

    public TransferFromAccntResource(
        TransferFromAccntService transferFromAccntService,
        TransferFromAccntRepository transferFromAccntRepository
    ) {
        this.transferFromAccntService = transferFromAccntService;
        this.transferFromAccntRepository = transferFromAccntRepository;
    }

    /**
     * {@code POST  /transfer-from-accnts} : Create a new transferFromAccnt.
     *
     * @param transferFromAccnt the transferFromAccnt to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new transferFromAccnt, or with status {@code 400 (Bad Request)} if the transferFromAccnt has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("")
    public ResponseEntity<TransferFromAccnt> createTransferFromAccnt(@Valid @RequestBody TransferFromAccnt transferFromAccnt)
        throws URISyntaxException {
        log.debug("REST request to save TransferFromAccnt : {}", transferFromAccnt);
        if (transferFromAccnt.getId() != null) {
            throw new BadRequestAlertException("A new transferFromAccnt cannot already have an ID", ENTITY_NAME, "idexists");
        }
        TransferFromAccnt result = transferFromAccntService.save(transferFromAccnt);
        return ResponseEntity
            .created(new URI("/api/transfer-from-accnts/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /transfer-from-accnts/:id} : Updates an existing transferFromAccnt.
     *
     * @param id the id of the transferFromAccnt to save.
     * @param transferFromAccnt the transferFromAccnt to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated transferFromAccnt,
     * or with status {@code 400 (Bad Request)} if the transferFromAccnt is not valid,
     * or with status {@code 500 (Internal Server Error)} if the transferFromAccnt couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/{id}")
    public ResponseEntity<TransferFromAccnt> updateTransferFromAccnt(
        @PathVariable(value = "id", required = false) final Long id,
        @Valid @RequestBody TransferFromAccnt transferFromAccnt
    ) throws URISyntaxException {
        log.debug("REST request to update TransferFromAccnt : {}, {}", id, transferFromAccnt);
        if (transferFromAccnt.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, transferFromAccnt.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!transferFromAccntRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        TransferFromAccnt result = transferFromAccntService.update(transferFromAccnt);
        return ResponseEntity
            .ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, transferFromAccnt.getId().toString()))
            .body(result);
    }

    /**
     * {@code PATCH  /transfer-from-accnts/:id} : Partial updates given fields of an existing transferFromAccnt, field will ignore if it is null
     *
     * @param id the id of the transferFromAccnt to save.
     * @param transferFromAccnt the transferFromAccnt to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated transferFromAccnt,
     * or with status {@code 400 (Bad Request)} if the transferFromAccnt is not valid,
     * or with status {@code 404 (Not Found)} if the transferFromAccnt is not found,
     * or with status {@code 500 (Internal Server Error)} if the transferFromAccnt couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PatchMapping(value = "/{id}", consumes = { "application/json", "application/merge-patch+json" })
    public ResponseEntity<TransferFromAccnt> partialUpdateTransferFromAccnt(
        @PathVariable(value = "id", required = false) final Long id,
        @NotNull @RequestBody TransferFromAccnt transferFromAccnt
    ) throws URISyntaxException {
        log.debug("REST request to partial update TransferFromAccnt partially : {}, {}", id, transferFromAccnt);
        if (transferFromAccnt.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, transferFromAccnt.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!transferFromAccntRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        Optional<TransferFromAccnt> result = transferFromAccntService.partialUpdate(transferFromAccnt);

        return ResponseUtil.wrapOrNotFound(
            result,
            HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, transferFromAccnt.getId().toString())
        );
    }

    /**
     * {@code GET  /transfer-from-accnts} : get all the transferFromAccnts.
     *
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of transferFromAccnts in body.
     */
    @GetMapping("")
    public List<TransferFromAccnt> getAllTransferFromAccnts() {
        log.debug("REST request to get all TransferFromAccnts");
        return transferFromAccntService.findAll();
    }

    /**
     * {@code GET  /transfer-from-accnts/:id} : get the "id" transferFromAccnt.
     *
     * @param id the id of the transferFromAccnt to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the transferFromAccnt, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/{id}")
    public ResponseEntity<TransferFromAccnt> getTransferFromAccnt(@PathVariable("id") Long id) {
        log.debug("REST request to get TransferFromAccnt : {}", id);
        Optional<TransferFromAccnt> transferFromAccnt = transferFromAccntService.findOne(id);
        return ResponseUtil.wrapOrNotFound(transferFromAccnt);
    }

    /**
     * {@code DELETE  /transfer-from-accnts/:id} : delete the "id" transferFromAccnt.
     *
     * @param id the id of the transferFromAccnt to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTransferFromAccnt(@PathVariable("id") Long id) {
        log.debug("REST request to delete TransferFromAccnt : {}", id);
        transferFromAccntService.delete(id);
        return ResponseEntity
            .noContent()
            .headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString()))
            .build();
    }
}
