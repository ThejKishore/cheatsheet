package com.learn.jpa.service.impl;

import com.learn.jpa.domain.Transaction;
import com.learn.jpa.repository.TransactionRepository;
import com.learn.jpa.service.TransactionService;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.Transaction}.
 */
@Service
@Transactional
public class TransactionServiceImpl implements TransactionService {

    private final Logger log = LoggerFactory.getLogger(TransactionServiceImpl.class);

    private final TransactionRepository transactionRepository;

    public TransactionServiceImpl(TransactionRepository transactionRepository) {
        this.transactionRepository = transactionRepository;
    }

    @Override
    public Transaction save(Transaction transaction) {
        log.debug("Request to save Transaction : {}", transaction);
        return transactionRepository.save(transaction);
    }

    @Override
    public Transaction update(Transaction transaction) {
        log.debug("Request to update Transaction : {}", transaction);
        return transactionRepository.save(transaction);
    }

    @Override
    public Optional<Transaction> partialUpdate(Transaction transaction) {
        log.debug("Request to partially update Transaction : {}", transaction);

        return transactionRepository
            .findById(transaction.getId())
            .map(existingTransaction -> {
                if (transaction.getTranId() != null) {
                    existingTransaction.setTranId(transaction.getTranId());
                }
                if (transaction.getTranName() != null) {
                    existingTransaction.setTranName(transaction.getTranName());
                }
                if (transaction.getFrmCnt() != null) {
                    existingTransaction.setFrmCnt(transaction.getFrmCnt());
                }
                if (transaction.getToCnt() != null) {
                    existingTransaction.setToCnt(transaction.getToCnt());
                }
                if (transaction.getTotalAmount() != null) {
                    existingTransaction.setTotalAmount(transaction.getTotalAmount());
                }
                if (transaction.getCreatedDate() != null) {
                    existingTransaction.setCreatedDate(transaction.getCreatedDate());
                }
                if (transaction.getUpdatedDate() != null) {
                    existingTransaction.setUpdatedDate(transaction.getUpdatedDate());
                }
                if (transaction.getCreatedBy() != null) {
                    existingTransaction.setCreatedBy(transaction.getCreatedBy());
                }
                if (transaction.getUpdatedBy() != null) {
                    existingTransaction.setUpdatedBy(transaction.getUpdatedBy());
                }
                if (transaction.getSettlementDate() != null) {
                    existingTransaction.setSettlementDate(transaction.getSettlementDate());
                }
                if (transaction.getFrequencyType() != null) {
                    existingTransaction.setFrequencyType(transaction.getFrequencyType());
                }
                if (transaction.getTranType() != null) {
                    existingTransaction.setTranType(transaction.getTranType());
                }
                if (transaction.getProfileId() != null) {
                    existingTransaction.setProfileId(transaction.getProfileId());
                }
                if (transaction.getProfileName() != null) {
                    existingTransaction.setProfileName(transaction.getProfileName());
                }
                if (transaction.getNarrative() != null) {
                    existingTransaction.setNarrative(transaction.getNarrative());
                }
                if (transaction.getPrecedingNarrative() != null) {
                    existingTransaction.setPrecedingNarrative(transaction.getPrecedingNarrative());
                }
                if (transaction.getCustomNarrative() != null) {
                    existingTransaction.setCustomNarrative(transaction.getCustomNarrative());
                }
                if (transaction.getSystemGeneratedNarrative() != null) {
                    existingTransaction.setSystemGeneratedNarrative(transaction.getSystemGeneratedNarrative());
                }

                return existingTransaction;
            })
            .map(transactionRepository::save);
    }

    @Override
    @Transactional(readOnly = true)
    public List<Transaction> findAll() {
        log.debug("Request to get all Transactions");
        return transactionRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<Transaction> findOne(Long id) {
        log.debug("Request to get Transaction : {}", id);
        return transactionRepository.findById(id);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete Transaction : {}", id);
        transactionRepository.deleteById(id);
    }
}
