package com.learn.jpa.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.ZonedDateTime;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * A Transaction.
 */
@Entity
@Table(name = "jhi_transaction")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@SuppressWarnings("common-java:DuplicatedBlocks")
public class Transaction implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "id")
    private Long id;

    @NotNull
    @Column(name = "tran_id", nullable = false, unique = true)
    private Long tranId;

    @Column(name = "tran_name")
    private String tranName;

    @Column(name = "frm_cnt")
    private Integer frmCnt;

    @Column(name = "to_cnt")
    private Integer toCnt;

    @Column(name = "total_amount", precision = 21, scale = 2)
    private BigDecimal totalAmount;

    @Column(name = "created_date")
    private ZonedDateTime createdDate;

    @Column(name = "updated_date")
    private ZonedDateTime updatedDate;

    @Column(name = "created_by")
    private String createdBy;

    @Column(name = "updated_by")
    private String updatedBy;

    @Column(name = "settlement_date")
    private ZonedDateTime settlementDate;

    @Column(name = "frequency_type")
    private String frequencyType;

    @Column(name = "tran_type")
    private String tranType;

    @Column(name = "profile_id")
    private Long profileId;

    @Column(name = "profile_name")
    private String profileName;

    @Column(name = "narrative")
    private String narrative;

    @Column(name = "preceding_narrative")
    private String precedingNarrative;

    @Column(name = "custom_narrative")
    private String customNarrative;

    @Column(name = "system_generated_narrative")
    private String systemGeneratedNarrative;

    @JsonIgnoreProperties(value = { "transaction", "achTransaction", "wireTransaction", "transferTransaction" }, allowSetters = true)
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(unique = true)
    private TransactionMapping transactionMapping;

    @JsonIgnoreProperties(value = { "transaction" }, allowSetters = true)
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(unique = true)
    private TransactionApproval transactionApproval;

    @JsonIgnoreProperties(value = { "transaction" }, allowSetters = true)
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(unique = true)
    private TransactionReview transactionReview;

    // jhipster-needle-entity-add-field - JHipster will add fields here

    public Long getId() {
        return this.id;
    }

    public Transaction id(Long id) {
        this.setId(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getTranId() {
        return this.tranId;
    }

    public Transaction tranId(Long tranId) {
        this.setTranId(tranId);
        return this;
    }

    public void setTranId(Long tranId) {
        this.tranId = tranId;
    }

    public String getTranName() {
        return this.tranName;
    }

    public Transaction tranName(String tranName) {
        this.setTranName(tranName);
        return this;
    }

    public void setTranName(String tranName) {
        this.tranName = tranName;
    }

    public Integer getFrmCnt() {
        return this.frmCnt;
    }

    public Transaction frmCnt(Integer frmCnt) {
        this.setFrmCnt(frmCnt);
        return this;
    }

    public void setFrmCnt(Integer frmCnt) {
        this.frmCnt = frmCnt;
    }

    public Integer getToCnt() {
        return this.toCnt;
    }

    public Transaction toCnt(Integer toCnt) {
        this.setToCnt(toCnt);
        return this;
    }

    public void setToCnt(Integer toCnt) {
        this.toCnt = toCnt;
    }

    public BigDecimal getTotalAmount() {
        return this.totalAmount;
    }

    public Transaction totalAmount(BigDecimal totalAmount) {
        this.setTotalAmount(totalAmount);
        return this;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public ZonedDateTime getCreatedDate() {
        return this.createdDate;
    }

    public Transaction createdDate(ZonedDateTime createdDate) {
        this.setCreatedDate(createdDate);
        return this;
    }

    public void setCreatedDate(ZonedDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public ZonedDateTime getUpdatedDate() {
        return this.updatedDate;
    }

    public Transaction updatedDate(ZonedDateTime updatedDate) {
        this.setUpdatedDate(updatedDate);
        return this;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getCreatedBy() {
        return this.createdBy;
    }

    public Transaction createdBy(String createdBy) {
        this.setCreatedBy(createdBy);
        return this;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return this.updatedBy;
    }

    public Transaction updatedBy(String updatedBy) {
        this.setUpdatedBy(updatedBy);
        return this;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public ZonedDateTime getSettlementDate() {
        return this.settlementDate;
    }

    public Transaction settlementDate(ZonedDateTime settlementDate) {
        this.setSettlementDate(settlementDate);
        return this;
    }

    public void setSettlementDate(ZonedDateTime settlementDate) {
        this.settlementDate = settlementDate;
    }

    public String getFrequencyType() {
        return this.frequencyType;
    }

    public Transaction frequencyType(String frequencyType) {
        this.setFrequencyType(frequencyType);
        return this;
    }

    public void setFrequencyType(String frequencyType) {
        this.frequencyType = frequencyType;
    }

    public String getTranType() {
        return this.tranType;
    }

    public Transaction tranType(String tranType) {
        this.setTranType(tranType);
        return this;
    }

    public void setTranType(String tranType) {
        this.tranType = tranType;
    }

    public Long getProfileId() {
        return this.profileId;
    }

    public Transaction profileId(Long profileId) {
        this.setProfileId(profileId);
        return this;
    }

    public void setProfileId(Long profileId) {
        this.profileId = profileId;
    }

    public String getProfileName() {
        return this.profileName;
    }

    public Transaction profileName(String profileName) {
        this.setProfileName(profileName);
        return this;
    }

    public void setProfileName(String profileName) {
        this.profileName = profileName;
    }

    public String getNarrative() {
        return this.narrative;
    }

    public Transaction narrative(String narrative) {
        this.setNarrative(narrative);
        return this;
    }

    public void setNarrative(String narrative) {
        this.narrative = narrative;
    }

    public String getPrecedingNarrative() {
        return this.precedingNarrative;
    }

    public Transaction precedingNarrative(String precedingNarrative) {
        this.setPrecedingNarrative(precedingNarrative);
        return this;
    }

    public void setPrecedingNarrative(String precedingNarrative) {
        this.precedingNarrative = precedingNarrative;
    }

    public String getCustomNarrative() {
        return this.customNarrative;
    }

    public Transaction customNarrative(String customNarrative) {
        this.setCustomNarrative(customNarrative);
        return this;
    }

    public void setCustomNarrative(String customNarrative) {
        this.customNarrative = customNarrative;
    }

    public String getSystemGeneratedNarrative() {
        return this.systemGeneratedNarrative;
    }

    public Transaction systemGeneratedNarrative(String systemGeneratedNarrative) {
        this.setSystemGeneratedNarrative(systemGeneratedNarrative);
        return this;
    }

    public void setSystemGeneratedNarrative(String systemGeneratedNarrative) {
        this.systemGeneratedNarrative = systemGeneratedNarrative;
    }

    public TransactionMapping getTransactionMapping() {
        return this.transactionMapping;
    }

    public void setTransactionMapping(TransactionMapping transactionMapping) {
        this.transactionMapping = transactionMapping;
    }

    public Transaction transactionMapping(TransactionMapping transactionMapping) {
        this.setTransactionMapping(transactionMapping);
        return this;
    }

    public TransactionApproval getTransactionApproval() {
        return this.transactionApproval;
    }

    public void setTransactionApproval(TransactionApproval transactionApproval) {
        this.transactionApproval = transactionApproval;
    }

    public Transaction transactionApproval(TransactionApproval transactionApproval) {
        this.setTransactionApproval(transactionApproval);
        return this;
    }

    public TransactionReview getTransactionReview() {
        return this.transactionReview;
    }

    public void setTransactionReview(TransactionReview transactionReview) {
        this.transactionReview = transactionReview;
    }

    public Transaction transactionReview(TransactionReview transactionReview) {
        this.setTransactionReview(transactionReview);
        return this;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Transaction)) {
            return false;
        }
        return getId() != null && getId().equals(((Transaction) o).getId());
    }

    @Override
    public int hashCode() {
        // see https://vladmihalcea.com/how-to-implement-equals-and-hashcode-using-the-jpa-entity-identifier/
        return getClass().hashCode();
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "Transaction{" +
            "id=" + getId() +
            ", tranId=" + getTranId() +
            ", tranName='" + getTranName() + "'" +
            ", frmCnt=" + getFrmCnt() +
            ", toCnt=" + getToCnt() +
            ", totalAmount=" + getTotalAmount() +
            ", createdDate='" + getCreatedDate() + "'" +
            ", updatedDate='" + getUpdatedDate() + "'" +
            ", createdBy='" + getCreatedBy() + "'" +
            ", updatedBy='" + getUpdatedBy() + "'" +
            ", settlementDate='" + getSettlementDate() + "'" +
            ", frequencyType='" + getFrequencyType() + "'" +
            ", tranType='" + getTranType() + "'" +
            ", profileId=" + getProfileId() +
            ", profileName='" + getProfileName() + "'" +
            ", narrative='" + getNarrative() + "'" +
            ", precedingNarrative='" + getPrecedingNarrative() + "'" +
            ", customNarrative='" + getCustomNarrative() + "'" +
            ", systemGeneratedNarrative='" + getSystemGeneratedNarrative() + "'" +
            "}";
    }
}
