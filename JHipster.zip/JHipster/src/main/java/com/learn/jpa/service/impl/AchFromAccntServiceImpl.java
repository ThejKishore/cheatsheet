package com.learn.jpa.service.impl;

import com.learn.jpa.domain.AchFromAccnt;
import com.learn.jpa.repository.AchFromAccntRepository;
import com.learn.jpa.service.AchFromAccntService;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.AchFromAccnt}.
 */
@Service
@Transactional
public class AchFromAccntServiceImpl implements AchFromAccntService {

    private final Logger log = LoggerFactory.getLogger(AchFromAccntServiceImpl.class);

    private final AchFromAccntRepository achFromAccntRepository;

    public AchFromAccntServiceImpl(AchFromAccntRepository achFromAccntRepository) {
        this.achFromAccntRepository = achFromAccntRepository;
    }

    @Override
    public AchFromAccnt save(AchFromAccnt achFromAccnt) {
        log.debug("Request to save AchFromAccnt : {}", achFromAccnt);
        return achFromAccntRepository.save(achFromAccnt);
    }

    @Override
    public AchFromAccnt update(AchFromAccnt achFromAccnt) {
        log.debug("Request to update AchFromAccnt : {}", achFromAccnt);
        return achFromAccntRepository.save(achFromAccnt);
    }

    @Override
    public Optional<AchFromAccnt> partialUpdate(AchFromAccnt achFromAccnt) {
        log.debug("Request to partially update AchFromAccnt : {}", achFromAccnt);

        return achFromAccntRepository
            .findById(achFromAccnt.getId())
            .map(existingAchFromAccnt -> {
                if (achFromAccnt.getFromAccntID() != null) {
                    existingAchFromAccnt.setFromAccntID(achFromAccnt.getFromAccntID());
                }
                if (achFromAccnt.getFromAccntSk() != null) {
                    existingAchFromAccnt.setFromAccntSk(achFromAccnt.getFromAccntSk());
                }
                if (achFromAccnt.getFromAccntName() != null) {
                    existingAchFromAccnt.setFromAccntName(achFromAccnt.getFromAccntName());
                }
                if (achFromAccnt.getFromAccntAmnt() != null) {
                    existingAchFromAccnt.setFromAccntAmnt(achFromAccnt.getFromAccntAmnt());
                }

                return existingAchFromAccnt;
            })
            .map(achFromAccntRepository::save);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AchFromAccnt> findAll() {
        log.debug("Request to get all AchFromAccnts");
        return achFromAccntRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<AchFromAccnt> findOne(Long id) {
        log.debug("Request to get AchFromAccnt : {}", id);
        return achFromAccntRepository.findById(id);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete AchFromAccnt : {}", id);
        achFromAccntRepository.deleteById(id);
    }
}
