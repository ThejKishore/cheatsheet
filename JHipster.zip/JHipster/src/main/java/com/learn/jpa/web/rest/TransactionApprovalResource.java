package com.learn.jpa.web.rest;

import com.learn.jpa.domain.TransactionApproval;
import com.learn.jpa.repository.TransactionApprovalRepository;
import com.learn.jpa.service.TransactionApprovalService;
import com.learn.jpa.web.rest.errors.BadRequestAlertException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tech.jhipster.web.util.HeaderUtil;
import tech.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.learn.jpa.domain.TransactionApproval}.
 */
@RestController
@RequestMapping("/api/transaction-approvals")
public class TransactionApprovalResource {

    private final Logger log = LoggerFactory.getLogger(TransactionApprovalResource.class);

    private static final String ENTITY_NAME = "transactionApproval";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final TransactionApprovalService transactionApprovalService;

    private final TransactionApprovalRepository transactionApprovalRepository;

    public TransactionApprovalResource(
        TransactionApprovalService transactionApprovalService,
        TransactionApprovalRepository transactionApprovalRepository
    ) {
        this.transactionApprovalService = transactionApprovalService;
        this.transactionApprovalRepository = transactionApprovalRepository;
    }

    /**
     * {@code POST  /transaction-approvals} : Create a new transactionApproval.
     *
     * @param transactionApproval the transactionApproval to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new transactionApproval, or with status {@code 400 (Bad Request)} if the transactionApproval has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("")
    public ResponseEntity<TransactionApproval> createTransactionApproval(@Valid @RequestBody TransactionApproval transactionApproval)
        throws URISyntaxException {
        log.debug("REST request to save TransactionApproval : {}", transactionApproval);
        if (transactionApproval.getId() != null) {
            throw new BadRequestAlertException("A new transactionApproval cannot already have an ID", ENTITY_NAME, "idexists");
        }
        TransactionApproval result = transactionApprovalService.save(transactionApproval);
        return ResponseEntity
            .created(new URI("/api/transaction-approvals/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /transaction-approvals/:id} : Updates an existing transactionApproval.
     *
     * @param id the id of the transactionApproval to save.
     * @param transactionApproval the transactionApproval to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated transactionApproval,
     * or with status {@code 400 (Bad Request)} if the transactionApproval is not valid,
     * or with status {@code 500 (Internal Server Error)} if the transactionApproval couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/{id}")
    public ResponseEntity<TransactionApproval> updateTransactionApproval(
        @PathVariable(value = "id", required = false) final Long id,
        @Valid @RequestBody TransactionApproval transactionApproval
    ) throws URISyntaxException {
        log.debug("REST request to update TransactionApproval : {}, {}", id, transactionApproval);
        if (transactionApproval.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, transactionApproval.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!transactionApprovalRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        TransactionApproval result = transactionApprovalService.update(transactionApproval);
        return ResponseEntity
            .ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, transactionApproval.getId().toString()))
            .body(result);
    }

    /**
     * {@code PATCH  /transaction-approvals/:id} : Partial updates given fields of an existing transactionApproval, field will ignore if it is null
     *
     * @param id the id of the transactionApproval to save.
     * @param transactionApproval the transactionApproval to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated transactionApproval,
     * or with status {@code 400 (Bad Request)} if the transactionApproval is not valid,
     * or with status {@code 404 (Not Found)} if the transactionApproval is not found,
     * or with status {@code 500 (Internal Server Error)} if the transactionApproval couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PatchMapping(value = "/{id}", consumes = { "application/json", "application/merge-patch+json" })
    public ResponseEntity<TransactionApproval> partialUpdateTransactionApproval(
        @PathVariable(value = "id", required = false) final Long id,
        @NotNull @RequestBody TransactionApproval transactionApproval
    ) throws URISyntaxException {
        log.debug("REST request to partial update TransactionApproval partially : {}, {}", id, transactionApproval);
        if (transactionApproval.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, transactionApproval.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!transactionApprovalRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        Optional<TransactionApproval> result = transactionApprovalService.partialUpdate(transactionApproval);

        return ResponseUtil.wrapOrNotFound(
            result,
            HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, transactionApproval.getId().toString())
        );
    }

    /**
     * {@code GET  /transaction-approvals} : get all the transactionApprovals.
     *
     * @param filter the filter of the request.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of transactionApprovals in body.
     */
    @GetMapping("")
    public List<TransactionApproval> getAllTransactionApprovals(@RequestParam(name = "filter", required = false) String filter) {
        if ("transaction-is-null".equals(filter)) {
            log.debug("REST request to get all TransactionApprovals where transaction is null");
            return transactionApprovalService.findAllWhereTransactionIsNull();
        }
        log.debug("REST request to get all TransactionApprovals");
        return transactionApprovalService.findAll();
    }

    /**
     * {@code GET  /transaction-approvals/:id} : get the "id" transactionApproval.
     *
     * @param id the id of the transactionApproval to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the transactionApproval, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/{id}")
    public ResponseEntity<TransactionApproval> getTransactionApproval(@PathVariable("id") Long id) {
        log.debug("REST request to get TransactionApproval : {}", id);
        Optional<TransactionApproval> transactionApproval = transactionApprovalService.findOne(id);
        return ResponseUtil.wrapOrNotFound(transactionApproval);
    }

    /**
     * {@code DELETE  /transaction-approvals/:id} : delete the "id" transactionApproval.
     *
     * @param id the id of the transactionApproval to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTransactionApproval(@PathVariable("id") Long id) {
        log.debug("REST request to delete TransactionApproval : {}", id);
        transactionApprovalService.delete(id);
        return ResponseEntity
            .noContent()
            .headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString()))
            .build();
    }
}
