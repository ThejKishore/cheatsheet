package com.learn.jpa.web.rest;

import com.learn.jpa.domain.WireBeneficiary;
import com.learn.jpa.repository.WireBeneficiaryRepository;
import com.learn.jpa.service.WireBeneficiaryService;
import com.learn.jpa.web.rest.errors.BadRequestAlertException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tech.jhipster.web.util.HeaderUtil;
import tech.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.learn.jpa.domain.WireBeneficiary}.
 */
@RestController
@RequestMapping("/api/wire-beneficiaries")
public class WireBeneficiaryResource {

    private final Logger log = LoggerFactory.getLogger(WireBeneficiaryResource.class);

    private static final String ENTITY_NAME = "wireBeneficiary";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final WireBeneficiaryService wireBeneficiaryService;

    private final WireBeneficiaryRepository wireBeneficiaryRepository;

    public WireBeneficiaryResource(WireBeneficiaryService wireBeneficiaryService, WireBeneficiaryRepository wireBeneficiaryRepository) {
        this.wireBeneficiaryService = wireBeneficiaryService;
        this.wireBeneficiaryRepository = wireBeneficiaryRepository;
    }

    /**
     * {@code POST  /wire-beneficiaries} : Create a new wireBeneficiary.
     *
     * @param wireBeneficiary the wireBeneficiary to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new wireBeneficiary, or with status {@code 400 (Bad Request)} if the wireBeneficiary has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("")
    public ResponseEntity<WireBeneficiary> createWireBeneficiary(@Valid @RequestBody WireBeneficiary wireBeneficiary)
        throws URISyntaxException {
        log.debug("REST request to save WireBeneficiary : {}", wireBeneficiary);
        if (wireBeneficiary.getId() != null) {
            throw new BadRequestAlertException("A new wireBeneficiary cannot already have an ID", ENTITY_NAME, "idexists");
        }
        WireBeneficiary result = wireBeneficiaryService.save(wireBeneficiary);
        return ResponseEntity
            .created(new URI("/api/wire-beneficiaries/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /wire-beneficiaries/:id} : Updates an existing wireBeneficiary.
     *
     * @param id the id of the wireBeneficiary to save.
     * @param wireBeneficiary the wireBeneficiary to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated wireBeneficiary,
     * or with status {@code 400 (Bad Request)} if the wireBeneficiary is not valid,
     * or with status {@code 500 (Internal Server Error)} if the wireBeneficiary couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/{id}")
    public ResponseEntity<WireBeneficiary> updateWireBeneficiary(
        @PathVariable(value = "id", required = false) final Long id,
        @Valid @RequestBody WireBeneficiary wireBeneficiary
    ) throws URISyntaxException {
        log.debug("REST request to update WireBeneficiary : {}, {}", id, wireBeneficiary);
        if (wireBeneficiary.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, wireBeneficiary.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!wireBeneficiaryRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        WireBeneficiary result = wireBeneficiaryService.update(wireBeneficiary);
        return ResponseEntity
            .ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, wireBeneficiary.getId().toString()))
            .body(result);
    }

    /**
     * {@code PATCH  /wire-beneficiaries/:id} : Partial updates given fields of an existing wireBeneficiary, field will ignore if it is null
     *
     * @param id the id of the wireBeneficiary to save.
     * @param wireBeneficiary the wireBeneficiary to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated wireBeneficiary,
     * or with status {@code 400 (Bad Request)} if the wireBeneficiary is not valid,
     * or with status {@code 404 (Not Found)} if the wireBeneficiary is not found,
     * or with status {@code 500 (Internal Server Error)} if the wireBeneficiary couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PatchMapping(value = "/{id}", consumes = { "application/json", "application/merge-patch+json" })
    public ResponseEntity<WireBeneficiary> partialUpdateWireBeneficiary(
        @PathVariable(value = "id", required = false) final Long id,
        @NotNull @RequestBody WireBeneficiary wireBeneficiary
    ) throws URISyntaxException {
        log.debug("REST request to partial update WireBeneficiary partially : {}, {}", id, wireBeneficiary);
        if (wireBeneficiary.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, wireBeneficiary.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!wireBeneficiaryRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        Optional<WireBeneficiary> result = wireBeneficiaryService.partialUpdate(wireBeneficiary);

        return ResponseUtil.wrapOrNotFound(
            result,
            HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, wireBeneficiary.getId().toString())
        );
    }

    /**
     * {@code GET  /wire-beneficiaries} : get all the wireBeneficiaries.
     *
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of wireBeneficiaries in body.
     */
    @GetMapping("")
    public List<WireBeneficiary> getAllWireBeneficiaries() {
        log.debug("REST request to get all WireBeneficiaries");
        return wireBeneficiaryService.findAll();
    }

    /**
     * {@code GET  /wire-beneficiaries/:id} : get the "id" wireBeneficiary.
     *
     * @param id the id of the wireBeneficiary to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the wireBeneficiary, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/{id}")
    public ResponseEntity<WireBeneficiary> getWireBeneficiary(@PathVariable("id") Long id) {
        log.debug("REST request to get WireBeneficiary : {}", id);
        Optional<WireBeneficiary> wireBeneficiary = wireBeneficiaryService.findOne(id);
        return ResponseUtil.wrapOrNotFound(wireBeneficiary);
    }

    /**
     * {@code DELETE  /wire-beneficiaries/:id} : delete the "id" wireBeneficiary.
     *
     * @param id the id of the wireBeneficiary to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteWireBeneficiary(@PathVariable("id") Long id) {
        log.debug("REST request to delete WireBeneficiary : {}", id);
        wireBeneficiaryService.delete(id);
        return ResponseEntity
            .noContent()
            .headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString()))
            .build();
    }
}
