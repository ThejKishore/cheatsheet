package com.learn.jpa.service.impl;

import com.learn.jpa.domain.TransactionApproval;
import com.learn.jpa.repository.TransactionApprovalRepository;
import com.learn.jpa.service.TransactionApprovalService;
import java.util.List;
import java.util.Optional;
import java.util.stream.StreamSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.TransactionApproval}.
 */
@Service
@Transactional
public class TransactionApprovalServiceImpl implements TransactionApprovalService {

    private final Logger log = LoggerFactory.getLogger(TransactionApprovalServiceImpl.class);

    private final TransactionApprovalRepository transactionApprovalRepository;

    public TransactionApprovalServiceImpl(TransactionApprovalRepository transactionApprovalRepository) {
        this.transactionApprovalRepository = transactionApprovalRepository;
    }

    @Override
    public TransactionApproval save(TransactionApproval transactionApproval) {
        log.debug("Request to save TransactionApproval : {}", transactionApproval);
        return transactionApprovalRepository.save(transactionApproval);
    }

    @Override
    public TransactionApproval update(TransactionApproval transactionApproval) {
        log.debug("Request to update TransactionApproval : {}", transactionApproval);
        return transactionApprovalRepository.save(transactionApproval);
    }

    @Override
    public Optional<TransactionApproval> partialUpdate(TransactionApproval transactionApproval) {
        log.debug("Request to partially update TransactionApproval : {}", transactionApproval);

        return transactionApprovalRepository
            .findById(transactionApproval.getId())
            .map(existingTransactionApproval -> {
                if (transactionApproval.getTranId() != null) {
                    existingTransactionApproval.setTranId(transactionApproval.getTranId());
                }
                if (transactionApproval.getFirstApprover() != null) {
                    existingTransactionApproval.setFirstApprover(transactionApproval.getFirstApprover());
                }
                if (transactionApproval.getFirstApprovalReason() != null) {
                    existingTransactionApproval.setFirstApprovalReason(transactionApproval.getFirstApprovalReason());
                }
                if (transactionApproval.getFirstApprovalDate() != null) {
                    existingTransactionApproval.setFirstApprovalDate(transactionApproval.getFirstApprovalDate());
                }
                if (transactionApproval.getFirstRejector() != null) {
                    existingTransactionApproval.setFirstRejector(transactionApproval.getFirstRejector());
                }
                if (transactionApproval.getFirstRejectorReason() != null) {
                    existingTransactionApproval.setFirstRejectorReason(transactionApproval.getFirstRejectorReason());
                }
                if (transactionApproval.getFirstRejectedDate() != null) {
                    existingTransactionApproval.setFirstRejectedDate(transactionApproval.getFirstRejectedDate());
                }
                if (transactionApproval.getSecondApprover() != null) {
                    existingTransactionApproval.setSecondApprover(transactionApproval.getSecondApprover());
                }
                if (transactionApproval.getSecondApprovalReason() != null) {
                    existingTransactionApproval.setSecondApprovalReason(transactionApproval.getSecondApprovalReason());
                }
                if (transactionApproval.getSecondApprovalDate() != null) {
                    existingTransactionApproval.setSecondApprovalDate(transactionApproval.getSecondApprovalDate());
                }
                if (transactionApproval.getSecondRejector() != null) {
                    existingTransactionApproval.setSecondRejector(transactionApproval.getSecondRejector());
                }
                if (transactionApproval.getSecondRejectorReason() != null) {
                    existingTransactionApproval.setSecondRejectorReason(transactionApproval.getSecondRejectorReason());
                }
                if (transactionApproval.getSecondRejectedDate() != null) {
                    existingTransactionApproval.setSecondRejectedDate(transactionApproval.getSecondRejectedDate());
                }

                return existingTransactionApproval;
            })
            .map(transactionApprovalRepository::save);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TransactionApproval> findAll() {
        log.debug("Request to get all TransactionApprovals");
        return transactionApprovalRepository.findAll();
    }

    /**
     *  Get all the transactionApprovals where Transaction is {@code null}.
     *  @return the list of entities.
     */
    @Transactional(readOnly = true)
    public List<TransactionApproval> findAllWhereTransactionIsNull() {
        log.debug("Request to get all transactionApprovals where Transaction is null");
        return StreamSupport
            .stream(transactionApprovalRepository.findAll().spliterator(), false)
            .filter(transactionApproval -> transactionApproval.getTransaction() == null)
            .toList();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<TransactionApproval> findOne(Long id) {
        log.debug("Request to get TransactionApproval : {}", id);
        return transactionApprovalRepository.findById(id);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete TransactionApproval : {}", id);
        transactionApprovalRepository.deleteById(id);
    }
}
