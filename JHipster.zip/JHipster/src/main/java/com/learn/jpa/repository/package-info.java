/**
 * Repository layer.
 */
package com.learn.jpa.repository;
