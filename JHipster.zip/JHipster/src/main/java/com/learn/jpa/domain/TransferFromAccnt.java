package com.learn.jpa.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.math.BigDecimal;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * A TransferFromAccnt.
 */
@Entity
@Table(name = "transfer_from_accnt")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@SuppressWarnings("common-java:DuplicatedBlocks")
public class TransferFromAccnt implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "id")
    private Long id;

    @NotNull
    @Column(name = "from_accnt_id", nullable = false, unique = true)
    private Long fromAccntID;

    @Column(name = "from_accnt_sk")
    private Long fromAccntSk;

    @Column(name = "from_accnt_name")
    private String fromAccntName;

    @Column(name = "from_accnt_amnt", precision = 21, scale = 2)
    private BigDecimal fromAccntAmnt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JsonIgnoreProperties(value = { "transactionMapping", "transferFromAccnts", "transferToAccnts" }, allowSetters = true)
    private TransferTransaction transferTransaction;

    // jhipster-needle-entity-add-field - JHipster will add fields here

    public Long getId() {
        return this.id;
    }

    public TransferFromAccnt id(Long id) {
        this.setId(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getFromAccntID() {
        return this.fromAccntID;
    }

    public TransferFromAccnt fromAccntID(Long fromAccntID) {
        this.setFromAccntID(fromAccntID);
        return this;
    }

    public void setFromAccntID(Long fromAccntID) {
        this.fromAccntID = fromAccntID;
    }

    public Long getFromAccntSk() {
        return this.fromAccntSk;
    }

    public TransferFromAccnt fromAccntSk(Long fromAccntSk) {
        this.setFromAccntSk(fromAccntSk);
        return this;
    }

    public void setFromAccntSk(Long fromAccntSk) {
        this.fromAccntSk = fromAccntSk;
    }

    public String getFromAccntName() {
        return this.fromAccntName;
    }

    public TransferFromAccnt fromAccntName(String fromAccntName) {
        this.setFromAccntName(fromAccntName);
        return this;
    }

    public void setFromAccntName(String fromAccntName) {
        this.fromAccntName = fromAccntName;
    }

    public BigDecimal getFromAccntAmnt() {
        return this.fromAccntAmnt;
    }

    public TransferFromAccnt fromAccntAmnt(BigDecimal fromAccntAmnt) {
        this.setFromAccntAmnt(fromAccntAmnt);
        return this;
    }

    public void setFromAccntAmnt(BigDecimal fromAccntAmnt) {
        this.fromAccntAmnt = fromAccntAmnt;
    }

    public TransferTransaction getTransferTransaction() {
        return this.transferTransaction;
    }

    public void setTransferTransaction(TransferTransaction transferTransaction) {
        this.transferTransaction = transferTransaction;
    }

    public TransferFromAccnt transferTransaction(TransferTransaction transferTransaction) {
        this.setTransferTransaction(transferTransaction);
        return this;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TransferFromAccnt)) {
            return false;
        }
        return getId() != null && getId().equals(((TransferFromAccnt) o).getId());
    }

    @Override
    public int hashCode() {
        // see https://vladmihalcea.com/how-to-implement-equals-and-hashcode-using-the-jpa-entity-identifier/
        return getClass().hashCode();
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "TransferFromAccnt{" +
            "id=" + getId() +
            ", fromAccntID=" + getFromAccntID() +
            ", fromAccntSk=" + getFromAccntSk() +
            ", fromAccntName='" + getFromAccntName() + "'" +
            ", fromAccntAmnt=" + getFromAccntAmnt() +
            "}";
    }
}
