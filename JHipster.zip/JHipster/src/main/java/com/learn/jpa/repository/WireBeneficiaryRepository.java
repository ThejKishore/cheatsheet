package com.learn.jpa.repository;

import com.learn.jpa.domain.WireBeneficiary;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the WireBeneficiary entity.
 */
@SuppressWarnings("unused")
@Repository
public interface WireBeneficiaryRepository extends JpaRepository<WireBeneficiary, Long> {}
