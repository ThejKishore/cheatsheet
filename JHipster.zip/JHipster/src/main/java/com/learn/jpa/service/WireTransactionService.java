package com.learn.jpa.service;

import com.learn.jpa.domain.WireTransaction;
import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing {@link com.learn.jpa.domain.WireTransaction}.
 */
public interface WireTransactionService {
    /**
     * Save a wireTransaction.
     *
     * @param wireTransaction the entity to save.
     * @return the persisted entity.
     */
    WireTransaction save(WireTransaction wireTransaction);

    /**
     * Updates a wireTransaction.
     *
     * @param wireTransaction the entity to update.
     * @return the persisted entity.
     */
    WireTransaction update(WireTransaction wireTransaction);

    /**
     * Partially updates a wireTransaction.
     *
     * @param wireTransaction the entity to update partially.
     * @return the persisted entity.
     */
    Optional<WireTransaction> partialUpdate(WireTransaction wireTransaction);

    /**
     * Get all the wireTransactions.
     *
     * @return the list of entities.
     */
    List<WireTransaction> findAll();

    /**
     * Get the "id" wireTransaction.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<WireTransaction> findOne(Long id);

    /**
     * Delete the "id" wireTransaction.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
