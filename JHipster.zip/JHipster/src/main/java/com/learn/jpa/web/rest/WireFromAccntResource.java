package com.learn.jpa.web.rest;

import com.learn.jpa.domain.WireFromAccnt;
import com.learn.jpa.repository.WireFromAccntRepository;
import com.learn.jpa.service.WireFromAccntService;
import com.learn.jpa.web.rest.errors.BadRequestAlertException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tech.jhipster.web.util.HeaderUtil;
import tech.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.learn.jpa.domain.WireFromAccnt}.
 */
@RestController
@RequestMapping("/api/wire-from-accnts")
public class WireFromAccntResource {

    private final Logger log = LoggerFactory.getLogger(WireFromAccntResource.class);

    private static final String ENTITY_NAME = "wireFromAccnt";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final WireFromAccntService wireFromAccntService;

    private final WireFromAccntRepository wireFromAccntRepository;

    public WireFromAccntResource(WireFromAccntService wireFromAccntService, WireFromAccntRepository wireFromAccntRepository) {
        this.wireFromAccntService = wireFromAccntService;
        this.wireFromAccntRepository = wireFromAccntRepository;
    }

    /**
     * {@code POST  /wire-from-accnts} : Create a new wireFromAccnt.
     *
     * @param wireFromAccnt the wireFromAccnt to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new wireFromAccnt, or with status {@code 400 (Bad Request)} if the wireFromAccnt has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("")
    public ResponseEntity<WireFromAccnt> createWireFromAccnt(@Valid @RequestBody WireFromAccnt wireFromAccnt) throws URISyntaxException {
        log.debug("REST request to save WireFromAccnt : {}", wireFromAccnt);
        if (wireFromAccnt.getId() != null) {
            throw new BadRequestAlertException("A new wireFromAccnt cannot already have an ID", ENTITY_NAME, "idexists");
        }
        WireFromAccnt result = wireFromAccntService.save(wireFromAccnt);
        return ResponseEntity
            .created(new URI("/api/wire-from-accnts/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /wire-from-accnts/:id} : Updates an existing wireFromAccnt.
     *
     * @param id the id of the wireFromAccnt to save.
     * @param wireFromAccnt the wireFromAccnt to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated wireFromAccnt,
     * or with status {@code 400 (Bad Request)} if the wireFromAccnt is not valid,
     * or with status {@code 500 (Internal Server Error)} if the wireFromAccnt couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/{id}")
    public ResponseEntity<WireFromAccnt> updateWireFromAccnt(
        @PathVariable(value = "id", required = false) final Long id,
        @Valid @RequestBody WireFromAccnt wireFromAccnt
    ) throws URISyntaxException {
        log.debug("REST request to update WireFromAccnt : {}, {}", id, wireFromAccnt);
        if (wireFromAccnt.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, wireFromAccnt.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!wireFromAccntRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        WireFromAccnt result = wireFromAccntService.update(wireFromAccnt);
        return ResponseEntity
            .ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, wireFromAccnt.getId().toString()))
            .body(result);
    }

    /**
     * {@code PATCH  /wire-from-accnts/:id} : Partial updates given fields of an existing wireFromAccnt, field will ignore if it is null
     *
     * @param id the id of the wireFromAccnt to save.
     * @param wireFromAccnt the wireFromAccnt to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated wireFromAccnt,
     * or with status {@code 400 (Bad Request)} if the wireFromAccnt is not valid,
     * or with status {@code 404 (Not Found)} if the wireFromAccnt is not found,
     * or with status {@code 500 (Internal Server Error)} if the wireFromAccnt couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PatchMapping(value = "/{id}", consumes = { "application/json", "application/merge-patch+json" })
    public ResponseEntity<WireFromAccnt> partialUpdateWireFromAccnt(
        @PathVariable(value = "id", required = false) final Long id,
        @NotNull @RequestBody WireFromAccnt wireFromAccnt
    ) throws URISyntaxException {
        log.debug("REST request to partial update WireFromAccnt partially : {}, {}", id, wireFromAccnt);
        if (wireFromAccnt.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, wireFromAccnt.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!wireFromAccntRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        Optional<WireFromAccnt> result = wireFromAccntService.partialUpdate(wireFromAccnt);

        return ResponseUtil.wrapOrNotFound(
            result,
            HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, wireFromAccnt.getId().toString())
        );
    }

    /**
     * {@code GET  /wire-from-accnts} : get all the wireFromAccnts.
     *
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of wireFromAccnts in body.
     */
    @GetMapping("")
    public List<WireFromAccnt> getAllWireFromAccnts() {
        log.debug("REST request to get all WireFromAccnts");
        return wireFromAccntService.findAll();
    }

    /**
     * {@code GET  /wire-from-accnts/:id} : get the "id" wireFromAccnt.
     *
     * @param id the id of the wireFromAccnt to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the wireFromAccnt, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/{id}")
    public ResponseEntity<WireFromAccnt> getWireFromAccnt(@PathVariable("id") Long id) {
        log.debug("REST request to get WireFromAccnt : {}", id);
        Optional<WireFromAccnt> wireFromAccnt = wireFromAccntService.findOne(id);
        return ResponseUtil.wrapOrNotFound(wireFromAccnt);
    }

    /**
     * {@code DELETE  /wire-from-accnts/:id} : delete the "id" wireFromAccnt.
     *
     * @param id the id of the wireFromAccnt to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteWireFromAccnt(@PathVariable("id") Long id) {
        log.debug("REST request to delete WireFromAccnt : {}", id);
        wireFromAccntService.delete(id);
        return ResponseEntity
            .noContent()
            .headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString()))
            .build();
    }
}
