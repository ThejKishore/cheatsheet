package com.learn.jpa.service;

import com.learn.jpa.domain.AchFromAccnt;
import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing {@link com.learn.jpa.domain.AchFromAccnt}.
 */
public interface AchFromAccntService {
    /**
     * Save a achFromAccnt.
     *
     * @param achFromAccnt the entity to save.
     * @return the persisted entity.
     */
    AchFromAccnt save(AchFromAccnt achFromAccnt);

    /**
     * Updates a achFromAccnt.
     *
     * @param achFromAccnt the entity to update.
     * @return the persisted entity.
     */
    AchFromAccnt update(AchFromAccnt achFromAccnt);

    /**
     * Partially updates a achFromAccnt.
     *
     * @param achFromAccnt the entity to update partially.
     * @return the persisted entity.
     */
    Optional<AchFromAccnt> partialUpdate(AchFromAccnt achFromAccnt);

    /**
     * Get all the achFromAccnts.
     *
     * @return the list of entities.
     */
    List<AchFromAccnt> findAll();

    /**
     * Get the "id" achFromAccnt.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<AchFromAccnt> findOne(Long id);

    /**
     * Delete the "id" achFromAccnt.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
