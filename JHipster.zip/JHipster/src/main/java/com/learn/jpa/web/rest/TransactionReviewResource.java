package com.learn.jpa.web.rest;

import com.learn.jpa.domain.TransactionReview;
import com.learn.jpa.repository.TransactionReviewRepository;
import com.learn.jpa.service.TransactionReviewService;
import com.learn.jpa.web.rest.errors.BadRequestAlertException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tech.jhipster.web.util.HeaderUtil;
import tech.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.learn.jpa.domain.TransactionReview}.
 */
@RestController
@RequestMapping("/api/transaction-reviews")
public class TransactionReviewResource {

    private final Logger log = LoggerFactory.getLogger(TransactionReviewResource.class);

    private static final String ENTITY_NAME = "transactionReview";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final TransactionReviewService transactionReviewService;

    private final TransactionReviewRepository transactionReviewRepository;

    public TransactionReviewResource(
        TransactionReviewService transactionReviewService,
        TransactionReviewRepository transactionReviewRepository
    ) {
        this.transactionReviewService = transactionReviewService;
        this.transactionReviewRepository = transactionReviewRepository;
    }

    /**
     * {@code POST  /transaction-reviews} : Create a new transactionReview.
     *
     * @param transactionReview the transactionReview to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new transactionReview, or with status {@code 400 (Bad Request)} if the transactionReview has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("")
    public ResponseEntity<TransactionReview> createTransactionReview(@Valid @RequestBody TransactionReview transactionReview)
        throws URISyntaxException {
        log.debug("REST request to save TransactionReview : {}", transactionReview);
        if (transactionReview.getId() != null) {
            throw new BadRequestAlertException("A new transactionReview cannot already have an ID", ENTITY_NAME, "idexists");
        }
        TransactionReview result = transactionReviewService.save(transactionReview);
        return ResponseEntity
            .created(new URI("/api/transaction-reviews/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /transaction-reviews/:id} : Updates an existing transactionReview.
     *
     * @param id the id of the transactionReview to save.
     * @param transactionReview the transactionReview to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated transactionReview,
     * or with status {@code 400 (Bad Request)} if the transactionReview is not valid,
     * or with status {@code 500 (Internal Server Error)} if the transactionReview couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/{id}")
    public ResponseEntity<TransactionReview> updateTransactionReview(
        @PathVariable(value = "id", required = false) final Long id,
        @Valid @RequestBody TransactionReview transactionReview
    ) throws URISyntaxException {
        log.debug("REST request to update TransactionReview : {}, {}", id, transactionReview);
        if (transactionReview.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, transactionReview.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!transactionReviewRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        TransactionReview result = transactionReviewService.update(transactionReview);
        return ResponseEntity
            .ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, transactionReview.getId().toString()))
            .body(result);
    }

    /**
     * {@code PATCH  /transaction-reviews/:id} : Partial updates given fields of an existing transactionReview, field will ignore if it is null
     *
     * @param id the id of the transactionReview to save.
     * @param transactionReview the transactionReview to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated transactionReview,
     * or with status {@code 400 (Bad Request)} if the transactionReview is not valid,
     * or with status {@code 404 (Not Found)} if the transactionReview is not found,
     * or with status {@code 500 (Internal Server Error)} if the transactionReview couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PatchMapping(value = "/{id}", consumes = { "application/json", "application/merge-patch+json" })
    public ResponseEntity<TransactionReview> partialUpdateTransactionReview(
        @PathVariable(value = "id", required = false) final Long id,
        @NotNull @RequestBody TransactionReview transactionReview
    ) throws URISyntaxException {
        log.debug("REST request to partial update TransactionReview partially : {}, {}", id, transactionReview);
        if (transactionReview.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, transactionReview.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!transactionReviewRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        Optional<TransactionReview> result = transactionReviewService.partialUpdate(transactionReview);

        return ResponseUtil.wrapOrNotFound(
            result,
            HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, transactionReview.getId().toString())
        );
    }

    /**
     * {@code GET  /transaction-reviews} : get all the transactionReviews.
     *
     * @param filter the filter of the request.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of transactionReviews in body.
     */
    @GetMapping("")
    public List<TransactionReview> getAllTransactionReviews(@RequestParam(name = "filter", required = false) String filter) {
        if ("transaction-is-null".equals(filter)) {
            log.debug("REST request to get all TransactionReviews where transaction is null");
            return transactionReviewService.findAllWhereTransactionIsNull();
        }
        log.debug("REST request to get all TransactionReviews");
        return transactionReviewService.findAll();
    }

    /**
     * {@code GET  /transaction-reviews/:id} : get the "id" transactionReview.
     *
     * @param id the id of the transactionReview to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the transactionReview, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/{id}")
    public ResponseEntity<TransactionReview> getTransactionReview(@PathVariable("id") Long id) {
        log.debug("REST request to get TransactionReview : {}", id);
        Optional<TransactionReview> transactionReview = transactionReviewService.findOne(id);
        return ResponseUtil.wrapOrNotFound(transactionReview);
    }

    /**
     * {@code DELETE  /transaction-reviews/:id} : delete the "id" transactionReview.
     *
     * @param id the id of the transactionReview to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteTransactionReview(@PathVariable("id") Long id) {
        log.debug("REST request to delete TransactionReview : {}", id);
        transactionReviewService.delete(id);
        return ResponseEntity
            .noContent()
            .headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString()))
            .build();
    }
}
