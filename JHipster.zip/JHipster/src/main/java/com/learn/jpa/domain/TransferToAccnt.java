package com.learn.jpa.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.math.BigDecimal;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * A TransferToAccnt.
 */
@Entity
@Table(name = "transfer_to_accnt")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@SuppressWarnings("common-java:DuplicatedBlocks")
public class TransferToAccnt implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "id")
    private Long id;

    @NotNull
    @Column(name = "to_accnt_id", nullable = false, unique = true)
    private Long toAccntID;

    @Column(name = "to_accnt_sk")
    private Long toAccntSk;

    @Column(name = "to_accnt_name")
    private String toAccntName;

    @Column(name = "to_accnt_amnt", precision = 21, scale = 2)
    private BigDecimal toAccntAmnt;

    @ManyToOne(fetch = FetchType.LAZY)
    @JsonIgnoreProperties(value = { "transactionMapping", "transferFromAccnts", "transferToAccnts" }, allowSetters = true)
    private TransferTransaction transferTransaction;

    // jhipster-needle-entity-add-field - JHipster will add fields here

    public Long getId() {
        return this.id;
    }

    public TransferToAccnt id(Long id) {
        this.setId(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getToAccntID() {
        return this.toAccntID;
    }

    public TransferToAccnt toAccntID(Long toAccntID) {
        this.setToAccntID(toAccntID);
        return this;
    }

    public void setToAccntID(Long toAccntID) {
        this.toAccntID = toAccntID;
    }

    public Long getToAccntSk() {
        return this.toAccntSk;
    }

    public TransferToAccnt toAccntSk(Long toAccntSk) {
        this.setToAccntSk(toAccntSk);
        return this;
    }

    public void setToAccntSk(Long toAccntSk) {
        this.toAccntSk = toAccntSk;
    }

    public String getToAccntName() {
        return this.toAccntName;
    }

    public TransferToAccnt toAccntName(String toAccntName) {
        this.setToAccntName(toAccntName);
        return this;
    }

    public void setToAccntName(String toAccntName) {
        this.toAccntName = toAccntName;
    }

    public BigDecimal getToAccntAmnt() {
        return this.toAccntAmnt;
    }

    public TransferToAccnt toAccntAmnt(BigDecimal toAccntAmnt) {
        this.setToAccntAmnt(toAccntAmnt);
        return this;
    }

    public void setToAccntAmnt(BigDecimal toAccntAmnt) {
        this.toAccntAmnt = toAccntAmnt;
    }

    public TransferTransaction getTransferTransaction() {
        return this.transferTransaction;
    }

    public void setTransferTransaction(TransferTransaction transferTransaction) {
        this.transferTransaction = transferTransaction;
    }

    public TransferToAccnt transferTransaction(TransferTransaction transferTransaction) {
        this.setTransferTransaction(transferTransaction);
        return this;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TransferToAccnt)) {
            return false;
        }
        return getId() != null && getId().equals(((TransferToAccnt) o).getId());
    }

    @Override
    public int hashCode() {
        // see https://vladmihalcea.com/how-to-implement-equals-and-hashcode-using-the-jpa-entity-identifier/
        return getClass().hashCode();
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "TransferToAccnt{" +
            "id=" + getId() +
            ", toAccntID=" + getToAccntID() +
            ", toAccntSk=" + getToAccntSk() +
            ", toAccntName='" + getToAccntName() + "'" +
            ", toAccntAmnt=" + getToAccntAmnt() +
            "}";
    }
}
