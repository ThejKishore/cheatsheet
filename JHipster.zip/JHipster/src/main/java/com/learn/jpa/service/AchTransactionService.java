package com.learn.jpa.service;

import com.learn.jpa.domain.AchTransaction;
import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing {@link com.learn.jpa.domain.AchTransaction}.
 */
public interface AchTransactionService {
    /**
     * Save a achTransaction.
     *
     * @param achTransaction the entity to save.
     * @return the persisted entity.
     */
    AchTransaction save(AchTransaction achTransaction);

    /**
     * Updates a achTransaction.
     *
     * @param achTransaction the entity to update.
     * @return the persisted entity.
     */
    AchTransaction update(AchTransaction achTransaction);

    /**
     * Partially updates a achTransaction.
     *
     * @param achTransaction the entity to update partially.
     * @return the persisted entity.
     */
    Optional<AchTransaction> partialUpdate(AchTransaction achTransaction);

    /**
     * Get all the achTransactions.
     *
     * @return the list of entities.
     */
    List<AchTransaction> findAll();

    /**
     * Get the "id" achTransaction.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<AchTransaction> findOne(Long id);

    /**
     * Delete the "id" achTransaction.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
