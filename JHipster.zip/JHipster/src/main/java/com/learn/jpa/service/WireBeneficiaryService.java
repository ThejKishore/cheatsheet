package com.learn.jpa.service;

import com.learn.jpa.domain.WireBeneficiary;
import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing {@link com.learn.jpa.domain.WireBeneficiary}.
 */
public interface WireBeneficiaryService {
    /**
     * Save a wireBeneficiary.
     *
     * @param wireBeneficiary the entity to save.
     * @return the persisted entity.
     */
    WireBeneficiary save(WireBeneficiary wireBeneficiary);

    /**
     * Updates a wireBeneficiary.
     *
     * @param wireBeneficiary the entity to update.
     * @return the persisted entity.
     */
    WireBeneficiary update(WireBeneficiary wireBeneficiary);

    /**
     * Partially updates a wireBeneficiary.
     *
     * @param wireBeneficiary the entity to update partially.
     * @return the persisted entity.
     */
    Optional<WireBeneficiary> partialUpdate(WireBeneficiary wireBeneficiary);

    /**
     * Get all the wireBeneficiaries.
     *
     * @return the list of entities.
     */
    List<WireBeneficiary> findAll();

    /**
     * Get the "id" wireBeneficiary.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<WireBeneficiary> findOne(Long id);

    /**
     * Delete the "id" wireBeneficiary.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
