package com.learn.jpa.service.impl;

import com.learn.jpa.domain.WireBeneficiary;
import com.learn.jpa.repository.WireBeneficiaryRepository;
import com.learn.jpa.service.WireBeneficiaryService;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.WireBeneficiary}.
 */
@Service
@Transactional
public class WireBeneficiaryServiceImpl implements WireBeneficiaryService {

    private final Logger log = LoggerFactory.getLogger(WireBeneficiaryServiceImpl.class);

    private final WireBeneficiaryRepository wireBeneficiaryRepository;

    public WireBeneficiaryServiceImpl(WireBeneficiaryRepository wireBeneficiaryRepository) {
        this.wireBeneficiaryRepository = wireBeneficiaryRepository;
    }

    @Override
    public WireBeneficiary save(WireBeneficiary wireBeneficiary) {
        log.debug("Request to save WireBeneficiary : {}", wireBeneficiary);
        return wireBeneficiaryRepository.save(wireBeneficiary);
    }

    @Override
    public WireBeneficiary update(WireBeneficiary wireBeneficiary) {
        log.debug("Request to update WireBeneficiary : {}", wireBeneficiary);
        return wireBeneficiaryRepository.save(wireBeneficiary);
    }

    @Override
    public Optional<WireBeneficiary> partialUpdate(WireBeneficiary wireBeneficiary) {
        log.debug("Request to partially update WireBeneficiary : {}", wireBeneficiary);

        return wireBeneficiaryRepository
            .findById(wireBeneficiary.getId())
            .map(existingWireBeneficiary -> {
                if (wireBeneficiary.getBeneficiaryId() != null) {
                    existingWireBeneficiary.setBeneficiaryId(wireBeneficiary.getBeneficiaryId());
                }
                if (wireBeneficiary.getBeneficiaryName() != null) {
                    existingWireBeneficiary.setBeneficiaryName(wireBeneficiary.getBeneficiaryName());
                }
                if (wireBeneficiary.getBeneficiaryType() != null) {
                    existingWireBeneficiary.setBeneficiaryType(wireBeneficiary.getBeneficiaryType());
                }

                return existingWireBeneficiary;
            })
            .map(wireBeneficiaryRepository::save);
    }

    @Override
    @Transactional(readOnly = true)
    public List<WireBeneficiary> findAll() {
        log.debug("Request to get all WireBeneficiaries");
        return wireBeneficiaryRepository.findAll();
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<WireBeneficiary> findOne(Long id) {
        log.debug("Request to get WireBeneficiary : {}", id);
        return wireBeneficiaryRepository.findById(id);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete WireBeneficiary : {}", id);
        wireBeneficiaryRepository.deleteById(id);
    }
}
