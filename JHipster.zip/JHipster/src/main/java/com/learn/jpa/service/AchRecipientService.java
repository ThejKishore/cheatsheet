package com.learn.jpa.service;

import com.learn.jpa.domain.AchRecipient;
import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing {@link com.learn.jpa.domain.AchRecipient}.
 */
public interface AchRecipientService {
    /**
     * Save a achRecipient.
     *
     * @param achRecipient the entity to save.
     * @return the persisted entity.
     */
    AchRecipient save(AchRecipient achRecipient);

    /**
     * Updates a achRecipient.
     *
     * @param achRecipient the entity to update.
     * @return the persisted entity.
     */
    AchRecipient update(AchRecipient achRecipient);

    /**
     * Partially updates a achRecipient.
     *
     * @param achRecipient the entity to update partially.
     * @return the persisted entity.
     */
    Optional<AchRecipient> partialUpdate(AchRecipient achRecipient);

    /**
     * Get all the achRecipients.
     *
     * @return the list of entities.
     */
    List<AchRecipient> findAll();

    /**
     * Get all the AchRecipient where AchTransaction is {@code null}.
     *
     * @return the {@link List} of entities.
     */
    List<AchRecipient> findAllWhereAchTransactionIsNull();

    /**
     * Get the "id" achRecipient.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<AchRecipient> findOne(Long id);

    /**
     * Delete the "id" achRecipient.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
