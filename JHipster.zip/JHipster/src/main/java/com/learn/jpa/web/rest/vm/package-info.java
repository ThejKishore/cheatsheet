/**
 * Rest layer visual models.
 */
package com.learn.jpa.web.rest.vm;
