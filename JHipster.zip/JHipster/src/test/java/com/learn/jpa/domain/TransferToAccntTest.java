package com.learn.jpa.domain;

import static com.learn.jpa.domain.TransferToAccntTestSamples.*;
import static com.learn.jpa.domain.TransferTransactionTestSamples.*;
import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class TransferToAccntTest {

    @Test
    void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(TransferToAccnt.class);
        TransferToAccnt transferToAccnt1 = getTransferToAccntSample1();
        TransferToAccnt transferToAccnt2 = new TransferToAccnt();
        assertThat(transferToAccnt1).isNotEqualTo(transferToAccnt2);

        transferToAccnt2.setId(transferToAccnt1.getId());
        assertThat(transferToAccnt1).isEqualTo(transferToAccnt2);

        transferToAccnt2 = getTransferToAccntSample2();
        assertThat(transferToAccnt1).isNotEqualTo(transferToAccnt2);
    }

    @Test
    void transferTransactionTest() throws Exception {
        TransferToAccnt transferToAccnt = getTransferToAccntRandomSampleGenerator();
        TransferTransaction transferTransactionBack = getTransferTransactionRandomSampleGenerator();

        transferToAccnt.setTransferTransaction(transferTransactionBack);
        assertThat(transferToAccnt.getTransferTransaction()).isEqualTo(transferTransactionBack);

        transferToAccnt.transferTransaction(null);
        assertThat(transferToAccnt.getTransferTransaction()).isNull();
    }
}
