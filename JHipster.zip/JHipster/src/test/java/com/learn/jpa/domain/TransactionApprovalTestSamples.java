package com.learn.jpa.domain;

import java.util.Random;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

public class TransactionApprovalTestSamples {

    private static final Random random = new Random();
    private static final AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    public static TransactionApproval getTransactionApprovalSample1() {
        return new TransactionApproval()
            .id(1L)
            .tranId(1L)
            .firstApprover("firstApprover1")
            .firstApprovalReason("firstApprovalReason1")
            .firstRejector("firstRejector1")
            .firstRejectorReason("firstRejectorReason1")
            .secondApprover("secondApprover1")
            .secondApprovalReason("secondApprovalReason1")
            .secondRejector("secondRejector1")
            .secondRejectorReason("secondRejectorReason1");
    }

    public static TransactionApproval getTransactionApprovalSample2() {
        return new TransactionApproval()
            .id(2L)
            .tranId(2L)
            .firstApprover("firstApprover2")
            .firstApprovalReason("firstApprovalReason2")
            .firstRejector("firstRejector2")
            .firstRejectorReason("firstRejectorReason2")
            .secondApprover("secondApprover2")
            .secondApprovalReason("secondApprovalReason2")
            .secondRejector("secondRejector2")
            .secondRejectorReason("secondRejectorReason2");
    }

    public static TransactionApproval getTransactionApprovalRandomSampleGenerator() {
        return new TransactionApproval()
            .id(longCount.incrementAndGet())
            .tranId(longCount.incrementAndGet())
            .firstApprover(UUID.randomUUID().toString())
            .firstApprovalReason(UUID.randomUUID().toString())
            .firstRejector(UUID.randomUUID().toString())
            .firstRejectorReason(UUID.randomUUID().toString())
            .secondApprover(UUID.randomUUID().toString())
            .secondApprovalReason(UUID.randomUUID().toString())
            .secondRejector(UUID.randomUUID().toString())
            .secondRejectorReason(UUID.randomUUID().toString());
    }
}
