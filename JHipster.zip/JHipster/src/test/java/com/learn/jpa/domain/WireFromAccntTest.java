package com.learn.jpa.domain;

import static com.learn.jpa.domain.WireFromAccntTestSamples.*;
import static com.learn.jpa.domain.WireTransactionTestSamples.*;
import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class WireFromAccntTest {

    @Test
    void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(WireFromAccnt.class);
        WireFromAccnt wireFromAccnt1 = getWireFromAccntSample1();
        WireFromAccnt wireFromAccnt2 = new WireFromAccnt();
        assertThat(wireFromAccnt1).isNotEqualTo(wireFromAccnt2);

        wireFromAccnt2.setId(wireFromAccnt1.getId());
        assertThat(wireFromAccnt1).isEqualTo(wireFromAccnt2);

        wireFromAccnt2 = getWireFromAccntSample2();
        assertThat(wireFromAccnt1).isNotEqualTo(wireFromAccnt2);
    }

    @Test
    void wireTransactionTest() throws Exception {
        WireFromAccnt wireFromAccnt = getWireFromAccntRandomSampleGenerator();
        WireTransaction wireTransactionBack = getWireTransactionRandomSampleGenerator();

        wireFromAccnt.setWireTransaction(wireTransactionBack);
        assertThat(wireFromAccnt.getWireTransaction()).isEqualTo(wireTransactionBack);

        wireFromAccnt.wireTransaction(null);
        assertThat(wireFromAccnt.getWireTransaction()).isNull();
    }
}
