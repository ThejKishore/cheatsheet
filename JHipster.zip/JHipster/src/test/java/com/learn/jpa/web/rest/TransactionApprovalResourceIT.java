package com.learn.jpa.web.rest;

import static com.learn.jpa.web.rest.TestUtil.sameInstant;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.learn.jpa.IntegrationTest;
import com.learn.jpa.domain.TransactionApproval;
import com.learn.jpa.repository.TransactionApprovalRepository;
import jakarta.persistence.EntityManager;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

/**
 * Integration tests for the {@link TransactionApprovalResource} REST controller.
 */
@IntegrationTest
@AutoConfigureMockMvc
@WithMockUser
class TransactionApprovalResourceIT {

    private static final Long DEFAULT_TRAN_ID = 1L;
    private static final Long UPDATED_TRAN_ID = 2L;

    private static final String DEFAULT_FIRST_APPROVER = "AAAAAAAAAA";
    private static final String UPDATED_FIRST_APPROVER = "BBBBBBBBBB";

    private static final String DEFAULT_FIRST_APPROVAL_REASON = "AAAAAAAAAA";
    private static final String UPDATED_FIRST_APPROVAL_REASON = "BBBBBBBBBB";

    private static final ZonedDateTime DEFAULT_FIRST_APPROVAL_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneOffset.UTC);
    private static final ZonedDateTime UPDATED_FIRST_APPROVAL_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    private static final String DEFAULT_FIRST_REJECTOR = "AAAAAAAAAA";
    private static final String UPDATED_FIRST_REJECTOR = "BBBBBBBBBB";

    private static final String DEFAULT_FIRST_REJECTOR_REASON = "AAAAAAAAAA";
    private static final String UPDATED_FIRST_REJECTOR_REASON = "BBBBBBBBBB";

    private static final ZonedDateTime DEFAULT_FIRST_REJECTED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneOffset.UTC);
    private static final ZonedDateTime UPDATED_FIRST_REJECTED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    private static final String DEFAULT_SECOND_APPROVER = "AAAAAAAAAA";
    private static final String UPDATED_SECOND_APPROVER = "BBBBBBBBBB";

    private static final String DEFAULT_SECOND_APPROVAL_REASON = "AAAAAAAAAA";
    private static final String UPDATED_SECOND_APPROVAL_REASON = "BBBBBBBBBB";

    private static final ZonedDateTime DEFAULT_SECOND_APPROVAL_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneOffset.UTC);
    private static final ZonedDateTime UPDATED_SECOND_APPROVAL_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    private static final String DEFAULT_SECOND_REJECTOR = "AAAAAAAAAA";
    private static final String UPDATED_SECOND_REJECTOR = "BBBBBBBBBB";

    private static final String DEFAULT_SECOND_REJECTOR_REASON = "AAAAAAAAAA";
    private static final String UPDATED_SECOND_REJECTOR_REASON = "BBBBBBBBBB";

    private static final ZonedDateTime DEFAULT_SECOND_REJECTED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneOffset.UTC);
    private static final ZonedDateTime UPDATED_SECOND_REJECTED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    private static final String ENTITY_API_URL = "/api/transaction-approvals";
    private static final String ENTITY_API_URL_ID = ENTITY_API_URL + "/{id}";

    private static Random random = new Random();
    private static AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    @Autowired
    private TransactionApprovalRepository transactionApprovalRepository;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restTransactionApprovalMockMvc;

    private TransactionApproval transactionApproval;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static TransactionApproval createEntity(EntityManager em) {
        TransactionApproval transactionApproval = new TransactionApproval()
            .tranId(DEFAULT_TRAN_ID)
            .firstApprover(DEFAULT_FIRST_APPROVER)
            .firstApprovalReason(DEFAULT_FIRST_APPROVAL_REASON)
            .firstApprovalDate(DEFAULT_FIRST_APPROVAL_DATE)
            .firstRejector(DEFAULT_FIRST_REJECTOR)
            .firstRejectorReason(DEFAULT_FIRST_REJECTOR_REASON)
            .firstRejectedDate(DEFAULT_FIRST_REJECTED_DATE)
            .secondApprover(DEFAULT_SECOND_APPROVER)
            .secondApprovalReason(DEFAULT_SECOND_APPROVAL_REASON)
            .secondApprovalDate(DEFAULT_SECOND_APPROVAL_DATE)
            .secondRejector(DEFAULT_SECOND_REJECTOR)
            .secondRejectorReason(DEFAULT_SECOND_REJECTOR_REASON)
            .secondRejectedDate(DEFAULT_SECOND_REJECTED_DATE);
        return transactionApproval;
    }

    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static TransactionApproval createUpdatedEntity(EntityManager em) {
        TransactionApproval transactionApproval = new TransactionApproval()
            .tranId(UPDATED_TRAN_ID)
            .firstApprover(UPDATED_FIRST_APPROVER)
            .firstApprovalReason(UPDATED_FIRST_APPROVAL_REASON)
            .firstApprovalDate(UPDATED_FIRST_APPROVAL_DATE)
            .firstRejector(UPDATED_FIRST_REJECTOR)
            .firstRejectorReason(UPDATED_FIRST_REJECTOR_REASON)
            .firstRejectedDate(UPDATED_FIRST_REJECTED_DATE)
            .secondApprover(UPDATED_SECOND_APPROVER)
            .secondApprovalReason(UPDATED_SECOND_APPROVAL_REASON)
            .secondApprovalDate(UPDATED_SECOND_APPROVAL_DATE)
            .secondRejector(UPDATED_SECOND_REJECTOR)
            .secondRejectorReason(UPDATED_SECOND_REJECTOR_REASON)
            .secondRejectedDate(UPDATED_SECOND_REJECTED_DATE);
        return transactionApproval;
    }

    @BeforeEach
    public void initTest() {
        transactionApproval = createEntity(em);
    }

    @Test
    @Transactional
    void createTransactionApproval() throws Exception {
        int databaseSizeBeforeCreate = transactionApprovalRepository.findAll().size();
        // Create the TransactionApproval
        restTransactionApprovalMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(transactionApproval))
            )
            .andExpect(status().isCreated());

        // Validate the TransactionApproval in the database
        List<TransactionApproval> transactionApprovalList = transactionApprovalRepository.findAll();
        assertThat(transactionApprovalList).hasSize(databaseSizeBeforeCreate + 1);
        TransactionApproval testTransactionApproval = transactionApprovalList.get(transactionApprovalList.size() - 1);
        assertThat(testTransactionApproval.getTranId()).isEqualTo(DEFAULT_TRAN_ID);
        assertThat(testTransactionApproval.getFirstApprover()).isEqualTo(DEFAULT_FIRST_APPROVER);
        assertThat(testTransactionApproval.getFirstApprovalReason()).isEqualTo(DEFAULT_FIRST_APPROVAL_REASON);
        assertThat(testTransactionApproval.getFirstApprovalDate()).isEqualTo(DEFAULT_FIRST_APPROVAL_DATE);
        assertThat(testTransactionApproval.getFirstRejector()).isEqualTo(DEFAULT_FIRST_REJECTOR);
        assertThat(testTransactionApproval.getFirstRejectorReason()).isEqualTo(DEFAULT_FIRST_REJECTOR_REASON);
        assertThat(testTransactionApproval.getFirstRejectedDate()).isEqualTo(DEFAULT_FIRST_REJECTED_DATE);
        assertThat(testTransactionApproval.getSecondApprover()).isEqualTo(DEFAULT_SECOND_APPROVER);
        assertThat(testTransactionApproval.getSecondApprovalReason()).isEqualTo(DEFAULT_SECOND_APPROVAL_REASON);
        assertThat(testTransactionApproval.getSecondApprovalDate()).isEqualTo(DEFAULT_SECOND_APPROVAL_DATE);
        assertThat(testTransactionApproval.getSecondRejector()).isEqualTo(DEFAULT_SECOND_REJECTOR);
        assertThat(testTransactionApproval.getSecondRejectorReason()).isEqualTo(DEFAULT_SECOND_REJECTOR_REASON);
        assertThat(testTransactionApproval.getSecondRejectedDate()).isEqualTo(DEFAULT_SECOND_REJECTED_DATE);
    }

    @Test
    @Transactional
    void createTransactionApprovalWithExistingId() throws Exception {
        // Create the TransactionApproval with an existing ID
        transactionApproval.setId(1L);

        int databaseSizeBeforeCreate = transactionApprovalRepository.findAll().size();

        // An entity with an existing ID cannot be created, so this API call must fail
        restTransactionApprovalMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(transactionApproval))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransactionApproval in the database
        List<TransactionApproval> transactionApprovalList = transactionApprovalRepository.findAll();
        assertThat(transactionApprovalList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    void checkTranIdIsRequired() throws Exception {
        int databaseSizeBeforeTest = transactionApprovalRepository.findAll().size();
        // set the field null
        transactionApproval.setTranId(null);

        // Create the TransactionApproval, which fails.

        restTransactionApprovalMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(transactionApproval))
            )
            .andExpect(status().isBadRequest());

        List<TransactionApproval> transactionApprovalList = transactionApprovalRepository.findAll();
        assertThat(transactionApprovalList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void getAllTransactionApprovals() throws Exception {
        // Initialize the database
        transactionApprovalRepository.saveAndFlush(transactionApproval);

        // Get all the transactionApprovalList
        restTransactionApprovalMockMvc
            .perform(get(ENTITY_API_URL + "?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(transactionApproval.getId().intValue())))
            .andExpect(jsonPath("$.[*].tranId").value(hasItem(DEFAULT_TRAN_ID.intValue())))
            .andExpect(jsonPath("$.[*].firstApprover").value(hasItem(DEFAULT_FIRST_APPROVER)))
            .andExpect(jsonPath("$.[*].firstApprovalReason").value(hasItem(DEFAULT_FIRST_APPROVAL_REASON)))
            .andExpect(jsonPath("$.[*].firstApprovalDate").value(hasItem(sameInstant(DEFAULT_FIRST_APPROVAL_DATE))))
            .andExpect(jsonPath("$.[*].firstRejector").value(hasItem(DEFAULT_FIRST_REJECTOR)))
            .andExpect(jsonPath("$.[*].firstRejectorReason").value(hasItem(DEFAULT_FIRST_REJECTOR_REASON)))
            .andExpect(jsonPath("$.[*].firstRejectedDate").value(hasItem(sameInstant(DEFAULT_FIRST_REJECTED_DATE))))
            .andExpect(jsonPath("$.[*].secondApprover").value(hasItem(DEFAULT_SECOND_APPROVER)))
            .andExpect(jsonPath("$.[*].secondApprovalReason").value(hasItem(DEFAULT_SECOND_APPROVAL_REASON)))
            .andExpect(jsonPath("$.[*].secondApprovalDate").value(hasItem(sameInstant(DEFAULT_SECOND_APPROVAL_DATE))))
            .andExpect(jsonPath("$.[*].secondRejector").value(hasItem(DEFAULT_SECOND_REJECTOR)))
            .andExpect(jsonPath("$.[*].secondRejectorReason").value(hasItem(DEFAULT_SECOND_REJECTOR_REASON)))
            .andExpect(jsonPath("$.[*].secondRejectedDate").value(hasItem(sameInstant(DEFAULT_SECOND_REJECTED_DATE))));
    }

    @Test
    @Transactional
    void getTransactionApproval() throws Exception {
        // Initialize the database
        transactionApprovalRepository.saveAndFlush(transactionApproval);

        // Get the transactionApproval
        restTransactionApprovalMockMvc
            .perform(get(ENTITY_API_URL_ID, transactionApproval.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(transactionApproval.getId().intValue()))
            .andExpect(jsonPath("$.tranId").value(DEFAULT_TRAN_ID.intValue()))
            .andExpect(jsonPath("$.firstApprover").value(DEFAULT_FIRST_APPROVER))
            .andExpect(jsonPath("$.firstApprovalReason").value(DEFAULT_FIRST_APPROVAL_REASON))
            .andExpect(jsonPath("$.firstApprovalDate").value(sameInstant(DEFAULT_FIRST_APPROVAL_DATE)))
            .andExpect(jsonPath("$.firstRejector").value(DEFAULT_FIRST_REJECTOR))
            .andExpect(jsonPath("$.firstRejectorReason").value(DEFAULT_FIRST_REJECTOR_REASON))
            .andExpect(jsonPath("$.firstRejectedDate").value(sameInstant(DEFAULT_FIRST_REJECTED_DATE)))
            .andExpect(jsonPath("$.secondApprover").value(DEFAULT_SECOND_APPROVER))
            .andExpect(jsonPath("$.secondApprovalReason").value(DEFAULT_SECOND_APPROVAL_REASON))
            .andExpect(jsonPath("$.secondApprovalDate").value(sameInstant(DEFAULT_SECOND_APPROVAL_DATE)))
            .andExpect(jsonPath("$.secondRejector").value(DEFAULT_SECOND_REJECTOR))
            .andExpect(jsonPath("$.secondRejectorReason").value(DEFAULT_SECOND_REJECTOR_REASON))
            .andExpect(jsonPath("$.secondRejectedDate").value(sameInstant(DEFAULT_SECOND_REJECTED_DATE)));
    }

    @Test
    @Transactional
    void getNonExistingTransactionApproval() throws Exception {
        // Get the transactionApproval
        restTransactionApprovalMockMvc.perform(get(ENTITY_API_URL_ID, Long.MAX_VALUE)).andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    void putExistingTransactionApproval() throws Exception {
        // Initialize the database
        transactionApprovalRepository.saveAndFlush(transactionApproval);

        int databaseSizeBeforeUpdate = transactionApprovalRepository.findAll().size();

        // Update the transactionApproval
        TransactionApproval updatedTransactionApproval = transactionApprovalRepository.findById(transactionApproval.getId()).orElseThrow();
        // Disconnect from session so that the updates on updatedTransactionApproval are not directly saved in db
        em.detach(updatedTransactionApproval);
        updatedTransactionApproval
            .tranId(UPDATED_TRAN_ID)
            .firstApprover(UPDATED_FIRST_APPROVER)
            .firstApprovalReason(UPDATED_FIRST_APPROVAL_REASON)
            .firstApprovalDate(UPDATED_FIRST_APPROVAL_DATE)
            .firstRejector(UPDATED_FIRST_REJECTOR)
            .firstRejectorReason(UPDATED_FIRST_REJECTOR_REASON)
            .firstRejectedDate(UPDATED_FIRST_REJECTED_DATE)
            .secondApprover(UPDATED_SECOND_APPROVER)
            .secondApprovalReason(UPDATED_SECOND_APPROVAL_REASON)
            .secondApprovalDate(UPDATED_SECOND_APPROVAL_DATE)
            .secondRejector(UPDATED_SECOND_REJECTOR)
            .secondRejectorReason(UPDATED_SECOND_REJECTOR_REASON)
            .secondRejectedDate(UPDATED_SECOND_REJECTED_DATE);

        restTransactionApprovalMockMvc
            .perform(
                put(ENTITY_API_URL_ID, updatedTransactionApproval.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(updatedTransactionApproval))
            )
            .andExpect(status().isOk());

        // Validate the TransactionApproval in the database
        List<TransactionApproval> transactionApprovalList = transactionApprovalRepository.findAll();
        assertThat(transactionApprovalList).hasSize(databaseSizeBeforeUpdate);
        TransactionApproval testTransactionApproval = transactionApprovalList.get(transactionApprovalList.size() - 1);
        assertThat(testTransactionApproval.getTranId()).isEqualTo(UPDATED_TRAN_ID);
        assertThat(testTransactionApproval.getFirstApprover()).isEqualTo(UPDATED_FIRST_APPROVER);
        assertThat(testTransactionApproval.getFirstApprovalReason()).isEqualTo(UPDATED_FIRST_APPROVAL_REASON);
        assertThat(testTransactionApproval.getFirstApprovalDate()).isEqualTo(UPDATED_FIRST_APPROVAL_DATE);
        assertThat(testTransactionApproval.getFirstRejector()).isEqualTo(UPDATED_FIRST_REJECTOR);
        assertThat(testTransactionApproval.getFirstRejectorReason()).isEqualTo(UPDATED_FIRST_REJECTOR_REASON);
        assertThat(testTransactionApproval.getFirstRejectedDate()).isEqualTo(UPDATED_FIRST_REJECTED_DATE);
        assertThat(testTransactionApproval.getSecondApprover()).isEqualTo(UPDATED_SECOND_APPROVER);
        assertThat(testTransactionApproval.getSecondApprovalReason()).isEqualTo(UPDATED_SECOND_APPROVAL_REASON);
        assertThat(testTransactionApproval.getSecondApprovalDate()).isEqualTo(UPDATED_SECOND_APPROVAL_DATE);
        assertThat(testTransactionApproval.getSecondRejector()).isEqualTo(UPDATED_SECOND_REJECTOR);
        assertThat(testTransactionApproval.getSecondRejectorReason()).isEqualTo(UPDATED_SECOND_REJECTOR_REASON);
        assertThat(testTransactionApproval.getSecondRejectedDate()).isEqualTo(UPDATED_SECOND_REJECTED_DATE);
    }

    @Test
    @Transactional
    void putNonExistingTransactionApproval() throws Exception {
        int databaseSizeBeforeUpdate = transactionApprovalRepository.findAll().size();
        transactionApproval.setId(longCount.incrementAndGet());

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restTransactionApprovalMockMvc
            .perform(
                put(ENTITY_API_URL_ID, transactionApproval.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transactionApproval))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransactionApproval in the database
        List<TransactionApproval> transactionApprovalList = transactionApprovalRepository.findAll();
        assertThat(transactionApprovalList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithIdMismatchTransactionApproval() throws Exception {
        int databaseSizeBeforeUpdate = transactionApprovalRepository.findAll().size();
        transactionApproval.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransactionApprovalMockMvc
            .perform(
                put(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transactionApproval))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransactionApproval in the database
        List<TransactionApproval> transactionApprovalList = transactionApprovalRepository.findAll();
        assertThat(transactionApprovalList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithMissingIdPathParamTransactionApproval() throws Exception {
        int databaseSizeBeforeUpdate = transactionApprovalRepository.findAll().size();
        transactionApproval.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransactionApprovalMockMvc
            .perform(
                put(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(transactionApproval))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the TransactionApproval in the database
        List<TransactionApproval> transactionApprovalList = transactionApprovalRepository.findAll();
        assertThat(transactionApprovalList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void partialUpdateTransactionApprovalWithPatch() throws Exception {
        // Initialize the database
        transactionApprovalRepository.saveAndFlush(transactionApproval);

        int databaseSizeBeforeUpdate = transactionApprovalRepository.findAll().size();

        // Update the transactionApproval using partial update
        TransactionApproval partialUpdatedTransactionApproval = new TransactionApproval();
        partialUpdatedTransactionApproval.setId(transactionApproval.getId());

        partialUpdatedTransactionApproval
            .firstApprover(UPDATED_FIRST_APPROVER)
            .firstApprovalReason(UPDATED_FIRST_APPROVAL_REASON)
            .firstRejector(UPDATED_FIRST_REJECTOR)
            .firstRejectorReason(UPDATED_FIRST_REJECTOR_REASON)
            .firstRejectedDate(UPDATED_FIRST_REJECTED_DATE)
            .secondRejector(UPDATED_SECOND_REJECTOR);

        restTransactionApprovalMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedTransactionApproval.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedTransactionApproval))
            )
            .andExpect(status().isOk());

        // Validate the TransactionApproval in the database
        List<TransactionApproval> transactionApprovalList = transactionApprovalRepository.findAll();
        assertThat(transactionApprovalList).hasSize(databaseSizeBeforeUpdate);
        TransactionApproval testTransactionApproval = transactionApprovalList.get(transactionApprovalList.size() - 1);
        assertThat(testTransactionApproval.getTranId()).isEqualTo(DEFAULT_TRAN_ID);
        assertThat(testTransactionApproval.getFirstApprover()).isEqualTo(UPDATED_FIRST_APPROVER);
        assertThat(testTransactionApproval.getFirstApprovalReason()).isEqualTo(UPDATED_FIRST_APPROVAL_REASON);
        assertThat(testTransactionApproval.getFirstApprovalDate()).isEqualTo(DEFAULT_FIRST_APPROVAL_DATE);
        assertThat(testTransactionApproval.getFirstRejector()).isEqualTo(UPDATED_FIRST_REJECTOR);
        assertThat(testTransactionApproval.getFirstRejectorReason()).isEqualTo(UPDATED_FIRST_REJECTOR_REASON);
        assertThat(testTransactionApproval.getFirstRejectedDate()).isEqualTo(UPDATED_FIRST_REJECTED_DATE);
        assertThat(testTransactionApproval.getSecondApprover()).isEqualTo(DEFAULT_SECOND_APPROVER);
        assertThat(testTransactionApproval.getSecondApprovalReason()).isEqualTo(DEFAULT_SECOND_APPROVAL_REASON);
        assertThat(testTransactionApproval.getSecondApprovalDate()).isEqualTo(DEFAULT_SECOND_APPROVAL_DATE);
        assertThat(testTransactionApproval.getSecondRejector()).isEqualTo(UPDATED_SECOND_REJECTOR);
        assertThat(testTransactionApproval.getSecondRejectorReason()).isEqualTo(DEFAULT_SECOND_REJECTOR_REASON);
        assertThat(testTransactionApproval.getSecondRejectedDate()).isEqualTo(DEFAULT_SECOND_REJECTED_DATE);
    }

    @Test
    @Transactional
    void fullUpdateTransactionApprovalWithPatch() throws Exception {
        // Initialize the database
        transactionApprovalRepository.saveAndFlush(transactionApproval);

        int databaseSizeBeforeUpdate = transactionApprovalRepository.findAll().size();

        // Update the transactionApproval using partial update
        TransactionApproval partialUpdatedTransactionApproval = new TransactionApproval();
        partialUpdatedTransactionApproval.setId(transactionApproval.getId());

        partialUpdatedTransactionApproval
            .tranId(UPDATED_TRAN_ID)
            .firstApprover(UPDATED_FIRST_APPROVER)
            .firstApprovalReason(UPDATED_FIRST_APPROVAL_REASON)
            .firstApprovalDate(UPDATED_FIRST_APPROVAL_DATE)
            .firstRejector(UPDATED_FIRST_REJECTOR)
            .firstRejectorReason(UPDATED_FIRST_REJECTOR_REASON)
            .firstRejectedDate(UPDATED_FIRST_REJECTED_DATE)
            .secondApprover(UPDATED_SECOND_APPROVER)
            .secondApprovalReason(UPDATED_SECOND_APPROVAL_REASON)
            .secondApprovalDate(UPDATED_SECOND_APPROVAL_DATE)
            .secondRejector(UPDATED_SECOND_REJECTOR)
            .secondRejectorReason(UPDATED_SECOND_REJECTOR_REASON)
            .secondRejectedDate(UPDATED_SECOND_REJECTED_DATE);

        restTransactionApprovalMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedTransactionApproval.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedTransactionApproval))
            )
            .andExpect(status().isOk());

        // Validate the TransactionApproval in the database
        List<TransactionApproval> transactionApprovalList = transactionApprovalRepository.findAll();
        assertThat(transactionApprovalList).hasSize(databaseSizeBeforeUpdate);
        TransactionApproval testTransactionApproval = transactionApprovalList.get(transactionApprovalList.size() - 1);
        assertThat(testTransactionApproval.getTranId()).isEqualTo(UPDATED_TRAN_ID);
        assertThat(testTransactionApproval.getFirstApprover()).isEqualTo(UPDATED_FIRST_APPROVER);
        assertThat(testTransactionApproval.getFirstApprovalReason()).isEqualTo(UPDATED_FIRST_APPROVAL_REASON);
        assertThat(testTransactionApproval.getFirstApprovalDate()).isEqualTo(UPDATED_FIRST_APPROVAL_DATE);
        assertThat(testTransactionApproval.getFirstRejector()).isEqualTo(UPDATED_FIRST_REJECTOR);
        assertThat(testTransactionApproval.getFirstRejectorReason()).isEqualTo(UPDATED_FIRST_REJECTOR_REASON);
        assertThat(testTransactionApproval.getFirstRejectedDate()).isEqualTo(UPDATED_FIRST_REJECTED_DATE);
        assertThat(testTransactionApproval.getSecondApprover()).isEqualTo(UPDATED_SECOND_APPROVER);
        assertThat(testTransactionApproval.getSecondApprovalReason()).isEqualTo(UPDATED_SECOND_APPROVAL_REASON);
        assertThat(testTransactionApproval.getSecondApprovalDate()).isEqualTo(UPDATED_SECOND_APPROVAL_DATE);
        assertThat(testTransactionApproval.getSecondRejector()).isEqualTo(UPDATED_SECOND_REJECTOR);
        assertThat(testTransactionApproval.getSecondRejectorReason()).isEqualTo(UPDATED_SECOND_REJECTOR_REASON);
        assertThat(testTransactionApproval.getSecondRejectedDate()).isEqualTo(UPDATED_SECOND_REJECTED_DATE);
    }

    @Test
    @Transactional
    void patchNonExistingTransactionApproval() throws Exception {
        int databaseSizeBeforeUpdate = transactionApprovalRepository.findAll().size();
        transactionApproval.setId(longCount.incrementAndGet());

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restTransactionApprovalMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, transactionApproval.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(transactionApproval))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransactionApproval in the database
        List<TransactionApproval> transactionApprovalList = transactionApprovalRepository.findAll();
        assertThat(transactionApprovalList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithIdMismatchTransactionApproval() throws Exception {
        int databaseSizeBeforeUpdate = transactionApprovalRepository.findAll().size();
        transactionApproval.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransactionApprovalMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(transactionApproval))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransactionApproval in the database
        List<TransactionApproval> transactionApprovalList = transactionApprovalRepository.findAll();
        assertThat(transactionApprovalList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithMissingIdPathParamTransactionApproval() throws Exception {
        int databaseSizeBeforeUpdate = transactionApprovalRepository.findAll().size();
        transactionApproval.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransactionApprovalMockMvc
            .perform(
                patch(ENTITY_API_URL)
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(transactionApproval))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the TransactionApproval in the database
        List<TransactionApproval> transactionApprovalList = transactionApprovalRepository.findAll();
        assertThat(transactionApprovalList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void deleteTransactionApproval() throws Exception {
        // Initialize the database
        transactionApprovalRepository.saveAndFlush(transactionApproval);

        int databaseSizeBeforeDelete = transactionApprovalRepository.findAll().size();

        // Delete the transactionApproval
        restTransactionApprovalMockMvc
            .perform(delete(ENTITY_API_URL_ID, transactionApproval.getId()).accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<TransactionApproval> transactionApprovalList = transactionApprovalRepository.findAll();
        assertThat(transactionApprovalList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
