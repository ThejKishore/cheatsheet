package com.learn.jpa.domain;

import java.util.Random;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

public class TransferToAccntTestSamples {

    private static final Random random = new Random();
    private static final AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    public static TransferToAccnt getTransferToAccntSample1() {
        return new TransferToAccnt().id(1L).toAccntID(1L).toAccntSk(1L).toAccntName("toAccntName1");
    }

    public static TransferToAccnt getTransferToAccntSample2() {
        return new TransferToAccnt().id(2L).toAccntID(2L).toAccntSk(2L).toAccntName("toAccntName2");
    }

    public static TransferToAccnt getTransferToAccntRandomSampleGenerator() {
        return new TransferToAccnt()
            .id(longCount.incrementAndGet())
            .toAccntID(longCount.incrementAndGet())
            .toAccntSk(longCount.incrementAndGet())
            .toAccntName(UUID.randomUUID().toString());
    }
}
