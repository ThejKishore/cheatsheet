package com.learn.jpa.domain;

import java.util.Random;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

public class TransactionTestSamples {

    private static final Random random = new Random();
    private static final AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));
    private static final AtomicInteger intCount = new AtomicInteger(random.nextInt() + (2 * Short.MAX_VALUE));

    public static Transaction getTransactionSample1() {
        return new Transaction()
            .id(1L)
            .tranId(1L)
            .tranName("tranName1")
            .frmCnt(1)
            .toCnt(1)
            .createdBy("createdBy1")
            .updatedBy("updatedBy1")
            .frequencyType("frequencyType1")
            .tranType("tranType1")
            .profileId(1L)
            .profileName("profileName1")
            .narrative("narrative1")
            .precedingNarrative("precedingNarrative1")
            .customNarrative("customNarrative1")
            .systemGeneratedNarrative("systemGeneratedNarrative1");
    }

    public static Transaction getTransactionSample2() {
        return new Transaction()
            .id(2L)
            .tranId(2L)
            .tranName("tranName2")
            .frmCnt(2)
            .toCnt(2)
            .createdBy("createdBy2")
            .updatedBy("updatedBy2")
            .frequencyType("frequencyType2")
            .tranType("tranType2")
            .profileId(2L)
            .profileName("profileName2")
            .narrative("narrative2")
            .precedingNarrative("precedingNarrative2")
            .customNarrative("customNarrative2")
            .systemGeneratedNarrative("systemGeneratedNarrative2");
    }

    public static Transaction getTransactionRandomSampleGenerator() {
        return new Transaction()
            .id(longCount.incrementAndGet())
            .tranId(longCount.incrementAndGet())
            .tranName(UUID.randomUUID().toString())
            .frmCnt(intCount.incrementAndGet())
            .toCnt(intCount.incrementAndGet())
            .createdBy(UUID.randomUUID().toString())
            .updatedBy(UUID.randomUUID().toString())
            .frequencyType(UUID.randomUUID().toString())
            .tranType(UUID.randomUUID().toString())
            .profileId(longCount.incrementAndGet())
            .profileName(UUID.randomUUID().toString())
            .narrative(UUID.randomUUID().toString())
            .precedingNarrative(UUID.randomUUID().toString())
            .customNarrative(UUID.randomUUID().toString())
            .systemGeneratedNarrative(UUID.randomUUID().toString());
    }
}
