package com.learn.jpa.domain;

import static com.learn.jpa.domain.AchRecipientTestSamples.*;
import static com.learn.jpa.domain.AchTransactionTestSamples.*;
import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class AchRecipientTest {

    @Test
    void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(AchRecipient.class);
        AchRecipient achRecipient1 = getAchRecipientSample1();
        AchRecipient achRecipient2 = new AchRecipient();
        assertThat(achRecipient1).isNotEqualTo(achRecipient2);

        achRecipient2.setId(achRecipient1.getId());
        assertThat(achRecipient1).isEqualTo(achRecipient2);

        achRecipient2 = getAchRecipientSample2();
        assertThat(achRecipient1).isNotEqualTo(achRecipient2);
    }

    @Test
    void achTransactionTest() throws Exception {
        AchRecipient achRecipient = getAchRecipientRandomSampleGenerator();
        AchTransaction achTransactionBack = getAchTransactionRandomSampleGenerator();

        achRecipient.setAchTransaction(achTransactionBack);
        assertThat(achRecipient.getAchTransaction()).isEqualTo(achTransactionBack);
        assertThat(achTransactionBack.getAchRecipient()).isEqualTo(achRecipient);

        achRecipient.achTransaction(null);
        assertThat(achRecipient.getAchTransaction()).isNull();
        assertThat(achTransactionBack.getAchRecipient()).isNull();
    }
}
