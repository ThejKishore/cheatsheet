package com.learn.jpa.web.rest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.learn.jpa.IntegrationTest;
import com.learn.jpa.domain.WireRecipient;
import com.learn.jpa.repository.WireRecipientRepository;
import jakarta.persistence.EntityManager;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

/**
 * Integration tests for the {@link WireRecipientResource} REST controller.
 */
@IntegrationTest
@AutoConfigureMockMvc
@WithMockUser
class WireRecipientResourceIT {

    private static final Long DEFAULT_RECIPIENT_ID = 1L;
    private static final Long UPDATED_RECIPIENT_ID = 2L;

    private static final String DEFAULT_RECIPEINT_NAME = "AAAAAAAAAA";
    private static final String UPDATED_RECIPEINT_NAME = "BBBBBBBBBB";

    private static final String DEFAULT_RECIPIENT_ADDRESS = "AAAAAAAAAA";
    private static final String UPDATED_RECIPIENT_ADDRESS = "BBBBBBBBBB";

    private static final String DEFAULT_RECIPIENT_COUNTRY = "AAAAAAAAAA";
    private static final String UPDATED_RECIPIENT_COUNTRY = "BBBBBBBBBB";

    private static final String DEFAULT_RECIPIENT_STATE = "AAAAAAAAAA";
    private static final String UPDATED_RECIPIENT_STATE = "BBBBBBBBBB";

    private static final String DEFAULT_RECIPIENT_CITY = "AAAAAAAAAA";
    private static final String UPDATED_RECIPIENT_CITY = "BBBBBBBBBB";

    private static final String ENTITY_API_URL = "/api/wire-recipients";
    private static final String ENTITY_API_URL_ID = ENTITY_API_URL + "/{id}";

    private static Random random = new Random();
    private static AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    @Autowired
    private WireRecipientRepository wireRecipientRepository;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restWireRecipientMockMvc;

    private WireRecipient wireRecipient;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static WireRecipient createEntity(EntityManager em) {
        WireRecipient wireRecipient = new WireRecipient()
            .recipientId(DEFAULT_RECIPIENT_ID)
            .recipeintName(DEFAULT_RECIPEINT_NAME)
            .recipientAddress(DEFAULT_RECIPIENT_ADDRESS)
            .recipientCountry(DEFAULT_RECIPIENT_COUNTRY)
            .recipientState(DEFAULT_RECIPIENT_STATE)
            .recipientCity(DEFAULT_RECIPIENT_CITY);
        return wireRecipient;
    }

    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static WireRecipient createUpdatedEntity(EntityManager em) {
        WireRecipient wireRecipient = new WireRecipient()
            .recipientId(UPDATED_RECIPIENT_ID)
            .recipeintName(UPDATED_RECIPEINT_NAME)
            .recipientAddress(UPDATED_RECIPIENT_ADDRESS)
            .recipientCountry(UPDATED_RECIPIENT_COUNTRY)
            .recipientState(UPDATED_RECIPIENT_STATE)
            .recipientCity(UPDATED_RECIPIENT_CITY);
        return wireRecipient;
    }

    @BeforeEach
    public void initTest() {
        wireRecipient = createEntity(em);
    }

    @Test
    @Transactional
    void createWireRecipient() throws Exception {
        int databaseSizeBeforeCreate = wireRecipientRepository.findAll().size();
        // Create the WireRecipient
        restWireRecipientMockMvc
            .perform(post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(wireRecipient)))
            .andExpect(status().isCreated());

        // Validate the WireRecipient in the database
        List<WireRecipient> wireRecipientList = wireRecipientRepository.findAll();
        assertThat(wireRecipientList).hasSize(databaseSizeBeforeCreate + 1);
        WireRecipient testWireRecipient = wireRecipientList.get(wireRecipientList.size() - 1);
        assertThat(testWireRecipient.getRecipientId()).isEqualTo(DEFAULT_RECIPIENT_ID);
        assertThat(testWireRecipient.getRecipeintName()).isEqualTo(DEFAULT_RECIPEINT_NAME);
        assertThat(testWireRecipient.getRecipientAddress()).isEqualTo(DEFAULT_RECIPIENT_ADDRESS);
        assertThat(testWireRecipient.getRecipientCountry()).isEqualTo(DEFAULT_RECIPIENT_COUNTRY);
        assertThat(testWireRecipient.getRecipientState()).isEqualTo(DEFAULT_RECIPIENT_STATE);
        assertThat(testWireRecipient.getRecipientCity()).isEqualTo(DEFAULT_RECIPIENT_CITY);
    }

    @Test
    @Transactional
    void createWireRecipientWithExistingId() throws Exception {
        // Create the WireRecipient with an existing ID
        wireRecipient.setId(1L);

        int databaseSizeBeforeCreate = wireRecipientRepository.findAll().size();

        // An entity with an existing ID cannot be created, so this API call must fail
        restWireRecipientMockMvc
            .perform(post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(wireRecipient)))
            .andExpect(status().isBadRequest());

        // Validate the WireRecipient in the database
        List<WireRecipient> wireRecipientList = wireRecipientRepository.findAll();
        assertThat(wireRecipientList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    void checkRecipientIdIsRequired() throws Exception {
        int databaseSizeBeforeTest = wireRecipientRepository.findAll().size();
        // set the field null
        wireRecipient.setRecipientId(null);

        // Create the WireRecipient, which fails.

        restWireRecipientMockMvc
            .perform(post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(wireRecipient)))
            .andExpect(status().isBadRequest());

        List<WireRecipient> wireRecipientList = wireRecipientRepository.findAll();
        assertThat(wireRecipientList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void getAllWireRecipients() throws Exception {
        // Initialize the database
        wireRecipientRepository.saveAndFlush(wireRecipient);

        // Get all the wireRecipientList
        restWireRecipientMockMvc
            .perform(get(ENTITY_API_URL + "?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(wireRecipient.getId().intValue())))
            .andExpect(jsonPath("$.[*].recipientId").value(hasItem(DEFAULT_RECIPIENT_ID.intValue())))
            .andExpect(jsonPath("$.[*].recipeintName").value(hasItem(DEFAULT_RECIPEINT_NAME)))
            .andExpect(jsonPath("$.[*].recipientAddress").value(hasItem(DEFAULT_RECIPIENT_ADDRESS)))
            .andExpect(jsonPath("$.[*].recipientCountry").value(hasItem(DEFAULT_RECIPIENT_COUNTRY)))
            .andExpect(jsonPath("$.[*].recipientState").value(hasItem(DEFAULT_RECIPIENT_STATE)))
            .andExpect(jsonPath("$.[*].recipientCity").value(hasItem(DEFAULT_RECIPIENT_CITY)));
    }

    @Test
    @Transactional
    void getWireRecipient() throws Exception {
        // Initialize the database
        wireRecipientRepository.saveAndFlush(wireRecipient);

        // Get the wireRecipient
        restWireRecipientMockMvc
            .perform(get(ENTITY_API_URL_ID, wireRecipient.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(wireRecipient.getId().intValue()))
            .andExpect(jsonPath("$.recipientId").value(DEFAULT_RECIPIENT_ID.intValue()))
            .andExpect(jsonPath("$.recipeintName").value(DEFAULT_RECIPEINT_NAME))
            .andExpect(jsonPath("$.recipientAddress").value(DEFAULT_RECIPIENT_ADDRESS))
            .andExpect(jsonPath("$.recipientCountry").value(DEFAULT_RECIPIENT_COUNTRY))
            .andExpect(jsonPath("$.recipientState").value(DEFAULT_RECIPIENT_STATE))
            .andExpect(jsonPath("$.recipientCity").value(DEFAULT_RECIPIENT_CITY));
    }

    @Test
    @Transactional
    void getNonExistingWireRecipient() throws Exception {
        // Get the wireRecipient
        restWireRecipientMockMvc.perform(get(ENTITY_API_URL_ID, Long.MAX_VALUE)).andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    void putExistingWireRecipient() throws Exception {
        // Initialize the database
        wireRecipientRepository.saveAndFlush(wireRecipient);

        int databaseSizeBeforeUpdate = wireRecipientRepository.findAll().size();

        // Update the wireRecipient
        WireRecipient updatedWireRecipient = wireRecipientRepository.findById(wireRecipient.getId()).orElseThrow();
        // Disconnect from session so that the updates on updatedWireRecipient are not directly saved in db
        em.detach(updatedWireRecipient);
        updatedWireRecipient
            .recipientId(UPDATED_RECIPIENT_ID)
            .recipeintName(UPDATED_RECIPEINT_NAME)
            .recipientAddress(UPDATED_RECIPIENT_ADDRESS)
            .recipientCountry(UPDATED_RECIPIENT_COUNTRY)
            .recipientState(UPDATED_RECIPIENT_STATE)
            .recipientCity(UPDATED_RECIPIENT_CITY);

        restWireRecipientMockMvc
            .perform(
                put(ENTITY_API_URL_ID, updatedWireRecipient.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(updatedWireRecipient))
            )
            .andExpect(status().isOk());

        // Validate the WireRecipient in the database
        List<WireRecipient> wireRecipientList = wireRecipientRepository.findAll();
        assertThat(wireRecipientList).hasSize(databaseSizeBeforeUpdate);
        WireRecipient testWireRecipient = wireRecipientList.get(wireRecipientList.size() - 1);
        assertThat(testWireRecipient.getRecipientId()).isEqualTo(UPDATED_RECIPIENT_ID);
        assertThat(testWireRecipient.getRecipeintName()).isEqualTo(UPDATED_RECIPEINT_NAME);
        assertThat(testWireRecipient.getRecipientAddress()).isEqualTo(UPDATED_RECIPIENT_ADDRESS);
        assertThat(testWireRecipient.getRecipientCountry()).isEqualTo(UPDATED_RECIPIENT_COUNTRY);
        assertThat(testWireRecipient.getRecipientState()).isEqualTo(UPDATED_RECIPIENT_STATE);
        assertThat(testWireRecipient.getRecipientCity()).isEqualTo(UPDATED_RECIPIENT_CITY);
    }

    @Test
    @Transactional
    void putNonExistingWireRecipient() throws Exception {
        int databaseSizeBeforeUpdate = wireRecipientRepository.findAll().size();
        wireRecipient.setId(longCount.incrementAndGet());

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restWireRecipientMockMvc
            .perform(
                put(ENTITY_API_URL_ID, wireRecipient.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(wireRecipient))
            )
            .andExpect(status().isBadRequest());

        // Validate the WireRecipient in the database
        List<WireRecipient> wireRecipientList = wireRecipientRepository.findAll();
        assertThat(wireRecipientList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithIdMismatchWireRecipient() throws Exception {
        int databaseSizeBeforeUpdate = wireRecipientRepository.findAll().size();
        wireRecipient.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restWireRecipientMockMvc
            .perform(
                put(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(wireRecipient))
            )
            .andExpect(status().isBadRequest());

        // Validate the WireRecipient in the database
        List<WireRecipient> wireRecipientList = wireRecipientRepository.findAll();
        assertThat(wireRecipientList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithMissingIdPathParamWireRecipient() throws Exception {
        int databaseSizeBeforeUpdate = wireRecipientRepository.findAll().size();
        wireRecipient.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restWireRecipientMockMvc
            .perform(put(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(wireRecipient)))
            .andExpect(status().isMethodNotAllowed());

        // Validate the WireRecipient in the database
        List<WireRecipient> wireRecipientList = wireRecipientRepository.findAll();
        assertThat(wireRecipientList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void partialUpdateWireRecipientWithPatch() throws Exception {
        // Initialize the database
        wireRecipientRepository.saveAndFlush(wireRecipient);

        int databaseSizeBeforeUpdate = wireRecipientRepository.findAll().size();

        // Update the wireRecipient using partial update
        WireRecipient partialUpdatedWireRecipient = new WireRecipient();
        partialUpdatedWireRecipient.setId(wireRecipient.getId());

        partialUpdatedWireRecipient.recipientId(UPDATED_RECIPIENT_ID).recipientState(UPDATED_RECIPIENT_STATE);

        restWireRecipientMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedWireRecipient.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedWireRecipient))
            )
            .andExpect(status().isOk());

        // Validate the WireRecipient in the database
        List<WireRecipient> wireRecipientList = wireRecipientRepository.findAll();
        assertThat(wireRecipientList).hasSize(databaseSizeBeforeUpdate);
        WireRecipient testWireRecipient = wireRecipientList.get(wireRecipientList.size() - 1);
        assertThat(testWireRecipient.getRecipientId()).isEqualTo(UPDATED_RECIPIENT_ID);
        assertThat(testWireRecipient.getRecipeintName()).isEqualTo(DEFAULT_RECIPEINT_NAME);
        assertThat(testWireRecipient.getRecipientAddress()).isEqualTo(DEFAULT_RECIPIENT_ADDRESS);
        assertThat(testWireRecipient.getRecipientCountry()).isEqualTo(DEFAULT_RECIPIENT_COUNTRY);
        assertThat(testWireRecipient.getRecipientState()).isEqualTo(UPDATED_RECIPIENT_STATE);
        assertThat(testWireRecipient.getRecipientCity()).isEqualTo(DEFAULT_RECIPIENT_CITY);
    }

    @Test
    @Transactional
    void fullUpdateWireRecipientWithPatch() throws Exception {
        // Initialize the database
        wireRecipientRepository.saveAndFlush(wireRecipient);

        int databaseSizeBeforeUpdate = wireRecipientRepository.findAll().size();

        // Update the wireRecipient using partial update
        WireRecipient partialUpdatedWireRecipient = new WireRecipient();
        partialUpdatedWireRecipient.setId(wireRecipient.getId());

        partialUpdatedWireRecipient
            .recipientId(UPDATED_RECIPIENT_ID)
            .recipeintName(UPDATED_RECIPEINT_NAME)
            .recipientAddress(UPDATED_RECIPIENT_ADDRESS)
            .recipientCountry(UPDATED_RECIPIENT_COUNTRY)
            .recipientState(UPDATED_RECIPIENT_STATE)
            .recipientCity(UPDATED_RECIPIENT_CITY);

        restWireRecipientMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedWireRecipient.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedWireRecipient))
            )
            .andExpect(status().isOk());

        // Validate the WireRecipient in the database
        List<WireRecipient> wireRecipientList = wireRecipientRepository.findAll();
        assertThat(wireRecipientList).hasSize(databaseSizeBeforeUpdate);
        WireRecipient testWireRecipient = wireRecipientList.get(wireRecipientList.size() - 1);
        assertThat(testWireRecipient.getRecipientId()).isEqualTo(UPDATED_RECIPIENT_ID);
        assertThat(testWireRecipient.getRecipeintName()).isEqualTo(UPDATED_RECIPEINT_NAME);
        assertThat(testWireRecipient.getRecipientAddress()).isEqualTo(UPDATED_RECIPIENT_ADDRESS);
        assertThat(testWireRecipient.getRecipientCountry()).isEqualTo(UPDATED_RECIPIENT_COUNTRY);
        assertThat(testWireRecipient.getRecipientState()).isEqualTo(UPDATED_RECIPIENT_STATE);
        assertThat(testWireRecipient.getRecipientCity()).isEqualTo(UPDATED_RECIPIENT_CITY);
    }

    @Test
    @Transactional
    void patchNonExistingWireRecipient() throws Exception {
        int databaseSizeBeforeUpdate = wireRecipientRepository.findAll().size();
        wireRecipient.setId(longCount.incrementAndGet());

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restWireRecipientMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, wireRecipient.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(wireRecipient))
            )
            .andExpect(status().isBadRequest());

        // Validate the WireRecipient in the database
        List<WireRecipient> wireRecipientList = wireRecipientRepository.findAll();
        assertThat(wireRecipientList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithIdMismatchWireRecipient() throws Exception {
        int databaseSizeBeforeUpdate = wireRecipientRepository.findAll().size();
        wireRecipient.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restWireRecipientMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(wireRecipient))
            )
            .andExpect(status().isBadRequest());

        // Validate the WireRecipient in the database
        List<WireRecipient> wireRecipientList = wireRecipientRepository.findAll();
        assertThat(wireRecipientList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithMissingIdPathParamWireRecipient() throws Exception {
        int databaseSizeBeforeUpdate = wireRecipientRepository.findAll().size();
        wireRecipient.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restWireRecipientMockMvc
            .perform(
                patch(ENTITY_API_URL).contentType("application/merge-patch+json").content(TestUtil.convertObjectToJsonBytes(wireRecipient))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the WireRecipient in the database
        List<WireRecipient> wireRecipientList = wireRecipientRepository.findAll();
        assertThat(wireRecipientList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void deleteWireRecipient() throws Exception {
        // Initialize the database
        wireRecipientRepository.saveAndFlush(wireRecipient);

        int databaseSizeBeforeDelete = wireRecipientRepository.findAll().size();

        // Delete the wireRecipient
        restWireRecipientMockMvc
            .perform(delete(ENTITY_API_URL_ID, wireRecipient.getId()).accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<WireRecipient> wireRecipientList = wireRecipientRepository.findAll();
        assertThat(wireRecipientList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
