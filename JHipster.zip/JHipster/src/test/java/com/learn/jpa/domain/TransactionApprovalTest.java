package com.learn.jpa.domain;

import static com.learn.jpa.domain.TransactionApprovalTestSamples.*;
import static com.learn.jpa.domain.TransactionTestSamples.*;
import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class TransactionApprovalTest {

    @Test
    void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(TransactionApproval.class);
        TransactionApproval transactionApproval1 = getTransactionApprovalSample1();
        TransactionApproval transactionApproval2 = new TransactionApproval();
        assertThat(transactionApproval1).isNotEqualTo(transactionApproval2);

        transactionApproval2.setId(transactionApproval1.getId());
        assertThat(transactionApproval1).isEqualTo(transactionApproval2);

        transactionApproval2 = getTransactionApprovalSample2();
        assertThat(transactionApproval1).isNotEqualTo(transactionApproval2);
    }

    @Test
    void transactionTest() throws Exception {
        TransactionApproval transactionApproval = getTransactionApprovalRandomSampleGenerator();
        Transaction transactionBack = getTransactionRandomSampleGenerator();

        transactionApproval.setTransaction(transactionBack);
        assertThat(transactionApproval.getTransaction()).isEqualTo(transactionBack);
        assertThat(transactionBack.getTransactionApproval()).isEqualTo(transactionApproval);

        transactionApproval.transaction(null);
        assertThat(transactionApproval.getTransaction()).isNull();
        assertThat(transactionBack.getTransactionApproval()).isNull();
    }
}
