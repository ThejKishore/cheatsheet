package com.learn.jpa.web.rest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.learn.jpa.IntegrationTest;
import com.learn.jpa.domain.WireBeneficiary;
import com.learn.jpa.repository.WireBeneficiaryRepository;
import jakarta.persistence.EntityManager;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

/**
 * Integration tests for the {@link WireBeneficiaryResource} REST controller.
 */
@IntegrationTest
@AutoConfigureMockMvc
@WithMockUser
class WireBeneficiaryResourceIT {

    private static final Long DEFAULT_BENEFICIARY_ID = 1L;
    private static final Long UPDATED_BENEFICIARY_ID = 2L;

    private static final String DEFAULT_BENEFICIARY_NAME = "AAAAAAAAAA";
    private static final String UPDATED_BENEFICIARY_NAME = "BBBBBBBBBB";

    private static final String DEFAULT_BENEFICIARY_TYPE = "AAAAAAAAAA";
    private static final String UPDATED_BENEFICIARY_TYPE = "BBBBBBBBBB";

    private static final String ENTITY_API_URL = "/api/wire-beneficiaries";
    private static final String ENTITY_API_URL_ID = ENTITY_API_URL + "/{id}";

    private static Random random = new Random();
    private static AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    @Autowired
    private WireBeneficiaryRepository wireBeneficiaryRepository;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restWireBeneficiaryMockMvc;

    private WireBeneficiary wireBeneficiary;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static WireBeneficiary createEntity(EntityManager em) {
        WireBeneficiary wireBeneficiary = new WireBeneficiary()
            .beneficiaryId(DEFAULT_BENEFICIARY_ID)
            .beneficiaryName(DEFAULT_BENEFICIARY_NAME)
            .beneficiaryType(DEFAULT_BENEFICIARY_TYPE);
        return wireBeneficiary;
    }

    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static WireBeneficiary createUpdatedEntity(EntityManager em) {
        WireBeneficiary wireBeneficiary = new WireBeneficiary()
            .beneficiaryId(UPDATED_BENEFICIARY_ID)
            .beneficiaryName(UPDATED_BENEFICIARY_NAME)
            .beneficiaryType(UPDATED_BENEFICIARY_TYPE);
        return wireBeneficiary;
    }

    @BeforeEach
    public void initTest() {
        wireBeneficiary = createEntity(em);
    }

    @Test
    @Transactional
    void createWireBeneficiary() throws Exception {
        int databaseSizeBeforeCreate = wireBeneficiaryRepository.findAll().size();
        // Create the WireBeneficiary
        restWireBeneficiaryMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(wireBeneficiary))
            )
            .andExpect(status().isCreated());

        // Validate the WireBeneficiary in the database
        List<WireBeneficiary> wireBeneficiaryList = wireBeneficiaryRepository.findAll();
        assertThat(wireBeneficiaryList).hasSize(databaseSizeBeforeCreate + 1);
        WireBeneficiary testWireBeneficiary = wireBeneficiaryList.get(wireBeneficiaryList.size() - 1);
        assertThat(testWireBeneficiary.getBeneficiaryId()).isEqualTo(DEFAULT_BENEFICIARY_ID);
        assertThat(testWireBeneficiary.getBeneficiaryName()).isEqualTo(DEFAULT_BENEFICIARY_NAME);
        assertThat(testWireBeneficiary.getBeneficiaryType()).isEqualTo(DEFAULT_BENEFICIARY_TYPE);
    }

    @Test
    @Transactional
    void createWireBeneficiaryWithExistingId() throws Exception {
        // Create the WireBeneficiary with an existing ID
        wireBeneficiary.setId(1L);

        int databaseSizeBeforeCreate = wireBeneficiaryRepository.findAll().size();

        // An entity with an existing ID cannot be created, so this API call must fail
        restWireBeneficiaryMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(wireBeneficiary))
            )
            .andExpect(status().isBadRequest());

        // Validate the WireBeneficiary in the database
        List<WireBeneficiary> wireBeneficiaryList = wireBeneficiaryRepository.findAll();
        assertThat(wireBeneficiaryList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    void checkBeneficiaryIdIsRequired() throws Exception {
        int databaseSizeBeforeTest = wireBeneficiaryRepository.findAll().size();
        // set the field null
        wireBeneficiary.setBeneficiaryId(null);

        // Create the WireBeneficiary, which fails.

        restWireBeneficiaryMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(wireBeneficiary))
            )
            .andExpect(status().isBadRequest());

        List<WireBeneficiary> wireBeneficiaryList = wireBeneficiaryRepository.findAll();
        assertThat(wireBeneficiaryList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void getAllWireBeneficiaries() throws Exception {
        // Initialize the database
        wireBeneficiaryRepository.saveAndFlush(wireBeneficiary);

        // Get all the wireBeneficiaryList
        restWireBeneficiaryMockMvc
            .perform(get(ENTITY_API_URL + "?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(wireBeneficiary.getId().intValue())))
            .andExpect(jsonPath("$.[*].beneficiaryId").value(hasItem(DEFAULT_BENEFICIARY_ID.intValue())))
            .andExpect(jsonPath("$.[*].beneficiaryName").value(hasItem(DEFAULT_BENEFICIARY_NAME)))
            .andExpect(jsonPath("$.[*].beneficiaryType").value(hasItem(DEFAULT_BENEFICIARY_TYPE)));
    }

    @Test
    @Transactional
    void getWireBeneficiary() throws Exception {
        // Initialize the database
        wireBeneficiaryRepository.saveAndFlush(wireBeneficiary);

        // Get the wireBeneficiary
        restWireBeneficiaryMockMvc
            .perform(get(ENTITY_API_URL_ID, wireBeneficiary.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(wireBeneficiary.getId().intValue()))
            .andExpect(jsonPath("$.beneficiaryId").value(DEFAULT_BENEFICIARY_ID.intValue()))
            .andExpect(jsonPath("$.beneficiaryName").value(DEFAULT_BENEFICIARY_NAME))
            .andExpect(jsonPath("$.beneficiaryType").value(DEFAULT_BENEFICIARY_TYPE));
    }

    @Test
    @Transactional
    void getNonExistingWireBeneficiary() throws Exception {
        // Get the wireBeneficiary
        restWireBeneficiaryMockMvc.perform(get(ENTITY_API_URL_ID, Long.MAX_VALUE)).andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    void putExistingWireBeneficiary() throws Exception {
        // Initialize the database
        wireBeneficiaryRepository.saveAndFlush(wireBeneficiary);

        int databaseSizeBeforeUpdate = wireBeneficiaryRepository.findAll().size();

        // Update the wireBeneficiary
        WireBeneficiary updatedWireBeneficiary = wireBeneficiaryRepository.findById(wireBeneficiary.getId()).orElseThrow();
        // Disconnect from session so that the updates on updatedWireBeneficiary are not directly saved in db
        em.detach(updatedWireBeneficiary);
        updatedWireBeneficiary
            .beneficiaryId(UPDATED_BENEFICIARY_ID)
            .beneficiaryName(UPDATED_BENEFICIARY_NAME)
            .beneficiaryType(UPDATED_BENEFICIARY_TYPE);

        restWireBeneficiaryMockMvc
            .perform(
                put(ENTITY_API_URL_ID, updatedWireBeneficiary.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(updatedWireBeneficiary))
            )
            .andExpect(status().isOk());

        // Validate the WireBeneficiary in the database
        List<WireBeneficiary> wireBeneficiaryList = wireBeneficiaryRepository.findAll();
        assertThat(wireBeneficiaryList).hasSize(databaseSizeBeforeUpdate);
        WireBeneficiary testWireBeneficiary = wireBeneficiaryList.get(wireBeneficiaryList.size() - 1);
        assertThat(testWireBeneficiary.getBeneficiaryId()).isEqualTo(UPDATED_BENEFICIARY_ID);
        assertThat(testWireBeneficiary.getBeneficiaryName()).isEqualTo(UPDATED_BENEFICIARY_NAME);
        assertThat(testWireBeneficiary.getBeneficiaryType()).isEqualTo(UPDATED_BENEFICIARY_TYPE);
    }

    @Test
    @Transactional
    void putNonExistingWireBeneficiary() throws Exception {
        int databaseSizeBeforeUpdate = wireBeneficiaryRepository.findAll().size();
        wireBeneficiary.setId(longCount.incrementAndGet());

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restWireBeneficiaryMockMvc
            .perform(
                put(ENTITY_API_URL_ID, wireBeneficiary.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(wireBeneficiary))
            )
            .andExpect(status().isBadRequest());

        // Validate the WireBeneficiary in the database
        List<WireBeneficiary> wireBeneficiaryList = wireBeneficiaryRepository.findAll();
        assertThat(wireBeneficiaryList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithIdMismatchWireBeneficiary() throws Exception {
        int databaseSizeBeforeUpdate = wireBeneficiaryRepository.findAll().size();
        wireBeneficiary.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restWireBeneficiaryMockMvc
            .perform(
                put(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(wireBeneficiary))
            )
            .andExpect(status().isBadRequest());

        // Validate the WireBeneficiary in the database
        List<WireBeneficiary> wireBeneficiaryList = wireBeneficiaryRepository.findAll();
        assertThat(wireBeneficiaryList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithMissingIdPathParamWireBeneficiary() throws Exception {
        int databaseSizeBeforeUpdate = wireBeneficiaryRepository.findAll().size();
        wireBeneficiary.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restWireBeneficiaryMockMvc
            .perform(
                put(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(wireBeneficiary))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the WireBeneficiary in the database
        List<WireBeneficiary> wireBeneficiaryList = wireBeneficiaryRepository.findAll();
        assertThat(wireBeneficiaryList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void partialUpdateWireBeneficiaryWithPatch() throws Exception {
        // Initialize the database
        wireBeneficiaryRepository.saveAndFlush(wireBeneficiary);

        int databaseSizeBeforeUpdate = wireBeneficiaryRepository.findAll().size();

        // Update the wireBeneficiary using partial update
        WireBeneficiary partialUpdatedWireBeneficiary = new WireBeneficiary();
        partialUpdatedWireBeneficiary.setId(wireBeneficiary.getId());

        restWireBeneficiaryMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedWireBeneficiary.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedWireBeneficiary))
            )
            .andExpect(status().isOk());

        // Validate the WireBeneficiary in the database
        List<WireBeneficiary> wireBeneficiaryList = wireBeneficiaryRepository.findAll();
        assertThat(wireBeneficiaryList).hasSize(databaseSizeBeforeUpdate);
        WireBeneficiary testWireBeneficiary = wireBeneficiaryList.get(wireBeneficiaryList.size() - 1);
        assertThat(testWireBeneficiary.getBeneficiaryId()).isEqualTo(DEFAULT_BENEFICIARY_ID);
        assertThat(testWireBeneficiary.getBeneficiaryName()).isEqualTo(DEFAULT_BENEFICIARY_NAME);
        assertThat(testWireBeneficiary.getBeneficiaryType()).isEqualTo(DEFAULT_BENEFICIARY_TYPE);
    }

    @Test
    @Transactional
    void fullUpdateWireBeneficiaryWithPatch() throws Exception {
        // Initialize the database
        wireBeneficiaryRepository.saveAndFlush(wireBeneficiary);

        int databaseSizeBeforeUpdate = wireBeneficiaryRepository.findAll().size();

        // Update the wireBeneficiary using partial update
        WireBeneficiary partialUpdatedWireBeneficiary = new WireBeneficiary();
        partialUpdatedWireBeneficiary.setId(wireBeneficiary.getId());

        partialUpdatedWireBeneficiary
            .beneficiaryId(UPDATED_BENEFICIARY_ID)
            .beneficiaryName(UPDATED_BENEFICIARY_NAME)
            .beneficiaryType(UPDATED_BENEFICIARY_TYPE);

        restWireBeneficiaryMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedWireBeneficiary.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedWireBeneficiary))
            )
            .andExpect(status().isOk());

        // Validate the WireBeneficiary in the database
        List<WireBeneficiary> wireBeneficiaryList = wireBeneficiaryRepository.findAll();
        assertThat(wireBeneficiaryList).hasSize(databaseSizeBeforeUpdate);
        WireBeneficiary testWireBeneficiary = wireBeneficiaryList.get(wireBeneficiaryList.size() - 1);
        assertThat(testWireBeneficiary.getBeneficiaryId()).isEqualTo(UPDATED_BENEFICIARY_ID);
        assertThat(testWireBeneficiary.getBeneficiaryName()).isEqualTo(UPDATED_BENEFICIARY_NAME);
        assertThat(testWireBeneficiary.getBeneficiaryType()).isEqualTo(UPDATED_BENEFICIARY_TYPE);
    }

    @Test
    @Transactional
    void patchNonExistingWireBeneficiary() throws Exception {
        int databaseSizeBeforeUpdate = wireBeneficiaryRepository.findAll().size();
        wireBeneficiary.setId(longCount.incrementAndGet());

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restWireBeneficiaryMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, wireBeneficiary.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(wireBeneficiary))
            )
            .andExpect(status().isBadRequest());

        // Validate the WireBeneficiary in the database
        List<WireBeneficiary> wireBeneficiaryList = wireBeneficiaryRepository.findAll();
        assertThat(wireBeneficiaryList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithIdMismatchWireBeneficiary() throws Exception {
        int databaseSizeBeforeUpdate = wireBeneficiaryRepository.findAll().size();
        wireBeneficiary.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restWireBeneficiaryMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(wireBeneficiary))
            )
            .andExpect(status().isBadRequest());

        // Validate the WireBeneficiary in the database
        List<WireBeneficiary> wireBeneficiaryList = wireBeneficiaryRepository.findAll();
        assertThat(wireBeneficiaryList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithMissingIdPathParamWireBeneficiary() throws Exception {
        int databaseSizeBeforeUpdate = wireBeneficiaryRepository.findAll().size();
        wireBeneficiary.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restWireBeneficiaryMockMvc
            .perform(
                patch(ENTITY_API_URL)
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(wireBeneficiary))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the WireBeneficiary in the database
        List<WireBeneficiary> wireBeneficiaryList = wireBeneficiaryRepository.findAll();
        assertThat(wireBeneficiaryList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void deleteWireBeneficiary() throws Exception {
        // Initialize the database
        wireBeneficiaryRepository.saveAndFlush(wireBeneficiary);

        int databaseSizeBeforeDelete = wireBeneficiaryRepository.findAll().size();

        // Delete the wireBeneficiary
        restWireBeneficiaryMockMvc
            .perform(delete(ENTITY_API_URL_ID, wireBeneficiary.getId()).accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<WireBeneficiary> wireBeneficiaryList = wireBeneficiaryRepository.findAll();
        assertThat(wireBeneficiaryList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
