package com.learn.jpa.web.rest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.learn.jpa.IntegrationTest;
import com.learn.jpa.domain.AchTransaction;
import com.learn.jpa.repository.AchTransactionRepository;
import jakarta.persistence.EntityManager;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

/**
 * Integration tests for the {@link AchTransactionResource} REST controller.
 */
@IntegrationTest
@AutoConfigureMockMvc
@WithMockUser
class AchTransactionResourceIT {

    private static final Long DEFAULT_ACH_TRAN_ID = 1L;
    private static final Long UPDATED_ACH_TRAN_ID = 2L;

    private static final String ENTITY_API_URL = "/api/ach-transactions";
    private static final String ENTITY_API_URL_ID = ENTITY_API_URL + "/{id}";

    private static Random random = new Random();
    private static AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    @Autowired
    private AchTransactionRepository achTransactionRepository;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restAchTransactionMockMvc;

    private AchTransaction achTransaction;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static AchTransaction createEntity(EntityManager em) {
        AchTransaction achTransaction = new AchTransaction().achTranId(DEFAULT_ACH_TRAN_ID);
        return achTransaction;
    }

    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static AchTransaction createUpdatedEntity(EntityManager em) {
        AchTransaction achTransaction = new AchTransaction().achTranId(UPDATED_ACH_TRAN_ID);
        return achTransaction;
    }

    @BeforeEach
    public void initTest() {
        achTransaction = createEntity(em);
    }

    @Test
    @Transactional
    void createAchTransaction() throws Exception {
        int databaseSizeBeforeCreate = achTransactionRepository.findAll().size();
        // Create the AchTransaction
        restAchTransactionMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(achTransaction))
            )
            .andExpect(status().isCreated());

        // Validate the AchTransaction in the database
        List<AchTransaction> achTransactionList = achTransactionRepository.findAll();
        assertThat(achTransactionList).hasSize(databaseSizeBeforeCreate + 1);
        AchTransaction testAchTransaction = achTransactionList.get(achTransactionList.size() - 1);
        assertThat(testAchTransaction.getAchTranId()).isEqualTo(DEFAULT_ACH_TRAN_ID);
    }

    @Test
    @Transactional
    void createAchTransactionWithExistingId() throws Exception {
        // Create the AchTransaction with an existing ID
        achTransaction.setId(1L);

        int databaseSizeBeforeCreate = achTransactionRepository.findAll().size();

        // An entity with an existing ID cannot be created, so this API call must fail
        restAchTransactionMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(achTransaction))
            )
            .andExpect(status().isBadRequest());

        // Validate the AchTransaction in the database
        List<AchTransaction> achTransactionList = achTransactionRepository.findAll();
        assertThat(achTransactionList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    void checkAchTranIdIsRequired() throws Exception {
        int databaseSizeBeforeTest = achTransactionRepository.findAll().size();
        // set the field null
        achTransaction.setAchTranId(null);

        // Create the AchTransaction, which fails.

        restAchTransactionMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(achTransaction))
            )
            .andExpect(status().isBadRequest());

        List<AchTransaction> achTransactionList = achTransactionRepository.findAll();
        assertThat(achTransactionList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void getAllAchTransactions() throws Exception {
        // Initialize the database
        achTransactionRepository.saveAndFlush(achTransaction);

        // Get all the achTransactionList
        restAchTransactionMockMvc
            .perform(get(ENTITY_API_URL + "?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(achTransaction.getId().intValue())))
            .andExpect(jsonPath("$.[*].achTranId").value(hasItem(DEFAULT_ACH_TRAN_ID.intValue())));
    }

    @Test
    @Transactional
    void getAchTransaction() throws Exception {
        // Initialize the database
        achTransactionRepository.saveAndFlush(achTransaction);

        // Get the achTransaction
        restAchTransactionMockMvc
            .perform(get(ENTITY_API_URL_ID, achTransaction.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(achTransaction.getId().intValue()))
            .andExpect(jsonPath("$.achTranId").value(DEFAULT_ACH_TRAN_ID.intValue()));
    }

    @Test
    @Transactional
    void getNonExistingAchTransaction() throws Exception {
        // Get the achTransaction
        restAchTransactionMockMvc.perform(get(ENTITY_API_URL_ID, Long.MAX_VALUE)).andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    void putExistingAchTransaction() throws Exception {
        // Initialize the database
        achTransactionRepository.saveAndFlush(achTransaction);

        int databaseSizeBeforeUpdate = achTransactionRepository.findAll().size();

        // Update the achTransaction
        AchTransaction updatedAchTransaction = achTransactionRepository.findById(achTransaction.getId()).orElseThrow();
        // Disconnect from session so that the updates on updatedAchTransaction are not directly saved in db
        em.detach(updatedAchTransaction);
        updatedAchTransaction.achTranId(UPDATED_ACH_TRAN_ID);

        restAchTransactionMockMvc
            .perform(
                put(ENTITY_API_URL_ID, updatedAchTransaction.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(updatedAchTransaction))
            )
            .andExpect(status().isOk());

        // Validate the AchTransaction in the database
        List<AchTransaction> achTransactionList = achTransactionRepository.findAll();
        assertThat(achTransactionList).hasSize(databaseSizeBeforeUpdate);
        AchTransaction testAchTransaction = achTransactionList.get(achTransactionList.size() - 1);
        assertThat(testAchTransaction.getAchTranId()).isEqualTo(UPDATED_ACH_TRAN_ID);
    }

    @Test
    @Transactional
    void putNonExistingAchTransaction() throws Exception {
        int databaseSizeBeforeUpdate = achTransactionRepository.findAll().size();
        achTransaction.setId(longCount.incrementAndGet());

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restAchTransactionMockMvc
            .perform(
                put(ENTITY_API_URL_ID, achTransaction.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(achTransaction))
            )
            .andExpect(status().isBadRequest());

        // Validate the AchTransaction in the database
        List<AchTransaction> achTransactionList = achTransactionRepository.findAll();
        assertThat(achTransactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithIdMismatchAchTransaction() throws Exception {
        int databaseSizeBeforeUpdate = achTransactionRepository.findAll().size();
        achTransaction.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restAchTransactionMockMvc
            .perform(
                put(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(achTransaction))
            )
            .andExpect(status().isBadRequest());

        // Validate the AchTransaction in the database
        List<AchTransaction> achTransactionList = achTransactionRepository.findAll();
        assertThat(achTransactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithMissingIdPathParamAchTransaction() throws Exception {
        int databaseSizeBeforeUpdate = achTransactionRepository.findAll().size();
        achTransaction.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restAchTransactionMockMvc
            .perform(put(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(achTransaction)))
            .andExpect(status().isMethodNotAllowed());

        // Validate the AchTransaction in the database
        List<AchTransaction> achTransactionList = achTransactionRepository.findAll();
        assertThat(achTransactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void partialUpdateAchTransactionWithPatch() throws Exception {
        // Initialize the database
        achTransactionRepository.saveAndFlush(achTransaction);

        int databaseSizeBeforeUpdate = achTransactionRepository.findAll().size();

        // Update the achTransaction using partial update
        AchTransaction partialUpdatedAchTransaction = new AchTransaction();
        partialUpdatedAchTransaction.setId(achTransaction.getId());

        partialUpdatedAchTransaction.achTranId(UPDATED_ACH_TRAN_ID);

        restAchTransactionMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedAchTransaction.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedAchTransaction))
            )
            .andExpect(status().isOk());

        // Validate the AchTransaction in the database
        List<AchTransaction> achTransactionList = achTransactionRepository.findAll();
        assertThat(achTransactionList).hasSize(databaseSizeBeforeUpdate);
        AchTransaction testAchTransaction = achTransactionList.get(achTransactionList.size() - 1);
        assertThat(testAchTransaction.getAchTranId()).isEqualTo(UPDATED_ACH_TRAN_ID);
    }

    @Test
    @Transactional
    void fullUpdateAchTransactionWithPatch() throws Exception {
        // Initialize the database
        achTransactionRepository.saveAndFlush(achTransaction);

        int databaseSizeBeforeUpdate = achTransactionRepository.findAll().size();

        // Update the achTransaction using partial update
        AchTransaction partialUpdatedAchTransaction = new AchTransaction();
        partialUpdatedAchTransaction.setId(achTransaction.getId());

        partialUpdatedAchTransaction.achTranId(UPDATED_ACH_TRAN_ID);

        restAchTransactionMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedAchTransaction.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedAchTransaction))
            )
            .andExpect(status().isOk());

        // Validate the AchTransaction in the database
        List<AchTransaction> achTransactionList = achTransactionRepository.findAll();
        assertThat(achTransactionList).hasSize(databaseSizeBeforeUpdate);
        AchTransaction testAchTransaction = achTransactionList.get(achTransactionList.size() - 1);
        assertThat(testAchTransaction.getAchTranId()).isEqualTo(UPDATED_ACH_TRAN_ID);
    }

    @Test
    @Transactional
    void patchNonExistingAchTransaction() throws Exception {
        int databaseSizeBeforeUpdate = achTransactionRepository.findAll().size();
        achTransaction.setId(longCount.incrementAndGet());

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restAchTransactionMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, achTransaction.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(achTransaction))
            )
            .andExpect(status().isBadRequest());

        // Validate the AchTransaction in the database
        List<AchTransaction> achTransactionList = achTransactionRepository.findAll();
        assertThat(achTransactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithIdMismatchAchTransaction() throws Exception {
        int databaseSizeBeforeUpdate = achTransactionRepository.findAll().size();
        achTransaction.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restAchTransactionMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(achTransaction))
            )
            .andExpect(status().isBadRequest());

        // Validate the AchTransaction in the database
        List<AchTransaction> achTransactionList = achTransactionRepository.findAll();
        assertThat(achTransactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithMissingIdPathParamAchTransaction() throws Exception {
        int databaseSizeBeforeUpdate = achTransactionRepository.findAll().size();
        achTransaction.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restAchTransactionMockMvc
            .perform(
                patch(ENTITY_API_URL).contentType("application/merge-patch+json").content(TestUtil.convertObjectToJsonBytes(achTransaction))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the AchTransaction in the database
        List<AchTransaction> achTransactionList = achTransactionRepository.findAll();
        assertThat(achTransactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void deleteAchTransaction() throws Exception {
        // Initialize the database
        achTransactionRepository.saveAndFlush(achTransaction);

        int databaseSizeBeforeDelete = achTransactionRepository.findAll().size();

        // Delete the achTransaction
        restAchTransactionMockMvc
            .perform(delete(ENTITY_API_URL_ID, achTransaction.getId()).accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<AchTransaction> achTransactionList = achTransactionRepository.findAll();
        assertThat(achTransactionList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
