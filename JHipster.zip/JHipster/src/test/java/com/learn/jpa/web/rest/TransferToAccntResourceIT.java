package com.learn.jpa.web.rest;

import static com.learn.jpa.web.rest.TestUtil.sameNumber;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.learn.jpa.IntegrationTest;
import com.learn.jpa.domain.TransferToAccnt;
import com.learn.jpa.repository.TransferToAccntRepository;
import jakarta.persistence.EntityManager;
import java.math.BigDecimal;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

/**
 * Integration tests for the {@link TransferToAccntResource} REST controller.
 */
@IntegrationTest
@AutoConfigureMockMvc
@WithMockUser
class TransferToAccntResourceIT {

    private static final Long DEFAULT_TO_ACCNT_ID = 1L;
    private static final Long UPDATED_TO_ACCNT_ID = 2L;

    private static final Long DEFAULT_TO_ACCNT_SK = 1L;
    private static final Long UPDATED_TO_ACCNT_SK = 2L;

    private static final String DEFAULT_TO_ACCNT_NAME = "AAAAAAAAAA";
    private static final String UPDATED_TO_ACCNT_NAME = "BBBBBBBBBB";

    private static final BigDecimal DEFAULT_TO_ACCNT_AMNT = new BigDecimal(1);
    private static final BigDecimal UPDATED_TO_ACCNT_AMNT = new BigDecimal(2);

    private static final String ENTITY_API_URL = "/api/transfer-to-accnts";
    private static final String ENTITY_API_URL_ID = ENTITY_API_URL + "/{id}";

    private static Random random = new Random();
    private static AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    @Autowired
    private TransferToAccntRepository transferToAccntRepository;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restTransferToAccntMockMvc;

    private TransferToAccnt transferToAccnt;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static TransferToAccnt createEntity(EntityManager em) {
        TransferToAccnt transferToAccnt = new TransferToAccnt()
            .toAccntID(DEFAULT_TO_ACCNT_ID)
            .toAccntSk(DEFAULT_TO_ACCNT_SK)
            .toAccntName(DEFAULT_TO_ACCNT_NAME)
            .toAccntAmnt(DEFAULT_TO_ACCNT_AMNT);
        return transferToAccnt;
    }

    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static TransferToAccnt createUpdatedEntity(EntityManager em) {
        TransferToAccnt transferToAccnt = new TransferToAccnt()
            .toAccntID(UPDATED_TO_ACCNT_ID)
            .toAccntSk(UPDATED_TO_ACCNT_SK)
            .toAccntName(UPDATED_TO_ACCNT_NAME)
            .toAccntAmnt(UPDATED_TO_ACCNT_AMNT);
        return transferToAccnt;
    }

    @BeforeEach
    public void initTest() {
        transferToAccnt = createEntity(em);
    }

    @Test
    @Transactional
    void createTransferToAccnt() throws Exception {
        int databaseSizeBeforeCreate = transferToAccntRepository.findAll().size();
        // Create the TransferToAccnt
        restTransferToAccntMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(transferToAccnt))
            )
            .andExpect(status().isCreated());

        // Validate the TransferToAccnt in the database
        List<TransferToAccnt> transferToAccntList = transferToAccntRepository.findAll();
        assertThat(transferToAccntList).hasSize(databaseSizeBeforeCreate + 1);
        TransferToAccnt testTransferToAccnt = transferToAccntList.get(transferToAccntList.size() - 1);
        assertThat(testTransferToAccnt.getToAccntID()).isEqualTo(DEFAULT_TO_ACCNT_ID);
        assertThat(testTransferToAccnt.getToAccntSk()).isEqualTo(DEFAULT_TO_ACCNT_SK);
        assertThat(testTransferToAccnt.getToAccntName()).isEqualTo(DEFAULT_TO_ACCNT_NAME);
        assertThat(testTransferToAccnt.getToAccntAmnt()).isEqualByComparingTo(DEFAULT_TO_ACCNT_AMNT);
    }

    @Test
    @Transactional
    void createTransferToAccntWithExistingId() throws Exception {
        // Create the TransferToAccnt with an existing ID
        transferToAccnt.setId(1L);

        int databaseSizeBeforeCreate = transferToAccntRepository.findAll().size();

        // An entity with an existing ID cannot be created, so this API call must fail
        restTransferToAccntMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(transferToAccnt))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransferToAccnt in the database
        List<TransferToAccnt> transferToAccntList = transferToAccntRepository.findAll();
        assertThat(transferToAccntList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    void checkToAccntIDIsRequired() throws Exception {
        int databaseSizeBeforeTest = transferToAccntRepository.findAll().size();
        // set the field null
        transferToAccnt.setToAccntID(null);

        // Create the TransferToAccnt, which fails.

        restTransferToAccntMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(transferToAccnt))
            )
            .andExpect(status().isBadRequest());

        List<TransferToAccnt> transferToAccntList = transferToAccntRepository.findAll();
        assertThat(transferToAccntList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void getAllTransferToAccnts() throws Exception {
        // Initialize the database
        transferToAccntRepository.saveAndFlush(transferToAccnt);

        // Get all the transferToAccntList
        restTransferToAccntMockMvc
            .perform(get(ENTITY_API_URL + "?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(transferToAccnt.getId().intValue())))
            .andExpect(jsonPath("$.[*].toAccntID").value(hasItem(DEFAULT_TO_ACCNT_ID.intValue())))
            .andExpect(jsonPath("$.[*].toAccntSk").value(hasItem(DEFAULT_TO_ACCNT_SK.intValue())))
            .andExpect(jsonPath("$.[*].toAccntName").value(hasItem(DEFAULT_TO_ACCNT_NAME)))
            .andExpect(jsonPath("$.[*].toAccntAmnt").value(hasItem(sameNumber(DEFAULT_TO_ACCNT_AMNT))));
    }

    @Test
    @Transactional
    void getTransferToAccnt() throws Exception {
        // Initialize the database
        transferToAccntRepository.saveAndFlush(transferToAccnt);

        // Get the transferToAccnt
        restTransferToAccntMockMvc
            .perform(get(ENTITY_API_URL_ID, transferToAccnt.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(transferToAccnt.getId().intValue()))
            .andExpect(jsonPath("$.toAccntID").value(DEFAULT_TO_ACCNT_ID.intValue()))
            .andExpect(jsonPath("$.toAccntSk").value(DEFAULT_TO_ACCNT_SK.intValue()))
            .andExpect(jsonPath("$.toAccntName").value(DEFAULT_TO_ACCNT_NAME))
            .andExpect(jsonPath("$.toAccntAmnt").value(sameNumber(DEFAULT_TO_ACCNT_AMNT)));
    }

    @Test
    @Transactional
    void getNonExistingTransferToAccnt() throws Exception {
        // Get the transferToAccnt
        restTransferToAccntMockMvc.perform(get(ENTITY_API_URL_ID, Long.MAX_VALUE)).andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    void putExistingTransferToAccnt() throws Exception {
        // Initialize the database
        transferToAccntRepository.saveAndFlush(transferToAccnt);

        int databaseSizeBeforeUpdate = transferToAccntRepository.findAll().size();

        // Update the transferToAccnt
        TransferToAccnt updatedTransferToAccnt = transferToAccntRepository.findById(transferToAccnt.getId()).orElseThrow();
        // Disconnect from session so that the updates on updatedTransferToAccnt are not directly saved in db
        em.detach(updatedTransferToAccnt);
        updatedTransferToAccnt
            .toAccntID(UPDATED_TO_ACCNT_ID)
            .toAccntSk(UPDATED_TO_ACCNT_SK)
            .toAccntName(UPDATED_TO_ACCNT_NAME)
            .toAccntAmnt(UPDATED_TO_ACCNT_AMNT);

        restTransferToAccntMockMvc
            .perform(
                put(ENTITY_API_URL_ID, updatedTransferToAccnt.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(updatedTransferToAccnt))
            )
            .andExpect(status().isOk());

        // Validate the TransferToAccnt in the database
        List<TransferToAccnt> transferToAccntList = transferToAccntRepository.findAll();
        assertThat(transferToAccntList).hasSize(databaseSizeBeforeUpdate);
        TransferToAccnt testTransferToAccnt = transferToAccntList.get(transferToAccntList.size() - 1);
        assertThat(testTransferToAccnt.getToAccntID()).isEqualTo(UPDATED_TO_ACCNT_ID);
        assertThat(testTransferToAccnt.getToAccntSk()).isEqualTo(UPDATED_TO_ACCNT_SK);
        assertThat(testTransferToAccnt.getToAccntName()).isEqualTo(UPDATED_TO_ACCNT_NAME);
        assertThat(testTransferToAccnt.getToAccntAmnt()).isEqualByComparingTo(UPDATED_TO_ACCNT_AMNT);
    }

    @Test
    @Transactional
    void putNonExistingTransferToAccnt() throws Exception {
        int databaseSizeBeforeUpdate = transferToAccntRepository.findAll().size();
        transferToAccnt.setId(longCount.incrementAndGet());

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restTransferToAccntMockMvc
            .perform(
                put(ENTITY_API_URL_ID, transferToAccnt.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transferToAccnt))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransferToAccnt in the database
        List<TransferToAccnt> transferToAccntList = transferToAccntRepository.findAll();
        assertThat(transferToAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithIdMismatchTransferToAccnt() throws Exception {
        int databaseSizeBeforeUpdate = transferToAccntRepository.findAll().size();
        transferToAccnt.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransferToAccntMockMvc
            .perform(
                put(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transferToAccnt))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransferToAccnt in the database
        List<TransferToAccnt> transferToAccntList = transferToAccntRepository.findAll();
        assertThat(transferToAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithMissingIdPathParamTransferToAccnt() throws Exception {
        int databaseSizeBeforeUpdate = transferToAccntRepository.findAll().size();
        transferToAccnt.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransferToAccntMockMvc
            .perform(
                put(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(transferToAccnt))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the TransferToAccnt in the database
        List<TransferToAccnt> transferToAccntList = transferToAccntRepository.findAll();
        assertThat(transferToAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void partialUpdateTransferToAccntWithPatch() throws Exception {
        // Initialize the database
        transferToAccntRepository.saveAndFlush(transferToAccnt);

        int databaseSizeBeforeUpdate = transferToAccntRepository.findAll().size();

        // Update the transferToAccnt using partial update
        TransferToAccnt partialUpdatedTransferToAccnt = new TransferToAccnt();
        partialUpdatedTransferToAccnt.setId(transferToAccnt.getId());

        partialUpdatedTransferToAccnt.toAccntID(UPDATED_TO_ACCNT_ID).toAccntSk(UPDATED_TO_ACCNT_SK).toAccntName(UPDATED_TO_ACCNT_NAME);

        restTransferToAccntMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedTransferToAccnt.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedTransferToAccnt))
            )
            .andExpect(status().isOk());

        // Validate the TransferToAccnt in the database
        List<TransferToAccnt> transferToAccntList = transferToAccntRepository.findAll();
        assertThat(transferToAccntList).hasSize(databaseSizeBeforeUpdate);
        TransferToAccnt testTransferToAccnt = transferToAccntList.get(transferToAccntList.size() - 1);
        assertThat(testTransferToAccnt.getToAccntID()).isEqualTo(UPDATED_TO_ACCNT_ID);
        assertThat(testTransferToAccnt.getToAccntSk()).isEqualTo(UPDATED_TO_ACCNT_SK);
        assertThat(testTransferToAccnt.getToAccntName()).isEqualTo(UPDATED_TO_ACCNT_NAME);
        assertThat(testTransferToAccnt.getToAccntAmnt()).isEqualByComparingTo(DEFAULT_TO_ACCNT_AMNT);
    }

    @Test
    @Transactional
    void fullUpdateTransferToAccntWithPatch() throws Exception {
        // Initialize the database
        transferToAccntRepository.saveAndFlush(transferToAccnt);

        int databaseSizeBeforeUpdate = transferToAccntRepository.findAll().size();

        // Update the transferToAccnt using partial update
        TransferToAccnt partialUpdatedTransferToAccnt = new TransferToAccnt();
        partialUpdatedTransferToAccnt.setId(transferToAccnt.getId());

        partialUpdatedTransferToAccnt
            .toAccntID(UPDATED_TO_ACCNT_ID)
            .toAccntSk(UPDATED_TO_ACCNT_SK)
            .toAccntName(UPDATED_TO_ACCNT_NAME)
            .toAccntAmnt(UPDATED_TO_ACCNT_AMNT);

        restTransferToAccntMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedTransferToAccnt.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedTransferToAccnt))
            )
            .andExpect(status().isOk());

        // Validate the TransferToAccnt in the database
        List<TransferToAccnt> transferToAccntList = transferToAccntRepository.findAll();
        assertThat(transferToAccntList).hasSize(databaseSizeBeforeUpdate);
        TransferToAccnt testTransferToAccnt = transferToAccntList.get(transferToAccntList.size() - 1);
        assertThat(testTransferToAccnt.getToAccntID()).isEqualTo(UPDATED_TO_ACCNT_ID);
        assertThat(testTransferToAccnt.getToAccntSk()).isEqualTo(UPDATED_TO_ACCNT_SK);
        assertThat(testTransferToAccnt.getToAccntName()).isEqualTo(UPDATED_TO_ACCNT_NAME);
        assertThat(testTransferToAccnt.getToAccntAmnt()).isEqualByComparingTo(UPDATED_TO_ACCNT_AMNT);
    }

    @Test
    @Transactional
    void patchNonExistingTransferToAccnt() throws Exception {
        int databaseSizeBeforeUpdate = transferToAccntRepository.findAll().size();
        transferToAccnt.setId(longCount.incrementAndGet());

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restTransferToAccntMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, transferToAccnt.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(transferToAccnt))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransferToAccnt in the database
        List<TransferToAccnt> transferToAccntList = transferToAccntRepository.findAll();
        assertThat(transferToAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithIdMismatchTransferToAccnt() throws Exception {
        int databaseSizeBeforeUpdate = transferToAccntRepository.findAll().size();
        transferToAccnt.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransferToAccntMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(transferToAccnt))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransferToAccnt in the database
        List<TransferToAccnt> transferToAccntList = transferToAccntRepository.findAll();
        assertThat(transferToAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithMissingIdPathParamTransferToAccnt() throws Exception {
        int databaseSizeBeforeUpdate = transferToAccntRepository.findAll().size();
        transferToAccnt.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransferToAccntMockMvc
            .perform(
                patch(ENTITY_API_URL)
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(transferToAccnt))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the TransferToAccnt in the database
        List<TransferToAccnt> transferToAccntList = transferToAccntRepository.findAll();
        assertThat(transferToAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void deleteTransferToAccnt() throws Exception {
        // Initialize the database
        transferToAccntRepository.saveAndFlush(transferToAccnt);

        int databaseSizeBeforeDelete = transferToAccntRepository.findAll().size();

        // Delete the transferToAccnt
        restTransferToAccntMockMvc
            .perform(delete(ENTITY_API_URL_ID, transferToAccnt.getId()).accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<TransferToAccnt> transferToAccntList = transferToAccntRepository.findAll();
        assertThat(transferToAccntList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
