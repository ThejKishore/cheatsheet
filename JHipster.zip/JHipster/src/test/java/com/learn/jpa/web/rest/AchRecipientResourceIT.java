package com.learn.jpa.web.rest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.learn.jpa.IntegrationTest;
import com.learn.jpa.domain.AchRecipient;
import com.learn.jpa.repository.AchRecipientRepository;
import jakarta.persistence.EntityManager;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

/**
 * Integration tests for the {@link AchRecipientResource} REST controller.
 */
@IntegrationTest
@AutoConfigureMockMvc
@WithMockUser
class AchRecipientResourceIT {

    private static final Long DEFAULT_RECIPIENT_ID = 1L;
    private static final Long UPDATED_RECIPIENT_ID = 2L;

    private static final String DEFAULT_RECIPEINT_NAME = "AAAAAAAAAA";
    private static final String UPDATED_RECIPEINT_NAME = "BBBBBBBBBB";

    private static final String DEFAULT_RECIPIENT_ADDRESS = "AAAAAAAAAA";
    private static final String UPDATED_RECIPIENT_ADDRESS = "BBBBBBBBBB";

    private static final String DEFAULT_RECIPIENT_COUNTRY = "AAAAAAAAAA";
    private static final String UPDATED_RECIPIENT_COUNTRY = "BBBBBBBBBB";

    private static final String DEFAULT_RECIPIENT_STATE = "AAAAAAAAAA";
    private static final String UPDATED_RECIPIENT_STATE = "BBBBBBBBBB";

    private static final String DEFAULT_RECIPIENT_CITY = "AAAAAAAAAA";
    private static final String UPDATED_RECIPIENT_CITY = "BBBBBBBBBB";

    private static final String ENTITY_API_URL = "/api/ach-recipients";
    private static final String ENTITY_API_URL_ID = ENTITY_API_URL + "/{id}";

    private static Random random = new Random();
    private static AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    @Autowired
    private AchRecipientRepository achRecipientRepository;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restAchRecipientMockMvc;

    private AchRecipient achRecipient;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static AchRecipient createEntity(EntityManager em) {
        AchRecipient achRecipient = new AchRecipient()
            .recipientId(DEFAULT_RECIPIENT_ID)
            .recipeintName(DEFAULT_RECIPEINT_NAME)
            .recipientAddress(DEFAULT_RECIPIENT_ADDRESS)
            .recipientCountry(DEFAULT_RECIPIENT_COUNTRY)
            .recipientState(DEFAULT_RECIPIENT_STATE)
            .recipientCity(DEFAULT_RECIPIENT_CITY);
        return achRecipient;
    }

    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static AchRecipient createUpdatedEntity(EntityManager em) {
        AchRecipient achRecipient = new AchRecipient()
            .recipientId(UPDATED_RECIPIENT_ID)
            .recipeintName(UPDATED_RECIPEINT_NAME)
            .recipientAddress(UPDATED_RECIPIENT_ADDRESS)
            .recipientCountry(UPDATED_RECIPIENT_COUNTRY)
            .recipientState(UPDATED_RECIPIENT_STATE)
            .recipientCity(UPDATED_RECIPIENT_CITY);
        return achRecipient;
    }

    @BeforeEach
    public void initTest() {
        achRecipient = createEntity(em);
    }

    @Test
    @Transactional
    void createAchRecipient() throws Exception {
        int databaseSizeBeforeCreate = achRecipientRepository.findAll().size();
        // Create the AchRecipient
        restAchRecipientMockMvc
            .perform(post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(achRecipient)))
            .andExpect(status().isCreated());

        // Validate the AchRecipient in the database
        List<AchRecipient> achRecipientList = achRecipientRepository.findAll();
        assertThat(achRecipientList).hasSize(databaseSizeBeforeCreate + 1);
        AchRecipient testAchRecipient = achRecipientList.get(achRecipientList.size() - 1);
        assertThat(testAchRecipient.getRecipientId()).isEqualTo(DEFAULT_RECIPIENT_ID);
        assertThat(testAchRecipient.getRecipeintName()).isEqualTo(DEFAULT_RECIPEINT_NAME);
        assertThat(testAchRecipient.getRecipientAddress()).isEqualTo(DEFAULT_RECIPIENT_ADDRESS);
        assertThat(testAchRecipient.getRecipientCountry()).isEqualTo(DEFAULT_RECIPIENT_COUNTRY);
        assertThat(testAchRecipient.getRecipientState()).isEqualTo(DEFAULT_RECIPIENT_STATE);
        assertThat(testAchRecipient.getRecipientCity()).isEqualTo(DEFAULT_RECIPIENT_CITY);
    }

    @Test
    @Transactional
    void createAchRecipientWithExistingId() throws Exception {
        // Create the AchRecipient with an existing ID
        achRecipient.setId(1L);

        int databaseSizeBeforeCreate = achRecipientRepository.findAll().size();

        // An entity with an existing ID cannot be created, so this API call must fail
        restAchRecipientMockMvc
            .perform(post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(achRecipient)))
            .andExpect(status().isBadRequest());

        // Validate the AchRecipient in the database
        List<AchRecipient> achRecipientList = achRecipientRepository.findAll();
        assertThat(achRecipientList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    void checkRecipientIdIsRequired() throws Exception {
        int databaseSizeBeforeTest = achRecipientRepository.findAll().size();
        // set the field null
        achRecipient.setRecipientId(null);

        // Create the AchRecipient, which fails.

        restAchRecipientMockMvc
            .perform(post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(achRecipient)))
            .andExpect(status().isBadRequest());

        List<AchRecipient> achRecipientList = achRecipientRepository.findAll();
        assertThat(achRecipientList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void getAllAchRecipients() throws Exception {
        // Initialize the database
        achRecipientRepository.saveAndFlush(achRecipient);

        // Get all the achRecipientList
        restAchRecipientMockMvc
            .perform(get(ENTITY_API_URL + "?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(achRecipient.getId().intValue())))
            .andExpect(jsonPath("$.[*].recipientId").value(hasItem(DEFAULT_RECIPIENT_ID.intValue())))
            .andExpect(jsonPath("$.[*].recipeintName").value(hasItem(DEFAULT_RECIPEINT_NAME)))
            .andExpect(jsonPath("$.[*].recipientAddress").value(hasItem(DEFAULT_RECIPIENT_ADDRESS)))
            .andExpect(jsonPath("$.[*].recipientCountry").value(hasItem(DEFAULT_RECIPIENT_COUNTRY)))
            .andExpect(jsonPath("$.[*].recipientState").value(hasItem(DEFAULT_RECIPIENT_STATE)))
            .andExpect(jsonPath("$.[*].recipientCity").value(hasItem(DEFAULT_RECIPIENT_CITY)));
    }

    @Test
    @Transactional
    void getAchRecipient() throws Exception {
        // Initialize the database
        achRecipientRepository.saveAndFlush(achRecipient);

        // Get the achRecipient
        restAchRecipientMockMvc
            .perform(get(ENTITY_API_URL_ID, achRecipient.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(achRecipient.getId().intValue()))
            .andExpect(jsonPath("$.recipientId").value(DEFAULT_RECIPIENT_ID.intValue()))
            .andExpect(jsonPath("$.recipeintName").value(DEFAULT_RECIPEINT_NAME))
            .andExpect(jsonPath("$.recipientAddress").value(DEFAULT_RECIPIENT_ADDRESS))
            .andExpect(jsonPath("$.recipientCountry").value(DEFAULT_RECIPIENT_COUNTRY))
            .andExpect(jsonPath("$.recipientState").value(DEFAULT_RECIPIENT_STATE))
            .andExpect(jsonPath("$.recipientCity").value(DEFAULT_RECIPIENT_CITY));
    }

    @Test
    @Transactional
    void getNonExistingAchRecipient() throws Exception {
        // Get the achRecipient
        restAchRecipientMockMvc.perform(get(ENTITY_API_URL_ID, Long.MAX_VALUE)).andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    void putExistingAchRecipient() throws Exception {
        // Initialize the database
        achRecipientRepository.saveAndFlush(achRecipient);

        int databaseSizeBeforeUpdate = achRecipientRepository.findAll().size();

        // Update the achRecipient
        AchRecipient updatedAchRecipient = achRecipientRepository.findById(achRecipient.getId()).orElseThrow();
        // Disconnect from session so that the updates on updatedAchRecipient are not directly saved in db
        em.detach(updatedAchRecipient);
        updatedAchRecipient
            .recipientId(UPDATED_RECIPIENT_ID)
            .recipeintName(UPDATED_RECIPEINT_NAME)
            .recipientAddress(UPDATED_RECIPIENT_ADDRESS)
            .recipientCountry(UPDATED_RECIPIENT_COUNTRY)
            .recipientState(UPDATED_RECIPIENT_STATE)
            .recipientCity(UPDATED_RECIPIENT_CITY);

        restAchRecipientMockMvc
            .perform(
                put(ENTITY_API_URL_ID, updatedAchRecipient.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(updatedAchRecipient))
            )
            .andExpect(status().isOk());

        // Validate the AchRecipient in the database
        List<AchRecipient> achRecipientList = achRecipientRepository.findAll();
        assertThat(achRecipientList).hasSize(databaseSizeBeforeUpdate);
        AchRecipient testAchRecipient = achRecipientList.get(achRecipientList.size() - 1);
        assertThat(testAchRecipient.getRecipientId()).isEqualTo(UPDATED_RECIPIENT_ID);
        assertThat(testAchRecipient.getRecipeintName()).isEqualTo(UPDATED_RECIPEINT_NAME);
        assertThat(testAchRecipient.getRecipientAddress()).isEqualTo(UPDATED_RECIPIENT_ADDRESS);
        assertThat(testAchRecipient.getRecipientCountry()).isEqualTo(UPDATED_RECIPIENT_COUNTRY);
        assertThat(testAchRecipient.getRecipientState()).isEqualTo(UPDATED_RECIPIENT_STATE);
        assertThat(testAchRecipient.getRecipientCity()).isEqualTo(UPDATED_RECIPIENT_CITY);
    }

    @Test
    @Transactional
    void putNonExistingAchRecipient() throws Exception {
        int databaseSizeBeforeUpdate = achRecipientRepository.findAll().size();
        achRecipient.setId(longCount.incrementAndGet());

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restAchRecipientMockMvc
            .perform(
                put(ENTITY_API_URL_ID, achRecipient.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(achRecipient))
            )
            .andExpect(status().isBadRequest());

        // Validate the AchRecipient in the database
        List<AchRecipient> achRecipientList = achRecipientRepository.findAll();
        assertThat(achRecipientList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithIdMismatchAchRecipient() throws Exception {
        int databaseSizeBeforeUpdate = achRecipientRepository.findAll().size();
        achRecipient.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restAchRecipientMockMvc
            .perform(
                put(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(achRecipient))
            )
            .andExpect(status().isBadRequest());

        // Validate the AchRecipient in the database
        List<AchRecipient> achRecipientList = achRecipientRepository.findAll();
        assertThat(achRecipientList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithMissingIdPathParamAchRecipient() throws Exception {
        int databaseSizeBeforeUpdate = achRecipientRepository.findAll().size();
        achRecipient.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restAchRecipientMockMvc
            .perform(put(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(achRecipient)))
            .andExpect(status().isMethodNotAllowed());

        // Validate the AchRecipient in the database
        List<AchRecipient> achRecipientList = achRecipientRepository.findAll();
        assertThat(achRecipientList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void partialUpdateAchRecipientWithPatch() throws Exception {
        // Initialize the database
        achRecipientRepository.saveAndFlush(achRecipient);

        int databaseSizeBeforeUpdate = achRecipientRepository.findAll().size();

        // Update the achRecipient using partial update
        AchRecipient partialUpdatedAchRecipient = new AchRecipient();
        partialUpdatedAchRecipient.setId(achRecipient.getId());

        partialUpdatedAchRecipient.recipientCountry(UPDATED_RECIPIENT_COUNTRY);

        restAchRecipientMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedAchRecipient.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedAchRecipient))
            )
            .andExpect(status().isOk());

        // Validate the AchRecipient in the database
        List<AchRecipient> achRecipientList = achRecipientRepository.findAll();
        assertThat(achRecipientList).hasSize(databaseSizeBeforeUpdate);
        AchRecipient testAchRecipient = achRecipientList.get(achRecipientList.size() - 1);
        assertThat(testAchRecipient.getRecipientId()).isEqualTo(DEFAULT_RECIPIENT_ID);
        assertThat(testAchRecipient.getRecipeintName()).isEqualTo(DEFAULT_RECIPEINT_NAME);
        assertThat(testAchRecipient.getRecipientAddress()).isEqualTo(DEFAULT_RECIPIENT_ADDRESS);
        assertThat(testAchRecipient.getRecipientCountry()).isEqualTo(UPDATED_RECIPIENT_COUNTRY);
        assertThat(testAchRecipient.getRecipientState()).isEqualTo(DEFAULT_RECIPIENT_STATE);
        assertThat(testAchRecipient.getRecipientCity()).isEqualTo(DEFAULT_RECIPIENT_CITY);
    }

    @Test
    @Transactional
    void fullUpdateAchRecipientWithPatch() throws Exception {
        // Initialize the database
        achRecipientRepository.saveAndFlush(achRecipient);

        int databaseSizeBeforeUpdate = achRecipientRepository.findAll().size();

        // Update the achRecipient using partial update
        AchRecipient partialUpdatedAchRecipient = new AchRecipient();
        partialUpdatedAchRecipient.setId(achRecipient.getId());

        partialUpdatedAchRecipient
            .recipientId(UPDATED_RECIPIENT_ID)
            .recipeintName(UPDATED_RECIPEINT_NAME)
            .recipientAddress(UPDATED_RECIPIENT_ADDRESS)
            .recipientCountry(UPDATED_RECIPIENT_COUNTRY)
            .recipientState(UPDATED_RECIPIENT_STATE)
            .recipientCity(UPDATED_RECIPIENT_CITY);

        restAchRecipientMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedAchRecipient.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedAchRecipient))
            )
            .andExpect(status().isOk());

        // Validate the AchRecipient in the database
        List<AchRecipient> achRecipientList = achRecipientRepository.findAll();
        assertThat(achRecipientList).hasSize(databaseSizeBeforeUpdate);
        AchRecipient testAchRecipient = achRecipientList.get(achRecipientList.size() - 1);
        assertThat(testAchRecipient.getRecipientId()).isEqualTo(UPDATED_RECIPIENT_ID);
        assertThat(testAchRecipient.getRecipeintName()).isEqualTo(UPDATED_RECIPEINT_NAME);
        assertThat(testAchRecipient.getRecipientAddress()).isEqualTo(UPDATED_RECIPIENT_ADDRESS);
        assertThat(testAchRecipient.getRecipientCountry()).isEqualTo(UPDATED_RECIPIENT_COUNTRY);
        assertThat(testAchRecipient.getRecipientState()).isEqualTo(UPDATED_RECIPIENT_STATE);
        assertThat(testAchRecipient.getRecipientCity()).isEqualTo(UPDATED_RECIPIENT_CITY);
    }

    @Test
    @Transactional
    void patchNonExistingAchRecipient() throws Exception {
        int databaseSizeBeforeUpdate = achRecipientRepository.findAll().size();
        achRecipient.setId(longCount.incrementAndGet());

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restAchRecipientMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, achRecipient.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(achRecipient))
            )
            .andExpect(status().isBadRequest());

        // Validate the AchRecipient in the database
        List<AchRecipient> achRecipientList = achRecipientRepository.findAll();
        assertThat(achRecipientList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithIdMismatchAchRecipient() throws Exception {
        int databaseSizeBeforeUpdate = achRecipientRepository.findAll().size();
        achRecipient.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restAchRecipientMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(achRecipient))
            )
            .andExpect(status().isBadRequest());

        // Validate the AchRecipient in the database
        List<AchRecipient> achRecipientList = achRecipientRepository.findAll();
        assertThat(achRecipientList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithMissingIdPathParamAchRecipient() throws Exception {
        int databaseSizeBeforeUpdate = achRecipientRepository.findAll().size();
        achRecipient.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restAchRecipientMockMvc
            .perform(
                patch(ENTITY_API_URL).contentType("application/merge-patch+json").content(TestUtil.convertObjectToJsonBytes(achRecipient))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the AchRecipient in the database
        List<AchRecipient> achRecipientList = achRecipientRepository.findAll();
        assertThat(achRecipientList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void deleteAchRecipient() throws Exception {
        // Initialize the database
        achRecipientRepository.saveAndFlush(achRecipient);

        int databaseSizeBeforeDelete = achRecipientRepository.findAll().size();

        // Delete the achRecipient
        restAchRecipientMockMvc
            .perform(delete(ENTITY_API_URL_ID, achRecipient.getId()).accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<AchRecipient> achRecipientList = achRecipientRepository.findAll();
        assertThat(achRecipientList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
