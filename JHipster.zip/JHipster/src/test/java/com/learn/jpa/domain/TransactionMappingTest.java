package com.learn.jpa.domain;

import static com.learn.jpa.domain.AchTransactionTestSamples.*;
import static com.learn.jpa.domain.TransactionMappingTestSamples.*;
import static com.learn.jpa.domain.TransactionTestSamples.*;
import static com.learn.jpa.domain.TransferTransactionTestSamples.*;
import static com.learn.jpa.domain.WireTransactionTestSamples.*;
import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class TransactionMappingTest {

    @Test
    void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(TransactionMapping.class);
        TransactionMapping transactionMapping1 = getTransactionMappingSample1();
        TransactionMapping transactionMapping2 = new TransactionMapping();
        assertThat(transactionMapping1).isNotEqualTo(transactionMapping2);

        transactionMapping2.setId(transactionMapping1.getId());
        assertThat(transactionMapping1).isEqualTo(transactionMapping2);

        transactionMapping2 = getTransactionMappingSample2();
        assertThat(transactionMapping1).isNotEqualTo(transactionMapping2);
    }

    @Test
    void transactionTest() throws Exception {
        TransactionMapping transactionMapping = getTransactionMappingRandomSampleGenerator();
        Transaction transactionBack = getTransactionRandomSampleGenerator();

        transactionMapping.setTransaction(transactionBack);
        assertThat(transactionMapping.getTransaction()).isEqualTo(transactionBack);
        assertThat(transactionBack.getTransactionMapping()).isEqualTo(transactionMapping);

        transactionMapping.transaction(null);
        assertThat(transactionMapping.getTransaction()).isNull();
        assertThat(transactionBack.getTransactionMapping()).isNull();
    }

    @Test
    void achTransactionTest() throws Exception {
        TransactionMapping transactionMapping = getTransactionMappingRandomSampleGenerator();
        AchTransaction achTransactionBack = getAchTransactionRandomSampleGenerator();

        transactionMapping.setAchTransaction(achTransactionBack);
        assertThat(transactionMapping.getAchTransaction()).isEqualTo(achTransactionBack);
        assertThat(achTransactionBack.getTransactionMapping()).isEqualTo(transactionMapping);

        transactionMapping.achTransaction(null);
        assertThat(transactionMapping.getAchTransaction()).isNull();
        assertThat(achTransactionBack.getTransactionMapping()).isNull();
    }

    @Test
    void wireTransactionTest() throws Exception {
        TransactionMapping transactionMapping = getTransactionMappingRandomSampleGenerator();
        WireTransaction wireTransactionBack = getWireTransactionRandomSampleGenerator();

        transactionMapping.setWireTransaction(wireTransactionBack);
        assertThat(transactionMapping.getWireTransaction()).isEqualTo(wireTransactionBack);
        assertThat(wireTransactionBack.getTransactionMapping()).isEqualTo(transactionMapping);

        transactionMapping.wireTransaction(null);
        assertThat(transactionMapping.getWireTransaction()).isNull();
        assertThat(wireTransactionBack.getTransactionMapping()).isNull();
    }

    @Test
    void transferTransactionTest() throws Exception {
        TransactionMapping transactionMapping = getTransactionMappingRandomSampleGenerator();
        TransferTransaction transferTransactionBack = getTransferTransactionRandomSampleGenerator();

        transactionMapping.setTransferTransaction(transferTransactionBack);
        assertThat(transactionMapping.getTransferTransaction()).isEqualTo(transferTransactionBack);
        assertThat(transferTransactionBack.getTransactionMapping()).isEqualTo(transactionMapping);

        transactionMapping.transferTransaction(null);
        assertThat(transactionMapping.getTransferTransaction()).isNull();
        assertThat(transferTransactionBack.getTransactionMapping()).isNull();
    }
}
