package com.learn.jpa.web.rest;

import static com.learn.jpa.web.rest.TestUtil.sameNumber;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.learn.jpa.IntegrationTest;
import com.learn.jpa.domain.WireFromAccnt;
import com.learn.jpa.repository.WireFromAccntRepository;
import jakarta.persistence.EntityManager;
import java.math.BigDecimal;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

/**
 * Integration tests for the {@link WireFromAccntResource} REST controller.
 */
@IntegrationTest
@AutoConfigureMockMvc
@WithMockUser
class WireFromAccntResourceIT {

    private static final Long DEFAULT_FROM_ACCNT_ID = 1L;
    private static final Long UPDATED_FROM_ACCNT_ID = 2L;

    private static final Long DEFAULT_FROM_ACCNT_SK = 1L;
    private static final Long UPDATED_FROM_ACCNT_SK = 2L;

    private static final String DEFAULT_FROM_ACCNT_NAME = "AAAAAAAAAA";
    private static final String UPDATED_FROM_ACCNT_NAME = "BBBBBBBBBB";

    private static final BigDecimal DEFAULT_FROM_ACCNT_AMNT = new BigDecimal(1);
    private static final BigDecimal UPDATED_FROM_ACCNT_AMNT = new BigDecimal(2);

    private static final String ENTITY_API_URL = "/api/wire-from-accnts";
    private static final String ENTITY_API_URL_ID = ENTITY_API_URL + "/{id}";

    private static Random random = new Random();
    private static AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    @Autowired
    private WireFromAccntRepository wireFromAccntRepository;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restWireFromAccntMockMvc;

    private WireFromAccnt wireFromAccnt;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static WireFromAccnt createEntity(EntityManager em) {
        WireFromAccnt wireFromAccnt = new WireFromAccnt()
            .fromAccntID(DEFAULT_FROM_ACCNT_ID)
            .fromAccntSk(DEFAULT_FROM_ACCNT_SK)
            .fromAccntName(DEFAULT_FROM_ACCNT_NAME)
            .fromAccntAmnt(DEFAULT_FROM_ACCNT_AMNT);
        return wireFromAccnt;
    }

    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static WireFromAccnt createUpdatedEntity(EntityManager em) {
        WireFromAccnt wireFromAccnt = new WireFromAccnt()
            .fromAccntID(UPDATED_FROM_ACCNT_ID)
            .fromAccntSk(UPDATED_FROM_ACCNT_SK)
            .fromAccntName(UPDATED_FROM_ACCNT_NAME)
            .fromAccntAmnt(UPDATED_FROM_ACCNT_AMNT);
        return wireFromAccnt;
    }

    @BeforeEach
    public void initTest() {
        wireFromAccnt = createEntity(em);
    }

    @Test
    @Transactional
    void createWireFromAccnt() throws Exception {
        int databaseSizeBeforeCreate = wireFromAccntRepository.findAll().size();
        // Create the WireFromAccnt
        restWireFromAccntMockMvc
            .perform(post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(wireFromAccnt)))
            .andExpect(status().isCreated());

        // Validate the WireFromAccnt in the database
        List<WireFromAccnt> wireFromAccntList = wireFromAccntRepository.findAll();
        assertThat(wireFromAccntList).hasSize(databaseSizeBeforeCreate + 1);
        WireFromAccnt testWireFromAccnt = wireFromAccntList.get(wireFromAccntList.size() - 1);
        assertThat(testWireFromAccnt.getFromAccntID()).isEqualTo(DEFAULT_FROM_ACCNT_ID);
        assertThat(testWireFromAccnt.getFromAccntSk()).isEqualTo(DEFAULT_FROM_ACCNT_SK);
        assertThat(testWireFromAccnt.getFromAccntName()).isEqualTo(DEFAULT_FROM_ACCNT_NAME);
        assertThat(testWireFromAccnt.getFromAccntAmnt()).isEqualByComparingTo(DEFAULT_FROM_ACCNT_AMNT);
    }

    @Test
    @Transactional
    void createWireFromAccntWithExistingId() throws Exception {
        // Create the WireFromAccnt with an existing ID
        wireFromAccnt.setId(1L);

        int databaseSizeBeforeCreate = wireFromAccntRepository.findAll().size();

        // An entity with an existing ID cannot be created, so this API call must fail
        restWireFromAccntMockMvc
            .perform(post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(wireFromAccnt)))
            .andExpect(status().isBadRequest());

        // Validate the WireFromAccnt in the database
        List<WireFromAccnt> wireFromAccntList = wireFromAccntRepository.findAll();
        assertThat(wireFromAccntList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    void checkFromAccntIDIsRequired() throws Exception {
        int databaseSizeBeforeTest = wireFromAccntRepository.findAll().size();
        // set the field null
        wireFromAccnt.setFromAccntID(null);

        // Create the WireFromAccnt, which fails.

        restWireFromAccntMockMvc
            .perform(post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(wireFromAccnt)))
            .andExpect(status().isBadRequest());

        List<WireFromAccnt> wireFromAccntList = wireFromAccntRepository.findAll();
        assertThat(wireFromAccntList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void getAllWireFromAccnts() throws Exception {
        // Initialize the database
        wireFromAccntRepository.saveAndFlush(wireFromAccnt);

        // Get all the wireFromAccntList
        restWireFromAccntMockMvc
            .perform(get(ENTITY_API_URL + "?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(wireFromAccnt.getId().intValue())))
            .andExpect(jsonPath("$.[*].fromAccntID").value(hasItem(DEFAULT_FROM_ACCNT_ID.intValue())))
            .andExpect(jsonPath("$.[*].fromAccntSk").value(hasItem(DEFAULT_FROM_ACCNT_SK.intValue())))
            .andExpect(jsonPath("$.[*].fromAccntName").value(hasItem(DEFAULT_FROM_ACCNT_NAME)))
            .andExpect(jsonPath("$.[*].fromAccntAmnt").value(hasItem(sameNumber(DEFAULT_FROM_ACCNT_AMNT))));
    }

    @Test
    @Transactional
    void getWireFromAccnt() throws Exception {
        // Initialize the database
        wireFromAccntRepository.saveAndFlush(wireFromAccnt);

        // Get the wireFromAccnt
        restWireFromAccntMockMvc
            .perform(get(ENTITY_API_URL_ID, wireFromAccnt.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(wireFromAccnt.getId().intValue()))
            .andExpect(jsonPath("$.fromAccntID").value(DEFAULT_FROM_ACCNT_ID.intValue()))
            .andExpect(jsonPath("$.fromAccntSk").value(DEFAULT_FROM_ACCNT_SK.intValue()))
            .andExpect(jsonPath("$.fromAccntName").value(DEFAULT_FROM_ACCNT_NAME))
            .andExpect(jsonPath("$.fromAccntAmnt").value(sameNumber(DEFAULT_FROM_ACCNT_AMNT)));
    }

    @Test
    @Transactional
    void getNonExistingWireFromAccnt() throws Exception {
        // Get the wireFromAccnt
        restWireFromAccntMockMvc.perform(get(ENTITY_API_URL_ID, Long.MAX_VALUE)).andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    void putExistingWireFromAccnt() throws Exception {
        // Initialize the database
        wireFromAccntRepository.saveAndFlush(wireFromAccnt);

        int databaseSizeBeforeUpdate = wireFromAccntRepository.findAll().size();

        // Update the wireFromAccnt
        WireFromAccnt updatedWireFromAccnt = wireFromAccntRepository.findById(wireFromAccnt.getId()).orElseThrow();
        // Disconnect from session so that the updates on updatedWireFromAccnt are not directly saved in db
        em.detach(updatedWireFromAccnt);
        updatedWireFromAccnt
            .fromAccntID(UPDATED_FROM_ACCNT_ID)
            .fromAccntSk(UPDATED_FROM_ACCNT_SK)
            .fromAccntName(UPDATED_FROM_ACCNT_NAME)
            .fromAccntAmnt(UPDATED_FROM_ACCNT_AMNT);

        restWireFromAccntMockMvc
            .perform(
                put(ENTITY_API_URL_ID, updatedWireFromAccnt.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(updatedWireFromAccnt))
            )
            .andExpect(status().isOk());

        // Validate the WireFromAccnt in the database
        List<WireFromAccnt> wireFromAccntList = wireFromAccntRepository.findAll();
        assertThat(wireFromAccntList).hasSize(databaseSizeBeforeUpdate);
        WireFromAccnt testWireFromAccnt = wireFromAccntList.get(wireFromAccntList.size() - 1);
        assertThat(testWireFromAccnt.getFromAccntID()).isEqualTo(UPDATED_FROM_ACCNT_ID);
        assertThat(testWireFromAccnt.getFromAccntSk()).isEqualTo(UPDATED_FROM_ACCNT_SK);
        assertThat(testWireFromAccnt.getFromAccntName()).isEqualTo(UPDATED_FROM_ACCNT_NAME);
        assertThat(testWireFromAccnt.getFromAccntAmnt()).isEqualByComparingTo(UPDATED_FROM_ACCNT_AMNT);
    }

    @Test
    @Transactional
    void putNonExistingWireFromAccnt() throws Exception {
        int databaseSizeBeforeUpdate = wireFromAccntRepository.findAll().size();
        wireFromAccnt.setId(longCount.incrementAndGet());

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restWireFromAccntMockMvc
            .perform(
                put(ENTITY_API_URL_ID, wireFromAccnt.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(wireFromAccnt))
            )
            .andExpect(status().isBadRequest());

        // Validate the WireFromAccnt in the database
        List<WireFromAccnt> wireFromAccntList = wireFromAccntRepository.findAll();
        assertThat(wireFromAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithIdMismatchWireFromAccnt() throws Exception {
        int databaseSizeBeforeUpdate = wireFromAccntRepository.findAll().size();
        wireFromAccnt.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restWireFromAccntMockMvc
            .perform(
                put(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(wireFromAccnt))
            )
            .andExpect(status().isBadRequest());

        // Validate the WireFromAccnt in the database
        List<WireFromAccnt> wireFromAccntList = wireFromAccntRepository.findAll();
        assertThat(wireFromAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithMissingIdPathParamWireFromAccnt() throws Exception {
        int databaseSizeBeforeUpdate = wireFromAccntRepository.findAll().size();
        wireFromAccnt.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restWireFromAccntMockMvc
            .perform(put(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(wireFromAccnt)))
            .andExpect(status().isMethodNotAllowed());

        // Validate the WireFromAccnt in the database
        List<WireFromAccnt> wireFromAccntList = wireFromAccntRepository.findAll();
        assertThat(wireFromAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void partialUpdateWireFromAccntWithPatch() throws Exception {
        // Initialize the database
        wireFromAccntRepository.saveAndFlush(wireFromAccnt);

        int databaseSizeBeforeUpdate = wireFromAccntRepository.findAll().size();

        // Update the wireFromAccnt using partial update
        WireFromAccnt partialUpdatedWireFromAccnt = new WireFromAccnt();
        partialUpdatedWireFromAccnt.setId(wireFromAccnt.getId());

        partialUpdatedWireFromAccnt
            .fromAccntSk(UPDATED_FROM_ACCNT_SK)
            .fromAccntName(UPDATED_FROM_ACCNT_NAME)
            .fromAccntAmnt(UPDATED_FROM_ACCNT_AMNT);

        restWireFromAccntMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedWireFromAccnt.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedWireFromAccnt))
            )
            .andExpect(status().isOk());

        // Validate the WireFromAccnt in the database
        List<WireFromAccnt> wireFromAccntList = wireFromAccntRepository.findAll();
        assertThat(wireFromAccntList).hasSize(databaseSizeBeforeUpdate);
        WireFromAccnt testWireFromAccnt = wireFromAccntList.get(wireFromAccntList.size() - 1);
        assertThat(testWireFromAccnt.getFromAccntID()).isEqualTo(DEFAULT_FROM_ACCNT_ID);
        assertThat(testWireFromAccnt.getFromAccntSk()).isEqualTo(UPDATED_FROM_ACCNT_SK);
        assertThat(testWireFromAccnt.getFromAccntName()).isEqualTo(UPDATED_FROM_ACCNT_NAME);
        assertThat(testWireFromAccnt.getFromAccntAmnt()).isEqualByComparingTo(UPDATED_FROM_ACCNT_AMNT);
    }

    @Test
    @Transactional
    void fullUpdateWireFromAccntWithPatch() throws Exception {
        // Initialize the database
        wireFromAccntRepository.saveAndFlush(wireFromAccnt);

        int databaseSizeBeforeUpdate = wireFromAccntRepository.findAll().size();

        // Update the wireFromAccnt using partial update
        WireFromAccnt partialUpdatedWireFromAccnt = new WireFromAccnt();
        partialUpdatedWireFromAccnt.setId(wireFromAccnt.getId());

        partialUpdatedWireFromAccnt
            .fromAccntID(UPDATED_FROM_ACCNT_ID)
            .fromAccntSk(UPDATED_FROM_ACCNT_SK)
            .fromAccntName(UPDATED_FROM_ACCNT_NAME)
            .fromAccntAmnt(UPDATED_FROM_ACCNT_AMNT);

        restWireFromAccntMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedWireFromAccnt.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedWireFromAccnt))
            )
            .andExpect(status().isOk());

        // Validate the WireFromAccnt in the database
        List<WireFromAccnt> wireFromAccntList = wireFromAccntRepository.findAll();
        assertThat(wireFromAccntList).hasSize(databaseSizeBeforeUpdate);
        WireFromAccnt testWireFromAccnt = wireFromAccntList.get(wireFromAccntList.size() - 1);
        assertThat(testWireFromAccnt.getFromAccntID()).isEqualTo(UPDATED_FROM_ACCNT_ID);
        assertThat(testWireFromAccnt.getFromAccntSk()).isEqualTo(UPDATED_FROM_ACCNT_SK);
        assertThat(testWireFromAccnt.getFromAccntName()).isEqualTo(UPDATED_FROM_ACCNT_NAME);
        assertThat(testWireFromAccnt.getFromAccntAmnt()).isEqualByComparingTo(UPDATED_FROM_ACCNT_AMNT);
    }

    @Test
    @Transactional
    void patchNonExistingWireFromAccnt() throws Exception {
        int databaseSizeBeforeUpdate = wireFromAccntRepository.findAll().size();
        wireFromAccnt.setId(longCount.incrementAndGet());

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restWireFromAccntMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, wireFromAccnt.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(wireFromAccnt))
            )
            .andExpect(status().isBadRequest());

        // Validate the WireFromAccnt in the database
        List<WireFromAccnt> wireFromAccntList = wireFromAccntRepository.findAll();
        assertThat(wireFromAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithIdMismatchWireFromAccnt() throws Exception {
        int databaseSizeBeforeUpdate = wireFromAccntRepository.findAll().size();
        wireFromAccnt.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restWireFromAccntMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(wireFromAccnt))
            )
            .andExpect(status().isBadRequest());

        // Validate the WireFromAccnt in the database
        List<WireFromAccnt> wireFromAccntList = wireFromAccntRepository.findAll();
        assertThat(wireFromAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithMissingIdPathParamWireFromAccnt() throws Exception {
        int databaseSizeBeforeUpdate = wireFromAccntRepository.findAll().size();
        wireFromAccnt.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restWireFromAccntMockMvc
            .perform(
                patch(ENTITY_API_URL).contentType("application/merge-patch+json").content(TestUtil.convertObjectToJsonBytes(wireFromAccnt))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the WireFromAccnt in the database
        List<WireFromAccnt> wireFromAccntList = wireFromAccntRepository.findAll();
        assertThat(wireFromAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void deleteWireFromAccnt() throws Exception {
        // Initialize the database
        wireFromAccntRepository.saveAndFlush(wireFromAccnt);

        int databaseSizeBeforeDelete = wireFromAccntRepository.findAll().size();

        // Delete the wireFromAccnt
        restWireFromAccntMockMvc
            .perform(delete(ENTITY_API_URL_ID, wireFromAccnt.getId()).accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<WireFromAccnt> wireFromAccntList = wireFromAccntRepository.findAll();
        assertThat(wireFromAccntList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
