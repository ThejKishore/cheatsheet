package com.learn.jpa.domain;

import static com.learn.jpa.domain.TransactionReviewTestSamples.*;
import static com.learn.jpa.domain.TransactionTestSamples.*;
import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class TransactionReviewTest {

    @Test
    void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(TransactionReview.class);
        TransactionReview transactionReview1 = getTransactionReviewSample1();
        TransactionReview transactionReview2 = new TransactionReview();
        assertThat(transactionReview1).isNotEqualTo(transactionReview2);

        transactionReview2.setId(transactionReview1.getId());
        assertThat(transactionReview1).isEqualTo(transactionReview2);

        transactionReview2 = getTransactionReviewSample2();
        assertThat(transactionReview1).isNotEqualTo(transactionReview2);
    }

    @Test
    void transactionTest() throws Exception {
        TransactionReview transactionReview = getTransactionReviewRandomSampleGenerator();
        Transaction transactionBack = getTransactionRandomSampleGenerator();

        transactionReview.setTransaction(transactionBack);
        assertThat(transactionReview.getTransaction()).isEqualTo(transactionBack);
        assertThat(transactionBack.getTransactionReview()).isEqualTo(transactionReview);

        transactionReview.transaction(null);
        assertThat(transactionReview.getTransaction()).isNull();
        assertThat(transactionBack.getTransactionReview()).isNull();
    }
}
