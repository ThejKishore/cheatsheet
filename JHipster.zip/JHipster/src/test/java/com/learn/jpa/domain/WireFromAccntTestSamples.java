package com.learn.jpa.domain;

import java.util.Random;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

public class WireFromAccntTestSamples {

    private static final Random random = new Random();
    private static final AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    public static WireFromAccnt getWireFromAccntSample1() {
        return new WireFromAccnt().id(1L).fromAccntID(1L).fromAccntSk(1L).fromAccntName("fromAccntName1");
    }

    public static WireFromAccnt getWireFromAccntSample2() {
        return new WireFromAccnt().id(2L).fromAccntID(2L).fromAccntSk(2L).fromAccntName("fromAccntName2");
    }

    public static WireFromAccnt getWireFromAccntRandomSampleGenerator() {
        return new WireFromAccnt()
            .id(longCount.incrementAndGet())
            .fromAccntID(longCount.incrementAndGet())
            .fromAccntSk(longCount.incrementAndGet())
            .fromAccntName(UUID.randomUUID().toString());
    }
}
