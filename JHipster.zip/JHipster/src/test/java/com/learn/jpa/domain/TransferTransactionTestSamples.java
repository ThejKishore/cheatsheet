package com.learn.jpa.domain;

import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

public class TransferTransactionTestSamples {

    private static final Random random = new Random();
    private static final AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    public static TransferTransaction getTransferTransactionSample1() {
        return new TransferTransaction().id(1L).transferTranId(1L);
    }

    public static TransferTransaction getTransferTransactionSample2() {
        return new TransferTransaction().id(2L).transferTranId(2L);
    }

    public static TransferTransaction getTransferTransactionRandomSampleGenerator() {
        return new TransferTransaction().id(longCount.incrementAndGet()).transferTranId(longCount.incrementAndGet());
    }
}
