package com.learn.jpa.domain;

import java.util.Random;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

public class AchRecipientTestSamples {

    private static final Random random = new Random();
    private static final AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    public static AchRecipient getAchRecipientSample1() {
        return new AchRecipient()
            .id(1L)
            .recipientId(1L)
            .recipeintName("recipeintName1")
            .recipientAddress("recipientAddress1")
            .recipientCountry("recipientCountry1")
            .recipientState("recipientState1")
            .recipientCity("recipientCity1");
    }

    public static AchRecipient getAchRecipientSample2() {
        return new AchRecipient()
            .id(2L)
            .recipientId(2L)
            .recipeintName("recipeintName2")
            .recipientAddress("recipientAddress2")
            .recipientCountry("recipientCountry2")
            .recipientState("recipientState2")
            .recipientCity("recipientCity2");
    }

    public static AchRecipient getAchRecipientRandomSampleGenerator() {
        return new AchRecipient()
            .id(longCount.incrementAndGet())
            .recipientId(longCount.incrementAndGet())
            .recipeintName(UUID.randomUUID().toString())
            .recipientAddress(UUID.randomUUID().toString())
            .recipientCountry(UUID.randomUUID().toString())
            .recipientState(UUID.randomUUID().toString())
            .recipientCity(UUID.randomUUID().toString());
    }
}
