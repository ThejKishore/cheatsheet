package com.learn.jpa.web.rest;

import static com.learn.jpa.web.rest.TestUtil.sameNumber;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.learn.jpa.IntegrationTest;
import com.learn.jpa.domain.TransferFromAccnt;
import com.learn.jpa.repository.TransferFromAccntRepository;
import jakarta.persistence.EntityManager;
import java.math.BigDecimal;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

/**
 * Integration tests for the {@link TransferFromAccntResource} REST controller.
 */
@IntegrationTest
@AutoConfigureMockMvc
@WithMockUser
class TransferFromAccntResourceIT {

    private static final Long DEFAULT_FROM_ACCNT_ID = 1L;
    private static final Long UPDATED_FROM_ACCNT_ID = 2L;

    private static final Long DEFAULT_FROM_ACCNT_SK = 1L;
    private static final Long UPDATED_FROM_ACCNT_SK = 2L;

    private static final String DEFAULT_FROM_ACCNT_NAME = "AAAAAAAAAA";
    private static final String UPDATED_FROM_ACCNT_NAME = "BBBBBBBBBB";

    private static final BigDecimal DEFAULT_FROM_ACCNT_AMNT = new BigDecimal(1);
    private static final BigDecimal UPDATED_FROM_ACCNT_AMNT = new BigDecimal(2);

    private static final String ENTITY_API_URL = "/api/transfer-from-accnts";
    private static final String ENTITY_API_URL_ID = ENTITY_API_URL + "/{id}";

    private static Random random = new Random();
    private static AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    @Autowired
    private TransferFromAccntRepository transferFromAccntRepository;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restTransferFromAccntMockMvc;

    private TransferFromAccnt transferFromAccnt;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static TransferFromAccnt createEntity(EntityManager em) {
        TransferFromAccnt transferFromAccnt = new TransferFromAccnt()
            .fromAccntID(DEFAULT_FROM_ACCNT_ID)
            .fromAccntSk(DEFAULT_FROM_ACCNT_SK)
            .fromAccntName(DEFAULT_FROM_ACCNT_NAME)
            .fromAccntAmnt(DEFAULT_FROM_ACCNT_AMNT);
        return transferFromAccnt;
    }

    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static TransferFromAccnt createUpdatedEntity(EntityManager em) {
        TransferFromAccnt transferFromAccnt = new TransferFromAccnt()
            .fromAccntID(UPDATED_FROM_ACCNT_ID)
            .fromAccntSk(UPDATED_FROM_ACCNT_SK)
            .fromAccntName(UPDATED_FROM_ACCNT_NAME)
            .fromAccntAmnt(UPDATED_FROM_ACCNT_AMNT);
        return transferFromAccnt;
    }

    @BeforeEach
    public void initTest() {
        transferFromAccnt = createEntity(em);
    }

    @Test
    @Transactional
    void createTransferFromAccnt() throws Exception {
        int databaseSizeBeforeCreate = transferFromAccntRepository.findAll().size();
        // Create the TransferFromAccnt
        restTransferFromAccntMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(transferFromAccnt))
            )
            .andExpect(status().isCreated());

        // Validate the TransferFromAccnt in the database
        List<TransferFromAccnt> transferFromAccntList = transferFromAccntRepository.findAll();
        assertThat(transferFromAccntList).hasSize(databaseSizeBeforeCreate + 1);
        TransferFromAccnt testTransferFromAccnt = transferFromAccntList.get(transferFromAccntList.size() - 1);
        assertThat(testTransferFromAccnt.getFromAccntID()).isEqualTo(DEFAULT_FROM_ACCNT_ID);
        assertThat(testTransferFromAccnt.getFromAccntSk()).isEqualTo(DEFAULT_FROM_ACCNT_SK);
        assertThat(testTransferFromAccnt.getFromAccntName()).isEqualTo(DEFAULT_FROM_ACCNT_NAME);
        assertThat(testTransferFromAccnt.getFromAccntAmnt()).isEqualByComparingTo(DEFAULT_FROM_ACCNT_AMNT);
    }

    @Test
    @Transactional
    void createTransferFromAccntWithExistingId() throws Exception {
        // Create the TransferFromAccnt with an existing ID
        transferFromAccnt.setId(1L);

        int databaseSizeBeforeCreate = transferFromAccntRepository.findAll().size();

        // An entity with an existing ID cannot be created, so this API call must fail
        restTransferFromAccntMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(transferFromAccnt))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransferFromAccnt in the database
        List<TransferFromAccnt> transferFromAccntList = transferFromAccntRepository.findAll();
        assertThat(transferFromAccntList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    void checkFromAccntIDIsRequired() throws Exception {
        int databaseSizeBeforeTest = transferFromAccntRepository.findAll().size();
        // set the field null
        transferFromAccnt.setFromAccntID(null);

        // Create the TransferFromAccnt, which fails.

        restTransferFromAccntMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(transferFromAccnt))
            )
            .andExpect(status().isBadRequest());

        List<TransferFromAccnt> transferFromAccntList = transferFromAccntRepository.findAll();
        assertThat(transferFromAccntList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void getAllTransferFromAccnts() throws Exception {
        // Initialize the database
        transferFromAccntRepository.saveAndFlush(transferFromAccnt);

        // Get all the transferFromAccntList
        restTransferFromAccntMockMvc
            .perform(get(ENTITY_API_URL + "?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(transferFromAccnt.getId().intValue())))
            .andExpect(jsonPath("$.[*].fromAccntID").value(hasItem(DEFAULT_FROM_ACCNT_ID.intValue())))
            .andExpect(jsonPath("$.[*].fromAccntSk").value(hasItem(DEFAULT_FROM_ACCNT_SK.intValue())))
            .andExpect(jsonPath("$.[*].fromAccntName").value(hasItem(DEFAULT_FROM_ACCNT_NAME)))
            .andExpect(jsonPath("$.[*].fromAccntAmnt").value(hasItem(sameNumber(DEFAULT_FROM_ACCNT_AMNT))));
    }

    @Test
    @Transactional
    void getTransferFromAccnt() throws Exception {
        // Initialize the database
        transferFromAccntRepository.saveAndFlush(transferFromAccnt);

        // Get the transferFromAccnt
        restTransferFromAccntMockMvc
            .perform(get(ENTITY_API_URL_ID, transferFromAccnt.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(transferFromAccnt.getId().intValue()))
            .andExpect(jsonPath("$.fromAccntID").value(DEFAULT_FROM_ACCNT_ID.intValue()))
            .andExpect(jsonPath("$.fromAccntSk").value(DEFAULT_FROM_ACCNT_SK.intValue()))
            .andExpect(jsonPath("$.fromAccntName").value(DEFAULT_FROM_ACCNT_NAME))
            .andExpect(jsonPath("$.fromAccntAmnt").value(sameNumber(DEFAULT_FROM_ACCNT_AMNT)));
    }

    @Test
    @Transactional
    void getNonExistingTransferFromAccnt() throws Exception {
        // Get the transferFromAccnt
        restTransferFromAccntMockMvc.perform(get(ENTITY_API_URL_ID, Long.MAX_VALUE)).andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    void putExistingTransferFromAccnt() throws Exception {
        // Initialize the database
        transferFromAccntRepository.saveAndFlush(transferFromAccnt);

        int databaseSizeBeforeUpdate = transferFromAccntRepository.findAll().size();

        // Update the transferFromAccnt
        TransferFromAccnt updatedTransferFromAccnt = transferFromAccntRepository.findById(transferFromAccnt.getId()).orElseThrow();
        // Disconnect from session so that the updates on updatedTransferFromAccnt are not directly saved in db
        em.detach(updatedTransferFromAccnt);
        updatedTransferFromAccnt
            .fromAccntID(UPDATED_FROM_ACCNT_ID)
            .fromAccntSk(UPDATED_FROM_ACCNT_SK)
            .fromAccntName(UPDATED_FROM_ACCNT_NAME)
            .fromAccntAmnt(UPDATED_FROM_ACCNT_AMNT);

        restTransferFromAccntMockMvc
            .perform(
                put(ENTITY_API_URL_ID, updatedTransferFromAccnt.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(updatedTransferFromAccnt))
            )
            .andExpect(status().isOk());

        // Validate the TransferFromAccnt in the database
        List<TransferFromAccnt> transferFromAccntList = transferFromAccntRepository.findAll();
        assertThat(transferFromAccntList).hasSize(databaseSizeBeforeUpdate);
        TransferFromAccnt testTransferFromAccnt = transferFromAccntList.get(transferFromAccntList.size() - 1);
        assertThat(testTransferFromAccnt.getFromAccntID()).isEqualTo(UPDATED_FROM_ACCNT_ID);
        assertThat(testTransferFromAccnt.getFromAccntSk()).isEqualTo(UPDATED_FROM_ACCNT_SK);
        assertThat(testTransferFromAccnt.getFromAccntName()).isEqualTo(UPDATED_FROM_ACCNT_NAME);
        assertThat(testTransferFromAccnt.getFromAccntAmnt()).isEqualByComparingTo(UPDATED_FROM_ACCNT_AMNT);
    }

    @Test
    @Transactional
    void putNonExistingTransferFromAccnt() throws Exception {
        int databaseSizeBeforeUpdate = transferFromAccntRepository.findAll().size();
        transferFromAccnt.setId(longCount.incrementAndGet());

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restTransferFromAccntMockMvc
            .perform(
                put(ENTITY_API_URL_ID, transferFromAccnt.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transferFromAccnt))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransferFromAccnt in the database
        List<TransferFromAccnt> transferFromAccntList = transferFromAccntRepository.findAll();
        assertThat(transferFromAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithIdMismatchTransferFromAccnt() throws Exception {
        int databaseSizeBeforeUpdate = transferFromAccntRepository.findAll().size();
        transferFromAccnt.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransferFromAccntMockMvc
            .perform(
                put(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transferFromAccnt))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransferFromAccnt in the database
        List<TransferFromAccnt> transferFromAccntList = transferFromAccntRepository.findAll();
        assertThat(transferFromAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithMissingIdPathParamTransferFromAccnt() throws Exception {
        int databaseSizeBeforeUpdate = transferFromAccntRepository.findAll().size();
        transferFromAccnt.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransferFromAccntMockMvc
            .perform(
                put(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(transferFromAccnt))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the TransferFromAccnt in the database
        List<TransferFromAccnt> transferFromAccntList = transferFromAccntRepository.findAll();
        assertThat(transferFromAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void partialUpdateTransferFromAccntWithPatch() throws Exception {
        // Initialize the database
        transferFromAccntRepository.saveAndFlush(transferFromAccnt);

        int databaseSizeBeforeUpdate = transferFromAccntRepository.findAll().size();

        // Update the transferFromAccnt using partial update
        TransferFromAccnt partialUpdatedTransferFromAccnt = new TransferFromAccnt();
        partialUpdatedTransferFromAccnt.setId(transferFromAccnt.getId());

        partialUpdatedTransferFromAccnt
            .fromAccntSk(UPDATED_FROM_ACCNT_SK)
            .fromAccntName(UPDATED_FROM_ACCNT_NAME)
            .fromAccntAmnt(UPDATED_FROM_ACCNT_AMNT);

        restTransferFromAccntMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedTransferFromAccnt.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedTransferFromAccnt))
            )
            .andExpect(status().isOk());

        // Validate the TransferFromAccnt in the database
        List<TransferFromAccnt> transferFromAccntList = transferFromAccntRepository.findAll();
        assertThat(transferFromAccntList).hasSize(databaseSizeBeforeUpdate);
        TransferFromAccnt testTransferFromAccnt = transferFromAccntList.get(transferFromAccntList.size() - 1);
        assertThat(testTransferFromAccnt.getFromAccntID()).isEqualTo(DEFAULT_FROM_ACCNT_ID);
        assertThat(testTransferFromAccnt.getFromAccntSk()).isEqualTo(UPDATED_FROM_ACCNT_SK);
        assertThat(testTransferFromAccnt.getFromAccntName()).isEqualTo(UPDATED_FROM_ACCNT_NAME);
        assertThat(testTransferFromAccnt.getFromAccntAmnt()).isEqualByComparingTo(UPDATED_FROM_ACCNT_AMNT);
    }

    @Test
    @Transactional
    void fullUpdateTransferFromAccntWithPatch() throws Exception {
        // Initialize the database
        transferFromAccntRepository.saveAndFlush(transferFromAccnt);

        int databaseSizeBeforeUpdate = transferFromAccntRepository.findAll().size();

        // Update the transferFromAccnt using partial update
        TransferFromAccnt partialUpdatedTransferFromAccnt = new TransferFromAccnt();
        partialUpdatedTransferFromAccnt.setId(transferFromAccnt.getId());

        partialUpdatedTransferFromAccnt
            .fromAccntID(UPDATED_FROM_ACCNT_ID)
            .fromAccntSk(UPDATED_FROM_ACCNT_SK)
            .fromAccntName(UPDATED_FROM_ACCNT_NAME)
            .fromAccntAmnt(UPDATED_FROM_ACCNT_AMNT);

        restTransferFromAccntMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedTransferFromAccnt.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedTransferFromAccnt))
            )
            .andExpect(status().isOk());

        // Validate the TransferFromAccnt in the database
        List<TransferFromAccnt> transferFromAccntList = transferFromAccntRepository.findAll();
        assertThat(transferFromAccntList).hasSize(databaseSizeBeforeUpdate);
        TransferFromAccnt testTransferFromAccnt = transferFromAccntList.get(transferFromAccntList.size() - 1);
        assertThat(testTransferFromAccnt.getFromAccntID()).isEqualTo(UPDATED_FROM_ACCNT_ID);
        assertThat(testTransferFromAccnt.getFromAccntSk()).isEqualTo(UPDATED_FROM_ACCNT_SK);
        assertThat(testTransferFromAccnt.getFromAccntName()).isEqualTo(UPDATED_FROM_ACCNT_NAME);
        assertThat(testTransferFromAccnt.getFromAccntAmnt()).isEqualByComparingTo(UPDATED_FROM_ACCNT_AMNT);
    }

    @Test
    @Transactional
    void patchNonExistingTransferFromAccnt() throws Exception {
        int databaseSizeBeforeUpdate = transferFromAccntRepository.findAll().size();
        transferFromAccnt.setId(longCount.incrementAndGet());

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restTransferFromAccntMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, transferFromAccnt.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(transferFromAccnt))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransferFromAccnt in the database
        List<TransferFromAccnt> transferFromAccntList = transferFromAccntRepository.findAll();
        assertThat(transferFromAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithIdMismatchTransferFromAccnt() throws Exception {
        int databaseSizeBeforeUpdate = transferFromAccntRepository.findAll().size();
        transferFromAccnt.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransferFromAccntMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(transferFromAccnt))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransferFromAccnt in the database
        List<TransferFromAccnt> transferFromAccntList = transferFromAccntRepository.findAll();
        assertThat(transferFromAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithMissingIdPathParamTransferFromAccnt() throws Exception {
        int databaseSizeBeforeUpdate = transferFromAccntRepository.findAll().size();
        transferFromAccnt.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransferFromAccntMockMvc
            .perform(
                patch(ENTITY_API_URL)
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(transferFromAccnt))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the TransferFromAccnt in the database
        List<TransferFromAccnt> transferFromAccntList = transferFromAccntRepository.findAll();
        assertThat(transferFromAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void deleteTransferFromAccnt() throws Exception {
        // Initialize the database
        transferFromAccntRepository.saveAndFlush(transferFromAccnt);

        int databaseSizeBeforeDelete = transferFromAccntRepository.findAll().size();

        // Delete the transferFromAccnt
        restTransferFromAccntMockMvc
            .perform(delete(ENTITY_API_URL_ID, transferFromAccnt.getId()).accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<TransferFromAccnt> transferFromAccntList = transferFromAccntRepository.findAll();
        assertThat(transferFromAccntList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
