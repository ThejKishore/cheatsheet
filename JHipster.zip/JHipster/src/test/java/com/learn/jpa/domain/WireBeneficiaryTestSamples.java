package com.learn.jpa.domain;

import java.util.Random;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

public class WireBeneficiaryTestSamples {

    private static final Random random = new Random();
    private static final AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    public static WireBeneficiary getWireBeneficiarySample1() {
        return new WireBeneficiary().id(1L).beneficiaryId(1L).beneficiaryName("beneficiaryName1").beneficiaryType("beneficiaryType1");
    }

    public static WireBeneficiary getWireBeneficiarySample2() {
        return new WireBeneficiary().id(2L).beneficiaryId(2L).beneficiaryName("beneficiaryName2").beneficiaryType("beneficiaryType2");
    }

    public static WireBeneficiary getWireBeneficiaryRandomSampleGenerator() {
        return new WireBeneficiary()
            .id(longCount.incrementAndGet())
            .beneficiaryId(longCount.incrementAndGet())
            .beneficiaryName(UUID.randomUUID().toString())
            .beneficiaryType(UUID.randomUUID().toString());
    }
}
