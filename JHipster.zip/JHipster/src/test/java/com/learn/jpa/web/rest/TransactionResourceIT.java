package com.learn.jpa.web.rest;

import static com.learn.jpa.web.rest.TestUtil.sameInstant;
import static com.learn.jpa.web.rest.TestUtil.sameNumber;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.learn.jpa.IntegrationTest;
import com.learn.jpa.domain.Transaction;
import com.learn.jpa.repository.TransactionRepository;
import jakarta.persistence.EntityManager;
import java.math.BigDecimal;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

/**
 * Integration tests for the {@link TransactionResource} REST controller.
 */
@IntegrationTest
@AutoConfigureMockMvc
@WithMockUser
class TransactionResourceIT {

    private static final Long DEFAULT_TRAN_ID = 1L;
    private static final Long UPDATED_TRAN_ID = 2L;

    private static final String DEFAULT_TRAN_NAME = "AAAAAAAAAA";
    private static final String UPDATED_TRAN_NAME = "BBBBBBBBBB";

    private static final Integer DEFAULT_FRM_CNT = 1;
    private static final Integer UPDATED_FRM_CNT = 2;

    private static final Integer DEFAULT_TO_CNT = 1;
    private static final Integer UPDATED_TO_CNT = 2;

    private static final BigDecimal DEFAULT_TOTAL_AMOUNT = new BigDecimal(1);
    private static final BigDecimal UPDATED_TOTAL_AMOUNT = new BigDecimal(2);

    private static final ZonedDateTime DEFAULT_CREATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneOffset.UTC);
    private static final ZonedDateTime UPDATED_CREATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    private static final ZonedDateTime DEFAULT_UPDATED_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneOffset.UTC);
    private static final ZonedDateTime UPDATED_UPDATED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    private static final String DEFAULT_CREATED_BY = "AAAAAAAAAA";
    private static final String UPDATED_CREATED_BY = "BBBBBBBBBB";

    private static final String DEFAULT_UPDATED_BY = "AAAAAAAAAA";
    private static final String UPDATED_UPDATED_BY = "BBBBBBBBBB";

    private static final ZonedDateTime DEFAULT_SETTLEMENT_DATE = ZonedDateTime.ofInstant(Instant.ofEpochMilli(0L), ZoneOffset.UTC);
    private static final ZonedDateTime UPDATED_SETTLEMENT_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    private static final String DEFAULT_FREQUENCY_TYPE = "AAAAAAAAAA";
    private static final String UPDATED_FREQUENCY_TYPE = "BBBBBBBBBB";

    private static final String DEFAULT_TRAN_TYPE = "AAAAAAAAAA";
    private static final String UPDATED_TRAN_TYPE = "BBBBBBBBBB";

    private static final Long DEFAULT_PROFILE_ID = 1L;
    private static final Long UPDATED_PROFILE_ID = 2L;

    private static final String DEFAULT_PROFILE_NAME = "AAAAAAAAAA";
    private static final String UPDATED_PROFILE_NAME = "BBBBBBBBBB";

    private static final String DEFAULT_NARRATIVE = "AAAAAAAAAA";
    private static final String UPDATED_NARRATIVE = "BBBBBBBBBB";

    private static final String DEFAULT_PRECEDING_NARRATIVE = "AAAAAAAAAA";
    private static final String UPDATED_PRECEDING_NARRATIVE = "BBBBBBBBBB";

    private static final String DEFAULT_CUSTOM_NARRATIVE = "AAAAAAAAAA";
    private static final String UPDATED_CUSTOM_NARRATIVE = "BBBBBBBBBB";

    private static final String DEFAULT_SYSTEM_GENERATED_NARRATIVE = "AAAAAAAAAA";
    private static final String UPDATED_SYSTEM_GENERATED_NARRATIVE = "BBBBBBBBBB";

    private static final String ENTITY_API_URL = "/api/transactions";
    private static final String ENTITY_API_URL_ID = ENTITY_API_URL + "/{id}";

    private static Random random = new Random();
    private static AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restTransactionMockMvc;

    private Transaction transaction;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Transaction createEntity(EntityManager em) {
        Transaction transaction = new Transaction()
            .tranId(DEFAULT_TRAN_ID)
            .tranName(DEFAULT_TRAN_NAME)
            .frmCnt(DEFAULT_FRM_CNT)
            .toCnt(DEFAULT_TO_CNT)
            .totalAmount(DEFAULT_TOTAL_AMOUNT)
            .createdDate(DEFAULT_CREATED_DATE)
            .updatedDate(DEFAULT_UPDATED_DATE)
            .createdBy(DEFAULT_CREATED_BY)
            .updatedBy(DEFAULT_UPDATED_BY)
            .settlementDate(DEFAULT_SETTLEMENT_DATE)
            .frequencyType(DEFAULT_FREQUENCY_TYPE)
            .tranType(DEFAULT_TRAN_TYPE)
            .profileId(DEFAULT_PROFILE_ID)
            .profileName(DEFAULT_PROFILE_NAME)
            .narrative(DEFAULT_NARRATIVE)
            .precedingNarrative(DEFAULT_PRECEDING_NARRATIVE)
            .customNarrative(DEFAULT_CUSTOM_NARRATIVE)
            .systemGeneratedNarrative(DEFAULT_SYSTEM_GENERATED_NARRATIVE);
        return transaction;
    }

    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static Transaction createUpdatedEntity(EntityManager em) {
        Transaction transaction = new Transaction()
            .tranId(UPDATED_TRAN_ID)
            .tranName(UPDATED_TRAN_NAME)
            .frmCnt(UPDATED_FRM_CNT)
            .toCnt(UPDATED_TO_CNT)
            .totalAmount(UPDATED_TOTAL_AMOUNT)
            .createdDate(UPDATED_CREATED_DATE)
            .updatedDate(UPDATED_UPDATED_DATE)
            .createdBy(UPDATED_CREATED_BY)
            .updatedBy(UPDATED_UPDATED_BY)
            .settlementDate(UPDATED_SETTLEMENT_DATE)
            .frequencyType(UPDATED_FREQUENCY_TYPE)
            .tranType(UPDATED_TRAN_TYPE)
            .profileId(UPDATED_PROFILE_ID)
            .profileName(UPDATED_PROFILE_NAME)
            .narrative(UPDATED_NARRATIVE)
            .precedingNarrative(UPDATED_PRECEDING_NARRATIVE)
            .customNarrative(UPDATED_CUSTOM_NARRATIVE)
            .systemGeneratedNarrative(UPDATED_SYSTEM_GENERATED_NARRATIVE);
        return transaction;
    }

    @BeforeEach
    public void initTest() {
        transaction = createEntity(em);
    }

    @Test
    @Transactional
    void createTransaction() throws Exception {
        int databaseSizeBeforeCreate = transactionRepository.findAll().size();
        // Create the Transaction
        restTransactionMockMvc
            .perform(post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(transaction)))
            .andExpect(status().isCreated());

        // Validate the Transaction in the database
        List<Transaction> transactionList = transactionRepository.findAll();
        assertThat(transactionList).hasSize(databaseSizeBeforeCreate + 1);
        Transaction testTransaction = transactionList.get(transactionList.size() - 1);
        assertThat(testTransaction.getTranId()).isEqualTo(DEFAULT_TRAN_ID);
        assertThat(testTransaction.getTranName()).isEqualTo(DEFAULT_TRAN_NAME);
        assertThat(testTransaction.getFrmCnt()).isEqualTo(DEFAULT_FRM_CNT);
        assertThat(testTransaction.getToCnt()).isEqualTo(DEFAULT_TO_CNT);
        assertThat(testTransaction.getTotalAmount()).isEqualByComparingTo(DEFAULT_TOTAL_AMOUNT);
        assertThat(testTransaction.getCreatedDate()).isEqualTo(DEFAULT_CREATED_DATE);
        assertThat(testTransaction.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);
        assertThat(testTransaction.getCreatedBy()).isEqualTo(DEFAULT_CREATED_BY);
        assertThat(testTransaction.getUpdatedBy()).isEqualTo(DEFAULT_UPDATED_BY);
        assertThat(testTransaction.getSettlementDate()).isEqualTo(DEFAULT_SETTLEMENT_DATE);
        assertThat(testTransaction.getFrequencyType()).isEqualTo(DEFAULT_FREQUENCY_TYPE);
        assertThat(testTransaction.getTranType()).isEqualTo(DEFAULT_TRAN_TYPE);
        assertThat(testTransaction.getProfileId()).isEqualTo(DEFAULT_PROFILE_ID);
        assertThat(testTransaction.getProfileName()).isEqualTo(DEFAULT_PROFILE_NAME);
        assertThat(testTransaction.getNarrative()).isEqualTo(DEFAULT_NARRATIVE);
        assertThat(testTransaction.getPrecedingNarrative()).isEqualTo(DEFAULT_PRECEDING_NARRATIVE);
        assertThat(testTransaction.getCustomNarrative()).isEqualTo(DEFAULT_CUSTOM_NARRATIVE);
        assertThat(testTransaction.getSystemGeneratedNarrative()).isEqualTo(DEFAULT_SYSTEM_GENERATED_NARRATIVE);
    }

    @Test
    @Transactional
    void createTransactionWithExistingId() throws Exception {
        // Create the Transaction with an existing ID
        transaction.setId(1L);

        int databaseSizeBeforeCreate = transactionRepository.findAll().size();

        // An entity with an existing ID cannot be created, so this API call must fail
        restTransactionMockMvc
            .perform(post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(transaction)))
            .andExpect(status().isBadRequest());

        // Validate the Transaction in the database
        List<Transaction> transactionList = transactionRepository.findAll();
        assertThat(transactionList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    void checkTranIdIsRequired() throws Exception {
        int databaseSizeBeforeTest = transactionRepository.findAll().size();
        // set the field null
        transaction.setTranId(null);

        // Create the Transaction, which fails.

        restTransactionMockMvc
            .perform(post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(transaction)))
            .andExpect(status().isBadRequest());

        List<Transaction> transactionList = transactionRepository.findAll();
        assertThat(transactionList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void getAllTransactions() throws Exception {
        // Initialize the database
        transactionRepository.saveAndFlush(transaction);

        // Get all the transactionList
        restTransactionMockMvc
            .perform(get(ENTITY_API_URL + "?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(transaction.getId().intValue())))
            .andExpect(jsonPath("$.[*].tranId").value(hasItem(DEFAULT_TRAN_ID.intValue())))
            .andExpect(jsonPath("$.[*].tranName").value(hasItem(DEFAULT_TRAN_NAME)))
            .andExpect(jsonPath("$.[*].frmCnt").value(hasItem(DEFAULT_FRM_CNT)))
            .andExpect(jsonPath("$.[*].toCnt").value(hasItem(DEFAULT_TO_CNT)))
            .andExpect(jsonPath("$.[*].totalAmount").value(hasItem(sameNumber(DEFAULT_TOTAL_AMOUNT))))
            .andExpect(jsonPath("$.[*].createdDate").value(hasItem(sameInstant(DEFAULT_CREATED_DATE))))
            .andExpect(jsonPath("$.[*].updatedDate").value(hasItem(sameInstant(DEFAULT_UPDATED_DATE))))
            .andExpect(jsonPath("$.[*].createdBy").value(hasItem(DEFAULT_CREATED_BY)))
            .andExpect(jsonPath("$.[*].updatedBy").value(hasItem(DEFAULT_UPDATED_BY)))
            .andExpect(jsonPath("$.[*].settlementDate").value(hasItem(sameInstant(DEFAULT_SETTLEMENT_DATE))))
            .andExpect(jsonPath("$.[*].frequencyType").value(hasItem(DEFAULT_FREQUENCY_TYPE)))
            .andExpect(jsonPath("$.[*].tranType").value(hasItem(DEFAULT_TRAN_TYPE)))
            .andExpect(jsonPath("$.[*].profileId").value(hasItem(DEFAULT_PROFILE_ID.intValue())))
            .andExpect(jsonPath("$.[*].profileName").value(hasItem(DEFAULT_PROFILE_NAME)))
            .andExpect(jsonPath("$.[*].narrative").value(hasItem(DEFAULT_NARRATIVE)))
            .andExpect(jsonPath("$.[*].precedingNarrative").value(hasItem(DEFAULT_PRECEDING_NARRATIVE)))
            .andExpect(jsonPath("$.[*].customNarrative").value(hasItem(DEFAULT_CUSTOM_NARRATIVE)))
            .andExpect(jsonPath("$.[*].systemGeneratedNarrative").value(hasItem(DEFAULT_SYSTEM_GENERATED_NARRATIVE)));
    }

    @Test
    @Transactional
    void getTransaction() throws Exception {
        // Initialize the database
        transactionRepository.saveAndFlush(transaction);

        // Get the transaction
        restTransactionMockMvc
            .perform(get(ENTITY_API_URL_ID, transaction.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(transaction.getId().intValue()))
            .andExpect(jsonPath("$.tranId").value(DEFAULT_TRAN_ID.intValue()))
            .andExpect(jsonPath("$.tranName").value(DEFAULT_TRAN_NAME))
            .andExpect(jsonPath("$.frmCnt").value(DEFAULT_FRM_CNT))
            .andExpect(jsonPath("$.toCnt").value(DEFAULT_TO_CNT))
            .andExpect(jsonPath("$.totalAmount").value(sameNumber(DEFAULT_TOTAL_AMOUNT)))
            .andExpect(jsonPath("$.createdDate").value(sameInstant(DEFAULT_CREATED_DATE)))
            .andExpect(jsonPath("$.updatedDate").value(sameInstant(DEFAULT_UPDATED_DATE)))
            .andExpect(jsonPath("$.createdBy").value(DEFAULT_CREATED_BY))
            .andExpect(jsonPath("$.updatedBy").value(DEFAULT_UPDATED_BY))
            .andExpect(jsonPath("$.settlementDate").value(sameInstant(DEFAULT_SETTLEMENT_DATE)))
            .andExpect(jsonPath("$.frequencyType").value(DEFAULT_FREQUENCY_TYPE))
            .andExpect(jsonPath("$.tranType").value(DEFAULT_TRAN_TYPE))
            .andExpect(jsonPath("$.profileId").value(DEFAULT_PROFILE_ID.intValue()))
            .andExpect(jsonPath("$.profileName").value(DEFAULT_PROFILE_NAME))
            .andExpect(jsonPath("$.narrative").value(DEFAULT_NARRATIVE))
            .andExpect(jsonPath("$.precedingNarrative").value(DEFAULT_PRECEDING_NARRATIVE))
            .andExpect(jsonPath("$.customNarrative").value(DEFAULT_CUSTOM_NARRATIVE))
            .andExpect(jsonPath("$.systemGeneratedNarrative").value(DEFAULT_SYSTEM_GENERATED_NARRATIVE));
    }

    @Test
    @Transactional
    void getNonExistingTransaction() throws Exception {
        // Get the transaction
        restTransactionMockMvc.perform(get(ENTITY_API_URL_ID, Long.MAX_VALUE)).andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    void putExistingTransaction() throws Exception {
        // Initialize the database
        transactionRepository.saveAndFlush(transaction);

        int databaseSizeBeforeUpdate = transactionRepository.findAll().size();

        // Update the transaction
        Transaction updatedTransaction = transactionRepository.findById(transaction.getId()).orElseThrow();
        // Disconnect from session so that the updates on updatedTransaction are not directly saved in db
        em.detach(updatedTransaction);
        updatedTransaction
            .tranId(UPDATED_TRAN_ID)
            .tranName(UPDATED_TRAN_NAME)
            .frmCnt(UPDATED_FRM_CNT)
            .toCnt(UPDATED_TO_CNT)
            .totalAmount(UPDATED_TOTAL_AMOUNT)
            .createdDate(UPDATED_CREATED_DATE)
            .updatedDate(UPDATED_UPDATED_DATE)
            .createdBy(UPDATED_CREATED_BY)
            .updatedBy(UPDATED_UPDATED_BY)
            .settlementDate(UPDATED_SETTLEMENT_DATE)
            .frequencyType(UPDATED_FREQUENCY_TYPE)
            .tranType(UPDATED_TRAN_TYPE)
            .profileId(UPDATED_PROFILE_ID)
            .profileName(UPDATED_PROFILE_NAME)
            .narrative(UPDATED_NARRATIVE)
            .precedingNarrative(UPDATED_PRECEDING_NARRATIVE)
            .customNarrative(UPDATED_CUSTOM_NARRATIVE)
            .systemGeneratedNarrative(UPDATED_SYSTEM_GENERATED_NARRATIVE);

        restTransactionMockMvc
            .perform(
                put(ENTITY_API_URL_ID, updatedTransaction.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(updatedTransaction))
            )
            .andExpect(status().isOk());

        // Validate the Transaction in the database
        List<Transaction> transactionList = transactionRepository.findAll();
        assertThat(transactionList).hasSize(databaseSizeBeforeUpdate);
        Transaction testTransaction = transactionList.get(transactionList.size() - 1);
        assertThat(testTransaction.getTranId()).isEqualTo(UPDATED_TRAN_ID);
        assertThat(testTransaction.getTranName()).isEqualTo(UPDATED_TRAN_NAME);
        assertThat(testTransaction.getFrmCnt()).isEqualTo(UPDATED_FRM_CNT);
        assertThat(testTransaction.getToCnt()).isEqualTo(UPDATED_TO_CNT);
        assertThat(testTransaction.getTotalAmount()).isEqualByComparingTo(UPDATED_TOTAL_AMOUNT);
        assertThat(testTransaction.getCreatedDate()).isEqualTo(UPDATED_CREATED_DATE);
        assertThat(testTransaction.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);
        assertThat(testTransaction.getCreatedBy()).isEqualTo(UPDATED_CREATED_BY);
        assertThat(testTransaction.getUpdatedBy()).isEqualTo(UPDATED_UPDATED_BY);
        assertThat(testTransaction.getSettlementDate()).isEqualTo(UPDATED_SETTLEMENT_DATE);
        assertThat(testTransaction.getFrequencyType()).isEqualTo(UPDATED_FREQUENCY_TYPE);
        assertThat(testTransaction.getTranType()).isEqualTo(UPDATED_TRAN_TYPE);
        assertThat(testTransaction.getProfileId()).isEqualTo(UPDATED_PROFILE_ID);
        assertThat(testTransaction.getProfileName()).isEqualTo(UPDATED_PROFILE_NAME);
        assertThat(testTransaction.getNarrative()).isEqualTo(UPDATED_NARRATIVE);
        assertThat(testTransaction.getPrecedingNarrative()).isEqualTo(UPDATED_PRECEDING_NARRATIVE);
        assertThat(testTransaction.getCustomNarrative()).isEqualTo(UPDATED_CUSTOM_NARRATIVE);
        assertThat(testTransaction.getSystemGeneratedNarrative()).isEqualTo(UPDATED_SYSTEM_GENERATED_NARRATIVE);
    }

    @Test
    @Transactional
    void putNonExistingTransaction() throws Exception {
        int databaseSizeBeforeUpdate = transactionRepository.findAll().size();
        transaction.setId(longCount.incrementAndGet());

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restTransactionMockMvc
            .perform(
                put(ENTITY_API_URL_ID, transaction.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transaction))
            )
            .andExpect(status().isBadRequest());

        // Validate the Transaction in the database
        List<Transaction> transactionList = transactionRepository.findAll();
        assertThat(transactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithIdMismatchTransaction() throws Exception {
        int databaseSizeBeforeUpdate = transactionRepository.findAll().size();
        transaction.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransactionMockMvc
            .perform(
                put(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transaction))
            )
            .andExpect(status().isBadRequest());

        // Validate the Transaction in the database
        List<Transaction> transactionList = transactionRepository.findAll();
        assertThat(transactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithMissingIdPathParamTransaction() throws Exception {
        int databaseSizeBeforeUpdate = transactionRepository.findAll().size();
        transaction.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransactionMockMvc
            .perform(put(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(transaction)))
            .andExpect(status().isMethodNotAllowed());

        // Validate the Transaction in the database
        List<Transaction> transactionList = transactionRepository.findAll();
        assertThat(transactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void partialUpdateTransactionWithPatch() throws Exception {
        // Initialize the database
        transactionRepository.saveAndFlush(transaction);

        int databaseSizeBeforeUpdate = transactionRepository.findAll().size();

        // Update the transaction using partial update
        Transaction partialUpdatedTransaction = new Transaction();
        partialUpdatedTransaction.setId(transaction.getId());

        partialUpdatedTransaction
            .tranId(UPDATED_TRAN_ID)
            .frmCnt(UPDATED_FRM_CNT)
            .createdDate(UPDATED_CREATED_DATE)
            .createdBy(UPDATED_CREATED_BY)
            .updatedBy(UPDATED_UPDATED_BY)
            .frequencyType(UPDATED_FREQUENCY_TYPE)
            .tranType(UPDATED_TRAN_TYPE)
            .customNarrative(UPDATED_CUSTOM_NARRATIVE);

        restTransactionMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedTransaction.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedTransaction))
            )
            .andExpect(status().isOk());

        // Validate the Transaction in the database
        List<Transaction> transactionList = transactionRepository.findAll();
        assertThat(transactionList).hasSize(databaseSizeBeforeUpdate);
        Transaction testTransaction = transactionList.get(transactionList.size() - 1);
        assertThat(testTransaction.getTranId()).isEqualTo(UPDATED_TRAN_ID);
        assertThat(testTransaction.getTranName()).isEqualTo(DEFAULT_TRAN_NAME);
        assertThat(testTransaction.getFrmCnt()).isEqualTo(UPDATED_FRM_CNT);
        assertThat(testTransaction.getToCnt()).isEqualTo(DEFAULT_TO_CNT);
        assertThat(testTransaction.getTotalAmount()).isEqualByComparingTo(DEFAULT_TOTAL_AMOUNT);
        assertThat(testTransaction.getCreatedDate()).isEqualTo(UPDATED_CREATED_DATE);
        assertThat(testTransaction.getUpdatedDate()).isEqualTo(DEFAULT_UPDATED_DATE);
        assertThat(testTransaction.getCreatedBy()).isEqualTo(UPDATED_CREATED_BY);
        assertThat(testTransaction.getUpdatedBy()).isEqualTo(UPDATED_UPDATED_BY);
        assertThat(testTransaction.getSettlementDate()).isEqualTo(DEFAULT_SETTLEMENT_DATE);
        assertThat(testTransaction.getFrequencyType()).isEqualTo(UPDATED_FREQUENCY_TYPE);
        assertThat(testTransaction.getTranType()).isEqualTo(UPDATED_TRAN_TYPE);
        assertThat(testTransaction.getProfileId()).isEqualTo(DEFAULT_PROFILE_ID);
        assertThat(testTransaction.getProfileName()).isEqualTo(DEFAULT_PROFILE_NAME);
        assertThat(testTransaction.getNarrative()).isEqualTo(DEFAULT_NARRATIVE);
        assertThat(testTransaction.getPrecedingNarrative()).isEqualTo(DEFAULT_PRECEDING_NARRATIVE);
        assertThat(testTransaction.getCustomNarrative()).isEqualTo(UPDATED_CUSTOM_NARRATIVE);
        assertThat(testTransaction.getSystemGeneratedNarrative()).isEqualTo(DEFAULT_SYSTEM_GENERATED_NARRATIVE);
    }

    @Test
    @Transactional
    void fullUpdateTransactionWithPatch() throws Exception {
        // Initialize the database
        transactionRepository.saveAndFlush(transaction);

        int databaseSizeBeforeUpdate = transactionRepository.findAll().size();

        // Update the transaction using partial update
        Transaction partialUpdatedTransaction = new Transaction();
        partialUpdatedTransaction.setId(transaction.getId());

        partialUpdatedTransaction
            .tranId(UPDATED_TRAN_ID)
            .tranName(UPDATED_TRAN_NAME)
            .frmCnt(UPDATED_FRM_CNT)
            .toCnt(UPDATED_TO_CNT)
            .totalAmount(UPDATED_TOTAL_AMOUNT)
            .createdDate(UPDATED_CREATED_DATE)
            .updatedDate(UPDATED_UPDATED_DATE)
            .createdBy(UPDATED_CREATED_BY)
            .updatedBy(UPDATED_UPDATED_BY)
            .settlementDate(UPDATED_SETTLEMENT_DATE)
            .frequencyType(UPDATED_FREQUENCY_TYPE)
            .tranType(UPDATED_TRAN_TYPE)
            .profileId(UPDATED_PROFILE_ID)
            .profileName(UPDATED_PROFILE_NAME)
            .narrative(UPDATED_NARRATIVE)
            .precedingNarrative(UPDATED_PRECEDING_NARRATIVE)
            .customNarrative(UPDATED_CUSTOM_NARRATIVE)
            .systemGeneratedNarrative(UPDATED_SYSTEM_GENERATED_NARRATIVE);

        restTransactionMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedTransaction.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedTransaction))
            )
            .andExpect(status().isOk());

        // Validate the Transaction in the database
        List<Transaction> transactionList = transactionRepository.findAll();
        assertThat(transactionList).hasSize(databaseSizeBeforeUpdate);
        Transaction testTransaction = transactionList.get(transactionList.size() - 1);
        assertThat(testTransaction.getTranId()).isEqualTo(UPDATED_TRAN_ID);
        assertThat(testTransaction.getTranName()).isEqualTo(UPDATED_TRAN_NAME);
        assertThat(testTransaction.getFrmCnt()).isEqualTo(UPDATED_FRM_CNT);
        assertThat(testTransaction.getToCnt()).isEqualTo(UPDATED_TO_CNT);
        assertThat(testTransaction.getTotalAmount()).isEqualByComparingTo(UPDATED_TOTAL_AMOUNT);
        assertThat(testTransaction.getCreatedDate()).isEqualTo(UPDATED_CREATED_DATE);
        assertThat(testTransaction.getUpdatedDate()).isEqualTo(UPDATED_UPDATED_DATE);
        assertThat(testTransaction.getCreatedBy()).isEqualTo(UPDATED_CREATED_BY);
        assertThat(testTransaction.getUpdatedBy()).isEqualTo(UPDATED_UPDATED_BY);
        assertThat(testTransaction.getSettlementDate()).isEqualTo(UPDATED_SETTLEMENT_DATE);
        assertThat(testTransaction.getFrequencyType()).isEqualTo(UPDATED_FREQUENCY_TYPE);
        assertThat(testTransaction.getTranType()).isEqualTo(UPDATED_TRAN_TYPE);
        assertThat(testTransaction.getProfileId()).isEqualTo(UPDATED_PROFILE_ID);
        assertThat(testTransaction.getProfileName()).isEqualTo(UPDATED_PROFILE_NAME);
        assertThat(testTransaction.getNarrative()).isEqualTo(UPDATED_NARRATIVE);
        assertThat(testTransaction.getPrecedingNarrative()).isEqualTo(UPDATED_PRECEDING_NARRATIVE);
        assertThat(testTransaction.getCustomNarrative()).isEqualTo(UPDATED_CUSTOM_NARRATIVE);
        assertThat(testTransaction.getSystemGeneratedNarrative()).isEqualTo(UPDATED_SYSTEM_GENERATED_NARRATIVE);
    }

    @Test
    @Transactional
    void patchNonExistingTransaction() throws Exception {
        int databaseSizeBeforeUpdate = transactionRepository.findAll().size();
        transaction.setId(longCount.incrementAndGet());

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restTransactionMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, transaction.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(transaction))
            )
            .andExpect(status().isBadRequest());

        // Validate the Transaction in the database
        List<Transaction> transactionList = transactionRepository.findAll();
        assertThat(transactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithIdMismatchTransaction() throws Exception {
        int databaseSizeBeforeUpdate = transactionRepository.findAll().size();
        transaction.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransactionMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(transaction))
            )
            .andExpect(status().isBadRequest());

        // Validate the Transaction in the database
        List<Transaction> transactionList = transactionRepository.findAll();
        assertThat(transactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithMissingIdPathParamTransaction() throws Exception {
        int databaseSizeBeforeUpdate = transactionRepository.findAll().size();
        transaction.setId(longCount.incrementAndGet());

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransactionMockMvc
            .perform(
                patch(ENTITY_API_URL).contentType("application/merge-patch+json").content(TestUtil.convertObjectToJsonBytes(transaction))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the Transaction in the database
        List<Transaction> transactionList = transactionRepository.findAll();
        assertThat(transactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void deleteTransaction() throws Exception {
        // Initialize the database
        transactionRepository.saveAndFlush(transaction);

        int databaseSizeBeforeDelete = transactionRepository.findAll().size();

        // Delete the transaction
        restTransactionMockMvc
            .perform(delete(ENTITY_API_URL_ID, transaction.getId()).accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<Transaction> transactionList = transactionRepository.findAll();
        assertThat(transactionList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
