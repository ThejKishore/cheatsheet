package com.learn.jpa.domain;

import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

public class AchTransactionTestSamples {

    private static final Random random = new Random();
    private static final AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    public static AchTransaction getAchTransactionSample1() {
        return new AchTransaction().id(1L).achTranId(1L);
    }

    public static AchTransaction getAchTransactionSample2() {
        return new AchTransaction().id(2L).achTranId(2L);
    }

    public static AchTransaction getAchTransactionRandomSampleGenerator() {
        return new AchTransaction().id(longCount.incrementAndGet()).achTranId(longCount.incrementAndGet());
    }
}
