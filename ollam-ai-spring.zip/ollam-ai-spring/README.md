# Spring AI with Ollama and OpenAI

This project demonstrates how to use Spring AI with both Ollama (running the mistral-nemo model) and OpenAI.

## Configuration

The application is configured to use both Ollama and OpenAI for AI capabilities:

### Ollama Configuration
- Base URL: http://localhost:11434
- Model: mistral-nemo
- The Docker Compose file is configured to automatically pull and run the mistral-nemo model

### OpenAI Configuration
- API Key: Set via the OPENAI_API_KEY environment variable
- Model: gpt-3.5-turbo

## Running the Application

### Option 1: Using Docker Compose (Recommended for most users)

1. Set your OpenAI API key as an environment variable:
   ```
   export OPENAI_API_KEY=your_api_key_here
   ```

2. Start the application using Docker Compose:
   ```
   docker-compose up
   ```

3. The application will start and automatically pull the mistral-nemo model for Ollama.

4. Access the application at http://localhost:8080

### Option 2: Running Ollama Locally on Mac

If you prefer to run Ollama directly on your Mac instead of using Docker:

1. Install Ollama on your Mac:
   ```
   brew install ollama
   ```

   If you don't have Homebrew installed, you can get it from https://brew.sh/

2. Start the Ollama service:
   ```
   ollama serve
   ```

3. In a separate terminal, pull the mistral-nemo model:
   ```
   ollama pull mistral-nemo
   ```

4. Set your OpenAI API key as an environment variable:
   ```
   export OPENAI_API_KEY=your_api_key_here
   ```

5. Start the Spring Boot application:
   ```
   ./gradlew bootRun
   ```

6. Access the application at http://localhost:8080

## Notes

- If you don't provide an OpenAI API key, a default value of "demo" will be used, which won't work for actual API calls.
- The application is configured to use both Ollama and OpenAI, so you can switch between them as needed.
- The pgvector database is used for vector storage capabilities.
- When running Ollama locally on Mac, you won't have the pgvector database available unless you install and configure it separately.
