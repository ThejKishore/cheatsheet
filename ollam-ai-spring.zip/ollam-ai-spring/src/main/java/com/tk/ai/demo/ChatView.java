package com.tk.ai.demo;

import com.vaadin.flow.component.Key;
import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.button.ButtonVariant;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.Icon;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.notification.NotificationVariant;
import com.vaadin.flow.component.orderedlayout.HorizontalLayout;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.progressbar.ProgressBar;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.router.PageTitle;
import com.vaadin.flow.router.Route;
import com.vaadin.flow.theme.lumo.LumoUtility;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.ollama.OllamaChatModel;
import org.springframework.ai.ollama.api.OllamaModel;
import org.springframework.ai.ollama.api.OllamaOptions;

@Route("")
@PageTitle("AI Chat")
public class ChatView extends VerticalLayout {

    private final OllamaChatModel chatModel;
    private final VerticalLayout chatContainer;
    private final TextField messageField;

    public ChatView(OllamaChatModel chatModel) {
        this.chatModel = chatModel;

        // Set up the layout
        setSizeFull();
        setPadding(true);
        setSpacing(true);
        addClassName(LumoUtility.Background.CONTRAST_5);

        // Create header
        H1 header = new H1("AI Chat with Ollama");
        header.addClassNames(
                LumoUtility.Margin.NONE,
                LumoUtility.TextAlignment.CENTER,
                LumoUtility.FontSize.XXLARGE
        );

        // Create clear chat button
        Button clearButton = new Button("New Chat", new Icon(VaadinIcon.TRASH));
        clearButton.addThemeVariants(ButtonVariant.LUMO_ERROR, ButtonVariant.LUMO_SMALL);
        clearButton.addClickListener(e -> clearChat());

        HorizontalLayout headerLayout = new HorizontalLayout(header, clearButton);
        headerLayout.setWidthFull();
        headerLayout.setJustifyContentMode(JustifyContentMode.BETWEEN);
        headerLayout.setAlignItems(Alignment.CENTER);
        headerLayout.addClassName(LumoUtility.Padding.SMALL);
        headerLayout.addClassName(LumoUtility.Background.CONTRAST_10);
        headerLayout.addClassName(LumoUtility.BorderRadius.MEDIUM);

        // Create chat container
        chatContainer = new VerticalLayout();
        chatContainer.setWidthFull();
        chatContainer.setPadding(true);
        chatContainer.setSpacing(true);
        chatContainer.getStyle()
                .set("overflow-y", "auto")
                .set("flex-grow", "1")
                .set("background-color", "var(--lumo-base-color)")
                .set("border-radius", "var(--lumo-border-radius-m)")
                .set("padding", "var(--lumo-space-m)")
                .set("box-shadow", "var(--lumo-box-shadow-s)");

        // Create input field and send button
        messageField = new TextField();
        messageField.setWidthFull();
        messageField.setPlaceholder("Type your message here...");
        messageField.addClassName(LumoUtility.FontSize.MEDIUM);

        Button sendButton = new Button("Send", new Icon(VaadinIcon.PAPERPLANE));
        sendButton.addThemeVariants(ButtonVariant.LUMO_PRIMARY);
        sendButton.addClickShortcut(Key.ENTER);

        HorizontalLayout inputLayout = new HorizontalLayout(messageField, sendButton);
        inputLayout.setWidthFull();
        inputLayout.expand(messageField);
        inputLayout.setSpacing(true);
        inputLayout.setPadding(true);
        inputLayout.addClassName(LumoUtility.Background.CONTRAST_5);
        inputLayout.addClassName(LumoUtility.BorderRadius.MEDIUM);

        // Add components to the main layout
        add(headerLayout, chatContainer, inputLayout);
        expand(chatContainer);

        // Add event listener for the send button
        sendButton.addClickListener(e -> sendMessage());

        // Add welcome message
        addMessageToChat("System", "Welcome to AI Chat! I'm powered by Ollama using the mistral-nemo model. How can I help you today?", "system-message");
    }

    private void sendMessage() {
        String userMessage = messageField.getValue().trim();
        if (userMessage.isEmpty()) {
            Notification notification = Notification.show("Please enter a message");
            notification.addThemeVariants(NotificationVariant.LUMO_ERROR);
            notification.setPosition(Notification.Position.MIDDLE);
            notification.setDuration(3000);
            return;
        }

        // Add user message to chat
        addMessageToChat("You", userMessage, "user-message");

        // Clear input field
        messageField.clear();
        messageField.focus();

        // Disable input while processing
        messageField.setEnabled(false);

        // Add loading indicator
        ProgressBar progressBar = new ProgressBar();
        progressBar.setIndeterminate(true);
        progressBar.setWidthFull();

        Span thinkingText = new Span("AI is thinking...");
        Div loadingDiv = new Div(new Div(thinkingText), progressBar);
        loadingDiv.addClassName("loading-indicator");
        loadingDiv.getStyle()
                .set("background-color", "var(--lumo-contrast-10pct)")
                .set("padding", "var(--lumo-space-s)")
                .set("border-radius", "var(--lumo-border-radius-s)")
                .set("margin-bottom", "var(--lumo-space-m)")
                .set("align-self", "flex-start")
                .set("max-width", "80%");

        chatContainer.add(loadingDiv);

        // Scroll to the loading indicator
        loadingDiv.getElement().executeJs(
                "setTimeout(() => { this.scrollIntoView({ behavior: 'smooth', block: 'end' }); }, 100);");

        // Get AI response asynchronously
        UI ui = UI.getCurrent();
        try {
            ChatResponse call = chatModel.call(new Prompt(
                    userMessage,
                    OllamaOptions.builder()
                            .model(OllamaModel.MISTRAL_NEMO)
                            .build()
            ));
            String aiResponse = call.getResult().getOutput().getText();
            ui.access(() -> {
                try {
                    // Ensure loading indicator is removed
                    if (loadingDiv.getParent() != null) {
                        chatContainer.remove(loadingDiv);
                    }

                    // Add AI response
                    addMessageToChat("AI", aiResponse, "ai-message");

                    // Re-enable input
                    messageField.setEnabled(true);
                    messageField.focus();
                } catch (Exception ex) {
                    System.err.println("Error updating UI: " + ex.getMessage());
                    ex.printStackTrace();
                }
            });
        } catch (Exception e) {
            e.printStackTrace(System.err);
            ui.access(() -> {
                try {
                    // Ensure loading indicator is removed
                    if (loadingDiv.getParent() != null) {
                        chatContainer.remove(loadingDiv);
                    }

                    // Add error message
                    addMessageToChat("System", "Error: " + e.getMessage(), "error-message");

                    // Show notification
                    Notification notification = Notification.show("Error: " + e.getMessage());
                    notification.addThemeVariants(NotificationVariant.LUMO_ERROR);
                    notification.setPosition(Notification.Position.MIDDLE);
                    notification.setDuration(5000);

                    // Re-enable input
                    messageField.setEnabled(true);
                    messageField.focus();
                } catch (Exception ex) {
                    System.err.println("Error updating UI in error handler: " + ex.getMessage());
                    ex.printStackTrace();
                }
            });
        }

    }

    private void addMessageToChat(String sender, String message, String className) {
        // Create sender label
        Span senderSpan = new Span(sender);
        senderSpan.getStyle()
                .set("font-weight", "bold")
                .set("margin-bottom", "var(--lumo-space-xs)");

        // Create message content
        Div messageContent = new Div();
        messageContent.setText(message);
        messageContent.getStyle()
                .set("white-space", "pre-wrap")
                .set("word-break", "break-word");

        // Create message container
        Div messageDiv = new Div(senderSpan, messageContent);
        messageDiv.addClassName(className);
        messageDiv.getStyle()
                .set("margin-bottom", "var(--lumo-space-m)")
                .set("padding", "var(--lumo-space-s)")
                .set("border-radius", "var(--lumo-border-radius-s)")
                .set("max-width", "80%")
                .set("box-shadow", "var(--lumo-box-shadow-xs)");

        if ("user-message".equals(className)) {
            messageDiv.getStyle()
                    .set("background-color", "var(--lumo-primary-color-10pct)")
                    .set("align-self", "flex-end")
                    .set("border-bottom-right-radius", "0");
            senderSpan.getStyle().set("color", "var(--lumo-primary-text-color)");
        } else if ("ai-message".equals(className)) {
            messageDiv.getStyle()
                    .set("background-color", "var(--lumo-contrast-10pct)")
                    .set("align-self", "flex-start")
                    .set("border-bottom-left-radius", "0");
            senderSpan.getStyle().set("color", "var(--lumo-secondary-text-color)");
        } else if ("system-message".equals(className)) {
            messageDiv.getStyle()
                    .set("background-color", "var(--lumo-success-color-10pct)")
                    .set("align-self", "center")
                    .set("text-align", "center");
            senderSpan.getStyle().set("color", "var(--lumo-success-text-color)");
        } else {
            messageDiv.getStyle()
                    .set("background-color", "var(--lumo-error-color-10pct)")
                    .set("align-self", "center");
            senderSpan.getStyle().set("color", "var(--lumo-error-text-color)");
        }

        chatContainer.add(messageDiv);

        // Scroll to the bottom
        messageDiv.getElement().executeJs(
                "setTimeout(() => { this.scrollIntoView({ behavior: 'smooth', block: 'end' }); }, 100);");
    }

    private void clearChat() {
        // Clear the chat container
        chatContainer.removeAll();

        // Add welcome message
        addMessageToChat("System", "Welcome to AI Chat! I'm powered by Ollama using the mistral-nemo model. How can I help you today?", "system-message");

        // Focus on the message field
        messageField.clear();
        messageField.focus();

        // Show notification
        Notification notification = Notification.show("Chat cleared");
        notification.addThemeVariants(NotificationVariant.LUMO_SUCCESS);
        notification.setPosition(Notification.Position.BOTTOM_CENTER);
        notification.setDuration(2000);
    }
}
