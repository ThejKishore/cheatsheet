package com.learn.jpa.domain;

import static com.learn.jpa.domain.TransactionMappingTestSamples.*;
import static com.learn.jpa.domain.TransferFromAccntTestSamples.*;
import static com.learn.jpa.domain.TransferToAccntTestSamples.*;
import static com.learn.jpa.domain.TransferTransactionTestSamples.*;
import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import java.util.HashSet;
import java.util.Set;
import org.junit.jupiter.api.Test;

class TransferTransactionTest {

    @Test
    void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(TransferTransaction.class);
        TransferTransaction transferTransaction1 = getTransferTransactionSample1();
        TransferTransaction transferTransaction2 = new TransferTransaction();
        assertThat(transferTransaction1).isNotEqualTo(transferTransaction2);

        transferTransaction2.setId(transferTransaction1.getId());
        assertThat(transferTransaction1).isEqualTo(transferTransaction2);

        transferTransaction2 = getTransferTransactionSample2();
        assertThat(transferTransaction1).isNotEqualTo(transferTransaction2);
    }

    @Test
    void transactionMappingTest() throws Exception {
        TransferTransaction transferTransaction = getTransferTransactionRandomSampleGenerator();
        TransactionMapping transactionMappingBack = getTransactionMappingRandomSampleGenerator();

        transferTransaction.setTransactionMapping(transactionMappingBack);
        assertThat(transferTransaction.getTransactionMapping()).isEqualTo(transactionMappingBack);

        transferTransaction.transactionMapping(null);
        assertThat(transferTransaction.getTransactionMapping()).isNull();
    }

    @Test
    void transferFromAccntTest() throws Exception {
        TransferTransaction transferTransaction = getTransferTransactionRandomSampleGenerator();
        TransferFromAccnt transferFromAccntBack = getTransferFromAccntRandomSampleGenerator();

        transferTransaction.addTransferFromAccnt(transferFromAccntBack);
        assertThat(transferTransaction.getTransferFromAccnts()).containsOnly(transferFromAccntBack);
        assertThat(transferFromAccntBack.getTransferTransaction()).isEqualTo(transferTransaction);

        transferTransaction.removeTransferFromAccnt(transferFromAccntBack);
        assertThat(transferTransaction.getTransferFromAccnts()).doesNotContain(transferFromAccntBack);
        assertThat(transferFromAccntBack.getTransferTransaction()).isNull();

        transferTransaction.transferFromAccnts(new HashSet<>(Set.of(transferFromAccntBack)));
        assertThat(transferTransaction.getTransferFromAccnts()).containsOnly(transferFromAccntBack);
        assertThat(transferFromAccntBack.getTransferTransaction()).isEqualTo(transferTransaction);

        transferTransaction.setTransferFromAccnts(new HashSet<>());
        assertThat(transferTransaction.getTransferFromAccnts()).doesNotContain(transferFromAccntBack);
        assertThat(transferFromAccntBack.getTransferTransaction()).isNull();
    }

    @Test
    void transferToAccntTest() throws Exception {
        TransferTransaction transferTransaction = getTransferTransactionRandomSampleGenerator();
        TransferToAccnt transferToAccntBack = getTransferToAccntRandomSampleGenerator();

        transferTransaction.addTransferToAccnt(transferToAccntBack);
        assertThat(transferTransaction.getTransferToAccnts()).containsOnly(transferToAccntBack);
        assertThat(transferToAccntBack.getTransferTransaction()).isEqualTo(transferTransaction);

        transferTransaction.removeTransferToAccnt(transferToAccntBack);
        assertThat(transferTransaction.getTransferToAccnts()).doesNotContain(transferToAccntBack);
        assertThat(transferToAccntBack.getTransferTransaction()).isNull();

        transferTransaction.transferToAccnts(new HashSet<>(Set.of(transferToAccntBack)));
        assertThat(transferTransaction.getTransferToAccnts()).containsOnly(transferToAccntBack);
        assertThat(transferToAccntBack.getTransferTransaction()).isEqualTo(transferTransaction);

        transferTransaction.setTransferToAccnts(new HashSet<>());
        assertThat(transferTransaction.getTransferToAccnts()).doesNotContain(transferToAccntBack);
        assertThat(transferToAccntBack.getTransferTransaction()).isNull();
    }
}
