package com.learn.jpa.domain;

import static com.learn.jpa.domain.AchFromAccntTestSamples.*;
import static com.learn.jpa.domain.AchTransactionTestSamples.*;
import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class AchFromAccntTest {

    @Test
    void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(AchFromAccnt.class);
        AchFromAccnt achFromAccnt1 = getAchFromAccntSample1();
        AchFromAccnt achFromAccnt2 = new AchFromAccnt();
        assertThat(achFromAccnt1).isNotEqualTo(achFromAccnt2);

        achFromAccnt2.setId(achFromAccnt1.getId());
        assertThat(achFromAccnt1).isEqualTo(achFromAccnt2);

        achFromAccnt2 = getAchFromAccntSample2();
        assertThat(achFromAccnt1).isNotEqualTo(achFromAccnt2);
    }

    @Test
    void achTransactionTest() throws Exception {
        AchFromAccnt achFromAccnt = getAchFromAccntRandomSampleGenerator();
        AchTransaction achTransactionBack = getAchTransactionRandomSampleGenerator();

        achFromAccnt.setAchTransaction(achTransactionBack);
        assertThat(achFromAccnt.getAchTransaction()).isEqualTo(achTransactionBack);

        achFromAccnt.achTransaction(null);
        assertThat(achFromAccnt.getAchTransaction()).isNull();
    }
}
