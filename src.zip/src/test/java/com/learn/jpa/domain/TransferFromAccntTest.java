package com.learn.jpa.domain;

import static com.learn.jpa.domain.TransferFromAccntTestSamples.*;
import static com.learn.jpa.domain.TransferTransactionTestSamples.*;
import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class TransferFromAccntTest {

    @Test
    void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(TransferFromAccnt.class);
        TransferFromAccnt transferFromAccnt1 = getTransferFromAccntSample1();
        TransferFromAccnt transferFromAccnt2 = new TransferFromAccnt();
        assertThat(transferFromAccnt1).isNotEqualTo(transferFromAccnt2);

        transferFromAccnt2.setId(transferFromAccnt1.getId());
        assertThat(transferFromAccnt1).isEqualTo(transferFromAccnt2);

        transferFromAccnt2 = getTransferFromAccntSample2();
        assertThat(transferFromAccnt1).isNotEqualTo(transferFromAccnt2);
    }

    @Test
    void transferTransactionTest() throws Exception {
        TransferFromAccnt transferFromAccnt = getTransferFromAccntRandomSampleGenerator();
        TransferTransaction transferTransactionBack = getTransferTransactionRandomSampleGenerator();

        transferFromAccnt.setTransferTransaction(transferTransactionBack);
        assertThat(transferFromAccnt.getTransferTransaction()).isEqualTo(transferTransactionBack);

        transferFromAccnt.transferTransaction(null);
        assertThat(transferFromAccnt.getTransferTransaction()).isNull();
    }
}
