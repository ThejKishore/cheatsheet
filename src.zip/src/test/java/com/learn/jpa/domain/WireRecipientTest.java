package com.learn.jpa.domain;

import static com.learn.jpa.domain.WireBeneficiaryTestSamples.*;
import static com.learn.jpa.domain.WireRecipientTestSamples.*;
import static com.learn.jpa.domain.WireTransactionTestSamples.*;
import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import java.util.HashSet;
import java.util.Set;
import org.junit.jupiter.api.Test;

class WireRecipientTest {

    @Test
    void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(WireRecipient.class);
        WireRecipient wireRecipient1 = getWireRecipientSample1();
        WireRecipient wireRecipient2 = new WireRecipient();
        assertThat(wireRecipient1).isNotEqualTo(wireRecipient2);

        wireRecipient2.setId(wireRecipient1.getId());
        assertThat(wireRecipient1).isEqualTo(wireRecipient2);

        wireRecipient2 = getWireRecipientSample2();
        assertThat(wireRecipient1).isNotEqualTo(wireRecipient2);
    }

    @Test
    void wireBeneficiaryTest() throws Exception {
        WireRecipient wireRecipient = getWireRecipientRandomSampleGenerator();
        WireBeneficiary wireBeneficiaryBack = getWireBeneficiaryRandomSampleGenerator();

        wireRecipient.addWireBeneficiary(wireBeneficiaryBack);
        assertThat(wireRecipient.getWireBeneficiaries()).containsOnly(wireBeneficiaryBack);
        assertThat(wireBeneficiaryBack.getWireRecipient()).isEqualTo(wireRecipient);

        wireRecipient.removeWireBeneficiary(wireBeneficiaryBack);
        assertThat(wireRecipient.getWireBeneficiaries()).doesNotContain(wireBeneficiaryBack);
        assertThat(wireBeneficiaryBack.getWireRecipient()).isNull();

        wireRecipient.wireBeneficiaries(new HashSet<>(Set.of(wireBeneficiaryBack)));
        assertThat(wireRecipient.getWireBeneficiaries()).containsOnly(wireBeneficiaryBack);
        assertThat(wireBeneficiaryBack.getWireRecipient()).isEqualTo(wireRecipient);

        wireRecipient.setWireBeneficiaries(new HashSet<>());
        assertThat(wireRecipient.getWireBeneficiaries()).doesNotContain(wireBeneficiaryBack);
        assertThat(wireBeneficiaryBack.getWireRecipient()).isNull();
    }

    @Test
    void wireTransactionTest() throws Exception {
        WireRecipient wireRecipient = getWireRecipientRandomSampleGenerator();
        WireTransaction wireTransactionBack = getWireTransactionRandomSampleGenerator();

        wireRecipient.setWireTransaction(wireTransactionBack);
        assertThat(wireRecipient.getWireTransaction()).isEqualTo(wireTransactionBack);
        assertThat(wireTransactionBack.getWireRecipient()).isEqualTo(wireRecipient);

        wireRecipient.wireTransaction(null);
        assertThat(wireRecipient.getWireTransaction()).isNull();
        assertThat(wireTransactionBack.getWireRecipient()).isNull();
    }
}
