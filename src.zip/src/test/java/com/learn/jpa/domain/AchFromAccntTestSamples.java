package com.learn.jpa.domain;

import java.util.Random;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

public class AchFromAccntTestSamples {

    private static final Random random = new Random();
    private static final AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    public static AchFromAccnt getAchFromAccntSample1() {
        return new AchFromAccnt().id(1L).fromAccntID(1L).fromAccntSk(1L).fromAccntName("fromAccntName1");
    }

    public static AchFromAccnt getAchFromAccntSample2() {
        return new AchFromAccnt().id(2L).fromAccntID(2L).fromAccntSk(2L).fromAccntName("fromAccntName2");
    }

    public static AchFromAccnt getAchFromAccntRandomSampleGenerator() {
        return new AchFromAccnt()
            .id(longCount.incrementAndGet())
            .fromAccntID(longCount.incrementAndGet())
            .fromAccntSk(longCount.incrementAndGet())
            .fromAccntName(UUID.randomUUID().toString());
    }
}
