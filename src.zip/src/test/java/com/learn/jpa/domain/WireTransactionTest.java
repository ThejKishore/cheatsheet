package com.learn.jpa.domain;

import static com.learn.jpa.domain.TransactionMappingTestSamples.*;
import static com.learn.jpa.domain.WireFromAccntTestSamples.*;
import static com.learn.jpa.domain.WireRecipientTestSamples.*;
import static com.learn.jpa.domain.WireTransactionTestSamples.*;
import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import java.util.HashSet;
import java.util.Set;
import org.junit.jupiter.api.Test;

class WireTransactionTest {

    @Test
    void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(WireTransaction.class);
        WireTransaction wireTransaction1 = getWireTransactionSample1();
        WireTransaction wireTransaction2 = new WireTransaction();
        assertThat(wireTransaction1).isNotEqualTo(wireTransaction2);

        wireTransaction2.setId(wireTransaction1.getId());
        assertThat(wireTransaction1).isEqualTo(wireTransaction2);

        wireTransaction2 = getWireTransactionSample2();
        assertThat(wireTransaction1).isNotEqualTo(wireTransaction2);
    }

    @Test
    void transactionMappingTest() throws Exception {
        WireTransaction wireTransaction = getWireTransactionRandomSampleGenerator();
        TransactionMapping transactionMappingBack = getTransactionMappingRandomSampleGenerator();

        wireTransaction.setTransactionMapping(transactionMappingBack);
        assertThat(wireTransaction.getTransactionMapping()).isEqualTo(transactionMappingBack);

        wireTransaction.transactionMapping(null);
        assertThat(wireTransaction.getTransactionMapping()).isNull();
    }

    @Test
    void wireRecipientTest() throws Exception {
        WireTransaction wireTransaction = getWireTransactionRandomSampleGenerator();
        WireRecipient wireRecipientBack = getWireRecipientRandomSampleGenerator();

        wireTransaction.setWireRecipient(wireRecipientBack);
        assertThat(wireTransaction.getWireRecipient()).isEqualTo(wireRecipientBack);

        wireTransaction.wireRecipient(null);
        assertThat(wireTransaction.getWireRecipient()).isNull();
    }

    @Test
    void wireFromAccntTest() throws Exception {
        WireTransaction wireTransaction = getWireTransactionRandomSampleGenerator();
        WireFromAccnt wireFromAccntBack = getWireFromAccntRandomSampleGenerator();

        wireTransaction.addWireFromAccnt(wireFromAccntBack);
        assertThat(wireTransaction.getWireFromAccnts()).containsOnly(wireFromAccntBack);
        assertThat(wireFromAccntBack.getWireTransaction()).isEqualTo(wireTransaction);

        wireTransaction.removeWireFromAccnt(wireFromAccntBack);
        assertThat(wireTransaction.getWireFromAccnts()).doesNotContain(wireFromAccntBack);
        assertThat(wireFromAccntBack.getWireTransaction()).isNull();

        wireTransaction.wireFromAccnts(new HashSet<>(Set.of(wireFromAccntBack)));
        assertThat(wireTransaction.getWireFromAccnts()).containsOnly(wireFromAccntBack);
        assertThat(wireFromAccntBack.getWireTransaction()).isEqualTo(wireTransaction);

        wireTransaction.setWireFromAccnts(new HashSet<>());
        assertThat(wireTransaction.getWireFromAccnts()).doesNotContain(wireFromAccntBack);
        assertThat(wireFromAccntBack.getWireTransaction()).isNull();
    }
}
