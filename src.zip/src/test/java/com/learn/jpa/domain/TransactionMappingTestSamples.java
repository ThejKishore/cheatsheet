package com.learn.jpa.domain;

import java.util.Random;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

public class TransactionMappingTestSamples {

    private static final Random random = new Random();
    private static final AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    public static TransactionMapping getTransactionMappingSample1() {
        return new TransactionMapping().id(1L).mappingId(1L).tranId(1L).tranTypeId(1L).tranType("tranType1");
    }

    public static TransactionMapping getTransactionMappingSample2() {
        return new TransactionMapping().id(2L).mappingId(2L).tranId(2L).tranTypeId(2L).tranType("tranType2");
    }

    public static TransactionMapping getTransactionMappingRandomSampleGenerator() {
        return new TransactionMapping()
            .id(longCount.incrementAndGet())
            .mappingId(longCount.incrementAndGet())
            .tranId(longCount.incrementAndGet())
            .tranTypeId(longCount.incrementAndGet())
            .tranType(UUID.randomUUID().toString());
    }
}
