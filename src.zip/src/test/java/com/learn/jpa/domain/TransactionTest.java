package com.learn.jpa.domain;

import static com.learn.jpa.domain.TransactionApprovalTestSamples.*;
import static com.learn.jpa.domain.TransactionMappingTestSamples.*;
import static com.learn.jpa.domain.TransactionReviewTestSamples.*;
import static com.learn.jpa.domain.TransactionTestSamples.*;
import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class TransactionTest {

    @Test
    void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(Transaction.class);
        Transaction transaction1 = getTransactionSample1();
        Transaction transaction2 = new Transaction();
        assertThat(transaction1).isNotEqualTo(transaction2);

        transaction2.setId(transaction1.getId());
        assertThat(transaction1).isEqualTo(transaction2);

        transaction2 = getTransactionSample2();
        assertThat(transaction1).isNotEqualTo(transaction2);
    }

    @Test
    void transactionMappingTest() throws Exception {
        Transaction transaction = getTransactionRandomSampleGenerator();
        TransactionMapping transactionMappingBack = getTransactionMappingRandomSampleGenerator();

        transaction.setTransactionMapping(transactionMappingBack);
        assertThat(transaction.getTransactionMapping()).isEqualTo(transactionMappingBack);

        transaction.transactionMapping(null);
        assertThat(transaction.getTransactionMapping()).isNull();
    }

    @Test
    void transactionApprovalTest() throws Exception {
        Transaction transaction = getTransactionRandomSampleGenerator();
        TransactionApproval transactionApprovalBack = getTransactionApprovalRandomSampleGenerator();

        transaction.setTransactionApproval(transactionApprovalBack);
        assertThat(transaction.getTransactionApproval()).isEqualTo(transactionApprovalBack);

        transaction.transactionApproval(null);
        assertThat(transaction.getTransactionApproval()).isNull();
    }

    @Test
    void transactionReviewTest() throws Exception {
        Transaction transaction = getTransactionRandomSampleGenerator();
        TransactionReview transactionReviewBack = getTransactionReviewRandomSampleGenerator();

        transaction.setTransactionReview(transactionReviewBack);
        assertThat(transaction.getTransactionReview()).isEqualTo(transactionReviewBack);

        transaction.transactionReview(null);
        assertThat(transaction.getTransactionReview()).isNull();
    }
}
