package com.learn.jpa.domain;

import static com.learn.jpa.domain.WireBeneficiaryTestSamples.*;
import static com.learn.jpa.domain.WireRecipientTestSamples.*;
import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class WireBeneficiaryTest {

    @Test
    void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(WireBeneficiary.class);
        WireBeneficiary wireBeneficiary1 = getWireBeneficiarySample1();
        WireBeneficiary wireBeneficiary2 = new WireBeneficiary();
        assertThat(wireBeneficiary1).isNotEqualTo(wireBeneficiary2);

        wireBeneficiary2.setId(wireBeneficiary1.getId());
        assertThat(wireBeneficiary1).isEqualTo(wireBeneficiary2);

        wireBeneficiary2 = getWireBeneficiarySample2();
        assertThat(wireBeneficiary1).isNotEqualTo(wireBeneficiary2);
    }

    @Test
    void wireRecipientTest() throws Exception {
        WireBeneficiary wireBeneficiary = getWireBeneficiaryRandomSampleGenerator();
        WireRecipient wireRecipientBack = getWireRecipientRandomSampleGenerator();

        wireBeneficiary.setWireRecipient(wireRecipientBack);
        assertThat(wireBeneficiary.getWireRecipient()).isEqualTo(wireRecipientBack);

        wireBeneficiary.wireRecipient(null);
        assertThat(wireBeneficiary.getWireRecipient()).isNull();
    }
}
