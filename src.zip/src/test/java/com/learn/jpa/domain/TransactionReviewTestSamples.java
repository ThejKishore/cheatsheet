package com.learn.jpa.domain;

import java.util.Random;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicLong;

public class TransactionReviewTestSamples {

    private static final Random random = new Random();
    private static final AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    public static TransactionReview getTransactionReviewSample1() {
        return new TransactionReview()
            .id(1L)
            .tranId(1L)
            .firstPledgeReviewerAccept("firstPledgeReviewerAccept1")
            .firstPledgeReviewerReject("firstPledgeReviewerReject1")
            .firstPledgeReviewerRejectReason("firstPledgeReviewerRejectReason1")
            .secondPledgeReviewerAccept("secondPledgeReviewerAccept1")
            .secondPledgeReviewerReject("secondPledgeReviewerReject1")
            .secondPledgeReviewerRejectReason("secondPledgeReviewerRejectReason1")
            .firstFiducaryReviewerAccept("firstFiducaryReviewerAccept1")
            .firstFiducaryReviewerReject("firstFiducaryReviewerReject1")
            .firstFiducaryReviewerRejectReason("firstFiducaryReviewerRejectReason1")
            .secondFiducaryReviewerAccept("secondFiducaryReviewerAccept1")
            .secondFiducaryReviewerReject("secondFiducaryReviewerReject1")
            .secondFiducaryReviewerRejectReason("secondFiducaryReviewerRejectReason1")
            .firstOverDraftReviewerAccept("firstOverDraftReviewerAccept1")
            .firstOverDraftReviewerReject("firstOverDraftReviewerReject1")
            .firstOverDraftReviewerRejectReason("firstOverDraftReviewerRejectReason1")
            .secondOverDraftReviewerAccept("secondOverDraftReviewerAccept1")
            .secondOverDraftReviewerReject("secondOverDraftReviewerReject1")
            .secondOverDraftReviewerRejectReason("secondOverDraftReviewerRejectReason1");
    }

    public static TransactionReview getTransactionReviewSample2() {
        return new TransactionReview()
            .id(2L)
            .tranId(2L)
            .firstPledgeReviewerAccept("firstPledgeReviewerAccept2")
            .firstPledgeReviewerReject("firstPledgeReviewerReject2")
            .firstPledgeReviewerRejectReason("firstPledgeReviewerRejectReason2")
            .secondPledgeReviewerAccept("secondPledgeReviewerAccept2")
            .secondPledgeReviewerReject("secondPledgeReviewerReject2")
            .secondPledgeReviewerRejectReason("secondPledgeReviewerRejectReason2")
            .firstFiducaryReviewerAccept("firstFiducaryReviewerAccept2")
            .firstFiducaryReviewerReject("firstFiducaryReviewerReject2")
            .firstFiducaryReviewerRejectReason("firstFiducaryReviewerRejectReason2")
            .secondFiducaryReviewerAccept("secondFiducaryReviewerAccept2")
            .secondFiducaryReviewerReject("secondFiducaryReviewerReject2")
            .secondFiducaryReviewerRejectReason("secondFiducaryReviewerRejectReason2")
            .firstOverDraftReviewerAccept("firstOverDraftReviewerAccept2")
            .firstOverDraftReviewerReject("firstOverDraftReviewerReject2")
            .firstOverDraftReviewerRejectReason("firstOverDraftReviewerRejectReason2")
            .secondOverDraftReviewerAccept("secondOverDraftReviewerAccept2")
            .secondOverDraftReviewerReject("secondOverDraftReviewerReject2")
            .secondOverDraftReviewerRejectReason("secondOverDraftReviewerRejectReason2");
    }

    public static TransactionReview getTransactionReviewRandomSampleGenerator() {
        return new TransactionReview()
            .id(longCount.incrementAndGet())
            .tranId(longCount.incrementAndGet())
            .firstPledgeReviewerAccept(UUID.randomUUID().toString())
            .firstPledgeReviewerReject(UUID.randomUUID().toString())
            .firstPledgeReviewerRejectReason(UUID.randomUUID().toString())
            .secondPledgeReviewerAccept(UUID.randomUUID().toString())
            .secondPledgeReviewerReject(UUID.randomUUID().toString())
            .secondPledgeReviewerRejectReason(UUID.randomUUID().toString())
            .firstFiducaryReviewerAccept(UUID.randomUUID().toString())
            .firstFiducaryReviewerReject(UUID.randomUUID().toString())
            .firstFiducaryReviewerRejectReason(UUID.randomUUID().toString())
            .secondFiducaryReviewerAccept(UUID.randomUUID().toString())
            .secondFiducaryReviewerReject(UUID.randomUUID().toString())
            .secondFiducaryReviewerRejectReason(UUID.randomUUID().toString())
            .firstOverDraftReviewerAccept(UUID.randomUUID().toString())
            .firstOverDraftReviewerReject(UUID.randomUUID().toString())
            .firstOverDraftReviewerRejectReason(UUID.randomUUID().toString())
            .secondOverDraftReviewerAccept(UUID.randomUUID().toString())
            .secondOverDraftReviewerReject(UUID.randomUUID().toString())
            .secondOverDraftReviewerRejectReason(UUID.randomUUID().toString());
    }
}
