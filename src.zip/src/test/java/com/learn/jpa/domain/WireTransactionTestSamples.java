package com.learn.jpa.domain;

import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;

public class WireTransactionTestSamples {

    private static final Random random = new Random();
    private static final AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    public static WireTransaction getWireTransactionSample1() {
        return new WireTransaction().id(1L).wireTranId(1L);
    }

    public static WireTransaction getWireTransactionSample2() {
        return new WireTransaction().id(2L).wireTranId(2L);
    }

    public static WireTransaction getWireTransactionRandomSampleGenerator() {
        return new WireTransaction().id(longCount.incrementAndGet()).wireTranId(longCount.incrementAndGet());
    }
}
