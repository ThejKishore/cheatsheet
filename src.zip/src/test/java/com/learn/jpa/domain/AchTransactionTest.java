package com.learn.jpa.domain;

import static com.learn.jpa.domain.AchFromAccntTestSamples.*;
import static com.learn.jpa.domain.AchRecipientTestSamples.*;
import static com.learn.jpa.domain.AchTransactionTestSamples.*;
import static com.learn.jpa.domain.TransactionMappingTestSamples.*;
import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import java.util.HashSet;
import java.util.Set;
import org.junit.jupiter.api.Test;

class AchTransactionTest {

    @Test
    void equalsVerifier() throws Exception {
        TestUtil.equalsVerifier(AchTransaction.class);
        AchTransaction achTransaction1 = getAchTransactionSample1();
        AchTransaction achTransaction2 = new AchTransaction();
        assertThat(achTransaction1).isNotEqualTo(achTransaction2);

        achTransaction2.setId(achTransaction1.getId());
        assertThat(achTransaction1).isEqualTo(achTransaction2);

        achTransaction2 = getAchTransactionSample2();
        assertThat(achTransaction1).isNotEqualTo(achTransaction2);
    }

    @Test
    void transactionMappingTest() throws Exception {
        AchTransaction achTransaction = getAchTransactionRandomSampleGenerator();
        TransactionMapping transactionMappingBack = getTransactionMappingRandomSampleGenerator();

        achTransaction.setTransactionMapping(transactionMappingBack);
        assertThat(achTransaction.getTransactionMapping()).isEqualTo(transactionMappingBack);

        achTransaction.transactionMapping(null);
        assertThat(achTransaction.getTransactionMapping()).isNull();
    }

    @Test
    void achRecipientTest() throws Exception {
        AchTransaction achTransaction = getAchTransactionRandomSampleGenerator();
        AchRecipient achRecipientBack = getAchRecipientRandomSampleGenerator();

        achTransaction.setAchRecipient(achRecipientBack);
        assertThat(achTransaction.getAchRecipient()).isEqualTo(achRecipientBack);

        achTransaction.achRecipient(null);
        assertThat(achTransaction.getAchRecipient()).isNull();
    }

    @Test
    void achFromAccntTest() throws Exception {
        AchTransaction achTransaction = getAchTransactionRandomSampleGenerator();
        AchFromAccnt achFromAccntBack = getAchFromAccntRandomSampleGenerator();

        achTransaction.addAchFromAccnt(achFromAccntBack);
        assertThat(achTransaction.getAchFromAccnts()).containsOnly(achFromAccntBack);
        assertThat(achFromAccntBack.getAchTransaction()).isEqualTo(achTransaction);

        achTransaction.removeAchFromAccnt(achFromAccntBack);
        assertThat(achTransaction.getAchFromAccnts()).doesNotContain(achFromAccntBack);
        assertThat(achFromAccntBack.getAchTransaction()).isNull();

        achTransaction.achFromAccnts(new HashSet<>(Set.of(achFromAccntBack)));
        assertThat(achTransaction.getAchFromAccnts()).containsOnly(achFromAccntBack);
        assertThat(achFromAccntBack.getAchTransaction()).isEqualTo(achTransaction);

        achTransaction.setAchFromAccnts(new HashSet<>());
        assertThat(achTransaction.getAchFromAccnts()).doesNotContain(achFromAccntBack);
        assertThat(achFromAccntBack.getAchTransaction()).isNull();
    }
}
