package com.learn.jpa.service.dto;

import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class WireRecipientDTOTest {

    @Test
    void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(WireRecipientDTO.class);
        WireRecipientDTO wireRecipientDTO1 = new WireRecipientDTO();
        wireRecipientDTO1.setId(1L);
        WireRecipientDTO wireRecipientDTO2 = new WireRecipientDTO();
        assertThat(wireRecipientDTO1).isNotEqualTo(wireRecipientDTO2);
        wireRecipientDTO2.setId(wireRecipientDTO1.getId());
        assertThat(wireRecipientDTO1).isEqualTo(wireRecipientDTO2);
        wireRecipientDTO2.setId(2L);
        assertThat(wireRecipientDTO1).isNotEqualTo(wireRecipientDTO2);
        wireRecipientDTO1.setId(null);
        assertThat(wireRecipientDTO1).isNotEqualTo(wireRecipientDTO2);
    }
}
