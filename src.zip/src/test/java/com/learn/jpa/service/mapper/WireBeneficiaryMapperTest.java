package com.learn.jpa.service.mapper;

import org.junit.jupiter.api.BeforeEach;

class WireBeneficiaryMapperTest {

    private WireBeneficiaryMapper wireBeneficiaryMapper;

    @BeforeEach
    public void setUp() {
        wireBeneficiaryMapper = new WireBeneficiaryMapperImpl();
    }
}
