package com.learn.jpa.service.dto;

import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class WireFromAccntDTOTest {

    @Test
    void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(WireFromAccntDTO.class);
        WireFromAccntDTO wireFromAccntDTO1 = new WireFromAccntDTO();
        wireFromAccntDTO1.setId(1L);
        WireFromAccntDTO wireFromAccntDTO2 = new WireFromAccntDTO();
        assertThat(wireFromAccntDTO1).isNotEqualTo(wireFromAccntDTO2);
        wireFromAccntDTO2.setId(wireFromAccntDTO1.getId());
        assertThat(wireFromAccntDTO1).isEqualTo(wireFromAccntDTO2);
        wireFromAccntDTO2.setId(2L);
        assertThat(wireFromAccntDTO1).isNotEqualTo(wireFromAccntDTO2);
        wireFromAccntDTO1.setId(null);
        assertThat(wireFromAccntDTO1).isNotEqualTo(wireFromAccntDTO2);
    }
}
