package com.learn.jpa.service.dto;

import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class AchTransactionDTOTest {

    @Test
    void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(AchTransactionDTO.class);
        AchTransactionDTO achTransactionDTO1 = new AchTransactionDTO();
        achTransactionDTO1.setId(1L);
        AchTransactionDTO achTransactionDTO2 = new AchTransactionDTO();
        assertThat(achTransactionDTO1).isNotEqualTo(achTransactionDTO2);
        achTransactionDTO2.setId(achTransactionDTO1.getId());
        assertThat(achTransactionDTO1).isEqualTo(achTransactionDTO2);
        achTransactionDTO2.setId(2L);
        assertThat(achTransactionDTO1).isNotEqualTo(achTransactionDTO2);
        achTransactionDTO1.setId(null);
        assertThat(achTransactionDTO1).isNotEqualTo(achTransactionDTO2);
    }
}
