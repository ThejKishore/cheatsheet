package com.learn.jpa.service.dto;

import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class TransferFromAccntDTOTest {

    @Test
    void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(TransferFromAccntDTO.class);
        TransferFromAccntDTO transferFromAccntDTO1 = new TransferFromAccntDTO();
        transferFromAccntDTO1.setId(1L);
        TransferFromAccntDTO transferFromAccntDTO2 = new TransferFromAccntDTO();
        assertThat(transferFromAccntDTO1).isNotEqualTo(transferFromAccntDTO2);
        transferFromAccntDTO2.setId(transferFromAccntDTO1.getId());
        assertThat(transferFromAccntDTO1).isEqualTo(transferFromAccntDTO2);
        transferFromAccntDTO2.setId(2L);
        assertThat(transferFromAccntDTO1).isNotEqualTo(transferFromAccntDTO2);
        transferFromAccntDTO1.setId(null);
        assertThat(transferFromAccntDTO1).isNotEqualTo(transferFromAccntDTO2);
    }
}
