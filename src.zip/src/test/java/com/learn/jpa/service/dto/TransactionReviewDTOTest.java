package com.learn.jpa.service.dto;

import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class TransactionReviewDTOTest {

    @Test
    void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(TransactionReviewDTO.class);
        TransactionReviewDTO transactionReviewDTO1 = new TransactionReviewDTO();
        transactionReviewDTO1.setId(1L);
        TransactionReviewDTO transactionReviewDTO2 = new TransactionReviewDTO();
        assertThat(transactionReviewDTO1).isNotEqualTo(transactionReviewDTO2);
        transactionReviewDTO2.setId(transactionReviewDTO1.getId());
        assertThat(transactionReviewDTO1).isEqualTo(transactionReviewDTO2);
        transactionReviewDTO2.setId(2L);
        assertThat(transactionReviewDTO1).isNotEqualTo(transactionReviewDTO2);
        transactionReviewDTO1.setId(null);
        assertThat(transactionReviewDTO1).isNotEqualTo(transactionReviewDTO2);
    }
}
