package com.learn.jpa.service.mapper;

import org.junit.jupiter.api.BeforeEach;

class WireFromAccntMapperTest {

    private WireFromAccntMapper wireFromAccntMapper;

    @BeforeEach
    public void setUp() {
        wireFromAccntMapper = new WireFromAccntMapperImpl();
    }
}
