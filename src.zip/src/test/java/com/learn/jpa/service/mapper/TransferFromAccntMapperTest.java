package com.learn.jpa.service.mapper;

import org.junit.jupiter.api.BeforeEach;

class TransferFromAccntMapperTest {

    private TransferFromAccntMapper transferFromAccntMapper;

    @BeforeEach
    public void setUp() {
        transferFromAccntMapper = new TransferFromAccntMapperImpl();
    }
}
