package com.learn.jpa.service.mapper;

import org.junit.jupiter.api.BeforeEach;

class AchTransactionMapperTest {

    private AchTransactionMapper achTransactionMapper;

    @BeforeEach
    public void setUp() {
        achTransactionMapper = new AchTransactionMapperImpl();
    }
}
