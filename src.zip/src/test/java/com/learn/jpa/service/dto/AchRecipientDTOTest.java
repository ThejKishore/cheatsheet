package com.learn.jpa.service.dto;

import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class AchRecipientDTOTest {

    @Test
    void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(AchRecipientDTO.class);
        AchRecipientDTO achRecipientDTO1 = new AchRecipientDTO();
        achRecipientDTO1.setId(1L);
        AchRecipientDTO achRecipientDTO2 = new AchRecipientDTO();
        assertThat(achRecipientDTO1).isNotEqualTo(achRecipientDTO2);
        achRecipientDTO2.setId(achRecipientDTO1.getId());
        assertThat(achRecipientDTO1).isEqualTo(achRecipientDTO2);
        achRecipientDTO2.setId(2L);
        assertThat(achRecipientDTO1).isNotEqualTo(achRecipientDTO2);
        achRecipientDTO1.setId(null);
        assertThat(achRecipientDTO1).isNotEqualTo(achRecipientDTO2);
    }
}
