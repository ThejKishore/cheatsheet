package com.learn.jpa.service.dto;

import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class AchFromAccntDTOTest {

    @Test
    void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(AchFromAccntDTO.class);
        AchFromAccntDTO achFromAccntDTO1 = new AchFromAccntDTO();
        achFromAccntDTO1.setId(1L);
        AchFromAccntDTO achFromAccntDTO2 = new AchFromAccntDTO();
        assertThat(achFromAccntDTO1).isNotEqualTo(achFromAccntDTO2);
        achFromAccntDTO2.setId(achFromAccntDTO1.getId());
        assertThat(achFromAccntDTO1).isEqualTo(achFromAccntDTO2);
        achFromAccntDTO2.setId(2L);
        assertThat(achFromAccntDTO1).isNotEqualTo(achFromAccntDTO2);
        achFromAccntDTO1.setId(null);
        assertThat(achFromAccntDTO1).isNotEqualTo(achFromAccntDTO2);
    }
}
