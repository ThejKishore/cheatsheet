package com.learn.jpa.service.dto;

import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class TransactionApprovalDTOTest {

    @Test
    void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(TransactionApprovalDTO.class);
        TransactionApprovalDTO transactionApprovalDTO1 = new TransactionApprovalDTO();
        transactionApprovalDTO1.setId(1L);
        TransactionApprovalDTO transactionApprovalDTO2 = new TransactionApprovalDTO();
        assertThat(transactionApprovalDTO1).isNotEqualTo(transactionApprovalDTO2);
        transactionApprovalDTO2.setId(transactionApprovalDTO1.getId());
        assertThat(transactionApprovalDTO1).isEqualTo(transactionApprovalDTO2);
        transactionApprovalDTO2.setId(2L);
        assertThat(transactionApprovalDTO1).isNotEqualTo(transactionApprovalDTO2);
        transactionApprovalDTO1.setId(null);
        assertThat(transactionApprovalDTO1).isNotEqualTo(transactionApprovalDTO2);
    }
}
