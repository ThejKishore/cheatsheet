package com.learn.jpa.service.dto;

import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class WireBeneficiaryDTOTest {

    @Test
    void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(WireBeneficiaryDTO.class);
        WireBeneficiaryDTO wireBeneficiaryDTO1 = new WireBeneficiaryDTO();
        wireBeneficiaryDTO1.setId(1L);
        WireBeneficiaryDTO wireBeneficiaryDTO2 = new WireBeneficiaryDTO();
        assertThat(wireBeneficiaryDTO1).isNotEqualTo(wireBeneficiaryDTO2);
        wireBeneficiaryDTO2.setId(wireBeneficiaryDTO1.getId());
        assertThat(wireBeneficiaryDTO1).isEqualTo(wireBeneficiaryDTO2);
        wireBeneficiaryDTO2.setId(2L);
        assertThat(wireBeneficiaryDTO1).isNotEqualTo(wireBeneficiaryDTO2);
        wireBeneficiaryDTO1.setId(null);
        assertThat(wireBeneficiaryDTO1).isNotEqualTo(wireBeneficiaryDTO2);
    }
}
