package com.learn.jpa.service.mapper;

import org.junit.jupiter.api.BeforeEach;

class TransferTransactionMapperTest {

    private TransferTransactionMapper transferTransactionMapper;

    @BeforeEach
    public void setUp() {
        transferTransactionMapper = new TransferTransactionMapperImpl();
    }
}
