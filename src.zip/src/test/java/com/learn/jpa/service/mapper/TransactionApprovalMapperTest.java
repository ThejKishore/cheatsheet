package com.learn.jpa.service.mapper;

import org.junit.jupiter.api.BeforeEach;

class TransactionApprovalMapperTest {

    private TransactionApprovalMapper transactionApprovalMapper;

    @BeforeEach
    public void setUp() {
        transactionApprovalMapper = new TransactionApprovalMapperImpl();
    }
}
