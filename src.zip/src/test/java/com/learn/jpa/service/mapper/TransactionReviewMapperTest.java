package com.learn.jpa.service.mapper;

import org.junit.jupiter.api.BeforeEach;

class TransactionReviewMapperTest {

    private TransactionReviewMapper transactionReviewMapper;

    @BeforeEach
    public void setUp() {
        transactionReviewMapper = new TransactionReviewMapperImpl();
    }
}
