package com.learn.jpa.service.mapper;

import org.junit.jupiter.api.BeforeEach;

class AchRecipientMapperTest {

    private AchRecipientMapper achRecipientMapper;

    @BeforeEach
    public void setUp() {
        achRecipientMapper = new AchRecipientMapperImpl();
    }
}
