package com.learn.jpa.service.mapper;

import org.junit.jupiter.api.BeforeEach;

class AchFromAccntMapperTest {

    private AchFromAccntMapper achFromAccntMapper;

    @BeforeEach
    public void setUp() {
        achFromAccntMapper = new AchFromAccntMapperImpl();
    }
}
