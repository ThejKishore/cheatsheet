package com.learn.jpa.service.mapper;

import org.junit.jupiter.api.BeforeEach;

class WireTransactionMapperTest {

    private WireTransactionMapper wireTransactionMapper;

    @BeforeEach
    public void setUp() {
        wireTransactionMapper = new WireTransactionMapperImpl();
    }
}
