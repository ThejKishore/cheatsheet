package com.learn.jpa.service.dto;

import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class TransferToAccntDTOTest {

    @Test
    void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(TransferToAccntDTO.class);
        TransferToAccntDTO transferToAccntDTO1 = new TransferToAccntDTO();
        transferToAccntDTO1.setId(1L);
        TransferToAccntDTO transferToAccntDTO2 = new TransferToAccntDTO();
        assertThat(transferToAccntDTO1).isNotEqualTo(transferToAccntDTO2);
        transferToAccntDTO2.setId(transferToAccntDTO1.getId());
        assertThat(transferToAccntDTO1).isEqualTo(transferToAccntDTO2);
        transferToAccntDTO2.setId(2L);
        assertThat(transferToAccntDTO1).isNotEqualTo(transferToAccntDTO2);
        transferToAccntDTO1.setId(null);
        assertThat(transferToAccntDTO1).isNotEqualTo(transferToAccntDTO2);
    }
}
