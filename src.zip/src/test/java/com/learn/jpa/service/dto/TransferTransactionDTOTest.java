package com.learn.jpa.service.dto;

import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class TransferTransactionDTOTest {

    @Test
    void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(TransferTransactionDTO.class);
        TransferTransactionDTO transferTransactionDTO1 = new TransferTransactionDTO();
        transferTransactionDTO1.setId(1L);
        TransferTransactionDTO transferTransactionDTO2 = new TransferTransactionDTO();
        assertThat(transferTransactionDTO1).isNotEqualTo(transferTransactionDTO2);
        transferTransactionDTO2.setId(transferTransactionDTO1.getId());
        assertThat(transferTransactionDTO1).isEqualTo(transferTransactionDTO2);
        transferTransactionDTO2.setId(2L);
        assertThat(transferTransactionDTO1).isNotEqualTo(transferTransactionDTO2);
        transferTransactionDTO1.setId(null);
        assertThat(transferTransactionDTO1).isNotEqualTo(transferTransactionDTO2);
    }
}
