package com.learn.jpa.service.dto;

import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class TransactionMappingDTOTest {

    @Test
    void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(TransactionMappingDTO.class);
        TransactionMappingDTO transactionMappingDTO1 = new TransactionMappingDTO();
        transactionMappingDTO1.setId(1L);
        TransactionMappingDTO transactionMappingDTO2 = new TransactionMappingDTO();
        assertThat(transactionMappingDTO1).isNotEqualTo(transactionMappingDTO2);
        transactionMappingDTO2.setId(transactionMappingDTO1.getId());
        assertThat(transactionMappingDTO1).isEqualTo(transactionMappingDTO2);
        transactionMappingDTO2.setId(2L);
        assertThat(transactionMappingDTO1).isNotEqualTo(transactionMappingDTO2);
        transactionMappingDTO1.setId(null);
        assertThat(transactionMappingDTO1).isNotEqualTo(transactionMappingDTO2);
    }
}
