package com.learn.jpa.service.dto;

import static org.assertj.core.api.Assertions.assertThat;

import com.learn.jpa.web.rest.TestUtil;
import org.junit.jupiter.api.Test;

class WireTransactionDTOTest {

    @Test
    void dtoEqualsVerifier() throws Exception {
        TestUtil.equalsVerifier(WireTransactionDTO.class);
        WireTransactionDTO wireTransactionDTO1 = new WireTransactionDTO();
        wireTransactionDTO1.setId(1L);
        WireTransactionDTO wireTransactionDTO2 = new WireTransactionDTO();
        assertThat(wireTransactionDTO1).isNotEqualTo(wireTransactionDTO2);
        wireTransactionDTO2.setId(wireTransactionDTO1.getId());
        assertThat(wireTransactionDTO1).isEqualTo(wireTransactionDTO2);
        wireTransactionDTO2.setId(2L);
        assertThat(wireTransactionDTO1).isNotEqualTo(wireTransactionDTO2);
        wireTransactionDTO1.setId(null);
        assertThat(wireTransactionDTO1).isNotEqualTo(wireTransactionDTO2);
    }
}
