package com.learn.jpa.service.mapper;

import org.junit.jupiter.api.BeforeEach;

class TransferToAccntMapperTest {

    private TransferToAccntMapper transferToAccntMapper;

    @BeforeEach
    public void setUp() {
        transferToAccntMapper = new TransferToAccntMapperImpl();
    }
}
