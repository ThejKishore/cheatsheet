package com.learn.jpa.service.mapper;

import org.junit.jupiter.api.BeforeEach;

class TransactionMappingMapperTest {

    private TransactionMappingMapper transactionMappingMapper;

    @BeforeEach
    public void setUp() {
        transactionMappingMapper = new TransactionMappingMapperImpl();
    }
}
