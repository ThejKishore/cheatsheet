package com.learn.jpa.service.mapper;

import org.junit.jupiter.api.BeforeEach;

class WireRecipientMapperTest {

    private WireRecipientMapper wireRecipientMapper;

    @BeforeEach
    public void setUp() {
        wireRecipientMapper = new WireRecipientMapperImpl();
    }
}
