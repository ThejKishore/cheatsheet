package com.learn.jpa.web.rest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.learn.jpa.IntegrationTest;
import com.learn.jpa.domain.TransferTransaction;
import com.learn.jpa.repository.TransferTransactionRepository;
import com.learn.jpa.service.dto.TransferTransactionDTO;
import com.learn.jpa.service.mapper.TransferTransactionMapper;
import jakarta.persistence.EntityManager;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

/**
 * Integration tests for the {@link TransferTransactionResource} REST controller.
 */
@IntegrationTest
@AutoConfigureMockMvc
@WithMockUser
class TransferTransactionResourceIT {

    private static final Long DEFAULT_TRANSFER_TRAN_ID = 1L;
    private static final Long UPDATED_TRANSFER_TRAN_ID = 2L;

    private static final String ENTITY_API_URL = "/api/transfer-transactions";
    private static final String ENTITY_API_URL_ID = ENTITY_API_URL + "/{id}";

    private static Random random = new Random();
    private static AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    @Autowired
    private TransferTransactionRepository transferTransactionRepository;

    @Autowired
    private TransferTransactionMapper transferTransactionMapper;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restTransferTransactionMockMvc;

    private TransferTransaction transferTransaction;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static TransferTransaction createEntity(EntityManager em) {
        TransferTransaction transferTransaction = new TransferTransaction().transferTranId(DEFAULT_TRANSFER_TRAN_ID);
        return transferTransaction;
    }

    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static TransferTransaction createUpdatedEntity(EntityManager em) {
        TransferTransaction transferTransaction = new TransferTransaction().transferTranId(UPDATED_TRANSFER_TRAN_ID);
        return transferTransaction;
    }

    @BeforeEach
    public void initTest() {
        transferTransaction = createEntity(em);
    }

    @Test
    @Transactional
    void createTransferTransaction() throws Exception {
        int databaseSizeBeforeCreate = transferTransactionRepository.findAll().size();
        // Create the TransferTransaction
        TransferTransactionDTO transferTransactionDTO = transferTransactionMapper.toDto(transferTransaction);
        restTransferTransactionMockMvc
            .perform(
                post(ENTITY_API_URL)
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transferTransactionDTO))
            )
            .andExpect(status().isCreated());

        // Validate the TransferTransaction in the database
        List<TransferTransaction> transferTransactionList = transferTransactionRepository.findAll();
        assertThat(transferTransactionList).hasSize(databaseSizeBeforeCreate + 1);
        TransferTransaction testTransferTransaction = transferTransactionList.get(transferTransactionList.size() - 1);
        assertThat(testTransferTransaction.getTransferTranId()).isEqualTo(DEFAULT_TRANSFER_TRAN_ID);
    }

    @Test
    @Transactional
    void createTransferTransactionWithExistingId() throws Exception {
        // Create the TransferTransaction with an existing ID
        transferTransaction.setId(1L);
        TransferTransactionDTO transferTransactionDTO = transferTransactionMapper.toDto(transferTransaction);

        int databaseSizeBeforeCreate = transferTransactionRepository.findAll().size();

        // An entity with an existing ID cannot be created, so this API call must fail
        restTransferTransactionMockMvc
            .perform(
                post(ENTITY_API_URL)
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transferTransactionDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransferTransaction in the database
        List<TransferTransaction> transferTransactionList = transferTransactionRepository.findAll();
        assertThat(transferTransactionList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    void checkTransferTranIdIsRequired() throws Exception {
        int databaseSizeBeforeTest = transferTransactionRepository.findAll().size();
        // set the field null
        transferTransaction.setTransferTranId(null);

        // Create the TransferTransaction, which fails.
        TransferTransactionDTO transferTransactionDTO = transferTransactionMapper.toDto(transferTransaction);

        restTransferTransactionMockMvc
            .perform(
                post(ENTITY_API_URL)
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transferTransactionDTO))
            )
            .andExpect(status().isBadRequest());

        List<TransferTransaction> transferTransactionList = transferTransactionRepository.findAll();
        assertThat(transferTransactionList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void getAllTransferTransactions() throws Exception {
        // Initialize the database
        transferTransactionRepository.saveAndFlush(transferTransaction);

        // Get all the transferTransactionList
        restTransferTransactionMockMvc
            .perform(get(ENTITY_API_URL + "?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(transferTransaction.getId().intValue())))
            .andExpect(jsonPath("$.[*].transferTranId").value(hasItem(DEFAULT_TRANSFER_TRAN_ID.intValue())));
    }

    @Test
    @Transactional
    void getTransferTransaction() throws Exception {
        // Initialize the database
        transferTransactionRepository.saveAndFlush(transferTransaction);

        // Get the transferTransaction
        restTransferTransactionMockMvc
            .perform(get(ENTITY_API_URL_ID, transferTransaction.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(transferTransaction.getId().intValue()))
            .andExpect(jsonPath("$.transferTranId").value(DEFAULT_TRANSFER_TRAN_ID.intValue()));
    }

    @Test
    @Transactional
    void getNonExistingTransferTransaction() throws Exception {
        // Get the transferTransaction
        restTransferTransactionMockMvc.perform(get(ENTITY_API_URL_ID, Long.MAX_VALUE)).andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    void putExistingTransferTransaction() throws Exception {
        // Initialize the database
        transferTransactionRepository.saveAndFlush(transferTransaction);

        int databaseSizeBeforeUpdate = transferTransactionRepository.findAll().size();

        // Update the transferTransaction
        TransferTransaction updatedTransferTransaction = transferTransactionRepository.findById(transferTransaction.getId()).orElseThrow();
        // Disconnect from session so that the updates on updatedTransferTransaction are not directly saved in db
        em.detach(updatedTransferTransaction);
        updatedTransferTransaction.transferTranId(UPDATED_TRANSFER_TRAN_ID);
        TransferTransactionDTO transferTransactionDTO = transferTransactionMapper.toDto(updatedTransferTransaction);

        restTransferTransactionMockMvc
            .perform(
                put(ENTITY_API_URL_ID, transferTransactionDTO.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transferTransactionDTO))
            )
            .andExpect(status().isOk());

        // Validate the TransferTransaction in the database
        List<TransferTransaction> transferTransactionList = transferTransactionRepository.findAll();
        assertThat(transferTransactionList).hasSize(databaseSizeBeforeUpdate);
        TransferTransaction testTransferTransaction = transferTransactionList.get(transferTransactionList.size() - 1);
        assertThat(testTransferTransaction.getTransferTranId()).isEqualTo(UPDATED_TRANSFER_TRAN_ID);
    }

    @Test
    @Transactional
    void putNonExistingTransferTransaction() throws Exception {
        int databaseSizeBeforeUpdate = transferTransactionRepository.findAll().size();
        transferTransaction.setId(longCount.incrementAndGet());

        // Create the TransferTransaction
        TransferTransactionDTO transferTransactionDTO = transferTransactionMapper.toDto(transferTransaction);

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restTransferTransactionMockMvc
            .perform(
                put(ENTITY_API_URL_ID, transferTransactionDTO.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transferTransactionDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransferTransaction in the database
        List<TransferTransaction> transferTransactionList = transferTransactionRepository.findAll();
        assertThat(transferTransactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithIdMismatchTransferTransaction() throws Exception {
        int databaseSizeBeforeUpdate = transferTransactionRepository.findAll().size();
        transferTransaction.setId(longCount.incrementAndGet());

        // Create the TransferTransaction
        TransferTransactionDTO transferTransactionDTO = transferTransactionMapper.toDto(transferTransaction);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransferTransactionMockMvc
            .perform(
                put(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transferTransactionDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransferTransaction in the database
        List<TransferTransaction> transferTransactionList = transferTransactionRepository.findAll();
        assertThat(transferTransactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithMissingIdPathParamTransferTransaction() throws Exception {
        int databaseSizeBeforeUpdate = transferTransactionRepository.findAll().size();
        transferTransaction.setId(longCount.incrementAndGet());

        // Create the TransferTransaction
        TransferTransactionDTO transferTransactionDTO = transferTransactionMapper.toDto(transferTransaction);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransferTransactionMockMvc
            .perform(
                put(ENTITY_API_URL)
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transferTransactionDTO))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the TransferTransaction in the database
        List<TransferTransaction> transferTransactionList = transferTransactionRepository.findAll();
        assertThat(transferTransactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void partialUpdateTransferTransactionWithPatch() throws Exception {
        // Initialize the database
        transferTransactionRepository.saveAndFlush(transferTransaction);

        int databaseSizeBeforeUpdate = transferTransactionRepository.findAll().size();

        // Update the transferTransaction using partial update
        TransferTransaction partialUpdatedTransferTransaction = new TransferTransaction();
        partialUpdatedTransferTransaction.setId(transferTransaction.getId());

        partialUpdatedTransferTransaction.transferTranId(UPDATED_TRANSFER_TRAN_ID);

        restTransferTransactionMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedTransferTransaction.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedTransferTransaction))
            )
            .andExpect(status().isOk());

        // Validate the TransferTransaction in the database
        List<TransferTransaction> transferTransactionList = transferTransactionRepository.findAll();
        assertThat(transferTransactionList).hasSize(databaseSizeBeforeUpdate);
        TransferTransaction testTransferTransaction = transferTransactionList.get(transferTransactionList.size() - 1);
        assertThat(testTransferTransaction.getTransferTranId()).isEqualTo(UPDATED_TRANSFER_TRAN_ID);
    }

    @Test
    @Transactional
    void fullUpdateTransferTransactionWithPatch() throws Exception {
        // Initialize the database
        transferTransactionRepository.saveAndFlush(transferTransaction);

        int databaseSizeBeforeUpdate = transferTransactionRepository.findAll().size();

        // Update the transferTransaction using partial update
        TransferTransaction partialUpdatedTransferTransaction = new TransferTransaction();
        partialUpdatedTransferTransaction.setId(transferTransaction.getId());

        partialUpdatedTransferTransaction.transferTranId(UPDATED_TRANSFER_TRAN_ID);

        restTransferTransactionMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedTransferTransaction.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedTransferTransaction))
            )
            .andExpect(status().isOk());

        // Validate the TransferTransaction in the database
        List<TransferTransaction> transferTransactionList = transferTransactionRepository.findAll();
        assertThat(transferTransactionList).hasSize(databaseSizeBeforeUpdate);
        TransferTransaction testTransferTransaction = transferTransactionList.get(transferTransactionList.size() - 1);
        assertThat(testTransferTransaction.getTransferTranId()).isEqualTo(UPDATED_TRANSFER_TRAN_ID);
    }

    @Test
    @Transactional
    void patchNonExistingTransferTransaction() throws Exception {
        int databaseSizeBeforeUpdate = transferTransactionRepository.findAll().size();
        transferTransaction.setId(longCount.incrementAndGet());

        // Create the TransferTransaction
        TransferTransactionDTO transferTransactionDTO = transferTransactionMapper.toDto(transferTransaction);

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restTransferTransactionMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, transferTransactionDTO.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(transferTransactionDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransferTransaction in the database
        List<TransferTransaction> transferTransactionList = transferTransactionRepository.findAll();
        assertThat(transferTransactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithIdMismatchTransferTransaction() throws Exception {
        int databaseSizeBeforeUpdate = transferTransactionRepository.findAll().size();
        transferTransaction.setId(longCount.incrementAndGet());

        // Create the TransferTransaction
        TransferTransactionDTO transferTransactionDTO = transferTransactionMapper.toDto(transferTransaction);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransferTransactionMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(transferTransactionDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransferTransaction in the database
        List<TransferTransaction> transferTransactionList = transferTransactionRepository.findAll();
        assertThat(transferTransactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithMissingIdPathParamTransferTransaction() throws Exception {
        int databaseSizeBeforeUpdate = transferTransactionRepository.findAll().size();
        transferTransaction.setId(longCount.incrementAndGet());

        // Create the TransferTransaction
        TransferTransactionDTO transferTransactionDTO = transferTransactionMapper.toDto(transferTransaction);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransferTransactionMockMvc
            .perform(
                patch(ENTITY_API_URL)
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(transferTransactionDTO))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the TransferTransaction in the database
        List<TransferTransaction> transferTransactionList = transferTransactionRepository.findAll();
        assertThat(transferTransactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void deleteTransferTransaction() throws Exception {
        // Initialize the database
        transferTransactionRepository.saveAndFlush(transferTransaction);

        int databaseSizeBeforeDelete = transferTransactionRepository.findAll().size();

        // Delete the transferTransaction
        restTransferTransactionMockMvc
            .perform(delete(ENTITY_API_URL_ID, transferTransaction.getId()).accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<TransferTransaction> transferTransactionList = transferTransactionRepository.findAll();
        assertThat(transferTransactionList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
