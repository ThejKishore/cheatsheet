package com.learn.jpa.web.rest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.learn.jpa.IntegrationTest;
import com.learn.jpa.domain.TransactionMapping;
import com.learn.jpa.repository.TransactionMappingRepository;
import com.learn.jpa.service.dto.TransactionMappingDTO;
import com.learn.jpa.service.mapper.TransactionMappingMapper;
import jakarta.persistence.EntityManager;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

/**
 * Integration tests for the {@link TransactionMappingResource} REST controller.
 */
@IntegrationTest
@AutoConfigureMockMvc
@WithMockUser
class TransactionMappingResourceIT {

    private static final Long DEFAULT_MAPPING_ID = 1L;
    private static final Long UPDATED_MAPPING_ID = 2L;

    private static final Long DEFAULT_TRAN_ID = 1L;
    private static final Long UPDATED_TRAN_ID = 2L;

    private static final Long DEFAULT_TRAN_TYPE_ID = 1L;
    private static final Long UPDATED_TRAN_TYPE_ID = 2L;

    private static final String DEFAULT_TRAN_TYPE = "AAAAAAAAAA";
    private static final String UPDATED_TRAN_TYPE = "BBBBBBBBBB";

    private static final String ENTITY_API_URL = "/api/transaction-mappings";
    private static final String ENTITY_API_URL_ID = ENTITY_API_URL + "/{id}";

    private static Random random = new Random();
    private static AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    @Autowired
    private TransactionMappingRepository transactionMappingRepository;

    @Autowired
    private TransactionMappingMapper transactionMappingMapper;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restTransactionMappingMockMvc;

    private TransactionMapping transactionMapping;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static TransactionMapping createEntity(EntityManager em) {
        TransactionMapping transactionMapping = new TransactionMapping()
            .mappingId(DEFAULT_MAPPING_ID)
            .tranId(DEFAULT_TRAN_ID)
            .tranTypeId(DEFAULT_TRAN_TYPE_ID)
            .tranType(DEFAULT_TRAN_TYPE);
        return transactionMapping;
    }

    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static TransactionMapping createUpdatedEntity(EntityManager em) {
        TransactionMapping transactionMapping = new TransactionMapping()
            .mappingId(UPDATED_MAPPING_ID)
            .tranId(UPDATED_TRAN_ID)
            .tranTypeId(UPDATED_TRAN_TYPE_ID)
            .tranType(UPDATED_TRAN_TYPE);
        return transactionMapping;
    }

    @BeforeEach
    public void initTest() {
        transactionMapping = createEntity(em);
    }

    @Test
    @Transactional
    void createTransactionMapping() throws Exception {
        int databaseSizeBeforeCreate = transactionMappingRepository.findAll().size();
        // Create the TransactionMapping
        TransactionMappingDTO transactionMappingDTO = transactionMappingMapper.toDto(transactionMapping);
        restTransactionMappingMockMvc
            .perform(
                post(ENTITY_API_URL)
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transactionMappingDTO))
            )
            .andExpect(status().isCreated());

        // Validate the TransactionMapping in the database
        List<TransactionMapping> transactionMappingList = transactionMappingRepository.findAll();
        assertThat(transactionMappingList).hasSize(databaseSizeBeforeCreate + 1);
        TransactionMapping testTransactionMapping = transactionMappingList.get(transactionMappingList.size() - 1);
        assertThat(testTransactionMapping.getMappingId()).isEqualTo(DEFAULT_MAPPING_ID);
        assertThat(testTransactionMapping.getTranId()).isEqualTo(DEFAULT_TRAN_ID);
        assertThat(testTransactionMapping.getTranTypeId()).isEqualTo(DEFAULT_TRAN_TYPE_ID);
        assertThat(testTransactionMapping.getTranType()).isEqualTo(DEFAULT_TRAN_TYPE);
    }

    @Test
    @Transactional
    void createTransactionMappingWithExistingId() throws Exception {
        // Create the TransactionMapping with an existing ID
        transactionMapping.setId(1L);
        TransactionMappingDTO transactionMappingDTO = transactionMappingMapper.toDto(transactionMapping);

        int databaseSizeBeforeCreate = transactionMappingRepository.findAll().size();

        // An entity with an existing ID cannot be created, so this API call must fail
        restTransactionMappingMockMvc
            .perform(
                post(ENTITY_API_URL)
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transactionMappingDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransactionMapping in the database
        List<TransactionMapping> transactionMappingList = transactionMappingRepository.findAll();
        assertThat(transactionMappingList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    void checkMappingIdIsRequired() throws Exception {
        int databaseSizeBeforeTest = transactionMappingRepository.findAll().size();
        // set the field null
        transactionMapping.setMappingId(null);

        // Create the TransactionMapping, which fails.
        TransactionMappingDTO transactionMappingDTO = transactionMappingMapper.toDto(transactionMapping);

        restTransactionMappingMockMvc
            .perform(
                post(ENTITY_API_URL)
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transactionMappingDTO))
            )
            .andExpect(status().isBadRequest());

        List<TransactionMapping> transactionMappingList = transactionMappingRepository.findAll();
        assertThat(transactionMappingList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void getAllTransactionMappings() throws Exception {
        // Initialize the database
        transactionMappingRepository.saveAndFlush(transactionMapping);

        // Get all the transactionMappingList
        restTransactionMappingMockMvc
            .perform(get(ENTITY_API_URL + "?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(transactionMapping.getId().intValue())))
            .andExpect(jsonPath("$.[*].mappingId").value(hasItem(DEFAULT_MAPPING_ID.intValue())))
            .andExpect(jsonPath("$.[*].tranId").value(hasItem(DEFAULT_TRAN_ID.intValue())))
            .andExpect(jsonPath("$.[*].tranTypeId").value(hasItem(DEFAULT_TRAN_TYPE_ID.intValue())))
            .andExpect(jsonPath("$.[*].tranType").value(hasItem(DEFAULT_TRAN_TYPE)));
    }

    @Test
    @Transactional
    void getTransactionMapping() throws Exception {
        // Initialize the database
        transactionMappingRepository.saveAndFlush(transactionMapping);

        // Get the transactionMapping
        restTransactionMappingMockMvc
            .perform(get(ENTITY_API_URL_ID, transactionMapping.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(transactionMapping.getId().intValue()))
            .andExpect(jsonPath("$.mappingId").value(DEFAULT_MAPPING_ID.intValue()))
            .andExpect(jsonPath("$.tranId").value(DEFAULT_TRAN_ID.intValue()))
            .andExpect(jsonPath("$.tranTypeId").value(DEFAULT_TRAN_TYPE_ID.intValue()))
            .andExpect(jsonPath("$.tranType").value(DEFAULT_TRAN_TYPE));
    }

    @Test
    @Transactional
    void getNonExistingTransactionMapping() throws Exception {
        // Get the transactionMapping
        restTransactionMappingMockMvc.perform(get(ENTITY_API_URL_ID, Long.MAX_VALUE)).andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    void putExistingTransactionMapping() throws Exception {
        // Initialize the database
        transactionMappingRepository.saveAndFlush(transactionMapping);

        int databaseSizeBeforeUpdate = transactionMappingRepository.findAll().size();

        // Update the transactionMapping
        TransactionMapping updatedTransactionMapping = transactionMappingRepository.findById(transactionMapping.getId()).orElseThrow();
        // Disconnect from session so that the updates on updatedTransactionMapping are not directly saved in db
        em.detach(updatedTransactionMapping);
        updatedTransactionMapping
            .mappingId(UPDATED_MAPPING_ID)
            .tranId(UPDATED_TRAN_ID)
            .tranTypeId(UPDATED_TRAN_TYPE_ID)
            .tranType(UPDATED_TRAN_TYPE);
        TransactionMappingDTO transactionMappingDTO = transactionMappingMapper.toDto(updatedTransactionMapping);

        restTransactionMappingMockMvc
            .perform(
                put(ENTITY_API_URL_ID, transactionMappingDTO.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transactionMappingDTO))
            )
            .andExpect(status().isOk());

        // Validate the TransactionMapping in the database
        List<TransactionMapping> transactionMappingList = transactionMappingRepository.findAll();
        assertThat(transactionMappingList).hasSize(databaseSizeBeforeUpdate);
        TransactionMapping testTransactionMapping = transactionMappingList.get(transactionMappingList.size() - 1);
        assertThat(testTransactionMapping.getMappingId()).isEqualTo(UPDATED_MAPPING_ID);
        assertThat(testTransactionMapping.getTranId()).isEqualTo(UPDATED_TRAN_ID);
        assertThat(testTransactionMapping.getTranTypeId()).isEqualTo(UPDATED_TRAN_TYPE_ID);
        assertThat(testTransactionMapping.getTranType()).isEqualTo(UPDATED_TRAN_TYPE);
    }

    @Test
    @Transactional
    void putNonExistingTransactionMapping() throws Exception {
        int databaseSizeBeforeUpdate = transactionMappingRepository.findAll().size();
        transactionMapping.setId(longCount.incrementAndGet());

        // Create the TransactionMapping
        TransactionMappingDTO transactionMappingDTO = transactionMappingMapper.toDto(transactionMapping);

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restTransactionMappingMockMvc
            .perform(
                put(ENTITY_API_URL_ID, transactionMappingDTO.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transactionMappingDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransactionMapping in the database
        List<TransactionMapping> transactionMappingList = transactionMappingRepository.findAll();
        assertThat(transactionMappingList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithIdMismatchTransactionMapping() throws Exception {
        int databaseSizeBeforeUpdate = transactionMappingRepository.findAll().size();
        transactionMapping.setId(longCount.incrementAndGet());

        // Create the TransactionMapping
        TransactionMappingDTO transactionMappingDTO = transactionMappingMapper.toDto(transactionMapping);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransactionMappingMockMvc
            .perform(
                put(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transactionMappingDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransactionMapping in the database
        List<TransactionMapping> transactionMappingList = transactionMappingRepository.findAll();
        assertThat(transactionMappingList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithMissingIdPathParamTransactionMapping() throws Exception {
        int databaseSizeBeforeUpdate = transactionMappingRepository.findAll().size();
        transactionMapping.setId(longCount.incrementAndGet());

        // Create the TransactionMapping
        TransactionMappingDTO transactionMappingDTO = transactionMappingMapper.toDto(transactionMapping);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransactionMappingMockMvc
            .perform(
                put(ENTITY_API_URL)
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transactionMappingDTO))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the TransactionMapping in the database
        List<TransactionMapping> transactionMappingList = transactionMappingRepository.findAll();
        assertThat(transactionMappingList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void partialUpdateTransactionMappingWithPatch() throws Exception {
        // Initialize the database
        transactionMappingRepository.saveAndFlush(transactionMapping);

        int databaseSizeBeforeUpdate = transactionMappingRepository.findAll().size();

        // Update the transactionMapping using partial update
        TransactionMapping partialUpdatedTransactionMapping = new TransactionMapping();
        partialUpdatedTransactionMapping.setId(transactionMapping.getId());

        partialUpdatedTransactionMapping.tranId(UPDATED_TRAN_ID).tranTypeId(UPDATED_TRAN_TYPE_ID).tranType(UPDATED_TRAN_TYPE);

        restTransactionMappingMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedTransactionMapping.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedTransactionMapping))
            )
            .andExpect(status().isOk());

        // Validate the TransactionMapping in the database
        List<TransactionMapping> transactionMappingList = transactionMappingRepository.findAll();
        assertThat(transactionMappingList).hasSize(databaseSizeBeforeUpdate);
        TransactionMapping testTransactionMapping = transactionMappingList.get(transactionMappingList.size() - 1);
        assertThat(testTransactionMapping.getMappingId()).isEqualTo(DEFAULT_MAPPING_ID);
        assertThat(testTransactionMapping.getTranId()).isEqualTo(UPDATED_TRAN_ID);
        assertThat(testTransactionMapping.getTranTypeId()).isEqualTo(UPDATED_TRAN_TYPE_ID);
        assertThat(testTransactionMapping.getTranType()).isEqualTo(UPDATED_TRAN_TYPE);
    }

    @Test
    @Transactional
    void fullUpdateTransactionMappingWithPatch() throws Exception {
        // Initialize the database
        transactionMappingRepository.saveAndFlush(transactionMapping);

        int databaseSizeBeforeUpdate = transactionMappingRepository.findAll().size();

        // Update the transactionMapping using partial update
        TransactionMapping partialUpdatedTransactionMapping = new TransactionMapping();
        partialUpdatedTransactionMapping.setId(transactionMapping.getId());

        partialUpdatedTransactionMapping
            .mappingId(UPDATED_MAPPING_ID)
            .tranId(UPDATED_TRAN_ID)
            .tranTypeId(UPDATED_TRAN_TYPE_ID)
            .tranType(UPDATED_TRAN_TYPE);

        restTransactionMappingMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedTransactionMapping.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedTransactionMapping))
            )
            .andExpect(status().isOk());

        // Validate the TransactionMapping in the database
        List<TransactionMapping> transactionMappingList = transactionMappingRepository.findAll();
        assertThat(transactionMappingList).hasSize(databaseSizeBeforeUpdate);
        TransactionMapping testTransactionMapping = transactionMappingList.get(transactionMappingList.size() - 1);
        assertThat(testTransactionMapping.getMappingId()).isEqualTo(UPDATED_MAPPING_ID);
        assertThat(testTransactionMapping.getTranId()).isEqualTo(UPDATED_TRAN_ID);
        assertThat(testTransactionMapping.getTranTypeId()).isEqualTo(UPDATED_TRAN_TYPE_ID);
        assertThat(testTransactionMapping.getTranType()).isEqualTo(UPDATED_TRAN_TYPE);
    }

    @Test
    @Transactional
    void patchNonExistingTransactionMapping() throws Exception {
        int databaseSizeBeforeUpdate = transactionMappingRepository.findAll().size();
        transactionMapping.setId(longCount.incrementAndGet());

        // Create the TransactionMapping
        TransactionMappingDTO transactionMappingDTO = transactionMappingMapper.toDto(transactionMapping);

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restTransactionMappingMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, transactionMappingDTO.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(transactionMappingDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransactionMapping in the database
        List<TransactionMapping> transactionMappingList = transactionMappingRepository.findAll();
        assertThat(transactionMappingList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithIdMismatchTransactionMapping() throws Exception {
        int databaseSizeBeforeUpdate = transactionMappingRepository.findAll().size();
        transactionMapping.setId(longCount.incrementAndGet());

        // Create the TransactionMapping
        TransactionMappingDTO transactionMappingDTO = transactionMappingMapper.toDto(transactionMapping);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransactionMappingMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(transactionMappingDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransactionMapping in the database
        List<TransactionMapping> transactionMappingList = transactionMappingRepository.findAll();
        assertThat(transactionMappingList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithMissingIdPathParamTransactionMapping() throws Exception {
        int databaseSizeBeforeUpdate = transactionMappingRepository.findAll().size();
        transactionMapping.setId(longCount.incrementAndGet());

        // Create the TransactionMapping
        TransactionMappingDTO transactionMappingDTO = transactionMappingMapper.toDto(transactionMapping);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransactionMappingMockMvc
            .perform(
                patch(ENTITY_API_URL)
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(transactionMappingDTO))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the TransactionMapping in the database
        List<TransactionMapping> transactionMappingList = transactionMappingRepository.findAll();
        assertThat(transactionMappingList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void deleteTransactionMapping() throws Exception {
        // Initialize the database
        transactionMappingRepository.saveAndFlush(transactionMapping);

        int databaseSizeBeforeDelete = transactionMappingRepository.findAll().size();

        // Delete the transactionMapping
        restTransactionMappingMockMvc
            .perform(delete(ENTITY_API_URL_ID, transactionMapping.getId()).accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<TransactionMapping> transactionMappingList = transactionMappingRepository.findAll();
        assertThat(transactionMappingList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
