package com.learn.jpa.web.rest;

import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.learn.jpa.IntegrationTest;
import com.learn.jpa.domain.WireTransaction;
import com.learn.jpa.repository.WireTransactionRepository;
import com.learn.jpa.service.dto.WireTransactionDTO;
import com.learn.jpa.service.mapper.WireTransactionMapper;
import jakarta.persistence.EntityManager;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

/**
 * Integration tests for the {@link WireTransactionResource} REST controller.
 */
@IntegrationTest
@AutoConfigureMockMvc
@WithMockUser
class WireTransactionResourceIT {

    private static final Long DEFAULT_WIRE_TRAN_ID = 1L;
    private static final Long UPDATED_WIRE_TRAN_ID = 2L;

    private static final String ENTITY_API_URL = "/api/wire-transactions";
    private static final String ENTITY_API_URL_ID = ENTITY_API_URL + "/{id}";

    private static Random random = new Random();
    private static AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    @Autowired
    private WireTransactionRepository wireTransactionRepository;

    @Autowired
    private WireTransactionMapper wireTransactionMapper;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restWireTransactionMockMvc;

    private WireTransaction wireTransaction;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static WireTransaction createEntity(EntityManager em) {
        WireTransaction wireTransaction = new WireTransaction().wireTranId(DEFAULT_WIRE_TRAN_ID);
        return wireTransaction;
    }

    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static WireTransaction createUpdatedEntity(EntityManager em) {
        WireTransaction wireTransaction = new WireTransaction().wireTranId(UPDATED_WIRE_TRAN_ID);
        return wireTransaction;
    }

    @BeforeEach
    public void initTest() {
        wireTransaction = createEntity(em);
    }

    @Test
    @Transactional
    void createWireTransaction() throws Exception {
        int databaseSizeBeforeCreate = wireTransactionRepository.findAll().size();
        // Create the WireTransaction
        WireTransactionDTO wireTransactionDTO = wireTransactionMapper.toDto(wireTransaction);
        restWireTransactionMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(wireTransactionDTO))
            )
            .andExpect(status().isCreated());

        // Validate the WireTransaction in the database
        List<WireTransaction> wireTransactionList = wireTransactionRepository.findAll();
        assertThat(wireTransactionList).hasSize(databaseSizeBeforeCreate + 1);
        WireTransaction testWireTransaction = wireTransactionList.get(wireTransactionList.size() - 1);
        assertThat(testWireTransaction.getWireTranId()).isEqualTo(DEFAULT_WIRE_TRAN_ID);
    }

    @Test
    @Transactional
    void createWireTransactionWithExistingId() throws Exception {
        // Create the WireTransaction with an existing ID
        wireTransaction.setId(1L);
        WireTransactionDTO wireTransactionDTO = wireTransactionMapper.toDto(wireTransaction);

        int databaseSizeBeforeCreate = wireTransactionRepository.findAll().size();

        // An entity with an existing ID cannot be created, so this API call must fail
        restWireTransactionMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(wireTransactionDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the WireTransaction in the database
        List<WireTransaction> wireTransactionList = wireTransactionRepository.findAll();
        assertThat(wireTransactionList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    void checkWireTranIdIsRequired() throws Exception {
        int databaseSizeBeforeTest = wireTransactionRepository.findAll().size();
        // set the field null
        wireTransaction.setWireTranId(null);

        // Create the WireTransaction, which fails.
        WireTransactionDTO wireTransactionDTO = wireTransactionMapper.toDto(wireTransaction);

        restWireTransactionMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(wireTransactionDTO))
            )
            .andExpect(status().isBadRequest());

        List<WireTransaction> wireTransactionList = wireTransactionRepository.findAll();
        assertThat(wireTransactionList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void getAllWireTransactions() throws Exception {
        // Initialize the database
        wireTransactionRepository.saveAndFlush(wireTransaction);

        // Get all the wireTransactionList
        restWireTransactionMockMvc
            .perform(get(ENTITY_API_URL + "?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(wireTransaction.getId().intValue())))
            .andExpect(jsonPath("$.[*].wireTranId").value(hasItem(DEFAULT_WIRE_TRAN_ID.intValue())));
    }

    @Test
    @Transactional
    void getWireTransaction() throws Exception {
        // Initialize the database
        wireTransactionRepository.saveAndFlush(wireTransaction);

        // Get the wireTransaction
        restWireTransactionMockMvc
            .perform(get(ENTITY_API_URL_ID, wireTransaction.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(wireTransaction.getId().intValue()))
            .andExpect(jsonPath("$.wireTranId").value(DEFAULT_WIRE_TRAN_ID.intValue()));
    }

    @Test
    @Transactional
    void getNonExistingWireTransaction() throws Exception {
        // Get the wireTransaction
        restWireTransactionMockMvc.perform(get(ENTITY_API_URL_ID, Long.MAX_VALUE)).andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    void putExistingWireTransaction() throws Exception {
        // Initialize the database
        wireTransactionRepository.saveAndFlush(wireTransaction);

        int databaseSizeBeforeUpdate = wireTransactionRepository.findAll().size();

        // Update the wireTransaction
        WireTransaction updatedWireTransaction = wireTransactionRepository.findById(wireTransaction.getId()).orElseThrow();
        // Disconnect from session so that the updates on updatedWireTransaction are not directly saved in db
        em.detach(updatedWireTransaction);
        updatedWireTransaction.wireTranId(UPDATED_WIRE_TRAN_ID);
        WireTransactionDTO wireTransactionDTO = wireTransactionMapper.toDto(updatedWireTransaction);

        restWireTransactionMockMvc
            .perform(
                put(ENTITY_API_URL_ID, wireTransactionDTO.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(wireTransactionDTO))
            )
            .andExpect(status().isOk());

        // Validate the WireTransaction in the database
        List<WireTransaction> wireTransactionList = wireTransactionRepository.findAll();
        assertThat(wireTransactionList).hasSize(databaseSizeBeforeUpdate);
        WireTransaction testWireTransaction = wireTransactionList.get(wireTransactionList.size() - 1);
        assertThat(testWireTransaction.getWireTranId()).isEqualTo(UPDATED_WIRE_TRAN_ID);
    }

    @Test
    @Transactional
    void putNonExistingWireTransaction() throws Exception {
        int databaseSizeBeforeUpdate = wireTransactionRepository.findAll().size();
        wireTransaction.setId(longCount.incrementAndGet());

        // Create the WireTransaction
        WireTransactionDTO wireTransactionDTO = wireTransactionMapper.toDto(wireTransaction);

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restWireTransactionMockMvc
            .perform(
                put(ENTITY_API_URL_ID, wireTransactionDTO.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(wireTransactionDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the WireTransaction in the database
        List<WireTransaction> wireTransactionList = wireTransactionRepository.findAll();
        assertThat(wireTransactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithIdMismatchWireTransaction() throws Exception {
        int databaseSizeBeforeUpdate = wireTransactionRepository.findAll().size();
        wireTransaction.setId(longCount.incrementAndGet());

        // Create the WireTransaction
        WireTransactionDTO wireTransactionDTO = wireTransactionMapper.toDto(wireTransaction);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restWireTransactionMockMvc
            .perform(
                put(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(wireTransactionDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the WireTransaction in the database
        List<WireTransaction> wireTransactionList = wireTransactionRepository.findAll();
        assertThat(wireTransactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithMissingIdPathParamWireTransaction() throws Exception {
        int databaseSizeBeforeUpdate = wireTransactionRepository.findAll().size();
        wireTransaction.setId(longCount.incrementAndGet());

        // Create the WireTransaction
        WireTransactionDTO wireTransactionDTO = wireTransactionMapper.toDto(wireTransaction);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restWireTransactionMockMvc
            .perform(
                put(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(wireTransactionDTO))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the WireTransaction in the database
        List<WireTransaction> wireTransactionList = wireTransactionRepository.findAll();
        assertThat(wireTransactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void partialUpdateWireTransactionWithPatch() throws Exception {
        // Initialize the database
        wireTransactionRepository.saveAndFlush(wireTransaction);

        int databaseSizeBeforeUpdate = wireTransactionRepository.findAll().size();

        // Update the wireTransaction using partial update
        WireTransaction partialUpdatedWireTransaction = new WireTransaction();
        partialUpdatedWireTransaction.setId(wireTransaction.getId());

        restWireTransactionMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedWireTransaction.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedWireTransaction))
            )
            .andExpect(status().isOk());

        // Validate the WireTransaction in the database
        List<WireTransaction> wireTransactionList = wireTransactionRepository.findAll();
        assertThat(wireTransactionList).hasSize(databaseSizeBeforeUpdate);
        WireTransaction testWireTransaction = wireTransactionList.get(wireTransactionList.size() - 1);
        assertThat(testWireTransaction.getWireTranId()).isEqualTo(DEFAULT_WIRE_TRAN_ID);
    }

    @Test
    @Transactional
    void fullUpdateWireTransactionWithPatch() throws Exception {
        // Initialize the database
        wireTransactionRepository.saveAndFlush(wireTransaction);

        int databaseSizeBeforeUpdate = wireTransactionRepository.findAll().size();

        // Update the wireTransaction using partial update
        WireTransaction partialUpdatedWireTransaction = new WireTransaction();
        partialUpdatedWireTransaction.setId(wireTransaction.getId());

        partialUpdatedWireTransaction.wireTranId(UPDATED_WIRE_TRAN_ID);

        restWireTransactionMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedWireTransaction.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedWireTransaction))
            )
            .andExpect(status().isOk());

        // Validate the WireTransaction in the database
        List<WireTransaction> wireTransactionList = wireTransactionRepository.findAll();
        assertThat(wireTransactionList).hasSize(databaseSizeBeforeUpdate);
        WireTransaction testWireTransaction = wireTransactionList.get(wireTransactionList.size() - 1);
        assertThat(testWireTransaction.getWireTranId()).isEqualTo(UPDATED_WIRE_TRAN_ID);
    }

    @Test
    @Transactional
    void patchNonExistingWireTransaction() throws Exception {
        int databaseSizeBeforeUpdate = wireTransactionRepository.findAll().size();
        wireTransaction.setId(longCount.incrementAndGet());

        // Create the WireTransaction
        WireTransactionDTO wireTransactionDTO = wireTransactionMapper.toDto(wireTransaction);

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restWireTransactionMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, wireTransactionDTO.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(wireTransactionDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the WireTransaction in the database
        List<WireTransaction> wireTransactionList = wireTransactionRepository.findAll();
        assertThat(wireTransactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithIdMismatchWireTransaction() throws Exception {
        int databaseSizeBeforeUpdate = wireTransactionRepository.findAll().size();
        wireTransaction.setId(longCount.incrementAndGet());

        // Create the WireTransaction
        WireTransactionDTO wireTransactionDTO = wireTransactionMapper.toDto(wireTransaction);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restWireTransactionMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(wireTransactionDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the WireTransaction in the database
        List<WireTransaction> wireTransactionList = wireTransactionRepository.findAll();
        assertThat(wireTransactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithMissingIdPathParamWireTransaction() throws Exception {
        int databaseSizeBeforeUpdate = wireTransactionRepository.findAll().size();
        wireTransaction.setId(longCount.incrementAndGet());

        // Create the WireTransaction
        WireTransactionDTO wireTransactionDTO = wireTransactionMapper.toDto(wireTransaction);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restWireTransactionMockMvc
            .perform(
                patch(ENTITY_API_URL)
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(wireTransactionDTO))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the WireTransaction in the database
        List<WireTransaction> wireTransactionList = wireTransactionRepository.findAll();
        assertThat(wireTransactionList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void deleteWireTransaction() throws Exception {
        // Initialize the database
        wireTransactionRepository.saveAndFlush(wireTransaction);

        int databaseSizeBeforeDelete = wireTransactionRepository.findAll().size();

        // Delete the wireTransaction
        restWireTransactionMockMvc
            .perform(delete(ENTITY_API_URL_ID, wireTransaction.getId()).accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<WireTransaction> wireTransactionList = wireTransactionRepository.findAll();
        assertThat(wireTransactionList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
