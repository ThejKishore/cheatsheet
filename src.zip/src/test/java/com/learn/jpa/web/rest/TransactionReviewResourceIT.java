package com.learn.jpa.web.rest;

import static com.learn.jpa.web.rest.TestUtil.sameInstant;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.learn.jpa.IntegrationTest;
import com.learn.jpa.domain.TransactionReview;
import com.learn.jpa.repository.TransactionReviewRepository;
import com.learn.jpa.service.dto.TransactionReviewDTO;
import com.learn.jpa.service.mapper.TransactionReviewMapper;
import jakarta.persistence.EntityManager;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

/**
 * Integration tests for the {@link TransactionReviewResource} REST controller.
 */
@IntegrationTest
@AutoConfigureMockMvc
@WithMockUser
class TransactionReviewResourceIT {

    private static final Long DEFAULT_TRAN_ID = 1L;
    private static final Long UPDATED_TRAN_ID = 2L;

    private static final String DEFAULT_FIRST_PLEDGE_REVIEWER_ACCEPT = "AAAAAAAAAA";
    private static final String UPDATED_FIRST_PLEDGE_REVIEWER_ACCEPT = "BBBBBBBBBB";

    private static final ZonedDateTime DEFAULT_FIRST_PLEDGE_REVIEWED_ACCEPT_DATE = ZonedDateTime.ofInstant(
        Instant.ofEpochMilli(0L),
        ZoneOffset.UTC
    );
    private static final ZonedDateTime UPDATED_FIRST_PLEDGE_REVIEWED_ACCEPT_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    private static final String DEFAULT_FIRST_PLEDGE_REVIEWER_REJECT = "AAAAAAAAAA";
    private static final String UPDATED_FIRST_PLEDGE_REVIEWER_REJECT = "BBBBBBBBBB";

    private static final String DEFAULT_FIRST_PLEDGE_REVIEWER_REJECT_REASON = "AAAAAAAAAA";
    private static final String UPDATED_FIRST_PLEDGE_REVIEWER_REJECT_REASON = "BBBBBBBBBB";

    private static final ZonedDateTime DEFAULT_FIRST_PLEDGE_REVIEWED_REJECTED_DATE = ZonedDateTime.ofInstant(
        Instant.ofEpochMilli(0L),
        ZoneOffset.UTC
    );
    private static final ZonedDateTime UPDATED_FIRST_PLEDGE_REVIEWED_REJECTED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    private static final String DEFAULT_SECOND_PLEDGE_REVIEWER_ACCEPT = "AAAAAAAAAA";
    private static final String UPDATED_SECOND_PLEDGE_REVIEWER_ACCEPT = "BBBBBBBBBB";

    private static final ZonedDateTime DEFAULT_SECOND_PLEDGE_REVIEWED_ACCEPT_DATE = ZonedDateTime.ofInstant(
        Instant.ofEpochMilli(0L),
        ZoneOffset.UTC
    );
    private static final ZonedDateTime UPDATED_SECOND_PLEDGE_REVIEWED_ACCEPT_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    private static final String DEFAULT_SECOND_PLEDGE_REVIEWER_REJECT = "AAAAAAAAAA";
    private static final String UPDATED_SECOND_PLEDGE_REVIEWER_REJECT = "BBBBBBBBBB";

    private static final String DEFAULT_SECOND_PLEDGE_REVIEWER_REJECT_REASON = "AAAAAAAAAA";
    private static final String UPDATED_SECOND_PLEDGE_REVIEWER_REJECT_REASON = "BBBBBBBBBB";

    private static final ZonedDateTime DEFAULT_SECOND_PLEDGE_REVIEWED_REJECTED_DATE = ZonedDateTime.ofInstant(
        Instant.ofEpochMilli(0L),
        ZoneOffset.UTC
    );
    private static final ZonedDateTime UPDATED_SECOND_PLEDGE_REVIEWED_REJECTED_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    private static final String DEFAULT_FIRST_FIDUCARY_REVIEWER_ACCEPT = "AAAAAAAAAA";
    private static final String UPDATED_FIRST_FIDUCARY_REVIEWER_ACCEPT = "BBBBBBBBBB";

    private static final ZonedDateTime DEFAULT_FIRST_FIDUCARY_REVIEWED_ACCEPT_DATE = ZonedDateTime.ofInstant(
        Instant.ofEpochMilli(0L),
        ZoneOffset.UTC
    );
    private static final ZonedDateTime UPDATED_FIRST_FIDUCARY_REVIEWED_ACCEPT_DATE = ZonedDateTime.now(ZoneId.systemDefault()).withNano(0);

    private static final String DEFAULT_FIRST_FIDUCARY_REVIEWER_REJECT = "AAAAAAAAAA";
    private static final String UPDATED_FIRST_FIDUCARY_REVIEWER_REJECT = "BBBBBBBBBB";

    private static final String DEFAULT_FIRST_FIDUCARY_REVIEWER_REJECT_REASON = "AAAAAAAAAA";
    private static final String UPDATED_FIRST_FIDUCARY_REVIEWER_REJECT_REASON = "BBBBBBBBBB";

    private static final ZonedDateTime DEFAULT_FIRST_FIDUCARY_REVIEWED_REJECTED_DATE = ZonedDateTime.ofInstant(
        Instant.ofEpochMilli(0L),
        ZoneOffset.UTC
    );
    private static final ZonedDateTime UPDATED_FIRST_FIDUCARY_REVIEWED_REJECTED_DATE = ZonedDateTime
        .now(ZoneId.systemDefault())
        .withNano(0);

    private static final String DEFAULT_SECOND_FIDUCARY_REVIEWER_ACCEPT = "AAAAAAAAAA";
    private static final String UPDATED_SECOND_FIDUCARY_REVIEWER_ACCEPT = "BBBBBBBBBB";

    private static final ZonedDateTime DEFAULT_SECOND_P_FIDUCARY_REVIEWED_ACCEPT_DATE = ZonedDateTime.ofInstant(
        Instant.ofEpochMilli(0L),
        ZoneOffset.UTC
    );
    private static final ZonedDateTime UPDATED_SECOND_P_FIDUCARY_REVIEWED_ACCEPT_DATE = ZonedDateTime
        .now(ZoneId.systemDefault())
        .withNano(0);

    private static final String DEFAULT_SECOND_FIDUCARY_REVIEWER_REJECT = "AAAAAAAAAA";
    private static final String UPDATED_SECOND_FIDUCARY_REVIEWER_REJECT = "BBBBBBBBBB";

    private static final String DEFAULT_SECOND_FIDUCARY_REVIEWER_REJECT_REASON = "AAAAAAAAAA";
    private static final String UPDATED_SECOND_FIDUCARY_REVIEWER_REJECT_REASON = "BBBBBBBBBB";

    private static final ZonedDateTime DEFAULT_SECOND_FIDUCARY_REVIEWED_REJECTED_DATE = ZonedDateTime.ofInstant(
        Instant.ofEpochMilli(0L),
        ZoneOffset.UTC
    );
    private static final ZonedDateTime UPDATED_SECOND_FIDUCARY_REVIEWED_REJECTED_DATE = ZonedDateTime
        .now(ZoneId.systemDefault())
        .withNano(0);

    private static final String DEFAULT_FIRST_OVER_DRAFT_REVIEWER_ACCEPT = "AAAAAAAAAA";
    private static final String UPDATED_FIRST_OVER_DRAFT_REVIEWER_ACCEPT = "BBBBBBBBBB";

    private static final ZonedDateTime DEFAULT_FIRST_OVER_DRAFT_REVIEWED_ACCEPT_DATE = ZonedDateTime.ofInstant(
        Instant.ofEpochMilli(0L),
        ZoneOffset.UTC
    );
    private static final ZonedDateTime UPDATED_FIRST_OVER_DRAFT_REVIEWED_ACCEPT_DATE = ZonedDateTime
        .now(ZoneId.systemDefault())
        .withNano(0);

    private static final String DEFAULT_FIRST_OVER_DRAFT_REVIEWER_REJECT = "AAAAAAAAAA";
    private static final String UPDATED_FIRST_OVER_DRAFT_REVIEWER_REJECT = "BBBBBBBBBB";

    private static final String DEFAULT_FIRST_OVER_DRAFT_REVIEWER_REJECT_REASON = "AAAAAAAAAA";
    private static final String UPDATED_FIRST_OVER_DRAFT_REVIEWER_REJECT_REASON = "BBBBBBBBBB";

    private static final ZonedDateTime DEFAULT_FIRST_OVER_DRAFT_REVIEWED_REJECTED_DATE = ZonedDateTime.ofInstant(
        Instant.ofEpochMilli(0L),
        ZoneOffset.UTC
    );
    private static final ZonedDateTime UPDATED_FIRST_OVER_DRAFT_REVIEWED_REJECTED_DATE = ZonedDateTime
        .now(ZoneId.systemDefault())
        .withNano(0);

    private static final String DEFAULT_SECOND_OVER_DRAFT_REVIEWER_ACCEPT = "AAAAAAAAAA";
    private static final String UPDATED_SECOND_OVER_DRAFT_REVIEWER_ACCEPT = "BBBBBBBBBB";

    private static final ZonedDateTime DEFAULT_SECOND_OVER_DRAFT_REVIEWED_ACCEPT_DATE = ZonedDateTime.ofInstant(
        Instant.ofEpochMilli(0L),
        ZoneOffset.UTC
    );
    private static final ZonedDateTime UPDATED_SECOND_OVER_DRAFT_REVIEWED_ACCEPT_DATE = ZonedDateTime
        .now(ZoneId.systemDefault())
        .withNano(0);

    private static final String DEFAULT_SECOND_OVER_DRAFT_REVIEWER_REJECT = "AAAAAAAAAA";
    private static final String UPDATED_SECOND_OVER_DRAFT_REVIEWER_REJECT = "BBBBBBBBBB";

    private static final String DEFAULT_SECOND_OVER_DRAFT_REVIEWER_REJECT_REASON = "AAAAAAAAAA";
    private static final String UPDATED_SECOND_OVER_DRAFT_REVIEWER_REJECT_REASON = "BBBBBBBBBB";

    private static final ZonedDateTime DEFAULT_SECOND_OVER_DRAFT_REVIEWED_REJECTED_DATE = ZonedDateTime.ofInstant(
        Instant.ofEpochMilli(0L),
        ZoneOffset.UTC
    );
    private static final ZonedDateTime UPDATED_SECOND_OVER_DRAFT_REVIEWED_REJECTED_DATE = ZonedDateTime
        .now(ZoneId.systemDefault())
        .withNano(0);

    private static final String ENTITY_API_URL = "/api/transaction-reviews";
    private static final String ENTITY_API_URL_ID = ENTITY_API_URL + "/{id}";

    private static Random random = new Random();
    private static AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    @Autowired
    private TransactionReviewRepository transactionReviewRepository;

    @Autowired
    private TransactionReviewMapper transactionReviewMapper;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restTransactionReviewMockMvc;

    private TransactionReview transactionReview;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static TransactionReview createEntity(EntityManager em) {
        TransactionReview transactionReview = new TransactionReview()
            .tranId(DEFAULT_TRAN_ID)
            .firstPledgeReviewerAccept(DEFAULT_FIRST_PLEDGE_REVIEWER_ACCEPT)
            .firstPledgeReviewedAcceptDate(DEFAULT_FIRST_PLEDGE_REVIEWED_ACCEPT_DATE)
            .firstPledgeReviewerReject(DEFAULT_FIRST_PLEDGE_REVIEWER_REJECT)
            .firstPledgeReviewerRejectReason(DEFAULT_FIRST_PLEDGE_REVIEWER_REJECT_REASON)
            .firstPledgeReviewedRejectedDate(DEFAULT_FIRST_PLEDGE_REVIEWED_REJECTED_DATE)
            .secondPledgeReviewerAccept(DEFAULT_SECOND_PLEDGE_REVIEWER_ACCEPT)
            .secondPledgeReviewedAcceptDate(DEFAULT_SECOND_PLEDGE_REVIEWED_ACCEPT_DATE)
            .secondPledgeReviewerReject(DEFAULT_SECOND_PLEDGE_REVIEWER_REJECT)
            .secondPledgeReviewerRejectReason(DEFAULT_SECOND_PLEDGE_REVIEWER_REJECT_REASON)
            .secondPledgeReviewedRejectedDate(DEFAULT_SECOND_PLEDGE_REVIEWED_REJECTED_DATE)
            .firstFiducaryReviewerAccept(DEFAULT_FIRST_FIDUCARY_REVIEWER_ACCEPT)
            .firstFiducaryReviewedAcceptDate(DEFAULT_FIRST_FIDUCARY_REVIEWED_ACCEPT_DATE)
            .firstFiducaryReviewerReject(DEFAULT_FIRST_FIDUCARY_REVIEWER_REJECT)
            .firstFiducaryReviewerRejectReason(DEFAULT_FIRST_FIDUCARY_REVIEWER_REJECT_REASON)
            .firstFiducaryReviewedRejectedDate(DEFAULT_FIRST_FIDUCARY_REVIEWED_REJECTED_DATE)
            .secondFiducaryReviewerAccept(DEFAULT_SECOND_FIDUCARY_REVIEWER_ACCEPT)
            .secondPFiducaryReviewedAcceptDate(DEFAULT_SECOND_P_FIDUCARY_REVIEWED_ACCEPT_DATE)
            .secondFiducaryReviewerReject(DEFAULT_SECOND_FIDUCARY_REVIEWER_REJECT)
            .secondFiducaryReviewerRejectReason(DEFAULT_SECOND_FIDUCARY_REVIEWER_REJECT_REASON)
            .secondFiducaryReviewedRejectedDate(DEFAULT_SECOND_FIDUCARY_REVIEWED_REJECTED_DATE)
            .firstOverDraftReviewerAccept(DEFAULT_FIRST_OVER_DRAFT_REVIEWER_ACCEPT)
            .firstOverDraftReviewedAcceptDate(DEFAULT_FIRST_OVER_DRAFT_REVIEWED_ACCEPT_DATE)
            .firstOverDraftReviewerReject(DEFAULT_FIRST_OVER_DRAFT_REVIEWER_REJECT)
            .firstOverDraftReviewerRejectReason(DEFAULT_FIRST_OVER_DRAFT_REVIEWER_REJECT_REASON)
            .firstOverDraftReviewedRejectedDate(DEFAULT_FIRST_OVER_DRAFT_REVIEWED_REJECTED_DATE)
            .secondOverDraftReviewerAccept(DEFAULT_SECOND_OVER_DRAFT_REVIEWER_ACCEPT)
            .secondOverDraftReviewedAcceptDate(DEFAULT_SECOND_OVER_DRAFT_REVIEWED_ACCEPT_DATE)
            .secondOverDraftReviewerReject(DEFAULT_SECOND_OVER_DRAFT_REVIEWER_REJECT)
            .secondOverDraftReviewerRejectReason(DEFAULT_SECOND_OVER_DRAFT_REVIEWER_REJECT_REASON)
            .secondOverDraftReviewedRejectedDate(DEFAULT_SECOND_OVER_DRAFT_REVIEWED_REJECTED_DATE);
        return transactionReview;
    }

    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static TransactionReview createUpdatedEntity(EntityManager em) {
        TransactionReview transactionReview = new TransactionReview()
            .tranId(UPDATED_TRAN_ID)
            .firstPledgeReviewerAccept(UPDATED_FIRST_PLEDGE_REVIEWER_ACCEPT)
            .firstPledgeReviewedAcceptDate(UPDATED_FIRST_PLEDGE_REVIEWED_ACCEPT_DATE)
            .firstPledgeReviewerReject(UPDATED_FIRST_PLEDGE_REVIEWER_REJECT)
            .firstPledgeReviewerRejectReason(UPDATED_FIRST_PLEDGE_REVIEWER_REJECT_REASON)
            .firstPledgeReviewedRejectedDate(UPDATED_FIRST_PLEDGE_REVIEWED_REJECTED_DATE)
            .secondPledgeReviewerAccept(UPDATED_SECOND_PLEDGE_REVIEWER_ACCEPT)
            .secondPledgeReviewedAcceptDate(UPDATED_SECOND_PLEDGE_REVIEWED_ACCEPT_DATE)
            .secondPledgeReviewerReject(UPDATED_SECOND_PLEDGE_REVIEWER_REJECT)
            .secondPledgeReviewerRejectReason(UPDATED_SECOND_PLEDGE_REVIEWER_REJECT_REASON)
            .secondPledgeReviewedRejectedDate(UPDATED_SECOND_PLEDGE_REVIEWED_REJECTED_DATE)
            .firstFiducaryReviewerAccept(UPDATED_FIRST_FIDUCARY_REVIEWER_ACCEPT)
            .firstFiducaryReviewedAcceptDate(UPDATED_FIRST_FIDUCARY_REVIEWED_ACCEPT_DATE)
            .firstFiducaryReviewerReject(UPDATED_FIRST_FIDUCARY_REVIEWER_REJECT)
            .firstFiducaryReviewerRejectReason(UPDATED_FIRST_FIDUCARY_REVIEWER_REJECT_REASON)
            .firstFiducaryReviewedRejectedDate(UPDATED_FIRST_FIDUCARY_REVIEWED_REJECTED_DATE)
            .secondFiducaryReviewerAccept(UPDATED_SECOND_FIDUCARY_REVIEWER_ACCEPT)
            .secondPFiducaryReviewedAcceptDate(UPDATED_SECOND_P_FIDUCARY_REVIEWED_ACCEPT_DATE)
            .secondFiducaryReviewerReject(UPDATED_SECOND_FIDUCARY_REVIEWER_REJECT)
            .secondFiducaryReviewerRejectReason(UPDATED_SECOND_FIDUCARY_REVIEWER_REJECT_REASON)
            .secondFiducaryReviewedRejectedDate(UPDATED_SECOND_FIDUCARY_REVIEWED_REJECTED_DATE)
            .firstOverDraftReviewerAccept(UPDATED_FIRST_OVER_DRAFT_REVIEWER_ACCEPT)
            .firstOverDraftReviewedAcceptDate(UPDATED_FIRST_OVER_DRAFT_REVIEWED_ACCEPT_DATE)
            .firstOverDraftReviewerReject(UPDATED_FIRST_OVER_DRAFT_REVIEWER_REJECT)
            .firstOverDraftReviewerRejectReason(UPDATED_FIRST_OVER_DRAFT_REVIEWER_REJECT_REASON)
            .firstOverDraftReviewedRejectedDate(UPDATED_FIRST_OVER_DRAFT_REVIEWED_REJECTED_DATE)
            .secondOverDraftReviewerAccept(UPDATED_SECOND_OVER_DRAFT_REVIEWER_ACCEPT)
            .secondOverDraftReviewedAcceptDate(UPDATED_SECOND_OVER_DRAFT_REVIEWED_ACCEPT_DATE)
            .secondOverDraftReviewerReject(UPDATED_SECOND_OVER_DRAFT_REVIEWER_REJECT)
            .secondOverDraftReviewerRejectReason(UPDATED_SECOND_OVER_DRAFT_REVIEWER_REJECT_REASON)
            .secondOverDraftReviewedRejectedDate(UPDATED_SECOND_OVER_DRAFT_REVIEWED_REJECTED_DATE);
        return transactionReview;
    }

    @BeforeEach
    public void initTest() {
        transactionReview = createEntity(em);
    }

    @Test
    @Transactional
    void createTransactionReview() throws Exception {
        int databaseSizeBeforeCreate = transactionReviewRepository.findAll().size();
        // Create the TransactionReview
        TransactionReviewDTO transactionReviewDTO = transactionReviewMapper.toDto(transactionReview);
        restTransactionReviewMockMvc
            .perform(
                post(ENTITY_API_URL)
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transactionReviewDTO))
            )
            .andExpect(status().isCreated());

        // Validate the TransactionReview in the database
        List<TransactionReview> transactionReviewList = transactionReviewRepository.findAll();
        assertThat(transactionReviewList).hasSize(databaseSizeBeforeCreate + 1);
        TransactionReview testTransactionReview = transactionReviewList.get(transactionReviewList.size() - 1);
        assertThat(testTransactionReview.getTranId()).isEqualTo(DEFAULT_TRAN_ID);
        assertThat(testTransactionReview.getFirstPledgeReviewerAccept()).isEqualTo(DEFAULT_FIRST_PLEDGE_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getFirstPledgeReviewedAcceptDate()).isEqualTo(DEFAULT_FIRST_PLEDGE_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getFirstPledgeReviewerReject()).isEqualTo(DEFAULT_FIRST_PLEDGE_REVIEWER_REJECT);
        assertThat(testTransactionReview.getFirstPledgeReviewerRejectReason()).isEqualTo(DEFAULT_FIRST_PLEDGE_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getFirstPledgeReviewedRejectedDate()).isEqualTo(DEFAULT_FIRST_PLEDGE_REVIEWED_REJECTED_DATE);
        assertThat(testTransactionReview.getSecondPledgeReviewerAccept()).isEqualTo(DEFAULT_SECOND_PLEDGE_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getSecondPledgeReviewedAcceptDate()).isEqualTo(DEFAULT_SECOND_PLEDGE_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getSecondPledgeReviewerReject()).isEqualTo(DEFAULT_SECOND_PLEDGE_REVIEWER_REJECT);
        assertThat(testTransactionReview.getSecondPledgeReviewerRejectReason()).isEqualTo(DEFAULT_SECOND_PLEDGE_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getSecondPledgeReviewedRejectedDate()).isEqualTo(DEFAULT_SECOND_PLEDGE_REVIEWED_REJECTED_DATE);
        assertThat(testTransactionReview.getFirstFiducaryReviewerAccept()).isEqualTo(DEFAULT_FIRST_FIDUCARY_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getFirstFiducaryReviewedAcceptDate()).isEqualTo(DEFAULT_FIRST_FIDUCARY_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getFirstFiducaryReviewerReject()).isEqualTo(DEFAULT_FIRST_FIDUCARY_REVIEWER_REJECT);
        assertThat(testTransactionReview.getFirstFiducaryReviewerRejectReason()).isEqualTo(DEFAULT_FIRST_FIDUCARY_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getFirstFiducaryReviewedRejectedDate()).isEqualTo(DEFAULT_FIRST_FIDUCARY_REVIEWED_REJECTED_DATE);
        assertThat(testTransactionReview.getSecondFiducaryReviewerAccept()).isEqualTo(DEFAULT_SECOND_FIDUCARY_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getSecondPFiducaryReviewedAcceptDate()).isEqualTo(DEFAULT_SECOND_P_FIDUCARY_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getSecondFiducaryReviewerReject()).isEqualTo(DEFAULT_SECOND_FIDUCARY_REVIEWER_REJECT);
        assertThat(testTransactionReview.getSecondFiducaryReviewerRejectReason()).isEqualTo(DEFAULT_SECOND_FIDUCARY_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getSecondFiducaryReviewedRejectedDate()).isEqualTo(DEFAULT_SECOND_FIDUCARY_REVIEWED_REJECTED_DATE);
        assertThat(testTransactionReview.getFirstOverDraftReviewerAccept()).isEqualTo(DEFAULT_FIRST_OVER_DRAFT_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getFirstOverDraftReviewedAcceptDate()).isEqualTo(DEFAULT_FIRST_OVER_DRAFT_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getFirstOverDraftReviewerReject()).isEqualTo(DEFAULT_FIRST_OVER_DRAFT_REVIEWER_REJECT);
        assertThat(testTransactionReview.getFirstOverDraftReviewerRejectReason())
            .isEqualTo(DEFAULT_FIRST_OVER_DRAFT_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getFirstOverDraftReviewedRejectedDate())
            .isEqualTo(DEFAULT_FIRST_OVER_DRAFT_REVIEWED_REJECTED_DATE);
        assertThat(testTransactionReview.getSecondOverDraftReviewerAccept()).isEqualTo(DEFAULT_SECOND_OVER_DRAFT_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getSecondOverDraftReviewedAcceptDate()).isEqualTo(DEFAULT_SECOND_OVER_DRAFT_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getSecondOverDraftReviewerReject()).isEqualTo(DEFAULT_SECOND_OVER_DRAFT_REVIEWER_REJECT);
        assertThat(testTransactionReview.getSecondOverDraftReviewerRejectReason())
            .isEqualTo(DEFAULT_SECOND_OVER_DRAFT_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getSecondOverDraftReviewedRejectedDate())
            .isEqualTo(DEFAULT_SECOND_OVER_DRAFT_REVIEWED_REJECTED_DATE);
    }

    @Test
    @Transactional
    void createTransactionReviewWithExistingId() throws Exception {
        // Create the TransactionReview with an existing ID
        transactionReview.setId(1L);
        TransactionReviewDTO transactionReviewDTO = transactionReviewMapper.toDto(transactionReview);

        int databaseSizeBeforeCreate = transactionReviewRepository.findAll().size();

        // An entity with an existing ID cannot be created, so this API call must fail
        restTransactionReviewMockMvc
            .perform(
                post(ENTITY_API_URL)
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transactionReviewDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransactionReview in the database
        List<TransactionReview> transactionReviewList = transactionReviewRepository.findAll();
        assertThat(transactionReviewList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    void checkTranIdIsRequired() throws Exception {
        int databaseSizeBeforeTest = transactionReviewRepository.findAll().size();
        // set the field null
        transactionReview.setTranId(null);

        // Create the TransactionReview, which fails.
        TransactionReviewDTO transactionReviewDTO = transactionReviewMapper.toDto(transactionReview);

        restTransactionReviewMockMvc
            .perform(
                post(ENTITY_API_URL)
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transactionReviewDTO))
            )
            .andExpect(status().isBadRequest());

        List<TransactionReview> transactionReviewList = transactionReviewRepository.findAll();
        assertThat(transactionReviewList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void getAllTransactionReviews() throws Exception {
        // Initialize the database
        transactionReviewRepository.saveAndFlush(transactionReview);

        // Get all the transactionReviewList
        restTransactionReviewMockMvc
            .perform(get(ENTITY_API_URL + "?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(transactionReview.getId().intValue())))
            .andExpect(jsonPath("$.[*].tranId").value(hasItem(DEFAULT_TRAN_ID.intValue())))
            .andExpect(jsonPath("$.[*].firstPledgeReviewerAccept").value(hasItem(DEFAULT_FIRST_PLEDGE_REVIEWER_ACCEPT)))
            .andExpect(
                jsonPath("$.[*].firstPledgeReviewedAcceptDate").value(hasItem(sameInstant(DEFAULT_FIRST_PLEDGE_REVIEWED_ACCEPT_DATE)))
            )
            .andExpect(jsonPath("$.[*].firstPledgeReviewerReject").value(hasItem(DEFAULT_FIRST_PLEDGE_REVIEWER_REJECT)))
            .andExpect(jsonPath("$.[*].firstPledgeReviewerRejectReason").value(hasItem(DEFAULT_FIRST_PLEDGE_REVIEWER_REJECT_REASON)))
            .andExpect(
                jsonPath("$.[*].firstPledgeReviewedRejectedDate").value(hasItem(sameInstant(DEFAULT_FIRST_PLEDGE_REVIEWED_REJECTED_DATE)))
            )
            .andExpect(jsonPath("$.[*].secondPledgeReviewerAccept").value(hasItem(DEFAULT_SECOND_PLEDGE_REVIEWER_ACCEPT)))
            .andExpect(
                jsonPath("$.[*].secondPledgeReviewedAcceptDate").value(hasItem(sameInstant(DEFAULT_SECOND_PLEDGE_REVIEWED_ACCEPT_DATE)))
            )
            .andExpect(jsonPath("$.[*].secondPledgeReviewerReject").value(hasItem(DEFAULT_SECOND_PLEDGE_REVIEWER_REJECT)))
            .andExpect(jsonPath("$.[*].secondPledgeReviewerRejectReason").value(hasItem(DEFAULT_SECOND_PLEDGE_REVIEWER_REJECT_REASON)))
            .andExpect(
                jsonPath("$.[*].secondPledgeReviewedRejectedDate").value(hasItem(sameInstant(DEFAULT_SECOND_PLEDGE_REVIEWED_REJECTED_DATE)))
            )
            .andExpect(jsonPath("$.[*].firstFiducaryReviewerAccept").value(hasItem(DEFAULT_FIRST_FIDUCARY_REVIEWER_ACCEPT)))
            .andExpect(
                jsonPath("$.[*].firstFiducaryReviewedAcceptDate").value(hasItem(sameInstant(DEFAULT_FIRST_FIDUCARY_REVIEWED_ACCEPT_DATE)))
            )
            .andExpect(jsonPath("$.[*].firstFiducaryReviewerReject").value(hasItem(DEFAULT_FIRST_FIDUCARY_REVIEWER_REJECT)))
            .andExpect(jsonPath("$.[*].firstFiducaryReviewerRejectReason").value(hasItem(DEFAULT_FIRST_FIDUCARY_REVIEWER_REJECT_REASON)))
            .andExpect(
                jsonPath("$.[*].firstFiducaryReviewedRejectedDate")
                    .value(hasItem(sameInstant(DEFAULT_FIRST_FIDUCARY_REVIEWED_REJECTED_DATE)))
            )
            .andExpect(jsonPath("$.[*].secondFiducaryReviewerAccept").value(hasItem(DEFAULT_SECOND_FIDUCARY_REVIEWER_ACCEPT)))
            .andExpect(
                jsonPath("$.[*].secondPFiducaryReviewedAcceptDate")
                    .value(hasItem(sameInstant(DEFAULT_SECOND_P_FIDUCARY_REVIEWED_ACCEPT_DATE)))
            )
            .andExpect(jsonPath("$.[*].secondFiducaryReviewerReject").value(hasItem(DEFAULT_SECOND_FIDUCARY_REVIEWER_REJECT)))
            .andExpect(jsonPath("$.[*].secondFiducaryReviewerRejectReason").value(hasItem(DEFAULT_SECOND_FIDUCARY_REVIEWER_REJECT_REASON)))
            .andExpect(
                jsonPath("$.[*].secondFiducaryReviewedRejectedDate")
                    .value(hasItem(sameInstant(DEFAULT_SECOND_FIDUCARY_REVIEWED_REJECTED_DATE)))
            )
            .andExpect(jsonPath("$.[*].firstOverDraftReviewerAccept").value(hasItem(DEFAULT_FIRST_OVER_DRAFT_REVIEWER_ACCEPT)))
            .andExpect(
                jsonPath("$.[*].firstOverDraftReviewedAcceptDate")
                    .value(hasItem(sameInstant(DEFAULT_FIRST_OVER_DRAFT_REVIEWED_ACCEPT_DATE)))
            )
            .andExpect(jsonPath("$.[*].firstOverDraftReviewerReject").value(hasItem(DEFAULT_FIRST_OVER_DRAFT_REVIEWER_REJECT)))
            .andExpect(jsonPath("$.[*].firstOverDraftReviewerRejectReason").value(hasItem(DEFAULT_FIRST_OVER_DRAFT_REVIEWER_REJECT_REASON)))
            .andExpect(
                jsonPath("$.[*].firstOverDraftReviewedRejectedDate")
                    .value(hasItem(sameInstant(DEFAULT_FIRST_OVER_DRAFT_REVIEWED_REJECTED_DATE)))
            )
            .andExpect(jsonPath("$.[*].secondOverDraftReviewerAccept").value(hasItem(DEFAULT_SECOND_OVER_DRAFT_REVIEWER_ACCEPT)))
            .andExpect(
                jsonPath("$.[*].secondOverDraftReviewedAcceptDate")
                    .value(hasItem(sameInstant(DEFAULT_SECOND_OVER_DRAFT_REVIEWED_ACCEPT_DATE)))
            )
            .andExpect(jsonPath("$.[*].secondOverDraftReviewerReject").value(hasItem(DEFAULT_SECOND_OVER_DRAFT_REVIEWER_REJECT)))
            .andExpect(
                jsonPath("$.[*].secondOverDraftReviewerRejectReason").value(hasItem(DEFAULT_SECOND_OVER_DRAFT_REVIEWER_REJECT_REASON))
            )
            .andExpect(
                jsonPath("$.[*].secondOverDraftReviewedRejectedDate")
                    .value(hasItem(sameInstant(DEFAULT_SECOND_OVER_DRAFT_REVIEWED_REJECTED_DATE)))
            );
    }

    @Test
    @Transactional
    void getTransactionReview() throws Exception {
        // Initialize the database
        transactionReviewRepository.saveAndFlush(transactionReview);

        // Get the transactionReview
        restTransactionReviewMockMvc
            .perform(get(ENTITY_API_URL_ID, transactionReview.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(transactionReview.getId().intValue()))
            .andExpect(jsonPath("$.tranId").value(DEFAULT_TRAN_ID.intValue()))
            .andExpect(jsonPath("$.firstPledgeReviewerAccept").value(DEFAULT_FIRST_PLEDGE_REVIEWER_ACCEPT))
            .andExpect(jsonPath("$.firstPledgeReviewedAcceptDate").value(sameInstant(DEFAULT_FIRST_PLEDGE_REVIEWED_ACCEPT_DATE)))
            .andExpect(jsonPath("$.firstPledgeReviewerReject").value(DEFAULT_FIRST_PLEDGE_REVIEWER_REJECT))
            .andExpect(jsonPath("$.firstPledgeReviewerRejectReason").value(DEFAULT_FIRST_PLEDGE_REVIEWER_REJECT_REASON))
            .andExpect(jsonPath("$.firstPledgeReviewedRejectedDate").value(sameInstant(DEFAULT_FIRST_PLEDGE_REVIEWED_REJECTED_DATE)))
            .andExpect(jsonPath("$.secondPledgeReviewerAccept").value(DEFAULT_SECOND_PLEDGE_REVIEWER_ACCEPT))
            .andExpect(jsonPath("$.secondPledgeReviewedAcceptDate").value(sameInstant(DEFAULT_SECOND_PLEDGE_REVIEWED_ACCEPT_DATE)))
            .andExpect(jsonPath("$.secondPledgeReviewerReject").value(DEFAULT_SECOND_PLEDGE_REVIEWER_REJECT))
            .andExpect(jsonPath("$.secondPledgeReviewerRejectReason").value(DEFAULT_SECOND_PLEDGE_REVIEWER_REJECT_REASON))
            .andExpect(jsonPath("$.secondPledgeReviewedRejectedDate").value(sameInstant(DEFAULT_SECOND_PLEDGE_REVIEWED_REJECTED_DATE)))
            .andExpect(jsonPath("$.firstFiducaryReviewerAccept").value(DEFAULT_FIRST_FIDUCARY_REVIEWER_ACCEPT))
            .andExpect(jsonPath("$.firstFiducaryReviewedAcceptDate").value(sameInstant(DEFAULT_FIRST_FIDUCARY_REVIEWED_ACCEPT_DATE)))
            .andExpect(jsonPath("$.firstFiducaryReviewerReject").value(DEFAULT_FIRST_FIDUCARY_REVIEWER_REJECT))
            .andExpect(jsonPath("$.firstFiducaryReviewerRejectReason").value(DEFAULT_FIRST_FIDUCARY_REVIEWER_REJECT_REASON))
            .andExpect(jsonPath("$.firstFiducaryReviewedRejectedDate").value(sameInstant(DEFAULT_FIRST_FIDUCARY_REVIEWED_REJECTED_DATE)))
            .andExpect(jsonPath("$.secondFiducaryReviewerAccept").value(DEFAULT_SECOND_FIDUCARY_REVIEWER_ACCEPT))
            .andExpect(jsonPath("$.secondPFiducaryReviewedAcceptDate").value(sameInstant(DEFAULT_SECOND_P_FIDUCARY_REVIEWED_ACCEPT_DATE)))
            .andExpect(jsonPath("$.secondFiducaryReviewerReject").value(DEFAULT_SECOND_FIDUCARY_REVIEWER_REJECT))
            .andExpect(jsonPath("$.secondFiducaryReviewerRejectReason").value(DEFAULT_SECOND_FIDUCARY_REVIEWER_REJECT_REASON))
            .andExpect(jsonPath("$.secondFiducaryReviewedRejectedDate").value(sameInstant(DEFAULT_SECOND_FIDUCARY_REVIEWED_REJECTED_DATE)))
            .andExpect(jsonPath("$.firstOverDraftReviewerAccept").value(DEFAULT_FIRST_OVER_DRAFT_REVIEWER_ACCEPT))
            .andExpect(jsonPath("$.firstOverDraftReviewedAcceptDate").value(sameInstant(DEFAULT_FIRST_OVER_DRAFT_REVIEWED_ACCEPT_DATE)))
            .andExpect(jsonPath("$.firstOverDraftReviewerReject").value(DEFAULT_FIRST_OVER_DRAFT_REVIEWER_REJECT))
            .andExpect(jsonPath("$.firstOverDraftReviewerRejectReason").value(DEFAULT_FIRST_OVER_DRAFT_REVIEWER_REJECT_REASON))
            .andExpect(jsonPath("$.firstOverDraftReviewedRejectedDate").value(sameInstant(DEFAULT_FIRST_OVER_DRAFT_REVIEWED_REJECTED_DATE)))
            .andExpect(jsonPath("$.secondOverDraftReviewerAccept").value(DEFAULT_SECOND_OVER_DRAFT_REVIEWER_ACCEPT))
            .andExpect(jsonPath("$.secondOverDraftReviewedAcceptDate").value(sameInstant(DEFAULT_SECOND_OVER_DRAFT_REVIEWED_ACCEPT_DATE)))
            .andExpect(jsonPath("$.secondOverDraftReviewerReject").value(DEFAULT_SECOND_OVER_DRAFT_REVIEWER_REJECT))
            .andExpect(jsonPath("$.secondOverDraftReviewerRejectReason").value(DEFAULT_SECOND_OVER_DRAFT_REVIEWER_REJECT_REASON))
            .andExpect(
                jsonPath("$.secondOverDraftReviewedRejectedDate").value(sameInstant(DEFAULT_SECOND_OVER_DRAFT_REVIEWED_REJECTED_DATE))
            );
    }

    @Test
    @Transactional
    void getNonExistingTransactionReview() throws Exception {
        // Get the transactionReview
        restTransactionReviewMockMvc.perform(get(ENTITY_API_URL_ID, Long.MAX_VALUE)).andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    void putExistingTransactionReview() throws Exception {
        // Initialize the database
        transactionReviewRepository.saveAndFlush(transactionReview);

        int databaseSizeBeforeUpdate = transactionReviewRepository.findAll().size();

        // Update the transactionReview
        TransactionReview updatedTransactionReview = transactionReviewRepository.findById(transactionReview.getId()).orElseThrow();
        // Disconnect from session so that the updates on updatedTransactionReview are not directly saved in db
        em.detach(updatedTransactionReview);
        updatedTransactionReview
            .tranId(UPDATED_TRAN_ID)
            .firstPledgeReviewerAccept(UPDATED_FIRST_PLEDGE_REVIEWER_ACCEPT)
            .firstPledgeReviewedAcceptDate(UPDATED_FIRST_PLEDGE_REVIEWED_ACCEPT_DATE)
            .firstPledgeReviewerReject(UPDATED_FIRST_PLEDGE_REVIEWER_REJECT)
            .firstPledgeReviewerRejectReason(UPDATED_FIRST_PLEDGE_REVIEWER_REJECT_REASON)
            .firstPledgeReviewedRejectedDate(UPDATED_FIRST_PLEDGE_REVIEWED_REJECTED_DATE)
            .secondPledgeReviewerAccept(UPDATED_SECOND_PLEDGE_REVIEWER_ACCEPT)
            .secondPledgeReviewedAcceptDate(UPDATED_SECOND_PLEDGE_REVIEWED_ACCEPT_DATE)
            .secondPledgeReviewerReject(UPDATED_SECOND_PLEDGE_REVIEWER_REJECT)
            .secondPledgeReviewerRejectReason(UPDATED_SECOND_PLEDGE_REVIEWER_REJECT_REASON)
            .secondPledgeReviewedRejectedDate(UPDATED_SECOND_PLEDGE_REVIEWED_REJECTED_DATE)
            .firstFiducaryReviewerAccept(UPDATED_FIRST_FIDUCARY_REVIEWER_ACCEPT)
            .firstFiducaryReviewedAcceptDate(UPDATED_FIRST_FIDUCARY_REVIEWED_ACCEPT_DATE)
            .firstFiducaryReviewerReject(UPDATED_FIRST_FIDUCARY_REVIEWER_REJECT)
            .firstFiducaryReviewerRejectReason(UPDATED_FIRST_FIDUCARY_REVIEWER_REJECT_REASON)
            .firstFiducaryReviewedRejectedDate(UPDATED_FIRST_FIDUCARY_REVIEWED_REJECTED_DATE)
            .secondFiducaryReviewerAccept(UPDATED_SECOND_FIDUCARY_REVIEWER_ACCEPT)
            .secondPFiducaryReviewedAcceptDate(UPDATED_SECOND_P_FIDUCARY_REVIEWED_ACCEPT_DATE)
            .secondFiducaryReviewerReject(UPDATED_SECOND_FIDUCARY_REVIEWER_REJECT)
            .secondFiducaryReviewerRejectReason(UPDATED_SECOND_FIDUCARY_REVIEWER_REJECT_REASON)
            .secondFiducaryReviewedRejectedDate(UPDATED_SECOND_FIDUCARY_REVIEWED_REJECTED_DATE)
            .firstOverDraftReviewerAccept(UPDATED_FIRST_OVER_DRAFT_REVIEWER_ACCEPT)
            .firstOverDraftReviewedAcceptDate(UPDATED_FIRST_OVER_DRAFT_REVIEWED_ACCEPT_DATE)
            .firstOverDraftReviewerReject(UPDATED_FIRST_OVER_DRAFT_REVIEWER_REJECT)
            .firstOverDraftReviewerRejectReason(UPDATED_FIRST_OVER_DRAFT_REVIEWER_REJECT_REASON)
            .firstOverDraftReviewedRejectedDate(UPDATED_FIRST_OVER_DRAFT_REVIEWED_REJECTED_DATE)
            .secondOverDraftReviewerAccept(UPDATED_SECOND_OVER_DRAFT_REVIEWER_ACCEPT)
            .secondOverDraftReviewedAcceptDate(UPDATED_SECOND_OVER_DRAFT_REVIEWED_ACCEPT_DATE)
            .secondOverDraftReviewerReject(UPDATED_SECOND_OVER_DRAFT_REVIEWER_REJECT)
            .secondOverDraftReviewerRejectReason(UPDATED_SECOND_OVER_DRAFT_REVIEWER_REJECT_REASON)
            .secondOverDraftReviewedRejectedDate(UPDATED_SECOND_OVER_DRAFT_REVIEWED_REJECTED_DATE);
        TransactionReviewDTO transactionReviewDTO = transactionReviewMapper.toDto(updatedTransactionReview);

        restTransactionReviewMockMvc
            .perform(
                put(ENTITY_API_URL_ID, transactionReviewDTO.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transactionReviewDTO))
            )
            .andExpect(status().isOk());

        // Validate the TransactionReview in the database
        List<TransactionReview> transactionReviewList = transactionReviewRepository.findAll();
        assertThat(transactionReviewList).hasSize(databaseSizeBeforeUpdate);
        TransactionReview testTransactionReview = transactionReviewList.get(transactionReviewList.size() - 1);
        assertThat(testTransactionReview.getTranId()).isEqualTo(UPDATED_TRAN_ID);
        assertThat(testTransactionReview.getFirstPledgeReviewerAccept()).isEqualTo(UPDATED_FIRST_PLEDGE_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getFirstPledgeReviewedAcceptDate()).isEqualTo(UPDATED_FIRST_PLEDGE_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getFirstPledgeReviewerReject()).isEqualTo(UPDATED_FIRST_PLEDGE_REVIEWER_REJECT);
        assertThat(testTransactionReview.getFirstPledgeReviewerRejectReason()).isEqualTo(UPDATED_FIRST_PLEDGE_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getFirstPledgeReviewedRejectedDate()).isEqualTo(UPDATED_FIRST_PLEDGE_REVIEWED_REJECTED_DATE);
        assertThat(testTransactionReview.getSecondPledgeReviewerAccept()).isEqualTo(UPDATED_SECOND_PLEDGE_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getSecondPledgeReviewedAcceptDate()).isEqualTo(UPDATED_SECOND_PLEDGE_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getSecondPledgeReviewerReject()).isEqualTo(UPDATED_SECOND_PLEDGE_REVIEWER_REJECT);
        assertThat(testTransactionReview.getSecondPledgeReviewerRejectReason()).isEqualTo(UPDATED_SECOND_PLEDGE_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getSecondPledgeReviewedRejectedDate()).isEqualTo(UPDATED_SECOND_PLEDGE_REVIEWED_REJECTED_DATE);
        assertThat(testTransactionReview.getFirstFiducaryReviewerAccept()).isEqualTo(UPDATED_FIRST_FIDUCARY_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getFirstFiducaryReviewedAcceptDate()).isEqualTo(UPDATED_FIRST_FIDUCARY_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getFirstFiducaryReviewerReject()).isEqualTo(UPDATED_FIRST_FIDUCARY_REVIEWER_REJECT);
        assertThat(testTransactionReview.getFirstFiducaryReviewerRejectReason()).isEqualTo(UPDATED_FIRST_FIDUCARY_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getFirstFiducaryReviewedRejectedDate()).isEqualTo(UPDATED_FIRST_FIDUCARY_REVIEWED_REJECTED_DATE);
        assertThat(testTransactionReview.getSecondFiducaryReviewerAccept()).isEqualTo(UPDATED_SECOND_FIDUCARY_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getSecondPFiducaryReviewedAcceptDate()).isEqualTo(UPDATED_SECOND_P_FIDUCARY_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getSecondFiducaryReviewerReject()).isEqualTo(UPDATED_SECOND_FIDUCARY_REVIEWER_REJECT);
        assertThat(testTransactionReview.getSecondFiducaryReviewerRejectReason()).isEqualTo(UPDATED_SECOND_FIDUCARY_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getSecondFiducaryReviewedRejectedDate()).isEqualTo(UPDATED_SECOND_FIDUCARY_REVIEWED_REJECTED_DATE);
        assertThat(testTransactionReview.getFirstOverDraftReviewerAccept()).isEqualTo(UPDATED_FIRST_OVER_DRAFT_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getFirstOverDraftReviewedAcceptDate()).isEqualTo(UPDATED_FIRST_OVER_DRAFT_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getFirstOverDraftReviewerReject()).isEqualTo(UPDATED_FIRST_OVER_DRAFT_REVIEWER_REJECT);
        assertThat(testTransactionReview.getFirstOverDraftReviewerRejectReason())
            .isEqualTo(UPDATED_FIRST_OVER_DRAFT_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getFirstOverDraftReviewedRejectedDate())
            .isEqualTo(UPDATED_FIRST_OVER_DRAFT_REVIEWED_REJECTED_DATE);
        assertThat(testTransactionReview.getSecondOverDraftReviewerAccept()).isEqualTo(UPDATED_SECOND_OVER_DRAFT_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getSecondOverDraftReviewedAcceptDate()).isEqualTo(UPDATED_SECOND_OVER_DRAFT_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getSecondOverDraftReviewerReject()).isEqualTo(UPDATED_SECOND_OVER_DRAFT_REVIEWER_REJECT);
        assertThat(testTransactionReview.getSecondOverDraftReviewerRejectReason())
            .isEqualTo(UPDATED_SECOND_OVER_DRAFT_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getSecondOverDraftReviewedRejectedDate())
            .isEqualTo(UPDATED_SECOND_OVER_DRAFT_REVIEWED_REJECTED_DATE);
    }

    @Test
    @Transactional
    void putNonExistingTransactionReview() throws Exception {
        int databaseSizeBeforeUpdate = transactionReviewRepository.findAll().size();
        transactionReview.setId(longCount.incrementAndGet());

        // Create the TransactionReview
        TransactionReviewDTO transactionReviewDTO = transactionReviewMapper.toDto(transactionReview);

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restTransactionReviewMockMvc
            .perform(
                put(ENTITY_API_URL_ID, transactionReviewDTO.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transactionReviewDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransactionReview in the database
        List<TransactionReview> transactionReviewList = transactionReviewRepository.findAll();
        assertThat(transactionReviewList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithIdMismatchTransactionReview() throws Exception {
        int databaseSizeBeforeUpdate = transactionReviewRepository.findAll().size();
        transactionReview.setId(longCount.incrementAndGet());

        // Create the TransactionReview
        TransactionReviewDTO transactionReviewDTO = transactionReviewMapper.toDto(transactionReview);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransactionReviewMockMvc
            .perform(
                put(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(transactionReviewDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransactionReview in the database
        List<TransactionReview> transactionReviewList = transactionReviewRepository.findAll();
        assertThat(transactionReviewList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithMissingIdPathParamTransactionReview() throws Exception {
        int databaseSizeBeforeUpdate = transactionReviewRepository.findAll().size();
        transactionReview.setId(longCount.incrementAndGet());

        // Create the TransactionReview
        TransactionReviewDTO transactionReviewDTO = transactionReviewMapper.toDto(transactionReview);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransactionReviewMockMvc
            .perform(
                put(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(transactionReviewDTO))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the TransactionReview in the database
        List<TransactionReview> transactionReviewList = transactionReviewRepository.findAll();
        assertThat(transactionReviewList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void partialUpdateTransactionReviewWithPatch() throws Exception {
        // Initialize the database
        transactionReviewRepository.saveAndFlush(transactionReview);

        int databaseSizeBeforeUpdate = transactionReviewRepository.findAll().size();

        // Update the transactionReview using partial update
        TransactionReview partialUpdatedTransactionReview = new TransactionReview();
        partialUpdatedTransactionReview.setId(transactionReview.getId());

        partialUpdatedTransactionReview
            .tranId(UPDATED_TRAN_ID)
            .firstPledgeReviewerAccept(UPDATED_FIRST_PLEDGE_REVIEWER_ACCEPT)
            .firstPledgeReviewerReject(UPDATED_FIRST_PLEDGE_REVIEWER_REJECT)
            .firstPledgeReviewerRejectReason(UPDATED_FIRST_PLEDGE_REVIEWER_REJECT_REASON)
            .firstPledgeReviewedRejectedDate(UPDATED_FIRST_PLEDGE_REVIEWED_REJECTED_DATE)
            .secondPledgeReviewerReject(UPDATED_SECOND_PLEDGE_REVIEWER_REJECT)
            .secondPledgeReviewerRejectReason(UPDATED_SECOND_PLEDGE_REVIEWER_REJECT_REASON)
            .secondPledgeReviewedRejectedDate(UPDATED_SECOND_PLEDGE_REVIEWED_REJECTED_DATE)
            .firstFiducaryReviewerAccept(UPDATED_FIRST_FIDUCARY_REVIEWER_ACCEPT)
            .firstFiducaryReviewedAcceptDate(UPDATED_FIRST_FIDUCARY_REVIEWED_ACCEPT_DATE)
            .firstFiducaryReviewerReject(UPDATED_FIRST_FIDUCARY_REVIEWER_REJECT)
            .firstFiducaryReviewedRejectedDate(UPDATED_FIRST_FIDUCARY_REVIEWED_REJECTED_DATE)
            .secondFiducaryReviewerAccept(UPDATED_SECOND_FIDUCARY_REVIEWER_ACCEPT)
            .secondPFiducaryReviewedAcceptDate(UPDATED_SECOND_P_FIDUCARY_REVIEWED_ACCEPT_DATE)
            .secondFiducaryReviewedRejectedDate(UPDATED_SECOND_FIDUCARY_REVIEWED_REJECTED_DATE)
            .firstOverDraftReviewerAccept(UPDATED_FIRST_OVER_DRAFT_REVIEWER_ACCEPT)
            .firstOverDraftReviewedAcceptDate(UPDATED_FIRST_OVER_DRAFT_REVIEWED_ACCEPT_DATE)
            .firstOverDraftReviewerReject(UPDATED_FIRST_OVER_DRAFT_REVIEWER_REJECT)
            .secondOverDraftReviewedAcceptDate(UPDATED_SECOND_OVER_DRAFT_REVIEWED_ACCEPT_DATE)
            .secondOverDraftReviewerRejectReason(UPDATED_SECOND_OVER_DRAFT_REVIEWER_REJECT_REASON);

        restTransactionReviewMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedTransactionReview.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedTransactionReview))
            )
            .andExpect(status().isOk());

        // Validate the TransactionReview in the database
        List<TransactionReview> transactionReviewList = transactionReviewRepository.findAll();
        assertThat(transactionReviewList).hasSize(databaseSizeBeforeUpdate);
        TransactionReview testTransactionReview = transactionReviewList.get(transactionReviewList.size() - 1);
        assertThat(testTransactionReview.getTranId()).isEqualTo(UPDATED_TRAN_ID);
        assertThat(testTransactionReview.getFirstPledgeReviewerAccept()).isEqualTo(UPDATED_FIRST_PLEDGE_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getFirstPledgeReviewedAcceptDate()).isEqualTo(DEFAULT_FIRST_PLEDGE_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getFirstPledgeReviewerReject()).isEqualTo(UPDATED_FIRST_PLEDGE_REVIEWER_REJECT);
        assertThat(testTransactionReview.getFirstPledgeReviewerRejectReason()).isEqualTo(UPDATED_FIRST_PLEDGE_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getFirstPledgeReviewedRejectedDate()).isEqualTo(UPDATED_FIRST_PLEDGE_REVIEWED_REJECTED_DATE);
        assertThat(testTransactionReview.getSecondPledgeReviewerAccept()).isEqualTo(DEFAULT_SECOND_PLEDGE_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getSecondPledgeReviewedAcceptDate()).isEqualTo(DEFAULT_SECOND_PLEDGE_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getSecondPledgeReviewerReject()).isEqualTo(UPDATED_SECOND_PLEDGE_REVIEWER_REJECT);
        assertThat(testTransactionReview.getSecondPledgeReviewerRejectReason()).isEqualTo(UPDATED_SECOND_PLEDGE_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getSecondPledgeReviewedRejectedDate()).isEqualTo(UPDATED_SECOND_PLEDGE_REVIEWED_REJECTED_DATE);
        assertThat(testTransactionReview.getFirstFiducaryReviewerAccept()).isEqualTo(UPDATED_FIRST_FIDUCARY_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getFirstFiducaryReviewedAcceptDate()).isEqualTo(UPDATED_FIRST_FIDUCARY_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getFirstFiducaryReviewerReject()).isEqualTo(UPDATED_FIRST_FIDUCARY_REVIEWER_REJECT);
        assertThat(testTransactionReview.getFirstFiducaryReviewerRejectReason()).isEqualTo(DEFAULT_FIRST_FIDUCARY_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getFirstFiducaryReviewedRejectedDate()).isEqualTo(UPDATED_FIRST_FIDUCARY_REVIEWED_REJECTED_DATE);
        assertThat(testTransactionReview.getSecondFiducaryReviewerAccept()).isEqualTo(UPDATED_SECOND_FIDUCARY_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getSecondPFiducaryReviewedAcceptDate()).isEqualTo(UPDATED_SECOND_P_FIDUCARY_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getSecondFiducaryReviewerReject()).isEqualTo(DEFAULT_SECOND_FIDUCARY_REVIEWER_REJECT);
        assertThat(testTransactionReview.getSecondFiducaryReviewerRejectReason()).isEqualTo(DEFAULT_SECOND_FIDUCARY_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getSecondFiducaryReviewedRejectedDate()).isEqualTo(UPDATED_SECOND_FIDUCARY_REVIEWED_REJECTED_DATE);
        assertThat(testTransactionReview.getFirstOverDraftReviewerAccept()).isEqualTo(UPDATED_FIRST_OVER_DRAFT_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getFirstOverDraftReviewedAcceptDate()).isEqualTo(UPDATED_FIRST_OVER_DRAFT_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getFirstOverDraftReviewerReject()).isEqualTo(UPDATED_FIRST_OVER_DRAFT_REVIEWER_REJECT);
        assertThat(testTransactionReview.getFirstOverDraftReviewerRejectReason())
            .isEqualTo(DEFAULT_FIRST_OVER_DRAFT_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getFirstOverDraftReviewedRejectedDate())
            .isEqualTo(DEFAULT_FIRST_OVER_DRAFT_REVIEWED_REJECTED_DATE);
        assertThat(testTransactionReview.getSecondOverDraftReviewerAccept()).isEqualTo(DEFAULT_SECOND_OVER_DRAFT_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getSecondOverDraftReviewedAcceptDate()).isEqualTo(UPDATED_SECOND_OVER_DRAFT_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getSecondOverDraftReviewerReject()).isEqualTo(DEFAULT_SECOND_OVER_DRAFT_REVIEWER_REJECT);
        assertThat(testTransactionReview.getSecondOverDraftReviewerRejectReason())
            .isEqualTo(UPDATED_SECOND_OVER_DRAFT_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getSecondOverDraftReviewedRejectedDate())
            .isEqualTo(DEFAULT_SECOND_OVER_DRAFT_REVIEWED_REJECTED_DATE);
    }

    @Test
    @Transactional
    void fullUpdateTransactionReviewWithPatch() throws Exception {
        // Initialize the database
        transactionReviewRepository.saveAndFlush(transactionReview);

        int databaseSizeBeforeUpdate = transactionReviewRepository.findAll().size();

        // Update the transactionReview using partial update
        TransactionReview partialUpdatedTransactionReview = new TransactionReview();
        partialUpdatedTransactionReview.setId(transactionReview.getId());

        partialUpdatedTransactionReview
            .tranId(UPDATED_TRAN_ID)
            .firstPledgeReviewerAccept(UPDATED_FIRST_PLEDGE_REVIEWER_ACCEPT)
            .firstPledgeReviewedAcceptDate(UPDATED_FIRST_PLEDGE_REVIEWED_ACCEPT_DATE)
            .firstPledgeReviewerReject(UPDATED_FIRST_PLEDGE_REVIEWER_REJECT)
            .firstPledgeReviewerRejectReason(UPDATED_FIRST_PLEDGE_REVIEWER_REJECT_REASON)
            .firstPledgeReviewedRejectedDate(UPDATED_FIRST_PLEDGE_REVIEWED_REJECTED_DATE)
            .secondPledgeReviewerAccept(UPDATED_SECOND_PLEDGE_REVIEWER_ACCEPT)
            .secondPledgeReviewedAcceptDate(UPDATED_SECOND_PLEDGE_REVIEWED_ACCEPT_DATE)
            .secondPledgeReviewerReject(UPDATED_SECOND_PLEDGE_REVIEWER_REJECT)
            .secondPledgeReviewerRejectReason(UPDATED_SECOND_PLEDGE_REVIEWER_REJECT_REASON)
            .secondPledgeReviewedRejectedDate(UPDATED_SECOND_PLEDGE_REVIEWED_REJECTED_DATE)
            .firstFiducaryReviewerAccept(UPDATED_FIRST_FIDUCARY_REVIEWER_ACCEPT)
            .firstFiducaryReviewedAcceptDate(UPDATED_FIRST_FIDUCARY_REVIEWED_ACCEPT_DATE)
            .firstFiducaryReviewerReject(UPDATED_FIRST_FIDUCARY_REVIEWER_REJECT)
            .firstFiducaryReviewerRejectReason(UPDATED_FIRST_FIDUCARY_REVIEWER_REJECT_REASON)
            .firstFiducaryReviewedRejectedDate(UPDATED_FIRST_FIDUCARY_REVIEWED_REJECTED_DATE)
            .secondFiducaryReviewerAccept(UPDATED_SECOND_FIDUCARY_REVIEWER_ACCEPT)
            .secondPFiducaryReviewedAcceptDate(UPDATED_SECOND_P_FIDUCARY_REVIEWED_ACCEPT_DATE)
            .secondFiducaryReviewerReject(UPDATED_SECOND_FIDUCARY_REVIEWER_REJECT)
            .secondFiducaryReviewerRejectReason(UPDATED_SECOND_FIDUCARY_REVIEWER_REJECT_REASON)
            .secondFiducaryReviewedRejectedDate(UPDATED_SECOND_FIDUCARY_REVIEWED_REJECTED_DATE)
            .firstOverDraftReviewerAccept(UPDATED_FIRST_OVER_DRAFT_REVIEWER_ACCEPT)
            .firstOverDraftReviewedAcceptDate(UPDATED_FIRST_OVER_DRAFT_REVIEWED_ACCEPT_DATE)
            .firstOverDraftReviewerReject(UPDATED_FIRST_OVER_DRAFT_REVIEWER_REJECT)
            .firstOverDraftReviewerRejectReason(UPDATED_FIRST_OVER_DRAFT_REVIEWER_REJECT_REASON)
            .firstOverDraftReviewedRejectedDate(UPDATED_FIRST_OVER_DRAFT_REVIEWED_REJECTED_DATE)
            .secondOverDraftReviewerAccept(UPDATED_SECOND_OVER_DRAFT_REVIEWER_ACCEPT)
            .secondOverDraftReviewedAcceptDate(UPDATED_SECOND_OVER_DRAFT_REVIEWED_ACCEPT_DATE)
            .secondOverDraftReviewerReject(UPDATED_SECOND_OVER_DRAFT_REVIEWER_REJECT)
            .secondOverDraftReviewerRejectReason(UPDATED_SECOND_OVER_DRAFT_REVIEWER_REJECT_REASON)
            .secondOverDraftReviewedRejectedDate(UPDATED_SECOND_OVER_DRAFT_REVIEWED_REJECTED_DATE);

        restTransactionReviewMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedTransactionReview.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedTransactionReview))
            )
            .andExpect(status().isOk());

        // Validate the TransactionReview in the database
        List<TransactionReview> transactionReviewList = transactionReviewRepository.findAll();
        assertThat(transactionReviewList).hasSize(databaseSizeBeforeUpdate);
        TransactionReview testTransactionReview = transactionReviewList.get(transactionReviewList.size() - 1);
        assertThat(testTransactionReview.getTranId()).isEqualTo(UPDATED_TRAN_ID);
        assertThat(testTransactionReview.getFirstPledgeReviewerAccept()).isEqualTo(UPDATED_FIRST_PLEDGE_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getFirstPledgeReviewedAcceptDate()).isEqualTo(UPDATED_FIRST_PLEDGE_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getFirstPledgeReviewerReject()).isEqualTo(UPDATED_FIRST_PLEDGE_REVIEWER_REJECT);
        assertThat(testTransactionReview.getFirstPledgeReviewerRejectReason()).isEqualTo(UPDATED_FIRST_PLEDGE_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getFirstPledgeReviewedRejectedDate()).isEqualTo(UPDATED_FIRST_PLEDGE_REVIEWED_REJECTED_DATE);
        assertThat(testTransactionReview.getSecondPledgeReviewerAccept()).isEqualTo(UPDATED_SECOND_PLEDGE_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getSecondPledgeReviewedAcceptDate()).isEqualTo(UPDATED_SECOND_PLEDGE_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getSecondPledgeReviewerReject()).isEqualTo(UPDATED_SECOND_PLEDGE_REVIEWER_REJECT);
        assertThat(testTransactionReview.getSecondPledgeReviewerRejectReason()).isEqualTo(UPDATED_SECOND_PLEDGE_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getSecondPledgeReviewedRejectedDate()).isEqualTo(UPDATED_SECOND_PLEDGE_REVIEWED_REJECTED_DATE);
        assertThat(testTransactionReview.getFirstFiducaryReviewerAccept()).isEqualTo(UPDATED_FIRST_FIDUCARY_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getFirstFiducaryReviewedAcceptDate()).isEqualTo(UPDATED_FIRST_FIDUCARY_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getFirstFiducaryReviewerReject()).isEqualTo(UPDATED_FIRST_FIDUCARY_REVIEWER_REJECT);
        assertThat(testTransactionReview.getFirstFiducaryReviewerRejectReason()).isEqualTo(UPDATED_FIRST_FIDUCARY_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getFirstFiducaryReviewedRejectedDate()).isEqualTo(UPDATED_FIRST_FIDUCARY_REVIEWED_REJECTED_DATE);
        assertThat(testTransactionReview.getSecondFiducaryReviewerAccept()).isEqualTo(UPDATED_SECOND_FIDUCARY_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getSecondPFiducaryReviewedAcceptDate()).isEqualTo(UPDATED_SECOND_P_FIDUCARY_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getSecondFiducaryReviewerReject()).isEqualTo(UPDATED_SECOND_FIDUCARY_REVIEWER_REJECT);
        assertThat(testTransactionReview.getSecondFiducaryReviewerRejectReason()).isEqualTo(UPDATED_SECOND_FIDUCARY_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getSecondFiducaryReviewedRejectedDate()).isEqualTo(UPDATED_SECOND_FIDUCARY_REVIEWED_REJECTED_DATE);
        assertThat(testTransactionReview.getFirstOverDraftReviewerAccept()).isEqualTo(UPDATED_FIRST_OVER_DRAFT_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getFirstOverDraftReviewedAcceptDate()).isEqualTo(UPDATED_FIRST_OVER_DRAFT_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getFirstOverDraftReviewerReject()).isEqualTo(UPDATED_FIRST_OVER_DRAFT_REVIEWER_REJECT);
        assertThat(testTransactionReview.getFirstOverDraftReviewerRejectReason())
            .isEqualTo(UPDATED_FIRST_OVER_DRAFT_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getFirstOverDraftReviewedRejectedDate())
            .isEqualTo(UPDATED_FIRST_OVER_DRAFT_REVIEWED_REJECTED_DATE);
        assertThat(testTransactionReview.getSecondOverDraftReviewerAccept()).isEqualTo(UPDATED_SECOND_OVER_DRAFT_REVIEWER_ACCEPT);
        assertThat(testTransactionReview.getSecondOverDraftReviewedAcceptDate()).isEqualTo(UPDATED_SECOND_OVER_DRAFT_REVIEWED_ACCEPT_DATE);
        assertThat(testTransactionReview.getSecondOverDraftReviewerReject()).isEqualTo(UPDATED_SECOND_OVER_DRAFT_REVIEWER_REJECT);
        assertThat(testTransactionReview.getSecondOverDraftReviewerRejectReason())
            .isEqualTo(UPDATED_SECOND_OVER_DRAFT_REVIEWER_REJECT_REASON);
        assertThat(testTransactionReview.getSecondOverDraftReviewedRejectedDate())
            .isEqualTo(UPDATED_SECOND_OVER_DRAFT_REVIEWED_REJECTED_DATE);
    }

    @Test
    @Transactional
    void patchNonExistingTransactionReview() throws Exception {
        int databaseSizeBeforeUpdate = transactionReviewRepository.findAll().size();
        transactionReview.setId(longCount.incrementAndGet());

        // Create the TransactionReview
        TransactionReviewDTO transactionReviewDTO = transactionReviewMapper.toDto(transactionReview);

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restTransactionReviewMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, transactionReviewDTO.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(transactionReviewDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransactionReview in the database
        List<TransactionReview> transactionReviewList = transactionReviewRepository.findAll();
        assertThat(transactionReviewList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithIdMismatchTransactionReview() throws Exception {
        int databaseSizeBeforeUpdate = transactionReviewRepository.findAll().size();
        transactionReview.setId(longCount.incrementAndGet());

        // Create the TransactionReview
        TransactionReviewDTO transactionReviewDTO = transactionReviewMapper.toDto(transactionReview);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransactionReviewMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(transactionReviewDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the TransactionReview in the database
        List<TransactionReview> transactionReviewList = transactionReviewRepository.findAll();
        assertThat(transactionReviewList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithMissingIdPathParamTransactionReview() throws Exception {
        int databaseSizeBeforeUpdate = transactionReviewRepository.findAll().size();
        transactionReview.setId(longCount.incrementAndGet());

        // Create the TransactionReview
        TransactionReviewDTO transactionReviewDTO = transactionReviewMapper.toDto(transactionReview);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restTransactionReviewMockMvc
            .perform(
                patch(ENTITY_API_URL)
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(transactionReviewDTO))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the TransactionReview in the database
        List<TransactionReview> transactionReviewList = transactionReviewRepository.findAll();
        assertThat(transactionReviewList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void deleteTransactionReview() throws Exception {
        // Initialize the database
        transactionReviewRepository.saveAndFlush(transactionReview);

        int databaseSizeBeforeDelete = transactionReviewRepository.findAll().size();

        // Delete the transactionReview
        restTransactionReviewMockMvc
            .perform(delete(ENTITY_API_URL_ID, transactionReview.getId()).accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<TransactionReview> transactionReviewList = transactionReviewRepository.findAll();
        assertThat(transactionReviewList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
