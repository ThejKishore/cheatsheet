package com.learn.jpa.web.rest;

import static com.learn.jpa.web.rest.TestUtil.sameNumber;
import static org.assertj.core.api.Assertions.assertThat;
import static org.hamcrest.Matchers.hasItem;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

import com.learn.jpa.IntegrationTest;
import com.learn.jpa.domain.AchFromAccnt;
import com.learn.jpa.repository.AchFromAccntRepository;
import com.learn.jpa.service.dto.AchFromAccntDTO;
import com.learn.jpa.service.mapper.AchFromAccntMapper;
import jakarta.persistence.EntityManager;
import java.math.BigDecimal;
import java.util.List;
import java.util.Random;
import java.util.concurrent.atomic.AtomicLong;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;

/**
 * Integration tests for the {@link AchFromAccntResource} REST controller.
 */
@IntegrationTest
@AutoConfigureMockMvc
@WithMockUser
class AchFromAccntResourceIT {

    private static final Long DEFAULT_FROM_ACCNT_ID = 1L;
    private static final Long UPDATED_FROM_ACCNT_ID = 2L;

    private static final Long DEFAULT_FROM_ACCNT_SK = 1L;
    private static final Long UPDATED_FROM_ACCNT_SK = 2L;

    private static final String DEFAULT_FROM_ACCNT_NAME = "AAAAAAAAAA";
    private static final String UPDATED_FROM_ACCNT_NAME = "BBBBBBBBBB";

    private static final BigDecimal DEFAULT_FROM_ACCNT_AMNT = new BigDecimal(1);
    private static final BigDecimal UPDATED_FROM_ACCNT_AMNT = new BigDecimal(2);

    private static final String ENTITY_API_URL = "/api/ach-from-accnts";
    private static final String ENTITY_API_URL_ID = ENTITY_API_URL + "/{id}";

    private static Random random = new Random();
    private static AtomicLong longCount = new AtomicLong(random.nextInt() + (2 * Integer.MAX_VALUE));

    @Autowired
    private AchFromAccntRepository achFromAccntRepository;

    @Autowired
    private AchFromAccntMapper achFromAccntMapper;

    @Autowired
    private EntityManager em;

    @Autowired
    private MockMvc restAchFromAccntMockMvc;

    private AchFromAccnt achFromAccnt;

    /**
     * Create an entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static AchFromAccnt createEntity(EntityManager em) {
        AchFromAccnt achFromAccnt = new AchFromAccnt()
            .fromAccntID(DEFAULT_FROM_ACCNT_ID)
            .fromAccntSk(DEFAULT_FROM_ACCNT_SK)
            .fromAccntName(DEFAULT_FROM_ACCNT_NAME)
            .fromAccntAmnt(DEFAULT_FROM_ACCNT_AMNT);
        return achFromAccnt;
    }

    /**
     * Create an updated entity for this test.
     *
     * This is a static method, as tests for other entities might also need it,
     * if they test an entity which requires the current entity.
     */
    public static AchFromAccnt createUpdatedEntity(EntityManager em) {
        AchFromAccnt achFromAccnt = new AchFromAccnt()
            .fromAccntID(UPDATED_FROM_ACCNT_ID)
            .fromAccntSk(UPDATED_FROM_ACCNT_SK)
            .fromAccntName(UPDATED_FROM_ACCNT_NAME)
            .fromAccntAmnt(UPDATED_FROM_ACCNT_AMNT);
        return achFromAccnt;
    }

    @BeforeEach
    public void initTest() {
        achFromAccnt = createEntity(em);
    }

    @Test
    @Transactional
    void createAchFromAccnt() throws Exception {
        int databaseSizeBeforeCreate = achFromAccntRepository.findAll().size();
        // Create the AchFromAccnt
        AchFromAccntDTO achFromAccntDTO = achFromAccntMapper.toDto(achFromAccnt);
        restAchFromAccntMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(achFromAccntDTO))
            )
            .andExpect(status().isCreated());

        // Validate the AchFromAccnt in the database
        List<AchFromAccnt> achFromAccntList = achFromAccntRepository.findAll();
        assertThat(achFromAccntList).hasSize(databaseSizeBeforeCreate + 1);
        AchFromAccnt testAchFromAccnt = achFromAccntList.get(achFromAccntList.size() - 1);
        assertThat(testAchFromAccnt.getFromAccntID()).isEqualTo(DEFAULT_FROM_ACCNT_ID);
        assertThat(testAchFromAccnt.getFromAccntSk()).isEqualTo(DEFAULT_FROM_ACCNT_SK);
        assertThat(testAchFromAccnt.getFromAccntName()).isEqualTo(DEFAULT_FROM_ACCNT_NAME);
        assertThat(testAchFromAccnt.getFromAccntAmnt()).isEqualByComparingTo(DEFAULT_FROM_ACCNT_AMNT);
    }

    @Test
    @Transactional
    void createAchFromAccntWithExistingId() throws Exception {
        // Create the AchFromAccnt with an existing ID
        achFromAccnt.setId(1L);
        AchFromAccntDTO achFromAccntDTO = achFromAccntMapper.toDto(achFromAccnt);

        int databaseSizeBeforeCreate = achFromAccntRepository.findAll().size();

        // An entity with an existing ID cannot be created, so this API call must fail
        restAchFromAccntMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(achFromAccntDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the AchFromAccnt in the database
        List<AchFromAccnt> achFromAccntList = achFromAccntRepository.findAll();
        assertThat(achFromAccntList).hasSize(databaseSizeBeforeCreate);
    }

    @Test
    @Transactional
    void checkFromAccntIDIsRequired() throws Exception {
        int databaseSizeBeforeTest = achFromAccntRepository.findAll().size();
        // set the field null
        achFromAccnt.setFromAccntID(null);

        // Create the AchFromAccnt, which fails.
        AchFromAccntDTO achFromAccntDTO = achFromAccntMapper.toDto(achFromAccnt);

        restAchFromAccntMockMvc
            .perform(
                post(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(achFromAccntDTO))
            )
            .andExpect(status().isBadRequest());

        List<AchFromAccnt> achFromAccntList = achFromAccntRepository.findAll();
        assertThat(achFromAccntList).hasSize(databaseSizeBeforeTest);
    }

    @Test
    @Transactional
    void getAllAchFromAccnts() throws Exception {
        // Initialize the database
        achFromAccntRepository.saveAndFlush(achFromAccnt);

        // Get all the achFromAccntList
        restAchFromAccntMockMvc
            .perform(get(ENTITY_API_URL + "?sort=id,desc"))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.[*].id").value(hasItem(achFromAccnt.getId().intValue())))
            .andExpect(jsonPath("$.[*].fromAccntID").value(hasItem(DEFAULT_FROM_ACCNT_ID.intValue())))
            .andExpect(jsonPath("$.[*].fromAccntSk").value(hasItem(DEFAULT_FROM_ACCNT_SK.intValue())))
            .andExpect(jsonPath("$.[*].fromAccntName").value(hasItem(DEFAULT_FROM_ACCNT_NAME)))
            .andExpect(jsonPath("$.[*].fromAccntAmnt").value(hasItem(sameNumber(DEFAULT_FROM_ACCNT_AMNT))));
    }

    @Test
    @Transactional
    void getAchFromAccnt() throws Exception {
        // Initialize the database
        achFromAccntRepository.saveAndFlush(achFromAccnt);

        // Get the achFromAccnt
        restAchFromAccntMockMvc
            .perform(get(ENTITY_API_URL_ID, achFromAccnt.getId()))
            .andExpect(status().isOk())
            .andExpect(content().contentType(MediaType.APPLICATION_JSON_VALUE))
            .andExpect(jsonPath("$.id").value(achFromAccnt.getId().intValue()))
            .andExpect(jsonPath("$.fromAccntID").value(DEFAULT_FROM_ACCNT_ID.intValue()))
            .andExpect(jsonPath("$.fromAccntSk").value(DEFAULT_FROM_ACCNT_SK.intValue()))
            .andExpect(jsonPath("$.fromAccntName").value(DEFAULT_FROM_ACCNT_NAME))
            .andExpect(jsonPath("$.fromAccntAmnt").value(sameNumber(DEFAULT_FROM_ACCNT_AMNT)));
    }

    @Test
    @Transactional
    void getNonExistingAchFromAccnt() throws Exception {
        // Get the achFromAccnt
        restAchFromAccntMockMvc.perform(get(ENTITY_API_URL_ID, Long.MAX_VALUE)).andExpect(status().isNotFound());
    }

    @Test
    @Transactional
    void putExistingAchFromAccnt() throws Exception {
        // Initialize the database
        achFromAccntRepository.saveAndFlush(achFromAccnt);

        int databaseSizeBeforeUpdate = achFromAccntRepository.findAll().size();

        // Update the achFromAccnt
        AchFromAccnt updatedAchFromAccnt = achFromAccntRepository.findById(achFromAccnt.getId()).orElseThrow();
        // Disconnect from session so that the updates on updatedAchFromAccnt are not directly saved in db
        em.detach(updatedAchFromAccnt);
        updatedAchFromAccnt
            .fromAccntID(UPDATED_FROM_ACCNT_ID)
            .fromAccntSk(UPDATED_FROM_ACCNT_SK)
            .fromAccntName(UPDATED_FROM_ACCNT_NAME)
            .fromAccntAmnt(UPDATED_FROM_ACCNT_AMNT);
        AchFromAccntDTO achFromAccntDTO = achFromAccntMapper.toDto(updatedAchFromAccnt);

        restAchFromAccntMockMvc
            .perform(
                put(ENTITY_API_URL_ID, achFromAccntDTO.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(achFromAccntDTO))
            )
            .andExpect(status().isOk());

        // Validate the AchFromAccnt in the database
        List<AchFromAccnt> achFromAccntList = achFromAccntRepository.findAll();
        assertThat(achFromAccntList).hasSize(databaseSizeBeforeUpdate);
        AchFromAccnt testAchFromAccnt = achFromAccntList.get(achFromAccntList.size() - 1);
        assertThat(testAchFromAccnt.getFromAccntID()).isEqualTo(UPDATED_FROM_ACCNT_ID);
        assertThat(testAchFromAccnt.getFromAccntSk()).isEqualTo(UPDATED_FROM_ACCNT_SK);
        assertThat(testAchFromAccnt.getFromAccntName()).isEqualTo(UPDATED_FROM_ACCNT_NAME);
        assertThat(testAchFromAccnt.getFromAccntAmnt()).isEqualByComparingTo(UPDATED_FROM_ACCNT_AMNT);
    }

    @Test
    @Transactional
    void putNonExistingAchFromAccnt() throws Exception {
        int databaseSizeBeforeUpdate = achFromAccntRepository.findAll().size();
        achFromAccnt.setId(longCount.incrementAndGet());

        // Create the AchFromAccnt
        AchFromAccntDTO achFromAccntDTO = achFromAccntMapper.toDto(achFromAccnt);

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restAchFromAccntMockMvc
            .perform(
                put(ENTITY_API_URL_ID, achFromAccntDTO.getId())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(achFromAccntDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the AchFromAccnt in the database
        List<AchFromAccnt> achFromAccntList = achFromAccntRepository.findAll();
        assertThat(achFromAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithIdMismatchAchFromAccnt() throws Exception {
        int databaseSizeBeforeUpdate = achFromAccntRepository.findAll().size();
        achFromAccnt.setId(longCount.incrementAndGet());

        // Create the AchFromAccnt
        AchFromAccntDTO achFromAccntDTO = achFromAccntMapper.toDto(achFromAccnt);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restAchFromAccntMockMvc
            .perform(
                put(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(TestUtil.convertObjectToJsonBytes(achFromAccntDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the AchFromAccnt in the database
        List<AchFromAccnt> achFromAccntList = achFromAccntRepository.findAll();
        assertThat(achFromAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void putWithMissingIdPathParamAchFromAccnt() throws Exception {
        int databaseSizeBeforeUpdate = achFromAccntRepository.findAll().size();
        achFromAccnt.setId(longCount.incrementAndGet());

        // Create the AchFromAccnt
        AchFromAccntDTO achFromAccntDTO = achFromAccntMapper.toDto(achFromAccnt);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restAchFromAccntMockMvc
            .perform(
                put(ENTITY_API_URL).contentType(MediaType.APPLICATION_JSON).content(TestUtil.convertObjectToJsonBytes(achFromAccntDTO))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the AchFromAccnt in the database
        List<AchFromAccnt> achFromAccntList = achFromAccntRepository.findAll();
        assertThat(achFromAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void partialUpdateAchFromAccntWithPatch() throws Exception {
        // Initialize the database
        achFromAccntRepository.saveAndFlush(achFromAccnt);

        int databaseSizeBeforeUpdate = achFromAccntRepository.findAll().size();

        // Update the achFromAccnt using partial update
        AchFromAccnt partialUpdatedAchFromAccnt = new AchFromAccnt();
        partialUpdatedAchFromAccnt.setId(achFromAccnt.getId());

        partialUpdatedAchFromAccnt
            .fromAccntSk(UPDATED_FROM_ACCNT_SK)
            .fromAccntName(UPDATED_FROM_ACCNT_NAME)
            .fromAccntAmnt(UPDATED_FROM_ACCNT_AMNT);

        restAchFromAccntMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedAchFromAccnt.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedAchFromAccnt))
            )
            .andExpect(status().isOk());

        // Validate the AchFromAccnt in the database
        List<AchFromAccnt> achFromAccntList = achFromAccntRepository.findAll();
        assertThat(achFromAccntList).hasSize(databaseSizeBeforeUpdate);
        AchFromAccnt testAchFromAccnt = achFromAccntList.get(achFromAccntList.size() - 1);
        assertThat(testAchFromAccnt.getFromAccntID()).isEqualTo(DEFAULT_FROM_ACCNT_ID);
        assertThat(testAchFromAccnt.getFromAccntSk()).isEqualTo(UPDATED_FROM_ACCNT_SK);
        assertThat(testAchFromAccnt.getFromAccntName()).isEqualTo(UPDATED_FROM_ACCNT_NAME);
        assertThat(testAchFromAccnt.getFromAccntAmnt()).isEqualByComparingTo(UPDATED_FROM_ACCNT_AMNT);
    }

    @Test
    @Transactional
    void fullUpdateAchFromAccntWithPatch() throws Exception {
        // Initialize the database
        achFromAccntRepository.saveAndFlush(achFromAccnt);

        int databaseSizeBeforeUpdate = achFromAccntRepository.findAll().size();

        // Update the achFromAccnt using partial update
        AchFromAccnt partialUpdatedAchFromAccnt = new AchFromAccnt();
        partialUpdatedAchFromAccnt.setId(achFromAccnt.getId());

        partialUpdatedAchFromAccnt
            .fromAccntID(UPDATED_FROM_ACCNT_ID)
            .fromAccntSk(UPDATED_FROM_ACCNT_SK)
            .fromAccntName(UPDATED_FROM_ACCNT_NAME)
            .fromAccntAmnt(UPDATED_FROM_ACCNT_AMNT);

        restAchFromAccntMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, partialUpdatedAchFromAccnt.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(partialUpdatedAchFromAccnt))
            )
            .andExpect(status().isOk());

        // Validate the AchFromAccnt in the database
        List<AchFromAccnt> achFromAccntList = achFromAccntRepository.findAll();
        assertThat(achFromAccntList).hasSize(databaseSizeBeforeUpdate);
        AchFromAccnt testAchFromAccnt = achFromAccntList.get(achFromAccntList.size() - 1);
        assertThat(testAchFromAccnt.getFromAccntID()).isEqualTo(UPDATED_FROM_ACCNT_ID);
        assertThat(testAchFromAccnt.getFromAccntSk()).isEqualTo(UPDATED_FROM_ACCNT_SK);
        assertThat(testAchFromAccnt.getFromAccntName()).isEqualTo(UPDATED_FROM_ACCNT_NAME);
        assertThat(testAchFromAccnt.getFromAccntAmnt()).isEqualByComparingTo(UPDATED_FROM_ACCNT_AMNT);
    }

    @Test
    @Transactional
    void patchNonExistingAchFromAccnt() throws Exception {
        int databaseSizeBeforeUpdate = achFromAccntRepository.findAll().size();
        achFromAccnt.setId(longCount.incrementAndGet());

        // Create the AchFromAccnt
        AchFromAccntDTO achFromAccntDTO = achFromAccntMapper.toDto(achFromAccnt);

        // If the entity doesn't have an ID, it will throw BadRequestAlertException
        restAchFromAccntMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, achFromAccntDTO.getId())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(achFromAccntDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the AchFromAccnt in the database
        List<AchFromAccnt> achFromAccntList = achFromAccntRepository.findAll();
        assertThat(achFromAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithIdMismatchAchFromAccnt() throws Exception {
        int databaseSizeBeforeUpdate = achFromAccntRepository.findAll().size();
        achFromAccnt.setId(longCount.incrementAndGet());

        // Create the AchFromAccnt
        AchFromAccntDTO achFromAccntDTO = achFromAccntMapper.toDto(achFromAccnt);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restAchFromAccntMockMvc
            .perform(
                patch(ENTITY_API_URL_ID, longCount.incrementAndGet())
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(achFromAccntDTO))
            )
            .andExpect(status().isBadRequest());

        // Validate the AchFromAccnt in the database
        List<AchFromAccnt> achFromAccntList = achFromAccntRepository.findAll();
        assertThat(achFromAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void patchWithMissingIdPathParamAchFromAccnt() throws Exception {
        int databaseSizeBeforeUpdate = achFromAccntRepository.findAll().size();
        achFromAccnt.setId(longCount.incrementAndGet());

        // Create the AchFromAccnt
        AchFromAccntDTO achFromAccntDTO = achFromAccntMapper.toDto(achFromAccnt);

        // If url ID doesn't match entity ID, it will throw BadRequestAlertException
        restAchFromAccntMockMvc
            .perform(
                patch(ENTITY_API_URL)
                    .contentType("application/merge-patch+json")
                    .content(TestUtil.convertObjectToJsonBytes(achFromAccntDTO))
            )
            .andExpect(status().isMethodNotAllowed());

        // Validate the AchFromAccnt in the database
        List<AchFromAccnt> achFromAccntList = achFromAccntRepository.findAll();
        assertThat(achFromAccntList).hasSize(databaseSizeBeforeUpdate);
    }

    @Test
    @Transactional
    void deleteAchFromAccnt() throws Exception {
        // Initialize the database
        achFromAccntRepository.saveAndFlush(achFromAccnt);

        int databaseSizeBeforeDelete = achFromAccntRepository.findAll().size();

        // Delete the achFromAccnt
        restAchFromAccntMockMvc
            .perform(delete(ENTITY_API_URL_ID, achFromAccnt.getId()).accept(MediaType.APPLICATION_JSON))
            .andExpect(status().isNoContent());

        // Validate the database contains one less item
        List<AchFromAccnt> achFromAccntList = achFromAccntRepository.findAll();
        assertThat(achFromAccntList).hasSize(databaseSizeBeforeDelete - 1);
    }
}
