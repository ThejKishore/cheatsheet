/**
 * Application management.
 */
package com.learn.jpa.management;
