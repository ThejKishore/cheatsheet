package com.learn.jpa.service.mapper;

import com.learn.jpa.domain.AchRecipient;
import com.learn.jpa.service.dto.AchRecipientDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link AchRecipient} and its DTO {@link AchRecipientDTO}.
 */
@Mapper(componentModel = "spring")
public interface AchRecipientMapper extends EntityMapper<AchRecipientDTO, AchRecipient> {}
