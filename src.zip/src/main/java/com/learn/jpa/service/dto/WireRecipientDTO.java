package com.learn.jpa.service.dto;

import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the {@link com.learn.jpa.domain.WireRecipient} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class WireRecipientDTO implements Serializable {

    private Long id;

    @NotNull
    private Long recipientId;

    private String recipeintName;

    private String recipientAddress;

    private String recipientCountry;

    private String recipientState;

    private String recipientCity;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getRecipientId() {
        return recipientId;
    }

    public void setRecipientId(Long recipientId) {
        this.recipientId = recipientId;
    }

    public String getRecipeintName() {
        return recipeintName;
    }

    public void setRecipeintName(String recipeintName) {
        this.recipeintName = recipeintName;
    }

    public String getRecipientAddress() {
        return recipientAddress;
    }

    public void setRecipientAddress(String recipientAddress) {
        this.recipientAddress = recipientAddress;
    }

    public String getRecipientCountry() {
        return recipientCountry;
    }

    public void setRecipientCountry(String recipientCountry) {
        this.recipientCountry = recipientCountry;
    }

    public String getRecipientState() {
        return recipientState;
    }

    public void setRecipientState(String recipientState) {
        this.recipientState = recipientState;
    }

    public String getRecipientCity() {
        return recipientCity;
    }

    public void setRecipientCity(String recipientCity) {
        this.recipientCity = recipientCity;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof WireRecipientDTO)) {
            return false;
        }

        WireRecipientDTO wireRecipientDTO = (WireRecipientDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, wireRecipientDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "WireRecipientDTO{" +
            "id=" + getId() +
            ", recipientId=" + getRecipientId() +
            ", recipeintName='" + getRecipeintName() + "'" +
            ", recipientAddress='" + getRecipientAddress() + "'" +
            ", recipientCountry='" + getRecipientCountry() + "'" +
            ", recipientState='" + getRecipientState() + "'" +
            ", recipientCity='" + getRecipientCity() + "'" +
            "}";
    }
}
