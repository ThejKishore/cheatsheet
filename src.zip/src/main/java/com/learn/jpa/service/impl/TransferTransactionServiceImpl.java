package com.learn.jpa.service.impl;

import com.learn.jpa.domain.TransferTransaction;
import com.learn.jpa.repository.TransferTransactionRepository;
import com.learn.jpa.service.TransferTransactionService;
import com.learn.jpa.service.dto.TransferTransactionDTO;
import com.learn.jpa.service.mapper.TransferTransactionMapper;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.TransferTransaction}.
 */
@Service
@Transactional
public class TransferTransactionServiceImpl implements TransferTransactionService {

    private final Logger log = LoggerFactory.getLogger(TransferTransactionServiceImpl.class);

    private final TransferTransactionRepository transferTransactionRepository;

    private final TransferTransactionMapper transferTransactionMapper;

    public TransferTransactionServiceImpl(
        TransferTransactionRepository transferTransactionRepository,
        TransferTransactionMapper transferTransactionMapper
    ) {
        this.transferTransactionRepository = transferTransactionRepository;
        this.transferTransactionMapper = transferTransactionMapper;
    }

    @Override
    public TransferTransactionDTO save(TransferTransactionDTO transferTransactionDTO) {
        log.debug("Request to save TransferTransaction : {}", transferTransactionDTO);
        TransferTransaction transferTransaction = transferTransactionMapper.toEntity(transferTransactionDTO);
        transferTransaction = transferTransactionRepository.save(transferTransaction);
        return transferTransactionMapper.toDto(transferTransaction);
    }

    @Override
    public TransferTransactionDTO update(TransferTransactionDTO transferTransactionDTO) {
        log.debug("Request to update TransferTransaction : {}", transferTransactionDTO);
        TransferTransaction transferTransaction = transferTransactionMapper.toEntity(transferTransactionDTO);
        transferTransaction = transferTransactionRepository.save(transferTransaction);
        return transferTransactionMapper.toDto(transferTransaction);
    }

    @Override
    public Optional<TransferTransactionDTO> partialUpdate(TransferTransactionDTO transferTransactionDTO) {
        log.debug("Request to partially update TransferTransaction : {}", transferTransactionDTO);

        return transferTransactionRepository
            .findById(transferTransactionDTO.getId())
            .map(existingTransferTransaction -> {
                transferTransactionMapper.partialUpdate(existingTransferTransaction, transferTransactionDTO);

                return existingTransferTransaction;
            })
            .map(transferTransactionRepository::save)
            .map(transferTransactionMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TransferTransactionDTO> findAll() {
        log.debug("Request to get all TransferTransactions");
        return transferTransactionRepository
            .findAll()
            .stream()
            .map(transferTransactionMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<TransferTransactionDTO> findOne(Long id) {
        log.debug("Request to get TransferTransaction : {}", id);
        return transferTransactionRepository.findById(id).map(transferTransactionMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete TransferTransaction : {}", id);
        transferTransactionRepository.deleteById(id);
    }
}
