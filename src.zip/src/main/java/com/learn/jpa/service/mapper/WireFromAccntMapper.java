package com.learn.jpa.service.mapper;

import com.learn.jpa.domain.WireFromAccnt;
import com.learn.jpa.domain.WireTransaction;
import com.learn.jpa.service.dto.WireFromAccntDTO;
import com.learn.jpa.service.dto.WireTransactionDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link WireFromAccnt} and its DTO {@link WireFromAccntDTO}.
 */
@Mapper(componentModel = "spring")
public interface WireFromAccntMapper extends EntityMapper<WireFromAccntDTO, WireFromAccnt> {
    @Mapping(target = "wireTransaction", source = "wireTransaction", qualifiedByName = "wireTransactionId")
    WireFromAccntDTO toDto(WireFromAccnt s);

    @Named("wireTransactionId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    WireTransactionDTO toDtoWireTransactionId(WireTransaction wireTransaction);
}
