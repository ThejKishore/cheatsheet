package com.learn.jpa.service.impl;

import com.learn.jpa.domain.TransactionMapping;
import com.learn.jpa.repository.TransactionMappingRepository;
import com.learn.jpa.service.TransactionMappingService;
import com.learn.jpa.service.dto.TransactionMappingDTO;
import com.learn.jpa.service.mapper.TransactionMappingMapper;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.TransactionMapping}.
 */
@Service
@Transactional
public class TransactionMappingServiceImpl implements TransactionMappingService {

    private final Logger log = LoggerFactory.getLogger(TransactionMappingServiceImpl.class);

    private final TransactionMappingRepository transactionMappingRepository;

    private final TransactionMappingMapper transactionMappingMapper;

    public TransactionMappingServiceImpl(
        TransactionMappingRepository transactionMappingRepository,
        TransactionMappingMapper transactionMappingMapper
    ) {
        this.transactionMappingRepository = transactionMappingRepository;
        this.transactionMappingMapper = transactionMappingMapper;
    }

    @Override
    public TransactionMappingDTO save(TransactionMappingDTO transactionMappingDTO) {
        log.debug("Request to save TransactionMapping : {}", transactionMappingDTO);
        TransactionMapping transactionMapping = transactionMappingMapper.toEntity(transactionMappingDTO);
        transactionMapping = transactionMappingRepository.save(transactionMapping);
        return transactionMappingMapper.toDto(transactionMapping);
    }

    @Override
    public TransactionMappingDTO update(TransactionMappingDTO transactionMappingDTO) {
        log.debug("Request to update TransactionMapping : {}", transactionMappingDTO);
        TransactionMapping transactionMapping = transactionMappingMapper.toEntity(transactionMappingDTO);
        transactionMapping = transactionMappingRepository.save(transactionMapping);
        return transactionMappingMapper.toDto(transactionMapping);
    }

    @Override
    public Optional<TransactionMappingDTO> partialUpdate(TransactionMappingDTO transactionMappingDTO) {
        log.debug("Request to partially update TransactionMapping : {}", transactionMappingDTO);

        return transactionMappingRepository
            .findById(transactionMappingDTO.getId())
            .map(existingTransactionMapping -> {
                transactionMappingMapper.partialUpdate(existingTransactionMapping, transactionMappingDTO);

                return existingTransactionMapping;
            })
            .map(transactionMappingRepository::save)
            .map(transactionMappingMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TransactionMappingDTO> findAll() {
        log.debug("Request to get all TransactionMappings");
        return transactionMappingRepository
            .findAll()
            .stream()
            .map(transactionMappingMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }

    /**
     *  Get all the transactionMappings where Transaction is {@code null}.
     *  @return the list of entities.
     */
    @Transactional(readOnly = true)
    public List<TransactionMappingDTO> findAllWhereTransactionIsNull() {
        log.debug("Request to get all transactionMappings where Transaction is null");
        return StreamSupport
            .stream(transactionMappingRepository.findAll().spliterator(), false)
            .filter(transactionMapping -> transactionMapping.getTransaction() == null)
            .map(transactionMappingMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }

    /**
     *  Get all the transactionMappings where AchTransaction is {@code null}.
     *  @return the list of entities.
     */
    @Transactional(readOnly = true)
    public List<TransactionMappingDTO> findAllWhereAchTransactionIsNull() {
        log.debug("Request to get all transactionMappings where AchTransaction is null");
        return StreamSupport
            .stream(transactionMappingRepository.findAll().spliterator(), false)
            .filter(transactionMapping -> transactionMapping.getAchTransaction() == null)
            .map(transactionMappingMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }

    /**
     *  Get all the transactionMappings where WireTransaction is {@code null}.
     *  @return the list of entities.
     */
    @Transactional(readOnly = true)
    public List<TransactionMappingDTO> findAllWhereWireTransactionIsNull() {
        log.debug("Request to get all transactionMappings where WireTransaction is null");
        return StreamSupport
            .stream(transactionMappingRepository.findAll().spliterator(), false)
            .filter(transactionMapping -> transactionMapping.getWireTransaction() == null)
            .map(transactionMappingMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }

    /**
     *  Get all the transactionMappings where TransferTransaction is {@code null}.
     *  @return the list of entities.
     */
    @Transactional(readOnly = true)
    public List<TransactionMappingDTO> findAllWhereTransferTransactionIsNull() {
        log.debug("Request to get all transactionMappings where TransferTransaction is null");
        return StreamSupport
            .stream(transactionMappingRepository.findAll().spliterator(), false)
            .filter(transactionMapping -> transactionMapping.getTransferTransaction() == null)
            .map(transactionMappingMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<TransactionMappingDTO> findOne(Long id) {
        log.debug("Request to get TransactionMapping : {}", id);
        return transactionMappingRepository.findById(id).map(transactionMappingMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete TransactionMapping : {}", id);
        transactionMappingRepository.deleteById(id);
    }
}
