package com.learn.jpa.service.impl;

import com.learn.jpa.domain.TransferToAccnt;
import com.learn.jpa.repository.TransferToAccntRepository;
import com.learn.jpa.service.TransferToAccntService;
import com.learn.jpa.service.dto.TransferToAccntDTO;
import com.learn.jpa.service.mapper.TransferToAccntMapper;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.TransferToAccnt}.
 */
@Service
@Transactional
public class TransferToAccntServiceImpl implements TransferToAccntService {

    private final Logger log = LoggerFactory.getLogger(TransferToAccntServiceImpl.class);

    private final TransferToAccntRepository transferToAccntRepository;

    private final TransferToAccntMapper transferToAccntMapper;

    public TransferToAccntServiceImpl(TransferToAccntRepository transferToAccntRepository, TransferToAccntMapper transferToAccntMapper) {
        this.transferToAccntRepository = transferToAccntRepository;
        this.transferToAccntMapper = transferToAccntMapper;
    }

    @Override
    public TransferToAccntDTO save(TransferToAccntDTO transferToAccntDTO) {
        log.debug("Request to save TransferToAccnt : {}", transferToAccntDTO);
        TransferToAccnt transferToAccnt = transferToAccntMapper.toEntity(transferToAccntDTO);
        transferToAccnt = transferToAccntRepository.save(transferToAccnt);
        return transferToAccntMapper.toDto(transferToAccnt);
    }

    @Override
    public TransferToAccntDTO update(TransferToAccntDTO transferToAccntDTO) {
        log.debug("Request to update TransferToAccnt : {}", transferToAccntDTO);
        TransferToAccnt transferToAccnt = transferToAccntMapper.toEntity(transferToAccntDTO);
        transferToAccnt = transferToAccntRepository.save(transferToAccnt);
        return transferToAccntMapper.toDto(transferToAccnt);
    }

    @Override
    public Optional<TransferToAccntDTO> partialUpdate(TransferToAccntDTO transferToAccntDTO) {
        log.debug("Request to partially update TransferToAccnt : {}", transferToAccntDTO);

        return transferToAccntRepository
            .findById(transferToAccntDTO.getId())
            .map(existingTransferToAccnt -> {
                transferToAccntMapper.partialUpdate(existingTransferToAccnt, transferToAccntDTO);

                return existingTransferToAccnt;
            })
            .map(transferToAccntRepository::save)
            .map(transferToAccntMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TransferToAccntDTO> findAll() {
        log.debug("Request to get all TransferToAccnts");
        return transferToAccntRepository
            .findAll()
            .stream()
            .map(transferToAccntMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<TransferToAccntDTO> findOne(Long id) {
        log.debug("Request to get TransferToAccnt : {}", id);
        return transferToAccntRepository.findById(id).map(transferToAccntMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete TransferToAccnt : {}", id);
        transferToAccntRepository.deleteById(id);
    }
}
