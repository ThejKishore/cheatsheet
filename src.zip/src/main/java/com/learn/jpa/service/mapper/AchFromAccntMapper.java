package com.learn.jpa.service.mapper;

import com.learn.jpa.domain.AchFromAccnt;
import com.learn.jpa.domain.AchTransaction;
import com.learn.jpa.service.dto.AchFromAccntDTO;
import com.learn.jpa.service.dto.AchTransactionDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link AchFromAccnt} and its DTO {@link AchFromAccntDTO}.
 */
@Mapper(componentModel = "spring")
public interface AchFromAccntMapper extends EntityMapper<AchFromAccntDTO, AchFromAccnt> {
    @Mapping(target = "achTransaction", source = "achTransaction", qualifiedByName = "achTransactionId")
    AchFromAccntDTO toDto(AchFromAccnt s);

    @Named("achTransactionId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    AchTransactionDTO toDtoAchTransactionId(AchTransaction achTransaction);
}
