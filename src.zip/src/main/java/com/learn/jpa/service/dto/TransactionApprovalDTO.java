package com.learn.jpa.service.dto;

import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.Objects;

/**
 * A DTO for the {@link com.learn.jpa.domain.TransactionApproval} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class TransactionApprovalDTO implements Serializable {

    private Long id;

    @NotNull
    private Long tranId;

    private String firstApprover;

    private String firstApprovalReason;

    private ZonedDateTime firstApprovalDate;

    private String firstRejector;

    private String firstRejectorReason;

    private ZonedDateTime firstRejectedDate;

    private String secondApprover;

    private String secondApprovalReason;

    private ZonedDateTime secondApprovalDate;

    private String secondRejector;

    private String secondRejectorReason;

    private ZonedDateTime secondRejectedDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getTranId() {
        return tranId;
    }

    public void setTranId(Long tranId) {
        this.tranId = tranId;
    }

    public String getFirstApprover() {
        return firstApprover;
    }

    public void setFirstApprover(String firstApprover) {
        this.firstApprover = firstApprover;
    }

    public String getFirstApprovalReason() {
        return firstApprovalReason;
    }

    public void setFirstApprovalReason(String firstApprovalReason) {
        this.firstApprovalReason = firstApprovalReason;
    }

    public ZonedDateTime getFirstApprovalDate() {
        return firstApprovalDate;
    }

    public void setFirstApprovalDate(ZonedDateTime firstApprovalDate) {
        this.firstApprovalDate = firstApprovalDate;
    }

    public String getFirstRejector() {
        return firstRejector;
    }

    public void setFirstRejector(String firstRejector) {
        this.firstRejector = firstRejector;
    }

    public String getFirstRejectorReason() {
        return firstRejectorReason;
    }

    public void setFirstRejectorReason(String firstRejectorReason) {
        this.firstRejectorReason = firstRejectorReason;
    }

    public ZonedDateTime getFirstRejectedDate() {
        return firstRejectedDate;
    }

    public void setFirstRejectedDate(ZonedDateTime firstRejectedDate) {
        this.firstRejectedDate = firstRejectedDate;
    }

    public String getSecondApprover() {
        return secondApprover;
    }

    public void setSecondApprover(String secondApprover) {
        this.secondApprover = secondApprover;
    }

    public String getSecondApprovalReason() {
        return secondApprovalReason;
    }

    public void setSecondApprovalReason(String secondApprovalReason) {
        this.secondApprovalReason = secondApprovalReason;
    }

    public ZonedDateTime getSecondApprovalDate() {
        return secondApprovalDate;
    }

    public void setSecondApprovalDate(ZonedDateTime secondApprovalDate) {
        this.secondApprovalDate = secondApprovalDate;
    }

    public String getSecondRejector() {
        return secondRejector;
    }

    public void setSecondRejector(String secondRejector) {
        this.secondRejector = secondRejector;
    }

    public String getSecondRejectorReason() {
        return secondRejectorReason;
    }

    public void setSecondRejectorReason(String secondRejectorReason) {
        this.secondRejectorReason = secondRejectorReason;
    }

    public ZonedDateTime getSecondRejectedDate() {
        return secondRejectedDate;
    }

    public void setSecondRejectedDate(ZonedDateTime secondRejectedDate) {
        this.secondRejectedDate = secondRejectedDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TransactionApprovalDTO)) {
            return false;
        }

        TransactionApprovalDTO transactionApprovalDTO = (TransactionApprovalDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, transactionApprovalDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "TransactionApprovalDTO{" +
            "id=" + getId() +
            ", tranId=" + getTranId() +
            ", firstApprover='" + getFirstApprover() + "'" +
            ", firstApprovalReason='" + getFirstApprovalReason() + "'" +
            ", firstApprovalDate='" + getFirstApprovalDate() + "'" +
            ", firstRejector='" + getFirstRejector() + "'" +
            ", firstRejectorReason='" + getFirstRejectorReason() + "'" +
            ", firstRejectedDate='" + getFirstRejectedDate() + "'" +
            ", secondApprover='" + getSecondApprover() + "'" +
            ", secondApprovalReason='" + getSecondApprovalReason() + "'" +
            ", secondApprovalDate='" + getSecondApprovalDate() + "'" +
            ", secondRejector='" + getSecondRejector() + "'" +
            ", secondRejectorReason='" + getSecondRejectorReason() + "'" +
            ", secondRejectedDate='" + getSecondRejectedDate() + "'" +
            "}";
    }
}
