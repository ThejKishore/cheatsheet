package com.learn.jpa.service;

import com.learn.jpa.service.dto.TransferFromAccntDTO;
import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing {@link com.learn.jpa.domain.TransferFromAccnt}.
 */
public interface TransferFromAccntService {
    /**
     * Save a transferFromAccnt.
     *
     * @param transferFromAccntDTO the entity to save.
     * @return the persisted entity.
     */
    TransferFromAccntDTO save(TransferFromAccntDTO transferFromAccntDTO);

    /**
     * Updates a transferFromAccnt.
     *
     * @param transferFromAccntDTO the entity to update.
     * @return the persisted entity.
     */
    TransferFromAccntDTO update(TransferFromAccntDTO transferFromAccntDTO);

    /**
     * Partially updates a transferFromAccnt.
     *
     * @param transferFromAccntDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<TransferFromAccntDTO> partialUpdate(TransferFromAccntDTO transferFromAccntDTO);

    /**
     * Get all the transferFromAccnts.
     *
     * @return the list of entities.
     */
    List<TransferFromAccntDTO> findAll();

    /**
     * Get the "id" transferFromAccnt.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<TransferFromAccntDTO> findOne(Long id);

    /**
     * Delete the "id" transferFromAccnt.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
