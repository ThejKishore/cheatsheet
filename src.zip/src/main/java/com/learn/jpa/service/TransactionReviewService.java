package com.learn.jpa.service;

import com.learn.jpa.service.dto.TransactionReviewDTO;
import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing {@link com.learn.jpa.domain.TransactionReview}.
 */
public interface TransactionReviewService {
    /**
     * Save a transactionReview.
     *
     * @param transactionReviewDTO the entity to save.
     * @return the persisted entity.
     */
    TransactionReviewDTO save(TransactionReviewDTO transactionReviewDTO);

    /**
     * Updates a transactionReview.
     *
     * @param transactionReviewDTO the entity to update.
     * @return the persisted entity.
     */
    TransactionReviewDTO update(TransactionReviewDTO transactionReviewDTO);

    /**
     * Partially updates a transactionReview.
     *
     * @param transactionReviewDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<TransactionReviewDTO> partialUpdate(TransactionReviewDTO transactionReviewDTO);

    /**
     * Get all the transactionReviews.
     *
     * @return the list of entities.
     */
    List<TransactionReviewDTO> findAll();

    /**
     * Get all the TransactionReviewDTO where Transaction is {@code null}.
     *
     * @return the {@link List} of entities.
     */
    List<TransactionReviewDTO> findAllWhereTransactionIsNull();

    /**
     * Get the "id" transactionReview.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<TransactionReviewDTO> findOne(Long id);

    /**
     * Delete the "id" transactionReview.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
