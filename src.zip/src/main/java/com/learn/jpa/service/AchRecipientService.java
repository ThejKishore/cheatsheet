package com.learn.jpa.service;

import com.learn.jpa.service.dto.AchRecipientDTO;
import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing {@link com.learn.jpa.domain.AchRecipient}.
 */
public interface AchRecipientService {
    /**
     * Save a achRecipient.
     *
     * @param achRecipientDTO the entity to save.
     * @return the persisted entity.
     */
    AchRecipientDTO save(AchRecipientDTO achRecipientDTO);

    /**
     * Updates a achRecipient.
     *
     * @param achRecipientDTO the entity to update.
     * @return the persisted entity.
     */
    AchRecipientDTO update(AchRecipientDTO achRecipientDTO);

    /**
     * Partially updates a achRecipient.
     *
     * @param achRecipientDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<AchRecipientDTO> partialUpdate(AchRecipientDTO achRecipientDTO);

    /**
     * Get all the achRecipients.
     *
     * @return the list of entities.
     */
    List<AchRecipientDTO> findAll();

    /**
     * Get all the AchRecipientDTO where AchTransaction is {@code null}.
     *
     * @return the {@link List} of entities.
     */
    List<AchRecipientDTO> findAllWhereAchTransactionIsNull();

    /**
     * Get the "id" achRecipient.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<AchRecipientDTO> findOne(Long id);

    /**
     * Delete the "id" achRecipient.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
