package com.learn.jpa.service.mapper;

import com.learn.jpa.domain.TransferToAccnt;
import com.learn.jpa.domain.TransferTransaction;
import com.learn.jpa.service.dto.TransferToAccntDTO;
import com.learn.jpa.service.dto.TransferTransactionDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link TransferToAccnt} and its DTO {@link TransferToAccntDTO}.
 */
@Mapper(componentModel = "spring")
public interface TransferToAccntMapper extends EntityMapper<TransferToAccntDTO, TransferToAccnt> {
    @Mapping(target = "transferTransaction", source = "transferTransaction", qualifiedByName = "transferTransactionId")
    TransferToAccntDTO toDto(TransferToAccnt s);

    @Named("transferTransactionId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    TransferTransactionDTO toDtoTransferTransactionId(TransferTransaction transferTransaction);
}
