package com.learn.jpa.service.impl;

import com.learn.jpa.domain.AchTransaction;
import com.learn.jpa.repository.AchTransactionRepository;
import com.learn.jpa.service.AchTransactionService;
import com.learn.jpa.service.dto.AchTransactionDTO;
import com.learn.jpa.service.mapper.AchTransactionMapper;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.AchTransaction}.
 */
@Service
@Transactional
public class AchTransactionServiceImpl implements AchTransactionService {

    private final Logger log = LoggerFactory.getLogger(AchTransactionServiceImpl.class);

    private final AchTransactionRepository achTransactionRepository;

    private final AchTransactionMapper achTransactionMapper;

    public AchTransactionServiceImpl(AchTransactionRepository achTransactionRepository, AchTransactionMapper achTransactionMapper) {
        this.achTransactionRepository = achTransactionRepository;
        this.achTransactionMapper = achTransactionMapper;
    }

    @Override
    public AchTransactionDTO save(AchTransactionDTO achTransactionDTO) {
        log.debug("Request to save AchTransaction : {}", achTransactionDTO);
        AchTransaction achTransaction = achTransactionMapper.toEntity(achTransactionDTO);
        achTransaction = achTransactionRepository.save(achTransaction);
        return achTransactionMapper.toDto(achTransaction);
    }

    @Override
    public AchTransactionDTO update(AchTransactionDTO achTransactionDTO) {
        log.debug("Request to update AchTransaction : {}", achTransactionDTO);
        AchTransaction achTransaction = achTransactionMapper.toEntity(achTransactionDTO);
        achTransaction = achTransactionRepository.save(achTransaction);
        return achTransactionMapper.toDto(achTransaction);
    }

    @Override
    public Optional<AchTransactionDTO> partialUpdate(AchTransactionDTO achTransactionDTO) {
        log.debug("Request to partially update AchTransaction : {}", achTransactionDTO);

        return achTransactionRepository
            .findById(achTransactionDTO.getId())
            .map(existingAchTransaction -> {
                achTransactionMapper.partialUpdate(existingAchTransaction, achTransactionDTO);

                return existingAchTransaction;
            })
            .map(achTransactionRepository::save)
            .map(achTransactionMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AchTransactionDTO> findAll() {
        log.debug("Request to get all AchTransactions");
        return achTransactionRepository
            .findAll()
            .stream()
            .map(achTransactionMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<AchTransactionDTO> findOne(Long id) {
        log.debug("Request to get AchTransaction : {}", id);
        return achTransactionRepository.findById(id).map(achTransactionMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete AchTransaction : {}", id);
        achTransactionRepository.deleteById(id);
    }
}
