package com.learn.jpa.service.mapper;

import com.learn.jpa.domain.AchRecipient;
import com.learn.jpa.domain.AchTransaction;
import com.learn.jpa.domain.TransactionMapping;
import com.learn.jpa.service.dto.AchRecipientDTO;
import com.learn.jpa.service.dto.AchTransactionDTO;
import com.learn.jpa.service.dto.TransactionMappingDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link AchTransaction} and its DTO {@link AchTransactionDTO}.
 */
@Mapper(componentModel = "spring")
public interface AchTransactionMapper extends EntityMapper<AchTransactionDTO, AchTransaction> {
    @Mapping(target = "transactionMapping", source = "transactionMapping", qualifiedByName = "transactionMappingId")
    @Mapping(target = "achRecipient", source = "achRecipient", qualifiedByName = "achRecipientId")
    AchTransactionDTO toDto(AchTransaction s);

    @Named("transactionMappingId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    TransactionMappingDTO toDtoTransactionMappingId(TransactionMapping transactionMapping);

    @Named("achRecipientId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    AchRecipientDTO toDtoAchRecipientId(AchRecipient achRecipient);
}
