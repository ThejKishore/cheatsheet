package com.learn.jpa.service.dto;

import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

/**
 * A DTO for the {@link com.learn.jpa.domain.TransferFromAccnt} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class TransferFromAccntDTO implements Serializable {

    private Long id;

    @NotNull
    private Long fromAccntID;

    private Long fromAccntSk;

    private String fromAccntName;

    private BigDecimal fromAccntAmnt;

    private TransferTransactionDTO transferTransaction;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getFromAccntID() {
        return fromAccntID;
    }

    public void setFromAccntID(Long fromAccntID) {
        this.fromAccntID = fromAccntID;
    }

    public Long getFromAccntSk() {
        return fromAccntSk;
    }

    public void setFromAccntSk(Long fromAccntSk) {
        this.fromAccntSk = fromAccntSk;
    }

    public String getFromAccntName() {
        return fromAccntName;
    }

    public void setFromAccntName(String fromAccntName) {
        this.fromAccntName = fromAccntName;
    }

    public BigDecimal getFromAccntAmnt() {
        return fromAccntAmnt;
    }

    public void setFromAccntAmnt(BigDecimal fromAccntAmnt) {
        this.fromAccntAmnt = fromAccntAmnt;
    }

    public TransferTransactionDTO getTransferTransaction() {
        return transferTransaction;
    }

    public void setTransferTransaction(TransferTransactionDTO transferTransaction) {
        this.transferTransaction = transferTransaction;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TransferFromAccntDTO)) {
            return false;
        }

        TransferFromAccntDTO transferFromAccntDTO = (TransferFromAccntDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, transferFromAccntDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "TransferFromAccntDTO{" +
            "id=" + getId() +
            ", fromAccntID=" + getFromAccntID() +
            ", fromAccntSk=" + getFromAccntSk() +
            ", fromAccntName='" + getFromAccntName() + "'" +
            ", fromAccntAmnt=" + getFromAccntAmnt() +
            ", transferTransaction=" + getTransferTransaction() +
            "}";
    }
}
