package com.learn.jpa.service.dto;

import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the {@link com.learn.jpa.domain.TransactionMapping} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class TransactionMappingDTO implements Serializable {

    private Long id;

    @NotNull
    private Long mappingId;

    private Long tranId;

    private Long tranTypeId;

    private String tranType;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getMappingId() {
        return mappingId;
    }

    public void setMappingId(Long mappingId) {
        this.mappingId = mappingId;
    }

    public Long getTranId() {
        return tranId;
    }

    public void setTranId(Long tranId) {
        this.tranId = tranId;
    }

    public Long getTranTypeId() {
        return tranTypeId;
    }

    public void setTranTypeId(Long tranTypeId) {
        this.tranTypeId = tranTypeId;
    }

    public String getTranType() {
        return tranType;
    }

    public void setTranType(String tranType) {
        this.tranType = tranType;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TransactionMappingDTO)) {
            return false;
        }

        TransactionMappingDTO transactionMappingDTO = (TransactionMappingDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, transactionMappingDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "TransactionMappingDTO{" +
            "id=" + getId() +
            ", mappingId=" + getMappingId() +
            ", tranId=" + getTranId() +
            ", tranTypeId=" + getTranTypeId() +
            ", tranType='" + getTranType() + "'" +
            "}";
    }
}
