package com.learn.jpa.service;

import com.learn.jpa.service.dto.TransactionMappingDTO;
import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing {@link com.learn.jpa.domain.TransactionMapping}.
 */
public interface TransactionMappingService {
    /**
     * Save a transactionMapping.
     *
     * @param transactionMappingDTO the entity to save.
     * @return the persisted entity.
     */
    TransactionMappingDTO save(TransactionMappingDTO transactionMappingDTO);

    /**
     * Updates a transactionMapping.
     *
     * @param transactionMappingDTO the entity to update.
     * @return the persisted entity.
     */
    TransactionMappingDTO update(TransactionMappingDTO transactionMappingDTO);

    /**
     * Partially updates a transactionMapping.
     *
     * @param transactionMappingDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<TransactionMappingDTO> partialUpdate(TransactionMappingDTO transactionMappingDTO);

    /**
     * Get all the transactionMappings.
     *
     * @return the list of entities.
     */
    List<TransactionMappingDTO> findAll();

    /**
     * Get all the TransactionMappingDTO where Transaction is {@code null}.
     *
     * @return the {@link List} of entities.
     */
    List<TransactionMappingDTO> findAllWhereTransactionIsNull();
    /**
     * Get all the TransactionMappingDTO where AchTransaction is {@code null}.
     *
     * @return the {@link List} of entities.
     */
    List<TransactionMappingDTO> findAllWhereAchTransactionIsNull();
    /**
     * Get all the TransactionMappingDTO where WireTransaction is {@code null}.
     *
     * @return the {@link List} of entities.
     */
    List<TransactionMappingDTO> findAllWhereWireTransactionIsNull();
    /**
     * Get all the TransactionMappingDTO where TransferTransaction is {@code null}.
     *
     * @return the {@link List} of entities.
     */
    List<TransactionMappingDTO> findAllWhereTransferTransactionIsNull();

    /**
     * Get the "id" transactionMapping.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<TransactionMappingDTO> findOne(Long id);

    /**
     * Delete the "id" transactionMapping.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
