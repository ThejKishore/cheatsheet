package com.learn.jpa.service.impl;

import com.learn.jpa.domain.WireRecipient;
import com.learn.jpa.repository.WireRecipientRepository;
import com.learn.jpa.service.WireRecipientService;
import com.learn.jpa.service.dto.WireRecipientDTO;
import com.learn.jpa.service.mapper.WireRecipientMapper;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.WireRecipient}.
 */
@Service
@Transactional
public class WireRecipientServiceImpl implements WireRecipientService {

    private final Logger log = LoggerFactory.getLogger(WireRecipientServiceImpl.class);

    private final WireRecipientRepository wireRecipientRepository;

    private final WireRecipientMapper wireRecipientMapper;

    public WireRecipientServiceImpl(WireRecipientRepository wireRecipientRepository, WireRecipientMapper wireRecipientMapper) {
        this.wireRecipientRepository = wireRecipientRepository;
        this.wireRecipientMapper = wireRecipientMapper;
    }

    @Override
    public WireRecipientDTO save(WireRecipientDTO wireRecipientDTO) {
        log.debug("Request to save WireRecipient : {}", wireRecipientDTO);
        WireRecipient wireRecipient = wireRecipientMapper.toEntity(wireRecipientDTO);
        wireRecipient = wireRecipientRepository.save(wireRecipient);
        return wireRecipientMapper.toDto(wireRecipient);
    }

    @Override
    public WireRecipientDTO update(WireRecipientDTO wireRecipientDTO) {
        log.debug("Request to update WireRecipient : {}", wireRecipientDTO);
        WireRecipient wireRecipient = wireRecipientMapper.toEntity(wireRecipientDTO);
        wireRecipient = wireRecipientRepository.save(wireRecipient);
        return wireRecipientMapper.toDto(wireRecipient);
    }

    @Override
    public Optional<WireRecipientDTO> partialUpdate(WireRecipientDTO wireRecipientDTO) {
        log.debug("Request to partially update WireRecipient : {}", wireRecipientDTO);

        return wireRecipientRepository
            .findById(wireRecipientDTO.getId())
            .map(existingWireRecipient -> {
                wireRecipientMapper.partialUpdate(existingWireRecipient, wireRecipientDTO);

                return existingWireRecipient;
            })
            .map(wireRecipientRepository::save)
            .map(wireRecipientMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public List<WireRecipientDTO> findAll() {
        log.debug("Request to get all WireRecipients");
        return wireRecipientRepository.findAll().stream().map(wireRecipientMapper::toDto).collect(Collectors.toCollection(LinkedList::new));
    }

    /**
     *  Get all the wireRecipients where WireTransaction is {@code null}.
     *  @return the list of entities.
     */
    @Transactional(readOnly = true)
    public List<WireRecipientDTO> findAllWhereWireTransactionIsNull() {
        log.debug("Request to get all wireRecipients where WireTransaction is null");
        return StreamSupport
            .stream(wireRecipientRepository.findAll().spliterator(), false)
            .filter(wireRecipient -> wireRecipient.getWireTransaction() == null)
            .map(wireRecipientMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<WireRecipientDTO> findOne(Long id) {
        log.debug("Request to get WireRecipient : {}", id);
        return wireRecipientRepository.findById(id).map(wireRecipientMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete WireRecipient : {}", id);
        wireRecipientRepository.deleteById(id);
    }
}
