package com.learn.jpa.service;

import com.learn.jpa.service.dto.TransferToAccntDTO;
import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing {@link com.learn.jpa.domain.TransferToAccnt}.
 */
public interface TransferToAccntService {
    /**
     * Save a transferToAccnt.
     *
     * @param transferToAccntDTO the entity to save.
     * @return the persisted entity.
     */
    TransferToAccntDTO save(TransferToAccntDTO transferToAccntDTO);

    /**
     * Updates a transferToAccnt.
     *
     * @param transferToAccntDTO the entity to update.
     * @return the persisted entity.
     */
    TransferToAccntDTO update(TransferToAccntDTO transferToAccntDTO);

    /**
     * Partially updates a transferToAccnt.
     *
     * @param transferToAccntDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<TransferToAccntDTO> partialUpdate(TransferToAccntDTO transferToAccntDTO);

    /**
     * Get all the transferToAccnts.
     *
     * @return the list of entities.
     */
    List<TransferToAccntDTO> findAll();

    /**
     * Get the "id" transferToAccnt.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<TransferToAccntDTO> findOne(Long id);

    /**
     * Delete the "id" transferToAccnt.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
