package com.learn.jpa.service;

import com.learn.jpa.service.dto.WireTransactionDTO;
import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing {@link com.learn.jpa.domain.WireTransaction}.
 */
public interface WireTransactionService {
    /**
     * Save a wireTransaction.
     *
     * @param wireTransactionDTO the entity to save.
     * @return the persisted entity.
     */
    WireTransactionDTO save(WireTransactionDTO wireTransactionDTO);

    /**
     * Updates a wireTransaction.
     *
     * @param wireTransactionDTO the entity to update.
     * @return the persisted entity.
     */
    WireTransactionDTO update(WireTransactionDTO wireTransactionDTO);

    /**
     * Partially updates a wireTransaction.
     *
     * @param wireTransactionDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<WireTransactionDTO> partialUpdate(WireTransactionDTO wireTransactionDTO);

    /**
     * Get all the wireTransactions.
     *
     * @return the list of entities.
     */
    List<WireTransactionDTO> findAll();

    /**
     * Get the "id" wireTransaction.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<WireTransactionDTO> findOne(Long id);

    /**
     * Delete the "id" wireTransaction.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
