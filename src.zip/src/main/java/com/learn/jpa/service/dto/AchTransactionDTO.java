package com.learn.jpa.service.dto;

import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the {@link com.learn.jpa.domain.AchTransaction} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class AchTransactionDTO implements Serializable {

    private Long id;

    @NotNull
    private Long achTranId;

    private TransactionMappingDTO transactionMapping;

    private AchRecipientDTO achRecipient;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAchTranId() {
        return achTranId;
    }

    public void setAchTranId(Long achTranId) {
        this.achTranId = achTranId;
    }

    public TransactionMappingDTO getTransactionMapping() {
        return transactionMapping;
    }

    public void setTransactionMapping(TransactionMappingDTO transactionMapping) {
        this.transactionMapping = transactionMapping;
    }

    public AchRecipientDTO getAchRecipient() {
        return achRecipient;
    }

    public void setAchRecipient(AchRecipientDTO achRecipient) {
        this.achRecipient = achRecipient;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof AchTransactionDTO)) {
            return false;
        }

        AchTransactionDTO achTransactionDTO = (AchTransactionDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, achTransactionDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "AchTransactionDTO{" +
            "id=" + getId() +
            ", achTranId=" + getAchTranId() +
            ", transactionMapping=" + getTransactionMapping() +
            ", achRecipient=" + getAchRecipient() +
            "}";
    }
}
