package com.learn.jpa.service.mapper;

import com.learn.jpa.domain.TransferFromAccnt;
import com.learn.jpa.domain.TransferTransaction;
import com.learn.jpa.service.dto.TransferFromAccntDTO;
import com.learn.jpa.service.dto.TransferTransactionDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link TransferFromAccnt} and its DTO {@link TransferFromAccntDTO}.
 */
@Mapper(componentModel = "spring")
public interface TransferFromAccntMapper extends EntityMapper<TransferFromAccntDTO, TransferFromAccnt> {
    @Mapping(target = "transferTransaction", source = "transferTransaction", qualifiedByName = "transferTransactionId")
    TransferFromAccntDTO toDto(TransferFromAccnt s);

    @Named("transferTransactionId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    TransferTransactionDTO toDtoTransferTransactionId(TransferTransaction transferTransaction);
}
