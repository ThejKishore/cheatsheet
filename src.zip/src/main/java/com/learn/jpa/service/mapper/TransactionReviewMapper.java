package com.learn.jpa.service.mapper;

import com.learn.jpa.domain.TransactionReview;
import com.learn.jpa.service.dto.TransactionReviewDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link TransactionReview} and its DTO {@link TransactionReviewDTO}.
 */
@Mapper(componentModel = "spring")
public interface TransactionReviewMapper extends EntityMapper<TransactionReviewDTO, TransactionReview> {}
