package com.learn.jpa.service;

import com.learn.jpa.service.dto.WireBeneficiaryDTO;
import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing {@link com.learn.jpa.domain.WireBeneficiary}.
 */
public interface WireBeneficiaryService {
    /**
     * Save a wireBeneficiary.
     *
     * @param wireBeneficiaryDTO the entity to save.
     * @return the persisted entity.
     */
    WireBeneficiaryDTO save(WireBeneficiaryDTO wireBeneficiaryDTO);

    /**
     * Updates a wireBeneficiary.
     *
     * @param wireBeneficiaryDTO the entity to update.
     * @return the persisted entity.
     */
    WireBeneficiaryDTO update(WireBeneficiaryDTO wireBeneficiaryDTO);

    /**
     * Partially updates a wireBeneficiary.
     *
     * @param wireBeneficiaryDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<WireBeneficiaryDTO> partialUpdate(WireBeneficiaryDTO wireBeneficiaryDTO);

    /**
     * Get all the wireBeneficiaries.
     *
     * @return the list of entities.
     */
    List<WireBeneficiaryDTO> findAll();

    /**
     * Get the "id" wireBeneficiary.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<WireBeneficiaryDTO> findOne(Long id);

    /**
     * Delete the "id" wireBeneficiary.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
