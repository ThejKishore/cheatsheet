package com.learn.jpa.service;

import com.learn.jpa.service.dto.TransferTransactionDTO;
import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing {@link com.learn.jpa.domain.TransferTransaction}.
 */
public interface TransferTransactionService {
    /**
     * Save a transferTransaction.
     *
     * @param transferTransactionDTO the entity to save.
     * @return the persisted entity.
     */
    TransferTransactionDTO save(TransferTransactionDTO transferTransactionDTO);

    /**
     * Updates a transferTransaction.
     *
     * @param transferTransactionDTO the entity to update.
     * @return the persisted entity.
     */
    TransferTransactionDTO update(TransferTransactionDTO transferTransactionDTO);

    /**
     * Partially updates a transferTransaction.
     *
     * @param transferTransactionDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<TransferTransactionDTO> partialUpdate(TransferTransactionDTO transferTransactionDTO);

    /**
     * Get all the transferTransactions.
     *
     * @return the list of entities.
     */
    List<TransferTransactionDTO> findAll();

    /**
     * Get the "id" transferTransaction.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<TransferTransactionDTO> findOne(Long id);

    /**
     * Delete the "id" transferTransaction.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
