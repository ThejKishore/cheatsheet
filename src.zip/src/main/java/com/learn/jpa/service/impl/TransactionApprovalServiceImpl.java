package com.learn.jpa.service.impl;

import com.learn.jpa.domain.TransactionApproval;
import com.learn.jpa.repository.TransactionApprovalRepository;
import com.learn.jpa.service.TransactionApprovalService;
import com.learn.jpa.service.dto.TransactionApprovalDTO;
import com.learn.jpa.service.mapper.TransactionApprovalMapper;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.TransactionApproval}.
 */
@Service
@Transactional
public class TransactionApprovalServiceImpl implements TransactionApprovalService {

    private final Logger log = LoggerFactory.getLogger(TransactionApprovalServiceImpl.class);

    private final TransactionApprovalRepository transactionApprovalRepository;

    private final TransactionApprovalMapper transactionApprovalMapper;

    public TransactionApprovalServiceImpl(
        TransactionApprovalRepository transactionApprovalRepository,
        TransactionApprovalMapper transactionApprovalMapper
    ) {
        this.transactionApprovalRepository = transactionApprovalRepository;
        this.transactionApprovalMapper = transactionApprovalMapper;
    }

    @Override
    public TransactionApprovalDTO save(TransactionApprovalDTO transactionApprovalDTO) {
        log.debug("Request to save TransactionApproval : {}", transactionApprovalDTO);
        TransactionApproval transactionApproval = transactionApprovalMapper.toEntity(transactionApprovalDTO);
        transactionApproval = transactionApprovalRepository.save(transactionApproval);
        return transactionApprovalMapper.toDto(transactionApproval);
    }

    @Override
    public TransactionApprovalDTO update(TransactionApprovalDTO transactionApprovalDTO) {
        log.debug("Request to update TransactionApproval : {}", transactionApprovalDTO);
        TransactionApproval transactionApproval = transactionApprovalMapper.toEntity(transactionApprovalDTO);
        transactionApproval = transactionApprovalRepository.save(transactionApproval);
        return transactionApprovalMapper.toDto(transactionApproval);
    }

    @Override
    public Optional<TransactionApprovalDTO> partialUpdate(TransactionApprovalDTO transactionApprovalDTO) {
        log.debug("Request to partially update TransactionApproval : {}", transactionApprovalDTO);

        return transactionApprovalRepository
            .findById(transactionApprovalDTO.getId())
            .map(existingTransactionApproval -> {
                transactionApprovalMapper.partialUpdate(existingTransactionApproval, transactionApprovalDTO);

                return existingTransactionApproval;
            })
            .map(transactionApprovalRepository::save)
            .map(transactionApprovalMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TransactionApprovalDTO> findAll() {
        log.debug("Request to get all TransactionApprovals");
        return transactionApprovalRepository
            .findAll()
            .stream()
            .map(transactionApprovalMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }

    /**
     *  Get all the transactionApprovals where Transaction is {@code null}.
     *  @return the list of entities.
     */
    @Transactional(readOnly = true)
    public List<TransactionApprovalDTO> findAllWhereTransactionIsNull() {
        log.debug("Request to get all transactionApprovals where Transaction is null");
        return StreamSupport
            .stream(transactionApprovalRepository.findAll().spliterator(), false)
            .filter(transactionApproval -> transactionApproval.getTransaction() == null)
            .map(transactionApprovalMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<TransactionApprovalDTO> findOne(Long id) {
        log.debug("Request to get TransactionApproval : {}", id);
        return transactionApprovalRepository.findById(id).map(transactionApprovalMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete TransactionApproval : {}", id);
        transactionApprovalRepository.deleteById(id);
    }
}
