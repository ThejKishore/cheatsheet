package com.learn.jpa.service.impl;

import com.learn.jpa.domain.TransferFromAccnt;
import com.learn.jpa.repository.TransferFromAccntRepository;
import com.learn.jpa.service.TransferFromAccntService;
import com.learn.jpa.service.dto.TransferFromAccntDTO;
import com.learn.jpa.service.mapper.TransferFromAccntMapper;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.TransferFromAccnt}.
 */
@Service
@Transactional
public class TransferFromAccntServiceImpl implements TransferFromAccntService {

    private final Logger log = LoggerFactory.getLogger(TransferFromAccntServiceImpl.class);

    private final TransferFromAccntRepository transferFromAccntRepository;

    private final TransferFromAccntMapper transferFromAccntMapper;

    public TransferFromAccntServiceImpl(
        TransferFromAccntRepository transferFromAccntRepository,
        TransferFromAccntMapper transferFromAccntMapper
    ) {
        this.transferFromAccntRepository = transferFromAccntRepository;
        this.transferFromAccntMapper = transferFromAccntMapper;
    }

    @Override
    public TransferFromAccntDTO save(TransferFromAccntDTO transferFromAccntDTO) {
        log.debug("Request to save TransferFromAccnt : {}", transferFromAccntDTO);
        TransferFromAccnt transferFromAccnt = transferFromAccntMapper.toEntity(transferFromAccntDTO);
        transferFromAccnt = transferFromAccntRepository.save(transferFromAccnt);
        return transferFromAccntMapper.toDto(transferFromAccnt);
    }

    @Override
    public TransferFromAccntDTO update(TransferFromAccntDTO transferFromAccntDTO) {
        log.debug("Request to update TransferFromAccnt : {}", transferFromAccntDTO);
        TransferFromAccnt transferFromAccnt = transferFromAccntMapper.toEntity(transferFromAccntDTO);
        transferFromAccnt = transferFromAccntRepository.save(transferFromAccnt);
        return transferFromAccntMapper.toDto(transferFromAccnt);
    }

    @Override
    public Optional<TransferFromAccntDTO> partialUpdate(TransferFromAccntDTO transferFromAccntDTO) {
        log.debug("Request to partially update TransferFromAccnt : {}", transferFromAccntDTO);

        return transferFromAccntRepository
            .findById(transferFromAccntDTO.getId())
            .map(existingTransferFromAccnt -> {
                transferFromAccntMapper.partialUpdate(existingTransferFromAccnt, transferFromAccntDTO);

                return existingTransferFromAccnt;
            })
            .map(transferFromAccntRepository::save)
            .map(transferFromAccntMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TransferFromAccntDTO> findAll() {
        log.debug("Request to get all TransferFromAccnts");
        return transferFromAccntRepository
            .findAll()
            .stream()
            .map(transferFromAccntMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<TransferFromAccntDTO> findOne(Long id) {
        log.debug("Request to get TransferFromAccnt : {}", id);
        return transferFromAccntRepository.findById(id).map(transferFromAccntMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete TransferFromAccnt : {}", id);
        transferFromAccntRepository.deleteById(id);
    }
}
