package com.learn.jpa.service.mapper;

import com.learn.jpa.domain.TransactionMapping;
import com.learn.jpa.domain.TransferTransaction;
import com.learn.jpa.service.dto.TransactionMappingDTO;
import com.learn.jpa.service.dto.TransferTransactionDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link TransferTransaction} and its DTO {@link TransferTransactionDTO}.
 */
@Mapper(componentModel = "spring")
public interface TransferTransactionMapper extends EntityMapper<TransferTransactionDTO, TransferTransaction> {
    @Mapping(target = "transactionMapping", source = "transactionMapping", qualifiedByName = "transactionMappingId")
    TransferTransactionDTO toDto(TransferTransaction s);

    @Named("transactionMappingId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    TransactionMappingDTO toDtoTransactionMappingId(TransactionMapping transactionMapping);
}
