package com.learn.jpa.service.impl;

import com.learn.jpa.domain.WireFromAccnt;
import com.learn.jpa.repository.WireFromAccntRepository;
import com.learn.jpa.service.WireFromAccntService;
import com.learn.jpa.service.dto.WireFromAccntDTO;
import com.learn.jpa.service.mapper.WireFromAccntMapper;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.WireFromAccnt}.
 */
@Service
@Transactional
public class WireFromAccntServiceImpl implements WireFromAccntService {

    private final Logger log = LoggerFactory.getLogger(WireFromAccntServiceImpl.class);

    private final WireFromAccntRepository wireFromAccntRepository;

    private final WireFromAccntMapper wireFromAccntMapper;

    public WireFromAccntServiceImpl(WireFromAccntRepository wireFromAccntRepository, WireFromAccntMapper wireFromAccntMapper) {
        this.wireFromAccntRepository = wireFromAccntRepository;
        this.wireFromAccntMapper = wireFromAccntMapper;
    }

    @Override
    public WireFromAccntDTO save(WireFromAccntDTO wireFromAccntDTO) {
        log.debug("Request to save WireFromAccnt : {}", wireFromAccntDTO);
        WireFromAccnt wireFromAccnt = wireFromAccntMapper.toEntity(wireFromAccntDTO);
        wireFromAccnt = wireFromAccntRepository.save(wireFromAccnt);
        return wireFromAccntMapper.toDto(wireFromAccnt);
    }

    @Override
    public WireFromAccntDTO update(WireFromAccntDTO wireFromAccntDTO) {
        log.debug("Request to update WireFromAccnt : {}", wireFromAccntDTO);
        WireFromAccnt wireFromAccnt = wireFromAccntMapper.toEntity(wireFromAccntDTO);
        wireFromAccnt = wireFromAccntRepository.save(wireFromAccnt);
        return wireFromAccntMapper.toDto(wireFromAccnt);
    }

    @Override
    public Optional<WireFromAccntDTO> partialUpdate(WireFromAccntDTO wireFromAccntDTO) {
        log.debug("Request to partially update WireFromAccnt : {}", wireFromAccntDTO);

        return wireFromAccntRepository
            .findById(wireFromAccntDTO.getId())
            .map(existingWireFromAccnt -> {
                wireFromAccntMapper.partialUpdate(existingWireFromAccnt, wireFromAccntDTO);

                return existingWireFromAccnt;
            })
            .map(wireFromAccntRepository::save)
            .map(wireFromAccntMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public List<WireFromAccntDTO> findAll() {
        log.debug("Request to get all WireFromAccnts");
        return wireFromAccntRepository.findAll().stream().map(wireFromAccntMapper::toDto).collect(Collectors.toCollection(LinkedList::new));
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<WireFromAccntDTO> findOne(Long id) {
        log.debug("Request to get WireFromAccnt : {}", id);
        return wireFromAccntRepository.findById(id).map(wireFromAccntMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete WireFromAccnt : {}", id);
        wireFromAccntRepository.deleteById(id);
    }
}
