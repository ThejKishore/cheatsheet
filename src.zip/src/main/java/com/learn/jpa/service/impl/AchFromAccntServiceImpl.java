package com.learn.jpa.service.impl;

import com.learn.jpa.domain.AchFromAccnt;
import com.learn.jpa.repository.AchFromAccntRepository;
import com.learn.jpa.service.AchFromAccntService;
import com.learn.jpa.service.dto.AchFromAccntDTO;
import com.learn.jpa.service.mapper.AchFromAccntMapper;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.AchFromAccnt}.
 */
@Service
@Transactional
public class AchFromAccntServiceImpl implements AchFromAccntService {

    private final Logger log = LoggerFactory.getLogger(AchFromAccntServiceImpl.class);

    private final AchFromAccntRepository achFromAccntRepository;

    private final AchFromAccntMapper achFromAccntMapper;

    public AchFromAccntServiceImpl(AchFromAccntRepository achFromAccntRepository, AchFromAccntMapper achFromAccntMapper) {
        this.achFromAccntRepository = achFromAccntRepository;
        this.achFromAccntMapper = achFromAccntMapper;
    }

    @Override
    public AchFromAccntDTO save(AchFromAccntDTO achFromAccntDTO) {
        log.debug("Request to save AchFromAccnt : {}", achFromAccntDTO);
        AchFromAccnt achFromAccnt = achFromAccntMapper.toEntity(achFromAccntDTO);
        achFromAccnt = achFromAccntRepository.save(achFromAccnt);
        return achFromAccntMapper.toDto(achFromAccnt);
    }

    @Override
    public AchFromAccntDTO update(AchFromAccntDTO achFromAccntDTO) {
        log.debug("Request to update AchFromAccnt : {}", achFromAccntDTO);
        AchFromAccnt achFromAccnt = achFromAccntMapper.toEntity(achFromAccntDTO);
        achFromAccnt = achFromAccntRepository.save(achFromAccnt);
        return achFromAccntMapper.toDto(achFromAccnt);
    }

    @Override
    public Optional<AchFromAccntDTO> partialUpdate(AchFromAccntDTO achFromAccntDTO) {
        log.debug("Request to partially update AchFromAccnt : {}", achFromAccntDTO);

        return achFromAccntRepository
            .findById(achFromAccntDTO.getId())
            .map(existingAchFromAccnt -> {
                achFromAccntMapper.partialUpdate(existingAchFromAccnt, achFromAccntDTO);

                return existingAchFromAccnt;
            })
            .map(achFromAccntRepository::save)
            .map(achFromAccntMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AchFromAccntDTO> findAll() {
        log.debug("Request to get all AchFromAccnts");
        return achFromAccntRepository.findAll().stream().map(achFromAccntMapper::toDto).collect(Collectors.toCollection(LinkedList::new));
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<AchFromAccntDTO> findOne(Long id) {
        log.debug("Request to get AchFromAccnt : {}", id);
        return achFromAccntRepository.findById(id).map(achFromAccntMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete AchFromAccnt : {}", id);
        achFromAccntRepository.deleteById(id);
    }
}
