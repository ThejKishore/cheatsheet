package com.learn.jpa.service;

import com.learn.jpa.service.dto.AchTransactionDTO;
import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing {@link com.learn.jpa.domain.AchTransaction}.
 */
public interface AchTransactionService {
    /**
     * Save a achTransaction.
     *
     * @param achTransactionDTO the entity to save.
     * @return the persisted entity.
     */
    AchTransactionDTO save(AchTransactionDTO achTransactionDTO);

    /**
     * Updates a achTransaction.
     *
     * @param achTransactionDTO the entity to update.
     * @return the persisted entity.
     */
    AchTransactionDTO update(AchTransactionDTO achTransactionDTO);

    /**
     * Partially updates a achTransaction.
     *
     * @param achTransactionDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<AchTransactionDTO> partialUpdate(AchTransactionDTO achTransactionDTO);

    /**
     * Get all the achTransactions.
     *
     * @return the list of entities.
     */
    List<AchTransactionDTO> findAll();

    /**
     * Get the "id" achTransaction.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<AchTransactionDTO> findOne(Long id);

    /**
     * Delete the "id" achTransaction.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
