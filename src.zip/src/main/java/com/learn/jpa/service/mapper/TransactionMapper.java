package com.learn.jpa.service.mapper;

import com.learn.jpa.domain.Transaction;
import com.learn.jpa.domain.TransactionApproval;
import com.learn.jpa.domain.TransactionMapping;
import com.learn.jpa.domain.TransactionReview;
import com.learn.jpa.service.dto.TransactionApprovalDTO;
import com.learn.jpa.service.dto.TransactionDTO;
import com.learn.jpa.service.dto.TransactionMappingDTO;
import com.learn.jpa.service.dto.TransactionReviewDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link Transaction} and its DTO {@link TransactionDTO}.
 */
@Mapper(componentModel = "spring")
public interface TransactionMapper extends EntityMapper<TransactionDTO, Transaction> {
    @Mapping(target = "transactionMapping", source = "transactionMapping", qualifiedByName = "transactionMappingId")
    @Mapping(target = "transactionApproval", source = "transactionApproval", qualifiedByName = "transactionApprovalId")
    @Mapping(target = "transactionReview", source = "transactionReview", qualifiedByName = "transactionReviewId")
    TransactionDTO toDto(Transaction s);

    @Named("transactionMappingId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    TransactionMappingDTO toDtoTransactionMappingId(TransactionMapping transactionMapping);

    @Named("transactionApprovalId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    TransactionApprovalDTO toDtoTransactionApprovalId(TransactionApproval transactionApproval);

    @Named("transactionReviewId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    TransactionReviewDTO toDtoTransactionReviewId(TransactionReview transactionReview);
}
