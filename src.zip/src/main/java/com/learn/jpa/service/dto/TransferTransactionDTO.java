package com.learn.jpa.service.dto;

import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the {@link com.learn.jpa.domain.TransferTransaction} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class TransferTransactionDTO implements Serializable {

    private Long id;

    @NotNull
    private Long transferTranId;

    private TransactionMappingDTO transactionMapping;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getTransferTranId() {
        return transferTranId;
    }

    public void setTransferTranId(Long transferTranId) {
        this.transferTranId = transferTranId;
    }

    public TransactionMappingDTO getTransactionMapping() {
        return transactionMapping;
    }

    public void setTransactionMapping(TransactionMappingDTO transactionMapping) {
        this.transactionMapping = transactionMapping;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TransferTransactionDTO)) {
            return false;
        }

        TransferTransactionDTO transferTransactionDTO = (TransferTransactionDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, transferTransactionDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "TransferTransactionDTO{" +
            "id=" + getId() +
            ", transferTranId=" + getTransferTranId() +
            ", transactionMapping=" + getTransactionMapping() +
            "}";
    }
}
