package com.learn.jpa.service.dto;

import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.time.ZonedDateTime;
import java.util.Objects;

/**
 * A DTO for the {@link com.learn.jpa.domain.Transaction} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class TransactionDTO implements Serializable {

    private Long id;

    @NotNull
    private Long tranId;

    private String tranName;

    private Integer frmCnt;

    private Integer toCnt;

    private BigDecimal totalAmount;

    private ZonedDateTime createdDate;

    private ZonedDateTime updatedDate;

    private String createdBy;

    private String updatedBy;

    private ZonedDateTime settlementDate;

    private String frequencyType;

    private String tranType;

    private Long profileId;

    private String profileName;

    private String narrative;

    private String precedingNarrative;

    private String customNarrative;

    private String systemGeneratedNarrative;

    private TransactionMappingDTO transactionMapping;

    private TransactionApprovalDTO transactionApproval;

    private TransactionReviewDTO transactionReview;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getTranId() {
        return tranId;
    }

    public void setTranId(Long tranId) {
        this.tranId = tranId;
    }

    public String getTranName() {
        return tranName;
    }

    public void setTranName(String tranName) {
        this.tranName = tranName;
    }

    public Integer getFrmCnt() {
        return frmCnt;
    }

    public void setFrmCnt(Integer frmCnt) {
        this.frmCnt = frmCnt;
    }

    public Integer getToCnt() {
        return toCnt;
    }

    public void setToCnt(Integer toCnt) {
        this.toCnt = toCnt;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public ZonedDateTime getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(ZonedDateTime createdDate) {
        this.createdDate = createdDate;
    }

    public ZonedDateTime getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(ZonedDateTime updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public ZonedDateTime getSettlementDate() {
        return settlementDate;
    }

    public void setSettlementDate(ZonedDateTime settlementDate) {
        this.settlementDate = settlementDate;
    }

    public String getFrequencyType() {
        return frequencyType;
    }

    public void setFrequencyType(String frequencyType) {
        this.frequencyType = frequencyType;
    }

    public String getTranType() {
        return tranType;
    }

    public void setTranType(String tranType) {
        this.tranType = tranType;
    }

    public Long getProfileId() {
        return profileId;
    }

    public void setProfileId(Long profileId) {
        this.profileId = profileId;
    }

    public String getProfileName() {
        return profileName;
    }

    public void setProfileName(String profileName) {
        this.profileName = profileName;
    }

    public String getNarrative() {
        return narrative;
    }

    public void setNarrative(String narrative) {
        this.narrative = narrative;
    }

    public String getPrecedingNarrative() {
        return precedingNarrative;
    }

    public void setPrecedingNarrative(String precedingNarrative) {
        this.precedingNarrative = precedingNarrative;
    }

    public String getCustomNarrative() {
        return customNarrative;
    }

    public void setCustomNarrative(String customNarrative) {
        this.customNarrative = customNarrative;
    }

    public String getSystemGeneratedNarrative() {
        return systemGeneratedNarrative;
    }

    public void setSystemGeneratedNarrative(String systemGeneratedNarrative) {
        this.systemGeneratedNarrative = systemGeneratedNarrative;
    }

    public TransactionMappingDTO getTransactionMapping() {
        return transactionMapping;
    }

    public void setTransactionMapping(TransactionMappingDTO transactionMapping) {
        this.transactionMapping = transactionMapping;
    }

    public TransactionApprovalDTO getTransactionApproval() {
        return transactionApproval;
    }

    public void setTransactionApproval(TransactionApprovalDTO transactionApproval) {
        this.transactionApproval = transactionApproval;
    }

    public TransactionReviewDTO getTransactionReview() {
        return transactionReview;
    }

    public void setTransactionReview(TransactionReviewDTO transactionReview) {
        this.transactionReview = transactionReview;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TransactionDTO)) {
            return false;
        }

        TransactionDTO transactionDTO = (TransactionDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, transactionDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "TransactionDTO{" +
            "id=" + getId() +
            ", tranId=" + getTranId() +
            ", tranName='" + getTranName() + "'" +
            ", frmCnt=" + getFrmCnt() +
            ", toCnt=" + getToCnt() +
            ", totalAmount=" + getTotalAmount() +
            ", createdDate='" + getCreatedDate() + "'" +
            ", updatedDate='" + getUpdatedDate() + "'" +
            ", createdBy='" + getCreatedBy() + "'" +
            ", updatedBy='" + getUpdatedBy() + "'" +
            ", settlementDate='" + getSettlementDate() + "'" +
            ", frequencyType='" + getFrequencyType() + "'" +
            ", tranType='" + getTranType() + "'" +
            ", profileId=" + getProfileId() +
            ", profileName='" + getProfileName() + "'" +
            ", narrative='" + getNarrative() + "'" +
            ", precedingNarrative='" + getPrecedingNarrative() + "'" +
            ", customNarrative='" + getCustomNarrative() + "'" +
            ", systemGeneratedNarrative='" + getSystemGeneratedNarrative() + "'" +
            ", transactionMapping=" + getTransactionMapping() +
            ", transactionApproval=" + getTransactionApproval() +
            ", transactionReview=" + getTransactionReview() +
            "}";
    }
}
