package com.learn.jpa.service.mapper;

import com.learn.jpa.domain.WireBeneficiary;
import com.learn.jpa.domain.WireRecipient;
import com.learn.jpa.service.dto.WireBeneficiaryDTO;
import com.learn.jpa.service.dto.WireRecipientDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link WireBeneficiary} and its DTO {@link WireBeneficiaryDTO}.
 */
@Mapper(componentModel = "spring")
public interface WireBeneficiaryMapper extends EntityMapper<WireBeneficiaryDTO, WireBeneficiary> {
    @Mapping(target = "wireRecipient", source = "wireRecipient", qualifiedByName = "wireRecipientId")
    WireBeneficiaryDTO toDto(WireBeneficiary s);

    @Named("wireRecipientId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    WireRecipientDTO toDtoWireRecipientId(WireRecipient wireRecipient);
}
