package com.learn.jpa.service.impl;

import com.learn.jpa.domain.WireTransaction;
import com.learn.jpa.repository.WireTransactionRepository;
import com.learn.jpa.service.WireTransactionService;
import com.learn.jpa.service.dto.WireTransactionDTO;
import com.learn.jpa.service.mapper.WireTransactionMapper;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.WireTransaction}.
 */
@Service
@Transactional
public class WireTransactionServiceImpl implements WireTransactionService {

    private final Logger log = LoggerFactory.getLogger(WireTransactionServiceImpl.class);

    private final WireTransactionRepository wireTransactionRepository;

    private final WireTransactionMapper wireTransactionMapper;

    public WireTransactionServiceImpl(WireTransactionRepository wireTransactionRepository, WireTransactionMapper wireTransactionMapper) {
        this.wireTransactionRepository = wireTransactionRepository;
        this.wireTransactionMapper = wireTransactionMapper;
    }

    @Override
    public WireTransactionDTO save(WireTransactionDTO wireTransactionDTO) {
        log.debug("Request to save WireTransaction : {}", wireTransactionDTO);
        WireTransaction wireTransaction = wireTransactionMapper.toEntity(wireTransactionDTO);
        wireTransaction = wireTransactionRepository.save(wireTransaction);
        return wireTransactionMapper.toDto(wireTransaction);
    }

    @Override
    public WireTransactionDTO update(WireTransactionDTO wireTransactionDTO) {
        log.debug("Request to update WireTransaction : {}", wireTransactionDTO);
        WireTransaction wireTransaction = wireTransactionMapper.toEntity(wireTransactionDTO);
        wireTransaction = wireTransactionRepository.save(wireTransaction);
        return wireTransactionMapper.toDto(wireTransaction);
    }

    @Override
    public Optional<WireTransactionDTO> partialUpdate(WireTransactionDTO wireTransactionDTO) {
        log.debug("Request to partially update WireTransaction : {}", wireTransactionDTO);

        return wireTransactionRepository
            .findById(wireTransactionDTO.getId())
            .map(existingWireTransaction -> {
                wireTransactionMapper.partialUpdate(existingWireTransaction, wireTransactionDTO);

                return existingWireTransaction;
            })
            .map(wireTransactionRepository::save)
            .map(wireTransactionMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public List<WireTransactionDTO> findAll() {
        log.debug("Request to get all WireTransactions");
        return wireTransactionRepository
            .findAll()
            .stream()
            .map(wireTransactionMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<WireTransactionDTO> findOne(Long id) {
        log.debug("Request to get WireTransaction : {}", id);
        return wireTransactionRepository.findById(id).map(wireTransactionMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete WireTransaction : {}", id);
        wireTransactionRepository.deleteById(id);
    }
}
