package com.learn.jpa.service.mapper;

import com.learn.jpa.domain.TransactionApproval;
import com.learn.jpa.service.dto.TransactionApprovalDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link TransactionApproval} and its DTO {@link TransactionApprovalDTO}.
 */
@Mapper(componentModel = "spring")
public interface TransactionApprovalMapper extends EntityMapper<TransactionApprovalDTO, TransactionApproval> {}
