package com.learn.jpa.service;

import com.learn.jpa.service.dto.AchFromAccntDTO;
import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing {@link com.learn.jpa.domain.AchFromAccnt}.
 */
public interface AchFromAccntService {
    /**
     * Save a achFromAccnt.
     *
     * @param achFromAccntDTO the entity to save.
     * @return the persisted entity.
     */
    AchFromAccntDTO save(AchFromAccntDTO achFromAccntDTO);

    /**
     * Updates a achFromAccnt.
     *
     * @param achFromAccntDTO the entity to update.
     * @return the persisted entity.
     */
    AchFromAccntDTO update(AchFromAccntDTO achFromAccntDTO);

    /**
     * Partially updates a achFromAccnt.
     *
     * @param achFromAccntDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<AchFromAccntDTO> partialUpdate(AchFromAccntDTO achFromAccntDTO);

    /**
     * Get all the achFromAccnts.
     *
     * @return the list of entities.
     */
    List<AchFromAccntDTO> findAll();

    /**
     * Get the "id" achFromAccnt.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<AchFromAccntDTO> findOne(Long id);

    /**
     * Delete the "id" achFromAccnt.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
