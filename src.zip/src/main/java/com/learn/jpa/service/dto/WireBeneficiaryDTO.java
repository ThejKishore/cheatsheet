package com.learn.jpa.service.dto;

import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the {@link com.learn.jpa.domain.WireBeneficiary} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class WireBeneficiaryDTO implements Serializable {

    private Long id;

    @NotNull
    private Long beneficiaryId;

    private String beneficiaryName;

    private String beneficiaryType;

    private WireRecipientDTO wireRecipient;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getBeneficiaryId() {
        return beneficiaryId;
    }

    public void setBeneficiaryId(Long beneficiaryId) {
        this.beneficiaryId = beneficiaryId;
    }

    public String getBeneficiaryName() {
        return beneficiaryName;
    }

    public void setBeneficiaryName(String beneficiaryName) {
        this.beneficiaryName = beneficiaryName;
    }

    public String getBeneficiaryType() {
        return beneficiaryType;
    }

    public void setBeneficiaryType(String beneficiaryType) {
        this.beneficiaryType = beneficiaryType;
    }

    public WireRecipientDTO getWireRecipient() {
        return wireRecipient;
    }

    public void setWireRecipient(WireRecipientDTO wireRecipient) {
        this.wireRecipient = wireRecipient;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof WireBeneficiaryDTO)) {
            return false;
        }

        WireBeneficiaryDTO wireBeneficiaryDTO = (WireBeneficiaryDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, wireBeneficiaryDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "WireBeneficiaryDTO{" +
            "id=" + getId() +
            ", beneficiaryId=" + getBeneficiaryId() +
            ", beneficiaryName='" + getBeneficiaryName() + "'" +
            ", beneficiaryType='" + getBeneficiaryType() + "'" +
            ", wireRecipient=" + getWireRecipient() +
            "}";
    }
}
