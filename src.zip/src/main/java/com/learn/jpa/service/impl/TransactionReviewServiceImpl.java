package com.learn.jpa.service.impl;

import com.learn.jpa.domain.TransactionReview;
import com.learn.jpa.repository.TransactionReviewRepository;
import com.learn.jpa.service.TransactionReviewService;
import com.learn.jpa.service.dto.TransactionReviewDTO;
import com.learn.jpa.service.mapper.TransactionReviewMapper;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.TransactionReview}.
 */
@Service
@Transactional
public class TransactionReviewServiceImpl implements TransactionReviewService {

    private final Logger log = LoggerFactory.getLogger(TransactionReviewServiceImpl.class);

    private final TransactionReviewRepository transactionReviewRepository;

    private final TransactionReviewMapper transactionReviewMapper;

    public TransactionReviewServiceImpl(
        TransactionReviewRepository transactionReviewRepository,
        TransactionReviewMapper transactionReviewMapper
    ) {
        this.transactionReviewRepository = transactionReviewRepository;
        this.transactionReviewMapper = transactionReviewMapper;
    }

    @Override
    public TransactionReviewDTO save(TransactionReviewDTO transactionReviewDTO) {
        log.debug("Request to save TransactionReview : {}", transactionReviewDTO);
        TransactionReview transactionReview = transactionReviewMapper.toEntity(transactionReviewDTO);
        transactionReview = transactionReviewRepository.save(transactionReview);
        return transactionReviewMapper.toDto(transactionReview);
    }

    @Override
    public TransactionReviewDTO update(TransactionReviewDTO transactionReviewDTO) {
        log.debug("Request to update TransactionReview : {}", transactionReviewDTO);
        TransactionReview transactionReview = transactionReviewMapper.toEntity(transactionReviewDTO);
        transactionReview = transactionReviewRepository.save(transactionReview);
        return transactionReviewMapper.toDto(transactionReview);
    }

    @Override
    public Optional<TransactionReviewDTO> partialUpdate(TransactionReviewDTO transactionReviewDTO) {
        log.debug("Request to partially update TransactionReview : {}", transactionReviewDTO);

        return transactionReviewRepository
            .findById(transactionReviewDTO.getId())
            .map(existingTransactionReview -> {
                transactionReviewMapper.partialUpdate(existingTransactionReview, transactionReviewDTO);

                return existingTransactionReview;
            })
            .map(transactionReviewRepository::save)
            .map(transactionReviewMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public List<TransactionReviewDTO> findAll() {
        log.debug("Request to get all TransactionReviews");
        return transactionReviewRepository
            .findAll()
            .stream()
            .map(transactionReviewMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }

    /**
     *  Get all the transactionReviews where Transaction is {@code null}.
     *  @return the list of entities.
     */
    @Transactional(readOnly = true)
    public List<TransactionReviewDTO> findAllWhereTransactionIsNull() {
        log.debug("Request to get all transactionReviews where Transaction is null");
        return StreamSupport
            .stream(transactionReviewRepository.findAll().spliterator(), false)
            .filter(transactionReview -> transactionReview.getTransaction() == null)
            .map(transactionReviewMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<TransactionReviewDTO> findOne(Long id) {
        log.debug("Request to get TransactionReview : {}", id);
        return transactionReviewRepository.findById(id).map(transactionReviewMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete TransactionReview : {}", id);
        transactionReviewRepository.deleteById(id);
    }
}
