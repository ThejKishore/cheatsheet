package com.learn.jpa.service.impl;

import com.learn.jpa.domain.AchRecipient;
import com.learn.jpa.repository.AchRecipientRepository;
import com.learn.jpa.service.AchRecipientService;
import com.learn.jpa.service.dto.AchRecipientDTO;
import com.learn.jpa.service.mapper.AchRecipientMapper;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.AchRecipient}.
 */
@Service
@Transactional
public class AchRecipientServiceImpl implements AchRecipientService {

    private final Logger log = LoggerFactory.getLogger(AchRecipientServiceImpl.class);

    private final AchRecipientRepository achRecipientRepository;

    private final AchRecipientMapper achRecipientMapper;

    public AchRecipientServiceImpl(AchRecipientRepository achRecipientRepository, AchRecipientMapper achRecipientMapper) {
        this.achRecipientRepository = achRecipientRepository;
        this.achRecipientMapper = achRecipientMapper;
    }

    @Override
    public AchRecipientDTO save(AchRecipientDTO achRecipientDTO) {
        log.debug("Request to save AchRecipient : {}", achRecipientDTO);
        AchRecipient achRecipient = achRecipientMapper.toEntity(achRecipientDTO);
        achRecipient = achRecipientRepository.save(achRecipient);
        return achRecipientMapper.toDto(achRecipient);
    }

    @Override
    public AchRecipientDTO update(AchRecipientDTO achRecipientDTO) {
        log.debug("Request to update AchRecipient : {}", achRecipientDTO);
        AchRecipient achRecipient = achRecipientMapper.toEntity(achRecipientDTO);
        achRecipient = achRecipientRepository.save(achRecipient);
        return achRecipientMapper.toDto(achRecipient);
    }

    @Override
    public Optional<AchRecipientDTO> partialUpdate(AchRecipientDTO achRecipientDTO) {
        log.debug("Request to partially update AchRecipient : {}", achRecipientDTO);

        return achRecipientRepository
            .findById(achRecipientDTO.getId())
            .map(existingAchRecipient -> {
                achRecipientMapper.partialUpdate(existingAchRecipient, achRecipientDTO);

                return existingAchRecipient;
            })
            .map(achRecipientRepository::save)
            .map(achRecipientMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AchRecipientDTO> findAll() {
        log.debug("Request to get all AchRecipients");
        return achRecipientRepository.findAll().stream().map(achRecipientMapper::toDto).collect(Collectors.toCollection(LinkedList::new));
    }

    /**
     *  Get all the achRecipients where AchTransaction is {@code null}.
     *  @return the list of entities.
     */
    @Transactional(readOnly = true)
    public List<AchRecipientDTO> findAllWhereAchTransactionIsNull() {
        log.debug("Request to get all achRecipients where AchTransaction is null");
        return StreamSupport
            .stream(achRecipientRepository.findAll().spliterator(), false)
            .filter(achRecipient -> achRecipient.getAchTransaction() == null)
            .map(achRecipientMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<AchRecipientDTO> findOne(Long id) {
        log.debug("Request to get AchRecipient : {}", id);
        return achRecipientRepository.findById(id).map(achRecipientMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete AchRecipient : {}", id);
        achRecipientRepository.deleteById(id);
    }
}
