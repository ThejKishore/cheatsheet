package com.learn.jpa.service.mapper;

import com.learn.jpa.domain.WireRecipient;
import com.learn.jpa.service.dto.WireRecipientDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link WireRecipient} and its DTO {@link WireRecipientDTO}.
 */
@Mapper(componentModel = "spring")
public interface WireRecipientMapper extends EntityMapper<WireRecipientDTO, WireRecipient> {}
