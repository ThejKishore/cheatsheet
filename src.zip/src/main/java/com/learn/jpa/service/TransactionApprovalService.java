package com.learn.jpa.service;

import com.learn.jpa.service.dto.TransactionApprovalDTO;
import java.util.List;
import java.util.Optional;

/**
 * Service Interface for managing {@link com.learn.jpa.domain.TransactionApproval}.
 */
public interface TransactionApprovalService {
    /**
     * Save a transactionApproval.
     *
     * @param transactionApprovalDTO the entity to save.
     * @return the persisted entity.
     */
    TransactionApprovalDTO save(TransactionApprovalDTO transactionApprovalDTO);

    /**
     * Updates a transactionApproval.
     *
     * @param transactionApprovalDTO the entity to update.
     * @return the persisted entity.
     */
    TransactionApprovalDTO update(TransactionApprovalDTO transactionApprovalDTO);

    /**
     * Partially updates a transactionApproval.
     *
     * @param transactionApprovalDTO the entity to update partially.
     * @return the persisted entity.
     */
    Optional<TransactionApprovalDTO> partialUpdate(TransactionApprovalDTO transactionApprovalDTO);

    /**
     * Get all the transactionApprovals.
     *
     * @return the list of entities.
     */
    List<TransactionApprovalDTO> findAll();

    /**
     * Get all the TransactionApprovalDTO where Transaction is {@code null}.
     *
     * @return the {@link List} of entities.
     */
    List<TransactionApprovalDTO> findAllWhereTransactionIsNull();

    /**
     * Get the "id" transactionApproval.
     *
     * @param id the id of the entity.
     * @return the entity.
     */
    Optional<TransactionApprovalDTO> findOne(Long id);

    /**
     * Delete the "id" transactionApproval.
     *
     * @param id the id of the entity.
     */
    void delete(Long id);
}
