package com.learn.jpa.service.dto;

import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.util.Objects;

/**
 * A DTO for the {@link com.learn.jpa.domain.WireTransaction} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class WireTransactionDTO implements Serializable {

    private Long id;

    @NotNull
    private Long wireTranId;

    private TransactionMappingDTO transactionMapping;

    private WireRecipientDTO wireRecipient;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getWireTranId() {
        return wireTranId;
    }

    public void setWireTranId(Long wireTranId) {
        this.wireTranId = wireTranId;
    }

    public TransactionMappingDTO getTransactionMapping() {
        return transactionMapping;
    }

    public void setTransactionMapping(TransactionMappingDTO transactionMapping) {
        this.transactionMapping = transactionMapping;
    }

    public WireRecipientDTO getWireRecipient() {
        return wireRecipient;
    }

    public void setWireRecipient(WireRecipientDTO wireRecipient) {
        this.wireRecipient = wireRecipient;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof WireTransactionDTO)) {
            return false;
        }

        WireTransactionDTO wireTransactionDTO = (WireTransactionDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, wireTransactionDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "WireTransactionDTO{" +
            "id=" + getId() +
            ", wireTranId=" + getWireTranId() +
            ", transactionMapping=" + getTransactionMapping() +
            ", wireRecipient=" + getWireRecipient() +
            "}";
    }
}
