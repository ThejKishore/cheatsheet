package com.learn.jpa.service.impl;

import com.learn.jpa.domain.WireBeneficiary;
import com.learn.jpa.repository.WireBeneficiaryRepository;
import com.learn.jpa.service.WireBeneficiaryService;
import com.learn.jpa.service.dto.WireBeneficiaryDTO;
import com.learn.jpa.service.mapper.WireBeneficiaryMapper;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * Service Implementation for managing {@link com.learn.jpa.domain.WireBeneficiary}.
 */
@Service
@Transactional
public class WireBeneficiaryServiceImpl implements WireBeneficiaryService {

    private final Logger log = LoggerFactory.getLogger(WireBeneficiaryServiceImpl.class);

    private final WireBeneficiaryRepository wireBeneficiaryRepository;

    private final WireBeneficiaryMapper wireBeneficiaryMapper;

    public WireBeneficiaryServiceImpl(WireBeneficiaryRepository wireBeneficiaryRepository, WireBeneficiaryMapper wireBeneficiaryMapper) {
        this.wireBeneficiaryRepository = wireBeneficiaryRepository;
        this.wireBeneficiaryMapper = wireBeneficiaryMapper;
    }

    @Override
    public WireBeneficiaryDTO save(WireBeneficiaryDTO wireBeneficiaryDTO) {
        log.debug("Request to save WireBeneficiary : {}", wireBeneficiaryDTO);
        WireBeneficiary wireBeneficiary = wireBeneficiaryMapper.toEntity(wireBeneficiaryDTO);
        wireBeneficiary = wireBeneficiaryRepository.save(wireBeneficiary);
        return wireBeneficiaryMapper.toDto(wireBeneficiary);
    }

    @Override
    public WireBeneficiaryDTO update(WireBeneficiaryDTO wireBeneficiaryDTO) {
        log.debug("Request to update WireBeneficiary : {}", wireBeneficiaryDTO);
        WireBeneficiary wireBeneficiary = wireBeneficiaryMapper.toEntity(wireBeneficiaryDTO);
        wireBeneficiary = wireBeneficiaryRepository.save(wireBeneficiary);
        return wireBeneficiaryMapper.toDto(wireBeneficiary);
    }

    @Override
    public Optional<WireBeneficiaryDTO> partialUpdate(WireBeneficiaryDTO wireBeneficiaryDTO) {
        log.debug("Request to partially update WireBeneficiary : {}", wireBeneficiaryDTO);

        return wireBeneficiaryRepository
            .findById(wireBeneficiaryDTO.getId())
            .map(existingWireBeneficiary -> {
                wireBeneficiaryMapper.partialUpdate(existingWireBeneficiary, wireBeneficiaryDTO);

                return existingWireBeneficiary;
            })
            .map(wireBeneficiaryRepository::save)
            .map(wireBeneficiaryMapper::toDto);
    }

    @Override
    @Transactional(readOnly = true)
    public List<WireBeneficiaryDTO> findAll() {
        log.debug("Request to get all WireBeneficiaries");
        return wireBeneficiaryRepository
            .findAll()
            .stream()
            .map(wireBeneficiaryMapper::toDto)
            .collect(Collectors.toCollection(LinkedList::new));
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<WireBeneficiaryDTO> findOne(Long id) {
        log.debug("Request to get WireBeneficiary : {}", id);
        return wireBeneficiaryRepository.findById(id).map(wireBeneficiaryMapper::toDto);
    }

    @Override
    public void delete(Long id) {
        log.debug("Request to delete WireBeneficiary : {}", id);
        wireBeneficiaryRepository.deleteById(id);
    }
}
