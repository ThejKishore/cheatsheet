package com.learn.jpa.service.dto;

import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Objects;

/**
 * A DTO for the {@link com.learn.jpa.domain.TransferToAccnt} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class TransferToAccntDTO implements Serializable {

    private Long id;

    @NotNull
    private Long toAccntID;

    private Long toAccntSk;

    private String toAccntName;

    private BigDecimal toAccntAmnt;

    private TransferTransactionDTO transferTransaction;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getToAccntID() {
        return toAccntID;
    }

    public void setToAccntID(Long toAccntID) {
        this.toAccntID = toAccntID;
    }

    public Long getToAccntSk() {
        return toAccntSk;
    }

    public void setToAccntSk(Long toAccntSk) {
        this.toAccntSk = toAccntSk;
    }

    public String getToAccntName() {
        return toAccntName;
    }

    public void setToAccntName(String toAccntName) {
        this.toAccntName = toAccntName;
    }

    public BigDecimal getToAccntAmnt() {
        return toAccntAmnt;
    }

    public void setToAccntAmnt(BigDecimal toAccntAmnt) {
        this.toAccntAmnt = toAccntAmnt;
    }

    public TransferTransactionDTO getTransferTransaction() {
        return transferTransaction;
    }

    public void setTransferTransaction(TransferTransactionDTO transferTransaction) {
        this.transferTransaction = transferTransaction;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TransferToAccntDTO)) {
            return false;
        }

        TransferToAccntDTO transferToAccntDTO = (TransferToAccntDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, transferToAccntDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "TransferToAccntDTO{" +
            "id=" + getId() +
            ", toAccntID=" + getToAccntID() +
            ", toAccntSk=" + getToAccntSk() +
            ", toAccntName='" + getToAccntName() + "'" +
            ", toAccntAmnt=" + getToAccntAmnt() +
            ", transferTransaction=" + getTransferTransaction() +
            "}";
    }
}
