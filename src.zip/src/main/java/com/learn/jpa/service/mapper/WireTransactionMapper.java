package com.learn.jpa.service.mapper;

import com.learn.jpa.domain.TransactionMapping;
import com.learn.jpa.domain.WireRecipient;
import com.learn.jpa.domain.WireTransaction;
import com.learn.jpa.service.dto.TransactionMappingDTO;
import com.learn.jpa.service.dto.WireRecipientDTO;
import com.learn.jpa.service.dto.WireTransactionDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link WireTransaction} and its DTO {@link WireTransactionDTO}.
 */
@Mapper(componentModel = "spring")
public interface WireTransactionMapper extends EntityMapper<WireTransactionDTO, WireTransaction> {
    @Mapping(target = "transactionMapping", source = "transactionMapping", qualifiedByName = "transactionMappingId")
    @Mapping(target = "wireRecipient", source = "wireRecipient", qualifiedByName = "wireRecipientId")
    WireTransactionDTO toDto(WireTransaction s);

    @Named("transactionMappingId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    TransactionMappingDTO toDtoTransactionMappingId(TransactionMapping transactionMapping);

    @Named("wireRecipientId")
    @BeanMapping(ignoreByDefault = true)
    @Mapping(target = "id", source = "id")
    WireRecipientDTO toDtoWireRecipientId(WireRecipient wireRecipient);
}
