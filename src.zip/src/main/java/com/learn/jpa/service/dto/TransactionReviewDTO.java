package com.learn.jpa.service.dto;

import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.time.ZonedDateTime;
import java.util.Objects;

/**
 * A DTO for the {@link com.learn.jpa.domain.TransactionReview} entity.
 */
@SuppressWarnings("common-java:DuplicatedBlocks")
public class TransactionReviewDTO implements Serializable {

    private Long id;

    @NotNull
    private Long tranId;

    private String firstPledgeReviewerAccept;

    private ZonedDateTime firstPledgeReviewedAcceptDate;

    private String firstPledgeReviewerReject;

    private String firstPledgeReviewerRejectReason;

    private ZonedDateTime firstPledgeReviewedRejectedDate;

    private String secondPledgeReviewerAccept;

    private ZonedDateTime secondPledgeReviewedAcceptDate;

    private String secondPledgeReviewerReject;

    private String secondPledgeReviewerRejectReason;

    private ZonedDateTime secondPledgeReviewedRejectedDate;

    private String firstFiducaryReviewerAccept;

    private ZonedDateTime firstFiducaryReviewedAcceptDate;

    private String firstFiducaryReviewerReject;

    private String firstFiducaryReviewerRejectReason;

    private ZonedDateTime firstFiducaryReviewedRejectedDate;

    private String secondFiducaryReviewerAccept;

    private ZonedDateTime secondPFiducaryReviewedAcceptDate;

    private String secondFiducaryReviewerReject;

    private String secondFiducaryReviewerRejectReason;

    private ZonedDateTime secondFiducaryReviewedRejectedDate;

    private String firstOverDraftReviewerAccept;

    private ZonedDateTime firstOverDraftReviewedAcceptDate;

    private String firstOverDraftReviewerReject;

    private String firstOverDraftReviewerRejectReason;

    private ZonedDateTime firstOverDraftReviewedRejectedDate;

    private String secondOverDraftReviewerAccept;

    private ZonedDateTime secondOverDraftReviewedAcceptDate;

    private String secondOverDraftReviewerReject;

    private String secondOverDraftReviewerRejectReason;

    private ZonedDateTime secondOverDraftReviewedRejectedDate;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getTranId() {
        return tranId;
    }

    public void setTranId(Long tranId) {
        this.tranId = tranId;
    }

    public String getFirstPledgeReviewerAccept() {
        return firstPledgeReviewerAccept;
    }

    public void setFirstPledgeReviewerAccept(String firstPledgeReviewerAccept) {
        this.firstPledgeReviewerAccept = firstPledgeReviewerAccept;
    }

    public ZonedDateTime getFirstPledgeReviewedAcceptDate() {
        return firstPledgeReviewedAcceptDate;
    }

    public void setFirstPledgeReviewedAcceptDate(ZonedDateTime firstPledgeReviewedAcceptDate) {
        this.firstPledgeReviewedAcceptDate = firstPledgeReviewedAcceptDate;
    }

    public String getFirstPledgeReviewerReject() {
        return firstPledgeReviewerReject;
    }

    public void setFirstPledgeReviewerReject(String firstPledgeReviewerReject) {
        this.firstPledgeReviewerReject = firstPledgeReviewerReject;
    }

    public String getFirstPledgeReviewerRejectReason() {
        return firstPledgeReviewerRejectReason;
    }

    public void setFirstPledgeReviewerRejectReason(String firstPledgeReviewerRejectReason) {
        this.firstPledgeReviewerRejectReason = firstPledgeReviewerRejectReason;
    }

    public ZonedDateTime getFirstPledgeReviewedRejectedDate() {
        return firstPledgeReviewedRejectedDate;
    }

    public void setFirstPledgeReviewedRejectedDate(ZonedDateTime firstPledgeReviewedRejectedDate) {
        this.firstPledgeReviewedRejectedDate = firstPledgeReviewedRejectedDate;
    }

    public String getSecondPledgeReviewerAccept() {
        return secondPledgeReviewerAccept;
    }

    public void setSecondPledgeReviewerAccept(String secondPledgeReviewerAccept) {
        this.secondPledgeReviewerAccept = secondPledgeReviewerAccept;
    }

    public ZonedDateTime getSecondPledgeReviewedAcceptDate() {
        return secondPledgeReviewedAcceptDate;
    }

    public void setSecondPledgeReviewedAcceptDate(ZonedDateTime secondPledgeReviewedAcceptDate) {
        this.secondPledgeReviewedAcceptDate = secondPledgeReviewedAcceptDate;
    }

    public String getSecondPledgeReviewerReject() {
        return secondPledgeReviewerReject;
    }

    public void setSecondPledgeReviewerReject(String secondPledgeReviewerReject) {
        this.secondPledgeReviewerReject = secondPledgeReviewerReject;
    }

    public String getSecondPledgeReviewerRejectReason() {
        return secondPledgeReviewerRejectReason;
    }

    public void setSecondPledgeReviewerRejectReason(String secondPledgeReviewerRejectReason) {
        this.secondPledgeReviewerRejectReason = secondPledgeReviewerRejectReason;
    }

    public ZonedDateTime getSecondPledgeReviewedRejectedDate() {
        return secondPledgeReviewedRejectedDate;
    }

    public void setSecondPledgeReviewedRejectedDate(ZonedDateTime secondPledgeReviewedRejectedDate) {
        this.secondPledgeReviewedRejectedDate = secondPledgeReviewedRejectedDate;
    }

    public String getFirstFiducaryReviewerAccept() {
        return firstFiducaryReviewerAccept;
    }

    public void setFirstFiducaryReviewerAccept(String firstFiducaryReviewerAccept) {
        this.firstFiducaryReviewerAccept = firstFiducaryReviewerAccept;
    }

    public ZonedDateTime getFirstFiducaryReviewedAcceptDate() {
        return firstFiducaryReviewedAcceptDate;
    }

    public void setFirstFiducaryReviewedAcceptDate(ZonedDateTime firstFiducaryReviewedAcceptDate) {
        this.firstFiducaryReviewedAcceptDate = firstFiducaryReviewedAcceptDate;
    }

    public String getFirstFiducaryReviewerReject() {
        return firstFiducaryReviewerReject;
    }

    public void setFirstFiducaryReviewerReject(String firstFiducaryReviewerReject) {
        this.firstFiducaryReviewerReject = firstFiducaryReviewerReject;
    }

    public String getFirstFiducaryReviewerRejectReason() {
        return firstFiducaryReviewerRejectReason;
    }

    public void setFirstFiducaryReviewerRejectReason(String firstFiducaryReviewerRejectReason) {
        this.firstFiducaryReviewerRejectReason = firstFiducaryReviewerRejectReason;
    }

    public ZonedDateTime getFirstFiducaryReviewedRejectedDate() {
        return firstFiducaryReviewedRejectedDate;
    }

    public void setFirstFiducaryReviewedRejectedDate(ZonedDateTime firstFiducaryReviewedRejectedDate) {
        this.firstFiducaryReviewedRejectedDate = firstFiducaryReviewedRejectedDate;
    }

    public String getSecondFiducaryReviewerAccept() {
        return secondFiducaryReviewerAccept;
    }

    public void setSecondFiducaryReviewerAccept(String secondFiducaryReviewerAccept) {
        this.secondFiducaryReviewerAccept = secondFiducaryReviewerAccept;
    }

    public ZonedDateTime getSecondPFiducaryReviewedAcceptDate() {
        return secondPFiducaryReviewedAcceptDate;
    }

    public void setSecondPFiducaryReviewedAcceptDate(ZonedDateTime secondPFiducaryReviewedAcceptDate) {
        this.secondPFiducaryReviewedAcceptDate = secondPFiducaryReviewedAcceptDate;
    }

    public String getSecondFiducaryReviewerReject() {
        return secondFiducaryReviewerReject;
    }

    public void setSecondFiducaryReviewerReject(String secondFiducaryReviewerReject) {
        this.secondFiducaryReviewerReject = secondFiducaryReviewerReject;
    }

    public String getSecondFiducaryReviewerRejectReason() {
        return secondFiducaryReviewerRejectReason;
    }

    public void setSecondFiducaryReviewerRejectReason(String secondFiducaryReviewerRejectReason) {
        this.secondFiducaryReviewerRejectReason = secondFiducaryReviewerRejectReason;
    }

    public ZonedDateTime getSecondFiducaryReviewedRejectedDate() {
        return secondFiducaryReviewedRejectedDate;
    }

    public void setSecondFiducaryReviewedRejectedDate(ZonedDateTime secondFiducaryReviewedRejectedDate) {
        this.secondFiducaryReviewedRejectedDate = secondFiducaryReviewedRejectedDate;
    }

    public String getFirstOverDraftReviewerAccept() {
        return firstOverDraftReviewerAccept;
    }

    public void setFirstOverDraftReviewerAccept(String firstOverDraftReviewerAccept) {
        this.firstOverDraftReviewerAccept = firstOverDraftReviewerAccept;
    }

    public ZonedDateTime getFirstOverDraftReviewedAcceptDate() {
        return firstOverDraftReviewedAcceptDate;
    }

    public void setFirstOverDraftReviewedAcceptDate(ZonedDateTime firstOverDraftReviewedAcceptDate) {
        this.firstOverDraftReviewedAcceptDate = firstOverDraftReviewedAcceptDate;
    }

    public String getFirstOverDraftReviewerReject() {
        return firstOverDraftReviewerReject;
    }

    public void setFirstOverDraftReviewerReject(String firstOverDraftReviewerReject) {
        this.firstOverDraftReviewerReject = firstOverDraftReviewerReject;
    }

    public String getFirstOverDraftReviewerRejectReason() {
        return firstOverDraftReviewerRejectReason;
    }

    public void setFirstOverDraftReviewerRejectReason(String firstOverDraftReviewerRejectReason) {
        this.firstOverDraftReviewerRejectReason = firstOverDraftReviewerRejectReason;
    }

    public ZonedDateTime getFirstOverDraftReviewedRejectedDate() {
        return firstOverDraftReviewedRejectedDate;
    }

    public void setFirstOverDraftReviewedRejectedDate(ZonedDateTime firstOverDraftReviewedRejectedDate) {
        this.firstOverDraftReviewedRejectedDate = firstOverDraftReviewedRejectedDate;
    }

    public String getSecondOverDraftReviewerAccept() {
        return secondOverDraftReviewerAccept;
    }

    public void setSecondOverDraftReviewerAccept(String secondOverDraftReviewerAccept) {
        this.secondOverDraftReviewerAccept = secondOverDraftReviewerAccept;
    }

    public ZonedDateTime getSecondOverDraftReviewedAcceptDate() {
        return secondOverDraftReviewedAcceptDate;
    }

    public void setSecondOverDraftReviewedAcceptDate(ZonedDateTime secondOverDraftReviewedAcceptDate) {
        this.secondOverDraftReviewedAcceptDate = secondOverDraftReviewedAcceptDate;
    }

    public String getSecondOverDraftReviewerReject() {
        return secondOverDraftReviewerReject;
    }

    public void setSecondOverDraftReviewerReject(String secondOverDraftReviewerReject) {
        this.secondOverDraftReviewerReject = secondOverDraftReviewerReject;
    }

    public String getSecondOverDraftReviewerRejectReason() {
        return secondOverDraftReviewerRejectReason;
    }

    public void setSecondOverDraftReviewerRejectReason(String secondOverDraftReviewerRejectReason) {
        this.secondOverDraftReviewerRejectReason = secondOverDraftReviewerRejectReason;
    }

    public ZonedDateTime getSecondOverDraftReviewedRejectedDate() {
        return secondOverDraftReviewedRejectedDate;
    }

    public void setSecondOverDraftReviewedRejectedDate(ZonedDateTime secondOverDraftReviewedRejectedDate) {
        this.secondOverDraftReviewedRejectedDate = secondOverDraftReviewedRejectedDate;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TransactionReviewDTO)) {
            return false;
        }

        TransactionReviewDTO transactionReviewDTO = (TransactionReviewDTO) o;
        if (this.id == null) {
            return false;
        }
        return Objects.equals(this.id, transactionReviewDTO.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(this.id);
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "TransactionReviewDTO{" +
            "id=" + getId() +
            ", tranId=" + getTranId() +
            ", firstPledgeReviewerAccept='" + getFirstPledgeReviewerAccept() + "'" +
            ", firstPledgeReviewedAcceptDate='" + getFirstPledgeReviewedAcceptDate() + "'" +
            ", firstPledgeReviewerReject='" + getFirstPledgeReviewerReject() + "'" +
            ", firstPledgeReviewerRejectReason='" + getFirstPledgeReviewerRejectReason() + "'" +
            ", firstPledgeReviewedRejectedDate='" + getFirstPledgeReviewedRejectedDate() + "'" +
            ", secondPledgeReviewerAccept='" + getSecondPledgeReviewerAccept() + "'" +
            ", secondPledgeReviewedAcceptDate='" + getSecondPledgeReviewedAcceptDate() + "'" +
            ", secondPledgeReviewerReject='" + getSecondPledgeReviewerReject() + "'" +
            ", secondPledgeReviewerRejectReason='" + getSecondPledgeReviewerRejectReason() + "'" +
            ", secondPledgeReviewedRejectedDate='" + getSecondPledgeReviewedRejectedDate() + "'" +
            ", firstFiducaryReviewerAccept='" + getFirstFiducaryReviewerAccept() + "'" +
            ", firstFiducaryReviewedAcceptDate='" + getFirstFiducaryReviewedAcceptDate() + "'" +
            ", firstFiducaryReviewerReject='" + getFirstFiducaryReviewerReject() + "'" +
            ", firstFiducaryReviewerRejectReason='" + getFirstFiducaryReviewerRejectReason() + "'" +
            ", firstFiducaryReviewedRejectedDate='" + getFirstFiducaryReviewedRejectedDate() + "'" +
            ", secondFiducaryReviewerAccept='" + getSecondFiducaryReviewerAccept() + "'" +
            ", secondPFiducaryReviewedAcceptDate='" + getSecondPFiducaryReviewedAcceptDate() + "'" +
            ", secondFiducaryReviewerReject='" + getSecondFiducaryReviewerReject() + "'" +
            ", secondFiducaryReviewerRejectReason='" + getSecondFiducaryReviewerRejectReason() + "'" +
            ", secondFiducaryReviewedRejectedDate='" + getSecondFiducaryReviewedRejectedDate() + "'" +
            ", firstOverDraftReviewerAccept='" + getFirstOverDraftReviewerAccept() + "'" +
            ", firstOverDraftReviewedAcceptDate='" + getFirstOverDraftReviewedAcceptDate() + "'" +
            ", firstOverDraftReviewerReject='" + getFirstOverDraftReviewerReject() + "'" +
            ", firstOverDraftReviewerRejectReason='" + getFirstOverDraftReviewerRejectReason() + "'" +
            ", firstOverDraftReviewedRejectedDate='" + getFirstOverDraftReviewedRejectedDate() + "'" +
            ", secondOverDraftReviewerAccept='" + getSecondOverDraftReviewerAccept() + "'" +
            ", secondOverDraftReviewedAcceptDate='" + getSecondOverDraftReviewedAcceptDate() + "'" +
            ", secondOverDraftReviewerReject='" + getSecondOverDraftReviewerReject() + "'" +
            ", secondOverDraftReviewerRejectReason='" + getSecondOverDraftReviewerRejectReason() + "'" +
            ", secondOverDraftReviewedRejectedDate='" + getSecondOverDraftReviewedRejectedDate() + "'" +
            "}";
    }
}
