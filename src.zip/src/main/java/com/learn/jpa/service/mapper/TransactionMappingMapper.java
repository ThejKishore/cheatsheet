package com.learn.jpa.service.mapper;

import com.learn.jpa.domain.TransactionMapping;
import com.learn.jpa.service.dto.TransactionMappingDTO;
import org.mapstruct.*;

/**
 * Mapper for the entity {@link TransactionMapping} and its DTO {@link TransactionMappingDTO}.
 */
@Mapper(componentModel = "spring")
public interface TransactionMappingMapper extends EntityMapper<TransactionMappingDTO, TransactionMapping> {}
