package com.learn.jpa.repository;

import com.learn.jpa.domain.TransferFromAccnt;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the TransferFromAccnt entity.
 */
@SuppressWarnings("unused")
@Repository
public interface TransferFromAccntRepository extends JpaRepository<TransferFromAccnt, Long> {}
