package com.learn.jpa.repository;

import com.learn.jpa.domain.WireTransaction;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the WireTransaction entity.
 */
@SuppressWarnings("unused")
@Repository
public interface WireTransactionRepository extends JpaRepository<WireTransaction, Long> {}
