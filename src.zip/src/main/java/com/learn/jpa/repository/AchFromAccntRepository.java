package com.learn.jpa.repository;

import com.learn.jpa.domain.AchFromAccnt;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the AchFromAccnt entity.
 */
@SuppressWarnings("unused")
@Repository
public interface AchFromAccntRepository extends JpaRepository<AchFromAccnt, Long> {}
