package com.learn.jpa.repository;

import com.learn.jpa.domain.AchTransaction;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the AchTransaction entity.
 */
@SuppressWarnings("unused")
@Repository
public interface AchTransactionRepository extends JpaRepository<AchTransaction, Long> {}
