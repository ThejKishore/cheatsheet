package com.learn.jpa.repository;

import com.learn.jpa.domain.WireFromAccnt;
import org.springframework.data.jpa.repository.*;
import org.springframework.stereotype.Repository;

/**
 * Spring Data JPA repository for the WireFromAccnt entity.
 */
@SuppressWarnings("unused")
@Repository
public interface WireFromAccntRepository extends JpaRepository<WireFromAccnt, Long> {}
