package com.learn.jpa.web.rest;

import com.learn.jpa.repository.AchFromAccntRepository;
import com.learn.jpa.service.AchFromAccntService;
import com.learn.jpa.service.dto.AchFromAccntDTO;
import com.learn.jpa.web.rest.errors.BadRequestAlertException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotNull;
import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import tech.jhipster.web.util.HeaderUtil;
import tech.jhipster.web.util.ResponseUtil;

/**
 * REST controller for managing {@link com.learn.jpa.domain.AchFromAccnt}.
 */
@RestController
@RequestMapping("/api/ach-from-accnts")
public class AchFromAccntResource {

    private final Logger log = LoggerFactory.getLogger(AchFromAccntResource.class);

    private static final String ENTITY_NAME = "achFromAccnt";

    @Value("${jhipster.clientApp.name}")
    private String applicationName;

    private final AchFromAccntService achFromAccntService;

    private final AchFromAccntRepository achFromAccntRepository;

    public AchFromAccntResource(AchFromAccntService achFromAccntService, AchFromAccntRepository achFromAccntRepository) {
        this.achFromAccntService = achFromAccntService;
        this.achFromAccntRepository = achFromAccntRepository;
    }

    /**
     * {@code POST  /ach-from-accnts} : Create a new achFromAccnt.
     *
     * @param achFromAccntDTO the achFromAccntDTO to create.
     * @return the {@link ResponseEntity} with status {@code 201 (Created)} and with body the new achFromAccntDTO, or with status {@code 400 (Bad Request)} if the achFromAccnt has already an ID.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PostMapping("")
    public ResponseEntity<AchFromAccntDTO> createAchFromAccnt(@Valid @RequestBody AchFromAccntDTO achFromAccntDTO)
        throws URISyntaxException {
        log.debug("REST request to save AchFromAccnt : {}", achFromAccntDTO);
        if (achFromAccntDTO.getId() != null) {
            throw new BadRequestAlertException("A new achFromAccnt cannot already have an ID", ENTITY_NAME, "idexists");
        }
        AchFromAccntDTO result = achFromAccntService.save(achFromAccntDTO);
        return ResponseEntity
            .created(new URI("/api/ach-from-accnts/" + result.getId()))
            .headers(HeaderUtil.createEntityCreationAlert(applicationName, true, ENTITY_NAME, result.getId().toString()))
            .body(result);
    }

    /**
     * {@code PUT  /ach-from-accnts/:id} : Updates an existing achFromAccnt.
     *
     * @param id the id of the achFromAccntDTO to save.
     * @param achFromAccntDTO the achFromAccntDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated achFromAccntDTO,
     * or with status {@code 400 (Bad Request)} if the achFromAccntDTO is not valid,
     * or with status {@code 500 (Internal Server Error)} if the achFromAccntDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PutMapping("/{id}")
    public ResponseEntity<AchFromAccntDTO> updateAchFromAccnt(
        @PathVariable(value = "id", required = false) final Long id,
        @Valid @RequestBody AchFromAccntDTO achFromAccntDTO
    ) throws URISyntaxException {
        log.debug("REST request to update AchFromAccnt : {}, {}", id, achFromAccntDTO);
        if (achFromAccntDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, achFromAccntDTO.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!achFromAccntRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        AchFromAccntDTO result = achFromAccntService.update(achFromAccntDTO);
        return ResponseEntity
            .ok()
            .headers(HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, achFromAccntDTO.getId().toString()))
            .body(result);
    }

    /**
     * {@code PATCH  /ach-from-accnts/:id} : Partial updates given fields of an existing achFromAccnt, field will ignore if it is null
     *
     * @param id the id of the achFromAccntDTO to save.
     * @param achFromAccntDTO the achFromAccntDTO to update.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the updated achFromAccntDTO,
     * or with status {@code 400 (Bad Request)} if the achFromAccntDTO is not valid,
     * or with status {@code 404 (Not Found)} if the achFromAccntDTO is not found,
     * or with status {@code 500 (Internal Server Error)} if the achFromAccntDTO couldn't be updated.
     * @throws URISyntaxException if the Location URI syntax is incorrect.
     */
    @PatchMapping(value = "/{id}", consumes = { "application/json", "application/merge-patch+json" })
    public ResponseEntity<AchFromAccntDTO> partialUpdateAchFromAccnt(
        @PathVariable(value = "id", required = false) final Long id,
        @NotNull @RequestBody AchFromAccntDTO achFromAccntDTO
    ) throws URISyntaxException {
        log.debug("REST request to partial update AchFromAccnt partially : {}, {}", id, achFromAccntDTO);
        if (achFromAccntDTO.getId() == null) {
            throw new BadRequestAlertException("Invalid id", ENTITY_NAME, "idnull");
        }
        if (!Objects.equals(id, achFromAccntDTO.getId())) {
            throw new BadRequestAlertException("Invalid ID", ENTITY_NAME, "idinvalid");
        }

        if (!achFromAccntRepository.existsById(id)) {
            throw new BadRequestAlertException("Entity not found", ENTITY_NAME, "idnotfound");
        }

        Optional<AchFromAccntDTO> result = achFromAccntService.partialUpdate(achFromAccntDTO);

        return ResponseUtil.wrapOrNotFound(
            result,
            HeaderUtil.createEntityUpdateAlert(applicationName, true, ENTITY_NAME, achFromAccntDTO.getId().toString())
        );
    }

    /**
     * {@code GET  /ach-from-accnts} : get all the achFromAccnts.
     *
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and the list of achFromAccnts in body.
     */
    @GetMapping("")
    public List<AchFromAccntDTO> getAllAchFromAccnts() {
        log.debug("REST request to get all AchFromAccnts");
        return achFromAccntService.findAll();
    }

    /**
     * {@code GET  /ach-from-accnts/:id} : get the "id" achFromAccnt.
     *
     * @param id the id of the achFromAccntDTO to retrieve.
     * @return the {@link ResponseEntity} with status {@code 200 (OK)} and with body the achFromAccntDTO, or with status {@code 404 (Not Found)}.
     */
    @GetMapping("/{id}")
    public ResponseEntity<AchFromAccntDTO> getAchFromAccnt(@PathVariable("id") Long id) {
        log.debug("REST request to get AchFromAccnt : {}", id);
        Optional<AchFromAccntDTO> achFromAccntDTO = achFromAccntService.findOne(id);
        return ResponseUtil.wrapOrNotFound(achFromAccntDTO);
    }

    /**
     * {@code DELETE  /ach-from-accnts/:id} : delete the "id" achFromAccnt.
     *
     * @param id the id of the achFromAccntDTO to delete.
     * @return the {@link ResponseEntity} with status {@code 204 (NO_CONTENT)}.
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAchFromAccnt(@PathVariable("id") Long id) {
        log.debug("REST request to delete AchFromAccnt : {}", id);
        achFromAccntService.delete(id);
        return ResponseEntity
            .noContent()
            .headers(HeaderUtil.createEntityDeletionAlert(applicationName, true, ENTITY_NAME, id.toString()))
            .build();
    }
}
