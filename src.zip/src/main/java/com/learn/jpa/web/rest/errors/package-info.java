/**
 * Rest layer error handling.
 */
package com.learn.jpa.web.rest.errors;
