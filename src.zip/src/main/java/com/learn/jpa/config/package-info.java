/**
 * Application configuration.
 */
package com.learn.jpa.config;
