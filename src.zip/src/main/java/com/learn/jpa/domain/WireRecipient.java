package com.learn.jpa.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * A WireRecipient.
 */
@Entity
@Table(name = "wire_recipient")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@SuppressWarnings("common-java:DuplicatedBlocks")
public class WireRecipient implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "id")
    private Long id;

    @NotNull
    @Column(name = "recipient_id", nullable = false, unique = true)
    private Long recipientId;

    @Column(name = "recipeint_name")
    private String recipeintName;

    @Column(name = "recipient_address")
    private String recipientAddress;

    @Column(name = "recipient_country")
    private String recipientCountry;

    @Column(name = "recipient_state")
    private String recipientState;

    @Column(name = "recipient_city")
    private String recipientCity;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "wireRecipient")
    @Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
    @JsonIgnoreProperties(value = { "wireRecipient" }, allowSetters = true)
    private Set<WireBeneficiary> wireBeneficiaries = new HashSet<>();

    @JsonIgnoreProperties(value = { "transactionMapping", "wireRecipient", "wireFromAccnts" }, allowSetters = true)
    @OneToOne(fetch = FetchType.LAZY, mappedBy = "wireRecipient")
    private WireTransaction wireTransaction;

    // jhipster-needle-entity-add-field - JHipster will add fields here

    public Long getId() {
        return this.id;
    }

    public WireRecipient id(Long id) {
        this.setId(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getRecipientId() {
        return this.recipientId;
    }

    public WireRecipient recipientId(Long recipientId) {
        this.setRecipientId(recipientId);
        return this;
    }

    public void setRecipientId(Long recipientId) {
        this.recipientId = recipientId;
    }

    public String getRecipeintName() {
        return this.recipeintName;
    }

    public WireRecipient recipeintName(String recipeintName) {
        this.setRecipeintName(recipeintName);
        return this;
    }

    public void setRecipeintName(String recipeintName) {
        this.recipeintName = recipeintName;
    }

    public String getRecipientAddress() {
        return this.recipientAddress;
    }

    public WireRecipient recipientAddress(String recipientAddress) {
        this.setRecipientAddress(recipientAddress);
        return this;
    }

    public void setRecipientAddress(String recipientAddress) {
        this.recipientAddress = recipientAddress;
    }

    public String getRecipientCountry() {
        return this.recipientCountry;
    }

    public WireRecipient recipientCountry(String recipientCountry) {
        this.setRecipientCountry(recipientCountry);
        return this;
    }

    public void setRecipientCountry(String recipientCountry) {
        this.recipientCountry = recipientCountry;
    }

    public String getRecipientState() {
        return this.recipientState;
    }

    public WireRecipient recipientState(String recipientState) {
        this.setRecipientState(recipientState);
        return this;
    }

    public void setRecipientState(String recipientState) {
        this.recipientState = recipientState;
    }

    public String getRecipientCity() {
        return this.recipientCity;
    }

    public WireRecipient recipientCity(String recipientCity) {
        this.setRecipientCity(recipientCity);
        return this;
    }

    public void setRecipientCity(String recipientCity) {
        this.recipientCity = recipientCity;
    }

    public Set<WireBeneficiary> getWireBeneficiaries() {
        return this.wireBeneficiaries;
    }

    public void setWireBeneficiaries(Set<WireBeneficiary> wireBeneficiaries) {
        if (this.wireBeneficiaries != null) {
            this.wireBeneficiaries.forEach(i -> i.setWireRecipient(null));
        }
        if (wireBeneficiaries != null) {
            wireBeneficiaries.forEach(i -> i.setWireRecipient(this));
        }
        this.wireBeneficiaries = wireBeneficiaries;
    }

    public WireRecipient wireBeneficiaries(Set<WireBeneficiary> wireBeneficiaries) {
        this.setWireBeneficiaries(wireBeneficiaries);
        return this;
    }

    public WireRecipient addWireBeneficiary(WireBeneficiary wireBeneficiary) {
        this.wireBeneficiaries.add(wireBeneficiary);
        wireBeneficiary.setWireRecipient(this);
        return this;
    }

    public WireRecipient removeWireBeneficiary(WireBeneficiary wireBeneficiary) {
        this.wireBeneficiaries.remove(wireBeneficiary);
        wireBeneficiary.setWireRecipient(null);
        return this;
    }

    public WireTransaction getWireTransaction() {
        return this.wireTransaction;
    }

    public void setWireTransaction(WireTransaction wireTransaction) {
        if (this.wireTransaction != null) {
            this.wireTransaction.setWireRecipient(null);
        }
        if (wireTransaction != null) {
            wireTransaction.setWireRecipient(this);
        }
        this.wireTransaction = wireTransaction;
    }

    public WireRecipient wireTransaction(WireTransaction wireTransaction) {
        this.setWireTransaction(wireTransaction);
        return this;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof WireRecipient)) {
            return false;
        }
        return getId() != null && getId().equals(((WireRecipient) o).getId());
    }

    @Override
    public int hashCode() {
        // see https://vladmihalcea.com/how-to-implement-equals-and-hashcode-using-the-jpa-entity-identifier/
        return getClass().hashCode();
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "WireRecipient{" +
            "id=" + getId() +
            ", recipientId=" + getRecipientId() +
            ", recipeintName='" + getRecipeintName() + "'" +
            ", recipientAddress='" + getRecipientAddress() + "'" +
            ", recipientCountry='" + getRecipientCountry() + "'" +
            ", recipientState='" + getRecipientState() + "'" +
            ", recipientCity='" + getRecipientCity() + "'" +
            "}";
    }
}
