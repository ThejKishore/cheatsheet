package com.learn.jpa.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.io.Serializable;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * A TransactionMapping.
 */
@Entity
@Table(name = "transaction_mapping")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@SuppressWarnings("common-java:DuplicatedBlocks")
public class TransactionMapping implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "id")
    private Long id;

    @NotNull
    @Column(name = "mapping_id", nullable = false, unique = true)
    private Long mappingId;

    @Column(name = "tran_id")
    private Long tranId;

    @Column(name = "tran_type_id")
    private Long tranTypeId;

    @Column(name = "tran_type")
    private String tranType;

    @JsonIgnoreProperties(value = { "transactionMapping", "transactionApproval", "transactionReview" }, allowSetters = true)
    @OneToOne(fetch = FetchType.LAZY, mappedBy = "transactionMapping")
    private Transaction transaction;

    @JsonIgnoreProperties(value = { "transactionMapping", "achRecipient", "achFromAccnts" }, allowSetters = true)
    @OneToOne(fetch = FetchType.LAZY, mappedBy = "transactionMapping")
    private AchTransaction achTransaction;

    @JsonIgnoreProperties(value = { "transactionMapping", "wireRecipient", "wireFromAccnts" }, allowSetters = true)
    @OneToOne(fetch = FetchType.LAZY, mappedBy = "transactionMapping")
    private WireTransaction wireTransaction;

    @JsonIgnoreProperties(value = { "transactionMapping", "transferFromAccnts", "transferToAccnts" }, allowSetters = true)
    @OneToOne(fetch = FetchType.LAZY, mappedBy = "transactionMapping")
    private TransferTransaction transferTransaction;

    // jhipster-needle-entity-add-field - JHipster will add fields here

    public Long getId() {
        return this.id;
    }

    public TransactionMapping id(Long id) {
        this.setId(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getMappingId() {
        return this.mappingId;
    }

    public TransactionMapping mappingId(Long mappingId) {
        this.setMappingId(mappingId);
        return this;
    }

    public void setMappingId(Long mappingId) {
        this.mappingId = mappingId;
    }

    public Long getTranId() {
        return this.tranId;
    }

    public TransactionMapping tranId(Long tranId) {
        this.setTranId(tranId);
        return this;
    }

    public void setTranId(Long tranId) {
        this.tranId = tranId;
    }

    public Long getTranTypeId() {
        return this.tranTypeId;
    }

    public TransactionMapping tranTypeId(Long tranTypeId) {
        this.setTranTypeId(tranTypeId);
        return this;
    }

    public void setTranTypeId(Long tranTypeId) {
        this.tranTypeId = tranTypeId;
    }

    public String getTranType() {
        return this.tranType;
    }

    public TransactionMapping tranType(String tranType) {
        this.setTranType(tranType);
        return this;
    }

    public void setTranType(String tranType) {
        this.tranType = tranType;
    }

    public Transaction getTransaction() {
        return this.transaction;
    }

    public void setTransaction(Transaction transaction) {
        if (this.transaction != null) {
            this.transaction.setTransactionMapping(null);
        }
        if (transaction != null) {
            transaction.setTransactionMapping(this);
        }
        this.transaction = transaction;
    }

    public TransactionMapping transaction(Transaction transaction) {
        this.setTransaction(transaction);
        return this;
    }

    public AchTransaction getAchTransaction() {
        return this.achTransaction;
    }

    public void setAchTransaction(AchTransaction achTransaction) {
        if (this.achTransaction != null) {
            this.achTransaction.setTransactionMapping(null);
        }
        if (achTransaction != null) {
            achTransaction.setTransactionMapping(this);
        }
        this.achTransaction = achTransaction;
    }

    public TransactionMapping achTransaction(AchTransaction achTransaction) {
        this.setAchTransaction(achTransaction);
        return this;
    }

    public WireTransaction getWireTransaction() {
        return this.wireTransaction;
    }

    public void setWireTransaction(WireTransaction wireTransaction) {
        if (this.wireTransaction != null) {
            this.wireTransaction.setTransactionMapping(null);
        }
        if (wireTransaction != null) {
            wireTransaction.setTransactionMapping(this);
        }
        this.wireTransaction = wireTransaction;
    }

    public TransactionMapping wireTransaction(WireTransaction wireTransaction) {
        this.setWireTransaction(wireTransaction);
        return this;
    }

    public TransferTransaction getTransferTransaction() {
        return this.transferTransaction;
    }

    public void setTransferTransaction(TransferTransaction transferTransaction) {
        if (this.transferTransaction != null) {
            this.transferTransaction.setTransactionMapping(null);
        }
        if (transferTransaction != null) {
            transferTransaction.setTransactionMapping(this);
        }
        this.transferTransaction = transferTransaction;
    }

    public TransactionMapping transferTransaction(TransferTransaction transferTransaction) {
        this.setTransferTransaction(transferTransaction);
        return this;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TransactionMapping)) {
            return false;
        }
        return getId() != null && getId().equals(((TransactionMapping) o).getId());
    }

    @Override
    public int hashCode() {
        // see https://vladmihalcea.com/how-to-implement-equals-and-hashcode-using-the-jpa-entity-identifier/
        return getClass().hashCode();
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "TransactionMapping{" +
            "id=" + getId() +
            ", mappingId=" + getMappingId() +
            ", tranId=" + getTranId() +
            ", tranTypeId=" + getTranTypeId() +
            ", tranType='" + getTranType() + "'" +
            "}";
    }
}
