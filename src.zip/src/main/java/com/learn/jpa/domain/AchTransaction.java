package com.learn.jpa.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * A AchTransaction.
 */
@Entity
@Table(name = "ach_transaction")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@SuppressWarnings("common-java:DuplicatedBlocks")
public class AchTransaction implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "id")
    private Long id;

    @NotNull
    @Column(name = "ach_tran_id", nullable = false, unique = true)
    private Long achTranId;

    @JsonIgnoreProperties(value = { "transaction", "achTransaction", "wireTransaction", "transferTransaction" }, allowSetters = true)
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(unique = true)
    private TransactionMapping transactionMapping;

    @JsonIgnoreProperties(value = { "achTransaction" }, allowSetters = true)
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(unique = true)
    private AchRecipient achRecipient;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "achTransaction")
    @Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
    @JsonIgnoreProperties(value = { "achTransaction" }, allowSetters = true)
    private Set<AchFromAccnt> achFromAccnts = new HashSet<>();

    // jhipster-needle-entity-add-field - JHipster will add fields here

    public Long getId() {
        return this.id;
    }

    public AchTransaction id(Long id) {
        this.setId(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getAchTranId() {
        return this.achTranId;
    }

    public AchTransaction achTranId(Long achTranId) {
        this.setAchTranId(achTranId);
        return this;
    }

    public void setAchTranId(Long achTranId) {
        this.achTranId = achTranId;
    }

    public TransactionMapping getTransactionMapping() {
        return this.transactionMapping;
    }

    public void setTransactionMapping(TransactionMapping transactionMapping) {
        this.transactionMapping = transactionMapping;
    }

    public AchTransaction transactionMapping(TransactionMapping transactionMapping) {
        this.setTransactionMapping(transactionMapping);
        return this;
    }

    public AchRecipient getAchRecipient() {
        return this.achRecipient;
    }

    public void setAchRecipient(AchRecipient achRecipient) {
        this.achRecipient = achRecipient;
    }

    public AchTransaction achRecipient(AchRecipient achRecipient) {
        this.setAchRecipient(achRecipient);
        return this;
    }

    public Set<AchFromAccnt> getAchFromAccnts() {
        return this.achFromAccnts;
    }

    public void setAchFromAccnts(Set<AchFromAccnt> achFromAccnts) {
        if (this.achFromAccnts != null) {
            this.achFromAccnts.forEach(i -> i.setAchTransaction(null));
        }
        if (achFromAccnts != null) {
            achFromAccnts.forEach(i -> i.setAchTransaction(this));
        }
        this.achFromAccnts = achFromAccnts;
    }

    public AchTransaction achFromAccnts(Set<AchFromAccnt> achFromAccnts) {
        this.setAchFromAccnts(achFromAccnts);
        return this;
    }

    public AchTransaction addAchFromAccnt(AchFromAccnt achFromAccnt) {
        this.achFromAccnts.add(achFromAccnt);
        achFromAccnt.setAchTransaction(this);
        return this;
    }

    public AchTransaction removeAchFromAccnt(AchFromAccnt achFromAccnt) {
        this.achFromAccnts.remove(achFromAccnt);
        achFromAccnt.setAchTransaction(null);
        return this;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof AchTransaction)) {
            return false;
        }
        return getId() != null && getId().equals(((AchTransaction) o).getId());
    }

    @Override
    public int hashCode() {
        // see https://vladmihalcea.com/how-to-implement-equals-and-hashcode-using-the-jpa-entity-identifier/
        return getClass().hashCode();
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "AchTransaction{" +
            "id=" + getId() +
            ", achTranId=" + getAchTranId() +
            "}";
    }
}
