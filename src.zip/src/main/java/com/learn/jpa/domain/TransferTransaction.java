package com.learn.jpa.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * A TransferTransaction.
 */
@Entity
@Table(name = "transfer_transaction")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@SuppressWarnings("common-java:DuplicatedBlocks")
public class TransferTransaction implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "id")
    private Long id;

    @NotNull
    @Column(name = "transfer_tran_id", nullable = false, unique = true)
    private Long transferTranId;

    @JsonIgnoreProperties(value = { "transaction", "achTransaction", "wireTransaction", "transferTransaction" }, allowSetters = true)
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(unique = true)
    private TransactionMapping transactionMapping;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "transferTransaction")
    @Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
    @JsonIgnoreProperties(value = { "transferTransaction" }, allowSetters = true)
    private Set<TransferFromAccnt> transferFromAccnts = new HashSet<>();

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "transferTransaction")
    @Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
    @JsonIgnoreProperties(value = { "transferTransaction" }, allowSetters = true)
    private Set<TransferToAccnt> transferToAccnts = new HashSet<>();

    // jhipster-needle-entity-add-field - JHipster will add fields here

    public Long getId() {
        return this.id;
    }

    public TransferTransaction id(Long id) {
        this.setId(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getTransferTranId() {
        return this.transferTranId;
    }

    public TransferTransaction transferTranId(Long transferTranId) {
        this.setTransferTranId(transferTranId);
        return this;
    }

    public void setTransferTranId(Long transferTranId) {
        this.transferTranId = transferTranId;
    }

    public TransactionMapping getTransactionMapping() {
        return this.transactionMapping;
    }

    public void setTransactionMapping(TransactionMapping transactionMapping) {
        this.transactionMapping = transactionMapping;
    }

    public TransferTransaction transactionMapping(TransactionMapping transactionMapping) {
        this.setTransactionMapping(transactionMapping);
        return this;
    }

    public Set<TransferFromAccnt> getTransferFromAccnts() {
        return this.transferFromAccnts;
    }

    public void setTransferFromAccnts(Set<TransferFromAccnt> transferFromAccnts) {
        if (this.transferFromAccnts != null) {
            this.transferFromAccnts.forEach(i -> i.setTransferTransaction(null));
        }
        if (transferFromAccnts != null) {
            transferFromAccnts.forEach(i -> i.setTransferTransaction(this));
        }
        this.transferFromAccnts = transferFromAccnts;
    }

    public TransferTransaction transferFromAccnts(Set<TransferFromAccnt> transferFromAccnts) {
        this.setTransferFromAccnts(transferFromAccnts);
        return this;
    }

    public TransferTransaction addTransferFromAccnt(TransferFromAccnt transferFromAccnt) {
        this.transferFromAccnts.add(transferFromAccnt);
        transferFromAccnt.setTransferTransaction(this);
        return this;
    }

    public TransferTransaction removeTransferFromAccnt(TransferFromAccnt transferFromAccnt) {
        this.transferFromAccnts.remove(transferFromAccnt);
        transferFromAccnt.setTransferTransaction(null);
        return this;
    }

    public Set<TransferToAccnt> getTransferToAccnts() {
        return this.transferToAccnts;
    }

    public void setTransferToAccnts(Set<TransferToAccnt> transferToAccnts) {
        if (this.transferToAccnts != null) {
            this.transferToAccnts.forEach(i -> i.setTransferTransaction(null));
        }
        if (transferToAccnts != null) {
            transferToAccnts.forEach(i -> i.setTransferTransaction(this));
        }
        this.transferToAccnts = transferToAccnts;
    }

    public TransferTransaction transferToAccnts(Set<TransferToAccnt> transferToAccnts) {
        this.setTransferToAccnts(transferToAccnts);
        return this;
    }

    public TransferTransaction addTransferToAccnt(TransferToAccnt transferToAccnt) {
        this.transferToAccnts.add(transferToAccnt);
        transferToAccnt.setTransferTransaction(this);
        return this;
    }

    public TransferTransaction removeTransferToAccnt(TransferToAccnt transferToAccnt) {
        this.transferToAccnts.remove(transferToAccnt);
        transferToAccnt.setTransferTransaction(null);
        return this;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TransferTransaction)) {
            return false;
        }
        return getId() != null && getId().equals(((TransferTransaction) o).getId());
    }

    @Override
    public int hashCode() {
        // see https://vladmihalcea.com/how-to-implement-equals-and-hashcode-using-the-jpa-entity-identifier/
        return getClass().hashCode();
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "TransferTransaction{" +
            "id=" + getId() +
            ", transferTranId=" + getTransferTranId() +
            "}";
    }
}
