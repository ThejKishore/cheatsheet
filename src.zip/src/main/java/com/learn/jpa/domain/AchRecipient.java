package com.learn.jpa.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.io.Serializable;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * A AchRecipient.
 */
@Entity
@Table(name = "ach_recipient")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@SuppressWarnings("common-java:DuplicatedBlocks")
public class AchRecipient implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "id")
    private Long id;

    @NotNull
    @Column(name = "recipient_id", nullable = false, unique = true)
    private Long recipientId;

    @Column(name = "recipeint_name")
    private String recipeintName;

    @Column(name = "recipient_address")
    private String recipientAddress;

    @Column(name = "recipient_country")
    private String recipientCountry;

    @Column(name = "recipient_state")
    private String recipientState;

    @Column(name = "recipient_city")
    private String recipientCity;

    @JsonIgnoreProperties(value = { "transactionMapping", "achRecipient", "achFromAccnts" }, allowSetters = true)
    @OneToOne(fetch = FetchType.LAZY, mappedBy = "achRecipient")
    private AchTransaction achTransaction;

    // jhipster-needle-entity-add-field - JHipster will add fields here

    public Long getId() {
        return this.id;
    }

    public AchRecipient id(Long id) {
        this.setId(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getRecipientId() {
        return this.recipientId;
    }

    public AchRecipient recipientId(Long recipientId) {
        this.setRecipientId(recipientId);
        return this;
    }

    public void setRecipientId(Long recipientId) {
        this.recipientId = recipientId;
    }

    public String getRecipeintName() {
        return this.recipeintName;
    }

    public AchRecipient recipeintName(String recipeintName) {
        this.setRecipeintName(recipeintName);
        return this;
    }

    public void setRecipeintName(String recipeintName) {
        this.recipeintName = recipeintName;
    }

    public String getRecipientAddress() {
        return this.recipientAddress;
    }

    public AchRecipient recipientAddress(String recipientAddress) {
        this.setRecipientAddress(recipientAddress);
        return this;
    }

    public void setRecipientAddress(String recipientAddress) {
        this.recipientAddress = recipientAddress;
    }

    public String getRecipientCountry() {
        return this.recipientCountry;
    }

    public AchRecipient recipientCountry(String recipientCountry) {
        this.setRecipientCountry(recipientCountry);
        return this;
    }

    public void setRecipientCountry(String recipientCountry) {
        this.recipientCountry = recipientCountry;
    }

    public String getRecipientState() {
        return this.recipientState;
    }

    public AchRecipient recipientState(String recipientState) {
        this.setRecipientState(recipientState);
        return this;
    }

    public void setRecipientState(String recipientState) {
        this.recipientState = recipientState;
    }

    public String getRecipientCity() {
        return this.recipientCity;
    }

    public AchRecipient recipientCity(String recipientCity) {
        this.setRecipientCity(recipientCity);
        return this;
    }

    public void setRecipientCity(String recipientCity) {
        this.recipientCity = recipientCity;
    }

    public AchTransaction getAchTransaction() {
        return this.achTransaction;
    }

    public void setAchTransaction(AchTransaction achTransaction) {
        if (this.achTransaction != null) {
            this.achTransaction.setAchRecipient(null);
        }
        if (achTransaction != null) {
            achTransaction.setAchRecipient(this);
        }
        this.achTransaction = achTransaction;
    }

    public AchRecipient achTransaction(AchTransaction achTransaction) {
        this.setAchTransaction(achTransaction);
        return this;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof AchRecipient)) {
            return false;
        }
        return getId() != null && getId().equals(((AchRecipient) o).getId());
    }

    @Override
    public int hashCode() {
        // see https://vladmihalcea.com/how-to-implement-equals-and-hashcode-using-the-jpa-entity-identifier/
        return getClass().hashCode();
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "AchRecipient{" +
            "id=" + getId() +
            ", recipientId=" + getRecipientId() +
            ", recipeintName='" + getRecipeintName() + "'" +
            ", recipientAddress='" + getRecipientAddress() + "'" +
            ", recipientCountry='" + getRecipientCountry() + "'" +
            ", recipientState='" + getRecipientState() + "'" +
            ", recipientCity='" + getRecipientCity() + "'" +
            "}";
    }
}
