/**
 * Domain objects.
 */
package com.learn.jpa.domain;
