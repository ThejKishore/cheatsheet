package com.learn.jpa.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.time.ZonedDateTime;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * A TransactionApproval.
 */
@Entity
@Table(name = "transaction_approval")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@SuppressWarnings("common-java:DuplicatedBlocks")
public class TransactionApproval implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "id")
    private Long id;

    @NotNull
    @Column(name = "tran_id", nullable = false, unique = true)
    private Long tranId;

    @Column(name = "first_approver")
    private String firstApprover;

    @Column(name = "first_approval_reason")
    private String firstApprovalReason;

    @Column(name = "first_approval_date")
    private ZonedDateTime firstApprovalDate;

    @Column(name = "first_rejector")
    private String firstRejector;

    @Column(name = "first_rejector_reason")
    private String firstRejectorReason;

    @Column(name = "first_rejected_date")
    private ZonedDateTime firstRejectedDate;

    @Column(name = "second_approver")
    private String secondApprover;

    @Column(name = "second_approval_reason")
    private String secondApprovalReason;

    @Column(name = "second_approval_date")
    private ZonedDateTime secondApprovalDate;

    @Column(name = "second_rejector")
    private String secondRejector;

    @Column(name = "second_rejector_reason")
    private String secondRejectorReason;

    @Column(name = "second_rejected_date")
    private ZonedDateTime secondRejectedDate;

    @JsonIgnoreProperties(value = { "transactionMapping", "transactionApproval", "transactionReview" }, allowSetters = true)
    @OneToOne(fetch = FetchType.LAZY, mappedBy = "transactionApproval")
    private Transaction transaction;

    // jhipster-needle-entity-add-field - JHipster will add fields here

    public Long getId() {
        return this.id;
    }

    public TransactionApproval id(Long id) {
        this.setId(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getTranId() {
        return this.tranId;
    }

    public TransactionApproval tranId(Long tranId) {
        this.setTranId(tranId);
        return this;
    }

    public void setTranId(Long tranId) {
        this.tranId = tranId;
    }

    public String getFirstApprover() {
        return this.firstApprover;
    }

    public TransactionApproval firstApprover(String firstApprover) {
        this.setFirstApprover(firstApprover);
        return this;
    }

    public void setFirstApprover(String firstApprover) {
        this.firstApprover = firstApprover;
    }

    public String getFirstApprovalReason() {
        return this.firstApprovalReason;
    }

    public TransactionApproval firstApprovalReason(String firstApprovalReason) {
        this.setFirstApprovalReason(firstApprovalReason);
        return this;
    }

    public void setFirstApprovalReason(String firstApprovalReason) {
        this.firstApprovalReason = firstApprovalReason;
    }

    public ZonedDateTime getFirstApprovalDate() {
        return this.firstApprovalDate;
    }

    public TransactionApproval firstApprovalDate(ZonedDateTime firstApprovalDate) {
        this.setFirstApprovalDate(firstApprovalDate);
        return this;
    }

    public void setFirstApprovalDate(ZonedDateTime firstApprovalDate) {
        this.firstApprovalDate = firstApprovalDate;
    }

    public String getFirstRejector() {
        return this.firstRejector;
    }

    public TransactionApproval firstRejector(String firstRejector) {
        this.setFirstRejector(firstRejector);
        return this;
    }

    public void setFirstRejector(String firstRejector) {
        this.firstRejector = firstRejector;
    }

    public String getFirstRejectorReason() {
        return this.firstRejectorReason;
    }

    public TransactionApproval firstRejectorReason(String firstRejectorReason) {
        this.setFirstRejectorReason(firstRejectorReason);
        return this;
    }

    public void setFirstRejectorReason(String firstRejectorReason) {
        this.firstRejectorReason = firstRejectorReason;
    }

    public ZonedDateTime getFirstRejectedDate() {
        return this.firstRejectedDate;
    }

    public TransactionApproval firstRejectedDate(ZonedDateTime firstRejectedDate) {
        this.setFirstRejectedDate(firstRejectedDate);
        return this;
    }

    public void setFirstRejectedDate(ZonedDateTime firstRejectedDate) {
        this.firstRejectedDate = firstRejectedDate;
    }

    public String getSecondApprover() {
        return this.secondApprover;
    }

    public TransactionApproval secondApprover(String secondApprover) {
        this.setSecondApprover(secondApprover);
        return this;
    }

    public void setSecondApprover(String secondApprover) {
        this.secondApprover = secondApprover;
    }

    public String getSecondApprovalReason() {
        return this.secondApprovalReason;
    }

    public TransactionApproval secondApprovalReason(String secondApprovalReason) {
        this.setSecondApprovalReason(secondApprovalReason);
        return this;
    }

    public void setSecondApprovalReason(String secondApprovalReason) {
        this.secondApprovalReason = secondApprovalReason;
    }

    public ZonedDateTime getSecondApprovalDate() {
        return this.secondApprovalDate;
    }

    public TransactionApproval secondApprovalDate(ZonedDateTime secondApprovalDate) {
        this.setSecondApprovalDate(secondApprovalDate);
        return this;
    }

    public void setSecondApprovalDate(ZonedDateTime secondApprovalDate) {
        this.secondApprovalDate = secondApprovalDate;
    }

    public String getSecondRejector() {
        return this.secondRejector;
    }

    public TransactionApproval secondRejector(String secondRejector) {
        this.setSecondRejector(secondRejector);
        return this;
    }

    public void setSecondRejector(String secondRejector) {
        this.secondRejector = secondRejector;
    }

    public String getSecondRejectorReason() {
        return this.secondRejectorReason;
    }

    public TransactionApproval secondRejectorReason(String secondRejectorReason) {
        this.setSecondRejectorReason(secondRejectorReason);
        return this;
    }

    public void setSecondRejectorReason(String secondRejectorReason) {
        this.secondRejectorReason = secondRejectorReason;
    }

    public ZonedDateTime getSecondRejectedDate() {
        return this.secondRejectedDate;
    }

    public TransactionApproval secondRejectedDate(ZonedDateTime secondRejectedDate) {
        this.setSecondRejectedDate(secondRejectedDate);
        return this;
    }

    public void setSecondRejectedDate(ZonedDateTime secondRejectedDate) {
        this.secondRejectedDate = secondRejectedDate;
    }

    public Transaction getTransaction() {
        return this.transaction;
    }

    public void setTransaction(Transaction transaction) {
        if (this.transaction != null) {
            this.transaction.setTransactionApproval(null);
        }
        if (transaction != null) {
            transaction.setTransactionApproval(this);
        }
        this.transaction = transaction;
    }

    public TransactionApproval transaction(Transaction transaction) {
        this.setTransaction(transaction);
        return this;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof TransactionApproval)) {
            return false;
        }
        return getId() != null && getId().equals(((TransactionApproval) o).getId());
    }

    @Override
    public int hashCode() {
        // see https://vladmihalcea.com/how-to-implement-equals-and-hashcode-using-the-jpa-entity-identifier/
        return getClass().hashCode();
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "TransactionApproval{" +
            "id=" + getId() +
            ", tranId=" + getTranId() +
            ", firstApprover='" + getFirstApprover() + "'" +
            ", firstApprovalReason='" + getFirstApprovalReason() + "'" +
            ", firstApprovalDate='" + getFirstApprovalDate() + "'" +
            ", firstRejector='" + getFirstRejector() + "'" +
            ", firstRejectorReason='" + getFirstRejectorReason() + "'" +
            ", firstRejectedDate='" + getFirstRejectedDate() + "'" +
            ", secondApprover='" + getSecondApprover() + "'" +
            ", secondApprovalReason='" + getSecondApprovalReason() + "'" +
            ", secondApprovalDate='" + getSecondApprovalDate() + "'" +
            ", secondRejector='" + getSecondRejector() + "'" +
            ", secondRejectorReason='" + getSecondRejectorReason() + "'" +
            ", secondRejectedDate='" + getSecondRejectedDate() + "'" +
            "}";
    }
}
