package com.learn.jpa.domain;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;
import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

/**
 * A WireTransaction.
 */
@Entity
@Table(name = "wire_transaction")
@Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
@SuppressWarnings("common-java:DuplicatedBlocks")
public class WireTransaction implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "sequenceGenerator")
    @SequenceGenerator(name = "sequenceGenerator")
    @Column(name = "id")
    private Long id;

    @NotNull
    @Column(name = "wire_tran_id", nullable = false, unique = true)
    private Long wireTranId;

    @JsonIgnoreProperties(value = { "transaction", "achTransaction", "wireTransaction", "transferTransaction" }, allowSetters = true)
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(unique = true)
    private TransactionMapping transactionMapping;

    @JsonIgnoreProperties(value = { "wireBeneficiaries", "wireTransaction" }, allowSetters = true)
    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(unique = true)
    private WireRecipient wireRecipient;

    @OneToMany(fetch = FetchType.LAZY, mappedBy = "wireTransaction")
    @Cache(usage = CacheConcurrencyStrategy.READ_WRITE)
    @JsonIgnoreProperties(value = { "wireTransaction" }, allowSetters = true)
    private Set<WireFromAccnt> wireFromAccnts = new HashSet<>();

    // jhipster-needle-entity-add-field - JHipster will add fields here

    public Long getId() {
        return this.id;
    }

    public WireTransaction id(Long id) {
        this.setId(id);
        return this;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getWireTranId() {
        return this.wireTranId;
    }

    public WireTransaction wireTranId(Long wireTranId) {
        this.setWireTranId(wireTranId);
        return this;
    }

    public void setWireTranId(Long wireTranId) {
        this.wireTranId = wireTranId;
    }

    public TransactionMapping getTransactionMapping() {
        return this.transactionMapping;
    }

    public void setTransactionMapping(TransactionMapping transactionMapping) {
        this.transactionMapping = transactionMapping;
    }

    public WireTransaction transactionMapping(TransactionMapping transactionMapping) {
        this.setTransactionMapping(transactionMapping);
        return this;
    }

    public WireRecipient getWireRecipient() {
        return this.wireRecipient;
    }

    public void setWireRecipient(WireRecipient wireRecipient) {
        this.wireRecipient = wireRecipient;
    }

    public WireTransaction wireRecipient(WireRecipient wireRecipient) {
        this.setWireRecipient(wireRecipient);
        return this;
    }

    public Set<WireFromAccnt> getWireFromAccnts() {
        return this.wireFromAccnts;
    }

    public void setWireFromAccnts(Set<WireFromAccnt> wireFromAccnts) {
        if (this.wireFromAccnts != null) {
            this.wireFromAccnts.forEach(i -> i.setWireTransaction(null));
        }
        if (wireFromAccnts != null) {
            wireFromAccnts.forEach(i -> i.setWireTransaction(this));
        }
        this.wireFromAccnts = wireFromAccnts;
    }

    public WireTransaction wireFromAccnts(Set<WireFromAccnt> wireFromAccnts) {
        this.setWireFromAccnts(wireFromAccnts);
        return this;
    }

    public WireTransaction addWireFromAccnt(WireFromAccnt wireFromAccnt) {
        this.wireFromAccnts.add(wireFromAccnt);
        wireFromAccnt.setWireTransaction(this);
        return this;
    }

    public WireTransaction removeWireFromAccnt(WireFromAccnt wireFromAccnt) {
        this.wireFromAccnts.remove(wireFromAccnt);
        wireFromAccnt.setWireTransaction(null);
        return this;
    }

    // jhipster-needle-entity-add-getters-setters - JHipster will add getters and setters here

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof WireTransaction)) {
            return false;
        }
        return getId() != null && getId().equals(((WireTransaction) o).getId());
    }

    @Override
    public int hashCode() {
        // see https://vladmihalcea.com/how-to-implement-equals-and-hashcode-using-the-jpa-entity-identifier/
        return getClass().hashCode();
    }

    // prettier-ignore
    @Override
    public String toString() {
        return "WireTransaction{" +
            "id=" + getId() +
            ", wireTranId=" + getWireTranId() +
            "}";
    }
}
