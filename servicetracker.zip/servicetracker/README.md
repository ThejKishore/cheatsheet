# Service Tracker API

This service tracks service build/migration records in a database and exposes a small REST API to create, update, and fetch the latest record for a service.

- OpenAPI specification: openapi.yaml
- Default base URL: http://localhost:8080

## Endpoints

1) Create migration/build entry
- Method/Path: POST /api/migrations
- Request body (application/json):
  {
    "service": "orders",
    "tag": "orders-1.2.3",
    "date": "2025-01-31T15:04:05Z", // optional; defaults to server time
    "sha": "9f5d2f8c3a7b4e1d0c9b8a7f6e5d4c3b2a190876",
    "person": "alice",
    "env": "dev",
    "status": "STARTED" // optional; defaults to STARTED
  }
- Responses:
  - 201 Created with MigrationResponse
  - 400 Bad Request if required fields are missing

2) Update migration status (latest or by tag)
- Method/Path: PUT /api/migrations/{service}
- Path params: service (string)
- Request body (application/json):
  {
    "tag": "orders-1.2.3", // optional; when omitted, updates latest record
    "status": "SUCCESS" // required
  }
- Responses:
  - 200 OK with MigrationResponse
  - 400 Bad Request if status is missing
  - 404 Not Found if no record exists to update

3) Get latest migration for a service
- Method/Path: GET /api/migrations/{service}
- Path params: service (string)
- Responses:
  - 200 OK with MigrationResponse. If no records exist for the service, the response will have "exists": false and the other fields null.
  - 400 Bad Request if service path is blank (edge case)

## Models

MigrationResponse:
{
  "exists": true,
  "service": "orders",
  "tag": "orders-1.2.3",
  "date": "2025-01-31T15:04:05Z",
  "sha": "9f5d2f8c3a7b4e1d0c9b8a7f6e5d4c3b2a190876",
  "person": "alice",
  "env": "dev",
  "status": "STARTED"
}

## Running locally and profiles

- Requirements: Java 17+.
- Profiles provided:
  - local: uses in-memory H2 database and enables Liquibase migrations.
  - cloud: intended for Oracle database; configure JDBC URL/credentials via environment variables or application-cloud.yml.
- Security: HTTP Basic is enabled for non-test profiles. The default user is `devops` and the password is stored encrypted via Jasypt in the profile YAMLs.

### Jasypt setup

This project uses Jasypt to decrypt secrets from YAML. You must provide the encryptor password at runtime so Spring can decrypt values like `ENC(...)`.

Set one of the following before starting the app:
- Environment variable: `JASYPT_ENCRYPTOR_PASSWORD=your-master-password`
- Or JVM property: `-Djasypt.encryptor.password=your-master-password`

Note: The encrypted values in application-local.yml and application-cloud.yml are placeholders. Replace them with real encrypted strings of `testit` (or your chosen password) generated with the same master password.

Example run commands:

- Local (H2):
  JASYPT_ENCRYPTOR_PASSWORD=your-master-password \
  ./gradlew bootRun --args='--spring.profiles.active=local'

- Cloud (Oracle):
  JASYPT_ENCRYPTOR_PASSWORD=your-master-password \
  ./gradlew bootRun --args='--spring.profiles.active=cloud --spring.datasource.url=jdbc:oracle:thin:@//HOST:1521/SERVICE --spring.datasource.username=USER --spring.datasource.password=ENC(your-encrypted-db-pass)'

The app will start on http://localhost:8080 by default.

### Using Basic Auth

Include the Authorization header in requests, e.g. with curl:

curl -u devops:testit http://localhost:8080/api/migrations/orders

## cURL test scripts

Create migration:

curl -i \
  -X POST "http://localhost:8080/api/migrations" \
  -H "Content-Type: application/json" \
  -d '{
    "service": "orders",
    "tag": "orders-1.2.3",
    "sha": "9f5d2f8c3a7b4e1d0c9b8a7f6e5d4c3b2a190876",
    "person": "alice",
    "env": "dev",
    "status": "STARTED"
  }'

Update status for latest record:

curl -i \
  -X PUT "http://localhost:8080/api/migrations/orders" \
  -H "Content-Type: application/json" \
  -d '{
    "status": "SUCCESS"
  }'

Update status by tag:

curl -i \
  -X PUT "http://localhost:8080/api/migrations/orders" \
  -H "Content-Type: application/json" \
  -d '{
    "tag": "orders-1.2.3",
    "status": "FAILED"
  }'

Get latest for a service:

curl -i "http://localhost:8080/api/migrations/orders"

## Bruno test scripts

This repository includes a Bruno collection under bruno/servicetracker.

How to use:
- Install Bruno: https://www.usebruno.com/
- In Bruno, open the folder bruno/servicetracker as a collection.
- Adjust the baseUrl variable in each request if your server is not on http://localhost:8080.
- Run the requests:
  - Create Migration
  - Update Status (Latest)
  - Update Status (By Tag)
  - Get Latest

Each request is pre-configured with sample payloads matching the OpenAPI spec.
