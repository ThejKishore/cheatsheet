package com.ntrs.wpa.migration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Component;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Optional;

@Component
public class MigrationStore {

    private final JdbcTemplate jdbc;

    @Value("${app.migration.sql.insert:INSERT INTO MIGRATION_RECORDS (SERVICE, TAG, DT, SHA, PERSON, ENV, STATUS) VALUES (?,?,?,?,?,?,?)}")
    private String sqlInsert;
    @Value("${app.migration.sql.updateStatusById:UPDATE MIGRATION_RECORDS SET STATUS=? WHERE ID=?}")
    private String sqlUpdateStatusById;
    @Value("${app.migration.sql.selectLatestByService:SELECT * FROM MIGRATION_RECORDS m WHERE m.SERVICE = ? ORDER BY m.DT DESC FETCH NEXT 1 ROWS ONLY}")
    private String sqlSelectLatestByService;
    @Value("${app.migration.sql.countByService:SELECT COUNT(*) FROM MIGRATION_RECORDS WHERE SERVICE = ?}")
    private String sqlCountByService;
    @Value("${app.migration.sql.selectLatestByServiceAndTag:SELECT * FROM MIGRATION_RECORDS m WHERE m.SERVICE = ? AND m.TAG = ? ORDER BY m.DT DESC FETCH NEXT 1 ROWS ONLY}")
    private String sqlSelectLatestByServiceAndTag;
    @Value("${app.migration.sql.selectById:SELECT * FROM MIGRATION_RECORDS WHERE ID = ?}")
    private String sqlSelectById;

    public MigrationStore(JdbcTemplate jdbc) {
        this.jdbc = jdbc;
    }

    public MigrationEntry save(MigrationEntry entry) {
        OffsetDateTime dt = entry.date() != null ? entry.date() : OffsetDateTime.now(ZoneOffset.UTC);
        KeyHolder kh = new GeneratedKeyHolder();
        jdbc.update(con -> {
            PreparedStatement ps = con.prepareStatement(sqlInsert, Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, entry.service());
            ps.setString(2, entry.tag());
            ps.setTimestamp(3, java.sql.Timestamp.valueOf(dt.toLocalDateTime()));
            ps.setString(4, entry.sha());
            ps.setString(5, entry.person());
            ps.setString(6, entry.env());
            ps.setString(7, entry.status());
            return ps;
        }, kh);
        Number key = kh.getKey();
        Long id = key != null ? key.longValue() : entry.id();
        return new MigrationEntry(id, entry.service(), entry.tag(), dt, entry.sha(), entry.person(), entry.env(), entry.status());
    }

    public Optional<MigrationEntry> updateStatus(String service, String tag, String status) {
        Optional<MigrationEntry> target;
        if (tag != null && !tag.isBlank()) {
            target = latestByServiceAndTag(service, tag);
        } else {
            target = latest(service);
        }
        if (target.isEmpty()) return Optional.empty();
        jdbc.update(sqlUpdateStatusById, status, target.get().id());
        // return the updated latest record for the service
        return byId(target.get().id());
    }

    public Optional<MigrationEntry> latest(String service) {
        return jdbc.query(sqlSelectLatestByService, (rs) -> rs.next() ? Optional.of(map(rs.getLong("ID"), rs.getString("SERVICE"), rs.getString("TAG"), rs.getTimestamp("DT").toLocalDateTime().atOffset(ZoneOffset.UTC), rs.getString("SHA"), rs.getString("PERSON"), rs.getString("ENV"), rs.getString("STATUS"))) : Optional.empty(), service);
    }

    public boolean exists(String service) {
        Integer count = jdbc.queryForObject(sqlCountByService, Integer.class, service);
        return count != null && count > 0;
    }

    private Optional<MigrationEntry> latestByServiceAndTag(String service, String tag) {
        return jdbc.query(sqlSelectLatestByServiceAndTag, (rs) -> rs.next() ? Optional.of(map(rs.getLong("ID"), rs.getString("SERVICE"), rs.getString("TAG"), rs.getTimestamp("DT").toLocalDateTime().atOffset(ZoneOffset.UTC), rs.getString("SHA"), rs.getString("PERSON"), rs.getString("ENV"), rs.getString("STATUS"))) : Optional.empty(), service, tag);
    }

    private Optional<MigrationEntry> byId(Long id) {
        return jdbc.query(sqlSelectById, (rs) -> rs.next() ? Optional.of(map(rs.getLong("ID"), rs.getString("SERVICE"), rs.getString("TAG"), rs.getTimestamp("DT").toLocalDateTime().atOffset(ZoneOffset.UTC), rs.getString("SHA"), rs.getString("PERSON"), rs.getString("ENV"), rs.getString("STATUS"))) : Optional.empty(), id);
    }

    private MigrationEntry map(Long id, String service, String tag, OffsetDateTime dt, String sha, String person, String env, String status) {
        return new MigrationEntry(id, service, tag, dt, sha, person, env, status);
    }
}