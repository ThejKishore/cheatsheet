package com.ntrs.wpa.migration.dto;

import jakarta.validation.constraints.NotBlank;

public record UpdateStatusRequest(
        String tag,    // optional; if null, update the latest entry for service
        @NotBlank String status  // required
) {}