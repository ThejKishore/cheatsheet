package com.ntrs.wpa.migration;

import java.time.OffsetDateTime;

public record MigrationEntry(
        Long id,          // db surrogate key
        String service,   // service name/id
        String tag,       // docker tag
        OffsetDateTime date, // build/migration date-time
        String sha,       // git sha
        String person,    // who triggered / committed
        String env,       // environment (e.g., dev, qa, prod)
        String status     // e.g., STARTED, SUCCESS, FAILED
) {}