package com.ntrs.wpa.migration.dto;

import com.ntrs.wpa.migration.MigrationEntry;

import java.time.OffsetDateTime;

public record MigrationResponse(
        boolean exists,
        String service,
        String tag,
        OffsetDateTime date,
        String sha,
        String person,
        String env,
        String status
) {
    public static MigrationResponse fromEntry(MigrationEntry e) {
        if (e == null) {
            return empty();
        }
        return new MigrationResponse(true, e.service(), e.tag(), e.date(), e.sha(), e.person(), e.env(), e.status());
    }

    public static MigrationResponse empty() {
        return new MigrationResponse(false, null, null, null, null, null, null, null);
    }
}