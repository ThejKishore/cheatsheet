package com.ntrs.wpa.migration.dto;

import jakarta.validation.constraints.NotBlank;

import java.time.OffsetDateTime;

public record CreateMigrationRequest(
        @NotBlank String service,
        @NotBlank String tag,
        OffsetDateTime date, // optional; default now when null
        @NotBlank String sha,
        @NotBlank String person,
        @NotBlank String env,
        String status // optional; default STARTED when null
) {}