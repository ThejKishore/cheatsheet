package com.ntrs.wpa.migration;

import com.ntrs.wpa.migration.dto.CreateMigrationRequest;
import com.ntrs.wpa.migration.dto.MigrationResponse;
import com.ntrs.wpa.migration.dto.UpdateStatusRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/migrations")
public class MigrationController {

    private static final Logger log = LoggerFactory.getLogger(MigrationController.class);

    private final MigrationStore store;

    public MigrationController(MigrationStore store) {
        this.store = store;
    }

    // POST: create/store a migration/build entry
    @PostMapping
    public ResponseEntity<MigrationResponse> create(@RequestBody @jakarta.validation.Valid CreateMigrationRequest req) {
        log.debug("POST /api/migrations payload: service={}, tag={}, sha={}, person={}, env={}, status={}", req.service(), req.tag(), req.sha(), req.person(), req.env(), req.status());
        String status = StringUtils.hasText(req.status()) ? req.status() : "STARTED";
        MigrationEntry entry = new MigrationEntry(
                null,
                req.service(),
                req.tag(),
                req.date(),
                req.sha(),
                req.person(),
                req.env(),
                status
        );
        MigrationEntry saved = store.save(entry);
        return ResponseEntity.status(HttpStatus.CREATED).body(MigrationResponse.fromEntry(saved));
    }

    // PUT: update status for a service (optionally by tag)
    @PutMapping("/{service}")
    public ResponseEntity<MigrationResponse> updateStatus(@PathVariable String service,
                                                         @RequestBody @jakarta.validation.Valid UpdateStatusRequest req) {
        log.debug("PUT /api/migrations/{} payload: tag={}, status={}", service, req.tag(), req.status());
        return store.updateStatus(service, req.tag(), req.status())
                .map(e -> ResponseEntity.ok(MigrationResponse.fromEntry(e)))
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build());
    }

    // GET: check if service has an entry; returns latest entry if exists
    @GetMapping("/{service}")
    public ResponseEntity<MigrationResponse> getLatest(@PathVariable String service) {
        log.debug("GET /api/migrations/{}", service);
        if (!StringUtils.hasText(service)) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build();
        }
        return store.latest(service)
                .map(e -> ResponseEntity.ok(MigrationResponse.fromEntry(e)))
                .orElseGet(() -> ResponseEntity.ok(MigrationResponse.empty())); // exists=false by default
    }
}
