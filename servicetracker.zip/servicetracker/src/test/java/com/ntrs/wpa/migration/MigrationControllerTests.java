package com.ntrs.wpa.migration;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Map;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@org.springframework.test.context.ActiveProfiles("test")
class MigrationControllerTests {

    private static final Logger log = LoggerFactory.getLogger(MigrationControllerTests.class);

    @org.junit.jupiter.api.BeforeAll
    static void beforeAll() {
        log.debug("Starting MigrationControllerTests with ActiveProfiles=test");
    }

    @Autowired
    MockMvc mockMvc;

    @Autowired
    ObjectMapper objectMapper;

    // --- Happy path tests ---

    @Test
    void getReturnsExistsFalseWhenNoEntry() throws Exception {
        String service = "orders-no-entry";
        mockMvc.perform(get("/api/migrations/" + service))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.exists").value(false));
    }

    @Test
    void createMigrationReturnsCreatedAndDefaultsStatus() throws Exception {
        String service = "orders-create";
        String tag = "v1.2.3";
        String postBody = objectMapper.writeValueAsString(Map.of(
                "service", service,
                "tag", tag,
                "sha", "abc123",
                "person", "jdoe",
                "env", "dev"
        ));
        mockMvc.perform(post("/api/migrations")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(postBody))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.exists").value(true))
                .andExpect(jsonPath("$.service").value(service))
                .andExpect(jsonPath("$.tag").value(tag))
                .andExpect(jsonPath("$.status").value("STARTED"));
    }

    @Test
    void getReturnsLatestAfterCreate() throws Exception {
        String service = "orders-get-after-create";
        String tag = "v2.0.0";
        String postBody = objectMapper.writeValueAsString(Map.of(
                "service", service,
                "tag", tag,
                "sha", "def456",
                "person", "alice",
                "env", "qa"
        ));
        mockMvc.perform(post("/api/migrations")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(postBody))
                .andExpect(status().isCreated());

        mockMvc.perform(get("/api/migrations/" + service))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.exists").value(true))
                .andExpect(jsonPath("$.tag").value(tag));
    }

    @Test
    void updateStatusSuccessByService() throws Exception {
        String service = "orders-update";
        String tag = "v3.1.0";
        // create first
        String postBody = objectMapper.writeValueAsString(Map.of(
                "service", service,
                "tag", tag,
                "sha", "ghi789",
                "person", "bob",
                "env", "dev"
        ));
        mockMvc.perform(post("/api/migrations")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(postBody))
                .andExpect(status().isCreated());

        // update
        String putBody = objectMapper.writeValueAsString(Map.of(
                "status", "SUCCESS"
        ));
        mockMvc.perform(put("/api/migrations/" + service)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(putBody))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("SUCCESS"));

        // confirm via GET
        mockMvc.perform(get("/api/migrations/" + service))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.status").value("SUCCESS"));
    }

    @Test
    void updateStatusByTagOnlyUpdatesMatchingTag() throws Exception {
        String service = "orders-update-by-tag";
        // create two tags
        String postBody1 = objectMapper.writeValueAsString(Map.of(
                "service", service,
                "tag", "t1",
                "sha", "s1",
                "person", "p1",
                "env", "dev"
        ));
        String postBody2 = objectMapper.writeValueAsString(Map.of(
                "service", service,
                "tag", "t2",
                "sha", "s2",
                "person", "p2",
                "env", "dev"
        ));
        mockMvc.perform(post("/api/migrations").contentType(MediaType.APPLICATION_JSON).content(postBody1))
                .andExpect(status().isCreated());
        mockMvc.perform(post("/api/migrations").contentType(MediaType.APPLICATION_JSON).content(postBody2))
                .andExpect(status().isCreated());

        // update only tag t1
        String putBody = objectMapper.writeValueAsString(Map.of(
                "tag", "t1",
                "status", "FAILED"
        ));
        mockMvc.perform(put("/api/migrations/" + service)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(putBody))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.tag").value("t1"))
                .andExpect(jsonPath("$.status").value("FAILED"));
    }

    // --- Edge case tests ---

    @Test
    void updateNonexistentServiceReturns404() throws Exception {
        String putBody = objectMapper.writeValueAsString(Map.of(
                "status", "SUCCESS"
        ));
        mockMvc.perform(put("/api/migrations/nonexistent-service")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(putBody))
                .andExpect(status().isNotFound());
    }

    @Test
    void updateWithTagNotFoundReturns404() throws Exception {
        String service = "orders-tag-404";
        // create with tag x
        String postBody = objectMapper.writeValueAsString(Map.of(
                "service", service,
                "tag", "x",
                "sha", "sha",
                "person", "person",
                "env", "env"
        ));
        mockMvc.perform(post("/api/migrations")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(postBody))
                .andExpect(status().isCreated());

        // try to update tag y
        String putBody = objectMapper.writeValueAsString(Map.of(
                "tag", "y",
                "status", "SUCCESS"
        ));
        mockMvc.perform(put("/api/migrations/" + service)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(putBody))
                .andExpect(status().isNotFound());
    }

    @Test
    void postMissingRequiredFieldsReturns400() throws Exception {
        // Missing service
        String bodyMissingService = objectMapper.writeValueAsString(Map.of(
                "tag", "t",
                "sha", "s",
                "person", "p",
                "env", "e"
        ));
        mockMvc.perform(post("/api/migrations")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(bodyMissingService))
                .andExpect(status().isBadRequest());

        // Missing tag
        String bodyMissingTag = objectMapper.writeValueAsString(Map.of(
                "service", "svc",
                "sha", "s",
                "person", "p",
                "env", "e"
        ));
        mockMvc.perform(post("/api/migrations")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(bodyMissingTag))
                .andExpect(status().isBadRequest());
    }

    @Test
    void postEmptyStringsReturns400() throws Exception {
        String body = objectMapper.writeValueAsString(Map.of(
                "service", " ",
                "tag", "",
                "sha", " ",
                "person", "",
                "env", " "
        ));
        mockMvc.perform(post("/api/migrations")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(body))
                .andExpect(status().isBadRequest());
    }

    @Test
    void putEmptyStatusReturns400() throws Exception {
        String service = "orders-empty-status";
        // create first
        String postBody = objectMapper.writeValueAsString(Map.of(
                "service", service,
                "tag", "t",
                "sha", "s",
                "person", "p",
                "env", "e"
        ));
        mockMvc.perform(post("/api/migrations")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(postBody))
                .andExpect(status().isCreated());

        String putBody = objectMapper.writeValueAsString(Map.of(
                "status", " "
        ));
        mockMvc.perform(put("/api/migrations/" + service)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(putBody))
                .andExpect(status().isBadRequest());
    }

    @Test
    void invalidJsonBodiesReturn400() throws Exception {
        // POST invalid JSON
        mockMvc.perform(post("/api/migrations")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("not-a-json"))
                .andExpect(status().isBadRequest());

        // PUT invalid JSON
        mockMvc.perform(put("/api/migrations/svc")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content("not-a-json"))
                .andExpect(status().isBadRequest());
    }
}