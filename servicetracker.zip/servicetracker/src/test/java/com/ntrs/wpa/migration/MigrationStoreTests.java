package com.ntrs.wpa.migration;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.Optional;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest
@ActiveProfiles("test")
class MigrationStoreTests {

    @Autowired
    MigrationStore store;

    @Autowired
    JdbcTemplate jdbc;

    @BeforeEach
    void cleanDb() {
        jdbc.update("DELETE FROM MIGRATION_RECORDS");
    }

    @Test
    void save_setsDateIfNull_andReturnsGeneratedId_andPersistsAllFields() {
        MigrationEntry e = new MigrationEntry(null, "svc-save", "t1", null, "sha1", "alice", "dev", "STARTED");

        MigrationEntry saved = store.save(e);

        assertThat(saved.id()).as("generated id").isNotNull();
        assertThat(saved.date()).as("auto-set date").isNotNull();

        // Verify persistence
        var row = jdbc.queryForMap("SELECT * FROM MIGRATION_RECORDS WHERE ID=?", saved.id());
        assertThat(row.get("SERVICE")).isEqualTo("svc-save");
        assertThat(((Timestamp) row.get("DT")).toLocalDateTime()).isNotNull();
        assertThat(row.get("TAG")).isEqualTo("t1");
        assertThat(row.get("SHA")).isEqualTo("sha1");
        assertThat(row.get("PERSON")).isEqualTo("alice");
        assertThat(row.get("ENV")).isEqualTo("dev");
        assertThat(row.get("STATUS")).isEqualTo("STARTED");
    }

    @Test
    void latest_returnsLatestByServiceByDate() {
        String service = "svc-latest";
        // older
        store.save(new MigrationEntry(null, service, "old", OffsetDateTime.of(LocalDateTime.of(2024, 1, 1, 10, 0), ZoneOffset.UTC), "s1", "p1", "dev", "STARTED"));
        // newer
        store.save(new MigrationEntry(null, service, "new", OffsetDateTime.of(LocalDateTime.of(2024, 1, 1, 12, 0), ZoneOffset.UTC), "s2", "p2", "dev", "STARTED"));

        Optional<MigrationEntry> latest = store.latest(service);
        assertThat(latest).isPresent();
        assertThat(latest.get().tag()).isEqualTo("new");
    }

    @Test
    void exists_returnsFalseWhenNoRows_andTrueWhenPresent() {
        assertThat(store.exists("missing"))
                .as("no rows for service").isFalse();

        store.save(new MigrationEntry(null, "svc-exists", "t", OffsetDateTime.now(ZoneOffset.UTC), "s", "p", "dev", "STARTED"));
        assertThat(store.exists("svc-exists")).isTrue();
    }

    @Test
    void updateStatus_withTag_updatesOnlyMatchingTagLatestRecord() {
        String service = "svc-update-tag";
        MigrationEntry t1 = store.save(new MigrationEntry(null, service, "t1", OffsetDateTime.now(ZoneOffset.UTC).minusHours(2), "s1", "p1", "dev", "STARTED"));
        MigrationEntry t2 = store.save(new MigrationEntry(null, service, "t2", OffsetDateTime.now(ZoneOffset.UTC).minusHours(1), "s2", "p2", "dev", "STARTED"));

        Optional<MigrationEntry> updated = store.updateStatus(service, "t1", "SUCCESS");
        assertThat(updated).isPresent();
        assertThat(updated.get().tag()).isEqualTo("t1");
        assertThat(updated.get().status()).isEqualTo("SUCCESS");

        // verify other tag unchanged
        var other = jdbc.queryForObject("SELECT STATUS FROM MIGRATION_RECORDS WHERE ID=?", String.class, t2.id());
        assertThat(other).isEqualTo("STARTED");
    }

    @Test
    void updateStatus_withoutTag_updatesLatestByService() {
        String service = "svc-update-no-tag";
        store.save(new MigrationEntry(null, service, "old", OffsetDateTime.now(ZoneOffset.UTC).minusMinutes(10), "s1", "p1", "dev", "STARTED"));
        MigrationEntry latest = store.save(new MigrationEntry(null, service, "new", OffsetDateTime.now(ZoneOffset.UTC), "s2", "p2", "dev", "STARTED"));

        Optional<MigrationEntry> updated = store.updateStatus(service, null, "FAILED");
        assertThat(updated).isPresent();
        assertThat(updated.get().id()).isEqualTo(latest.id());
        assertThat(updated.get().status()).isEqualTo("FAILED");
    }

    @Test
    void updateStatus_blankTag_treatedAsNoTag() {
        String service = "svc-update-blank-tag";
        MigrationEntry latest = store.save(new MigrationEntry(null, service, "tagx", OffsetDateTime.now(ZoneOffset.UTC), "s", "p", "dev", "STARTED"));

        Optional<MigrationEntry> updated = store.updateStatus(service, "   ", "SUCCESS");
        assertThat(updated).isPresent();
        assertThat(updated.get().id()).isEqualTo(latest.id());
        assertThat(updated.get().status()).isEqualTo("SUCCESS");
    }

    @Test
    void updateStatus_noRecords_returnsEmpty() {
        Optional<MigrationEntry> updated = store.updateStatus("no-such-service", null, "SUCCESS");
        assertThat(updated).isEmpty();
    }

    @Test
    void updateStatus_tagNotFound_returnsEmpty() {
        String service = "svc-tag-miss";
        store.save(new MigrationEntry(null, service, "x", OffsetDateTime.now(ZoneOffset.UTC), "s", "p", "dev", "STARTED"));

        Optional<MigrationEntry> updated = store.updateStatus(service, "y", "SUCCESS");
        assertThat(updated).isEmpty();
    }
}
