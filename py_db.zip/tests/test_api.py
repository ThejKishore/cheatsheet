"""Test FastAPI application endpoints."""

import pytest
from fastapi.testclient import TestClient
from app.main import app


client = TestClient(app)


def test_health_endpoint():
    """Test /health endpoint is accessible."""
    response = client.get("/health")
    
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ok"
    assert "timestamp" in data


def test_ready_endpoint():
    """Test /ready endpoint is accessible."""
    response = client.get("/ready")
    
    assert response.status_code == 200
    data = response.json()
    assert data["status"] == "ready"
    assert "timestamp" in data


def test_openapi_schema():
    """Test OpenAPI schema is generated."""
    response = client.get("/openapi.json")
    
    assert response.status_code == 200
    schema = response.json()
    assert schema["info"]["title"] == "Portfolio Explorer API"
    assert "paths" in schema


def test_docs_endpoint():
    """Test Swagger docs endpoint."""
    response = client.get("/docs")
    
    assert response.status_code == 200
    assert "swagger" in response.text.lower()
