"""Test configuration loading."""

import pytest


def test_config_loads():
    """Test that configuration can be loaded."""
    from app.config import settings
    
    assert settings.environment == "development"
    assert settings.log_level == "INFO"
    assert settings.duckdb_memory_limit == "1GB"
    assert settings.duckdb_threads == 2


def test_azure_settings_present():
    """Test that Azure settings are defined."""
    from app.config import settings
    
    assert settings.azure_storage_account
    assert settings.azure_container_name
