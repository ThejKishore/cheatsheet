"""Test portfolio analytics functions."""

import pytest
from datetime import date


def test_get_positions_function_exists():
    """Test that get_positions function exists."""
    from app.analytics import portfolio
    
    assert hasattr(portfolio, 'get_positions')
    assert callable(portfolio.get_positions)


def test_get_portfolio_summary_function_exists():
    """Test that get_portfolio_summary function exists."""
    from app.analytics import portfolio
    
    assert hasattr(portfolio, 'get_portfolio_summary')
    assert callable(portfolio.get_portfolio_summary)


def test_get_asset_allocation_function_exists():
    """Test that get_asset_allocation function exists."""
    from app.analytics import portfolio
    
    assert hasattr(portfolio, 'get_asset_allocation')
    assert callable(portfolio.get_asset_allocation)


def test_get_top_holdings_function_exists():
    """Test that get_top_holdings function exists."""
    from app.analytics import portfolio
    
    assert hasattr(portfolio, 'get_top_holdings')
    assert callable(portfolio.get_top_holdings)
