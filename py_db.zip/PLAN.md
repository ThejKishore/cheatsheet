# Portfolio Explorer Microservice — Build Plan

## Overview

A stateless, read-only portfolio analytics microservice that lets banking clients query their portfolio data (positions, holdings, asset allocation, performance) with date-range and account filters.

```
              ┌───────────────┐
              │    Clients    │
              └───────┬───────┘
                      │
                      ▼
              ┌───────────────┐
              │    FastAPI    │   (Azure Kubernetes — 2 CPU / 4 GB)
              └───────┬───────┘
                      │
             one ephemeral DB per request
                      │
                      ▼
              ┌───────────────┐        ┌─────────────────┐
              │    DuckDB     │        │    Snowflake    │
              │   :memory:    │◄──────►│  (source of    │
              │ read-only     │        │    truth)       │
              │ analytical    │        └─────────────────┘
              └───────┬───────┘
                      │
                      ▼
              ┌───────────────┐
              │ Azure Blob    │
              │   Storage     │
              │  Partitioned  │
              │   Parquet     │
              └───────────────┘
```

**Key principles (from learning.md):**
- Azure Blob Storage is the durable state; DuckDB is the ephemeral compute engine; FastAPI is the interface.
- One ephemeral `duckdb.connect(":memory:")` per request — no shared connections, no local `.duckdb` file.
- Snowflake owns the financial source of truth; nightly/hourly ETL denormalises into Parquet snapshots.
- Parameterise all SQL values; never interpolate user input into query strings.
- Resource limits set per DuckDB connection (`memory_limit`, `threads`) so the container is never OOM-killed.

---

## Progress Checklist

> Agents: update the `[x]` / `[ ]` markers as tasks are completed. Never delete a line — only tick it.

### Phase 1 — Project Scaffold & Configuration
- [ ] 1.1 Create project directory structure
- [ ] 1.2 Create `requirements.txt`
- [ ] 1.3 Create `app/config.py` with `pydantic-settings`
- [ ] 1.4 Create `.env.example` (no secrets, just keys)
- [ ] 1.5 Create `app/__init__.py`
- [ ] 1.6 Verify `python -m app.config` resolves all required settings

### Phase 2 — DuckDB Service Layer
- [ ] 2.1 Create `app/duckdb_service.py` with `duckdb_connection()` context manager
- [ ] 2.2 Configure memory limit and thread count from settings
- [ ] 2.3 Install and load `httpfs` / `azure` extension for Azure Blob Storage access
- [ ] 2.4 Configure Azure storage credentials (account name + workload identity / SAS)
- [ ] 2.5 Unit test: connection opens, executes trivial SQL, closes

### Phase 3 — Snowflake Ingestion Worker
- [ ] 3.1 Create `ingestion/snowflake_extractor.py` (Arrow batch iterator)
- [ ] 3.2 Create `ingestion/parquet_writer.py` (write batches → temp → validate → upload)
- [ ] 3.3 Create `ingestion/azure_uploader.py` (azure-storage-blob SDK upload)
- [ ] 3.4 Create `ingestion/manifest.py` (read/write `manifest.json` in Blob)
- [ ] 3.5 Create `ingestion/etl_job.py` (orchestrator: extract → write → validate → manifest)
- [ ] 3.6 Implement Hive-partitioned layout: `positions/as_of_date=YYYY-MM-DD/*.parquet`
- [ ] 3.7 Implement incremental ingestion (track `last_successful_date` in manifest)
- [ ] 3.8 End-to-end test: ingestion job writes valid Parquet to local/mock blob

### Phase 4 — Pydantic Schemas
- [ ] 4.1 Create `app/schemas.py` — request/response models:
  - `PortfolioPositionsResponse`
  - `PortfolioSummaryResponse`
  - `AssetAllocationResponse`
  - `TransactionResponse`
  - `PortfolioPerformanceResponse`
- [ ] 4.2 Validate schema round-trips with unit tests

### Phase 5 — Analytics Layer
- [ ] 5.1 Create `app/analytics/portfolio.py`:
  - `get_positions(client_id, as_of_date, account_ids?)` → positions list
  - `get_summary(client_id, as_of_date)` → totals
  - `get_asset_allocation(client_id, as_of_date)` → allocation breakdown
  - `get_top_holdings(client_id, as_of_date, limit)` → top-N holdings
- [ ] 5.2 Create `app/analytics/transactions.py`:
  - `get_transactions(client_id, start_date, end_date, account_ids?)` → transactions
- [ ] 5.3 Create `app/analytics/performance.py`:
  - `get_performance(client_id, start_date, end_date)` → daily values series
- [ ] 5.4 All queries use parameterised SQL — no f-string interpolation of user values
- [ ] 5.5 Path resolution uses a `DATASETS` whitelist, never raw user input paths
- [ ] 5.6 Unit tests for each analytics function (against local Parquet fixture files)

### Phase 6 — FastAPI Application
- [ ] 6.1 Create `app/main.py` with `FastAPI` app instance, lifespan, and OpenAPI metadata
- [ ] 6.2 `GET /health` — liveness probe
- [ ] 6.3 `GET /ready` — readiness probe (checks manifest availability)
- [ ] 6.4 `GET /v1/clients/{client_id}/portfolio` — latest positions (+ optional `account_id` filter)
- [ ] 6.5 `GET /v1/clients/{client_id}/portfolio/summary` — totals and asset allocation
- [ ] 6.6 `GET /v1/clients/{client_id}/portfolio/holdings` — top holdings (with `?limit=`)
- [ ] 6.7 `GET /v1/clients/{client_id}/portfolio/transactions` — transactions by date range (`?start_date=&end_date=`)
- [ ] 6.8 `GET /v1/clients/{client_id}/portfolio/performance` — daily value series by date range
- [ ] 6.9 All endpoints use synchronous handlers (DuckDB is synchronous; async blocks the event loop)
- [ ] 6.10 Input validation via Pydantic / FastAPI Query parameters

### Phase 7 — Authentication & Authorization
- [ ] 7.1 Create `app/auth.py` — JWT validation middleware / `Depends`
- [ ] 7.2 Implement `get_current_user()` dependency that extracts `user_id`, `allowed_client_ids`
- [ ] 7.3 Add `user.can_access_client(client_id)` guard to every client-scoped endpoint
- [ ] 7.4 Return `403 Forbidden` for unauthorized client access (never 404 — avoids enumeration)
- [ ] 7.5 Unit tests for auth middleware with valid and invalid tokens

### Phase 8 — Error Handling & Observability
- [ ] 8.1 Add global FastAPI exception handlers (400, 403, 404, 500)
- [ ] 8.2 Structured JSON logging (`structlog` or standard `logging`)
- [ ] 8.3 Request ID propagation (`X-Request-ID` header)
- [ ] 8.4 Add Prometheus metrics endpoint (`/metrics`) — request count, latency, error rate
- [ ] 8.5 DuckDB query timing logged per request

### Phase 9 — Container & Kubernetes
- [ ] 9.1 Create `Dockerfile` (python:3.12-slim, non-root user, no `.env` baked in)
- [ ] 9.2 Set `DUCKDB_MEMORY_LIMIT=1GB` and `DUCKDB_THREADS=2` for 2-CPU/4-GB container
- [ ] 9.3 Create `k8s/deployment.yaml` — Deployment, resource requests/limits, liveness/readiness probes
- [ ] 9.4 Create `k8s/service.yaml` — ClusterIP service
- [ ] 9.5 Create `k8s/configmap.yaml` — non-secret configuration
- [ ] 9.6 Create `k8s/serviceaccount.yaml` — Workload Identity for Azure Blob Storage access
- [ ] 9.7 Verify container starts and `/health` responds

### Phase 10 — Integration & Load Testing
- [ ] 10.1 Integration tests with real (dev) Parquet data in Azure Blob Storage
- [ ] 10.2 Load test: confirm container stays within 4 GB RAM under concurrent requests
- [ ] 10.3 Tune `DUCKDB_MEMORY_LIMIT` and `DUCKDB_THREADS` based on profiling

---

## Phase Detail

### Phase 1 — Project Scaffold & Configuration

**Project layout:**

```
portfolio-api/
├── app/
│   ├── __init__.py
│   ├── main.py
│   ├── config.py
│   ├── auth.py
│   ├── duckdb_service.py
│   ├── schemas.py
│   └── analytics/
│       ├── __init__.py
│       ├── portfolio.py
│       ├── transactions.py
│       └── performance.py
├── ingestion/
│   ├── __init__.py
│   ├── snowflake_extractor.py
│   ├── parquet_writer.py
│   ├── azure_uploader.py
│   ├── manifest.py
│   └── etl_job.py
├── tests/
│   ├── fixtures/
│   │   └── positions_sample.parquet
│   ├── test_analytics.py
│   ├── test_api.py
│   └── test_auth.py
├── k8s/
│   ├── deployment.yaml
│   ├── service.yaml
│   ├── configmap.yaml
│   └── serviceaccount.yaml
├── Dockerfile
├── requirements.txt
└── .env.example
```

**`requirements.txt`:**

```
fastapi
uvicorn[standard]
duckdb
snowflake-connector-python[pandas]
pyarrow
azure-storage-blob
azure-identity
pydantic-settings
python-jose[cryptography]
structlog
prometheus-fastapi-instrumentator
pytest
httpx
```

**`app/config.py`:**

```python
from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    azure_storage_account: str
    azure_container_name: str
    azure_storage_connection_string: str | None = None  # dev only

    snowflake_account: str
    snowflake_user: str
    snowflake_warehouse: str = "ANALYTICS_WH"
    snowflake_database: str = "ANALYTICS"
    snowflake_schema: str = "PUBLIC"

    duckdb_memory_limit: str = "1GB"
    duckdb_threads: int = 2

    jwt_algorithm: str = "RS256"
    jwt_public_key: str

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

settings = Settings()
```

`.env.example`:

```
AZURE_STORAGE_ACCOUNT=mystorageaccount
AZURE_CONTAINER_NAME=portfolio-data
SNOWFLAKE_ACCOUNT=myorg-myaccount
SNOWFLAKE_USER=svc_portfolio_reader
SNOWFLAKE_WAREHOUSE=ANALYTICS_WH
SNOWFLAKE_DATABASE=ANALYTICS
SNOWFLAKE_SCHEMA=PUBLIC
DUCKDB_MEMORY_LIMIT=1GB
DUCKDB_THREADS=2
JWT_ALGORITHM=RS256
JWT_PUBLIC_KEY=<contents of public key>
```

---

### Phase 2 — DuckDB Service Layer

Each request gets an isolated `:memory:` connection. The `httpfs` / `azure` extensions give DuckDB direct read access to Azure Blob Storage without intermediate downloads.

**`app/duckdb_service.py`:**

```python
from contextlib import contextmanager
import duckdb
from .config import settings

@contextmanager
def duckdb_connection():
    con = duckdb.connect(database=":memory:")
    try:
        con.execute("INSTALL httpfs; LOAD httpfs")
        con.execute("INSTALL azure; LOAD azure")
        con.execute(
            f"SET azure_storage_connection_string = '{settings.azure_storage_connection_string}'"
            if settings.azure_storage_connection_string
            else "SET azure_use_workload_identity = true"
        )
        con.execute(f"SET memory_limit = '{settings.duckdb_memory_limit}'")
        con.execute(f"SET threads = {settings.duckdb_threads}")
        yield con
    finally:
        con.close()
```

In production (AKS), Azure Workload Identity is injected via the pod service account — no connection strings in the container.

---

### Phase 3 — Snowflake Ingestion Worker

**Snowflake financial data model assumed (source of truth):**

| Table | Key Columns |
|---|---|
| `CLIENT` | `client_id`, `client_name`, `base_currency` |
| `ACCOUNT` | `account_id`, `client_id`, `account_type` |
| `POSITION` | `account_id`, `security_id`, `quantity`, `as_of_date` |
| `SECURITY` | `security_id`, `ticker`, `name`, `asset_class`, `sector` |
| `PRICE` | `security_id`, `price_date`, `price`, `currency` |
| `FX_RATE` | `from_currency`, `to_currency`, `rate_date`, `rate` |
| `TRANSACTION` | `transaction_id`, `account_id`, `security_id`, `transaction_date`, `type`, `quantity`, `price` |

**Denormalised Parquet schema written by the ETL (`portfolio_position`):**

```
client_id, account_id, as_of_date,
security_id, ticker, security_name, asset_class, sector,
quantity, price, market_value,
security_currency, base_currency, fx_rate, market_value_base,
weight
```

**Azure Blob Storage layout:**

```
<container>/
├── portfolio/
│   ├── positions/
│   │   └── as_of_date=YYYY-MM-DD/
│   │       └── part-000.parquet
│   ├── portfolio_values/
│   │   └── date=YYYY-MM-DD/
│   │       └── part-000.parquet
│   ├── transactions/
│   │   └── year=YYYY/month=MM/
│   │       └── part-000.parquet
│   └── performance/
│       └── date=YYYY-MM-DD/
│           └── part-000.parquet
└── manifest.json
```

**`manifest.json`:**

```json
{
  "dataset": "portfolio_positions",
  "as_of_date": "2026-10-07",
  "status": "published",
  "published_at": "2026-10-07T06:30:00Z"
}
```

**ETL flow:**

```
Snowflake (incremental SQL, parameterised dates)
    ↓  fetch_arrow_batches()
PyArrow batches
    ↓
write temp Parquet (local /tmp)
    ↓
validate row count / schema
    ↓
azure-storage-blob upload → positions/as_of_date=<date>/part-NNN.parquet
    ↓
update manifest.json → status: published
```

---

### Phase 5 — Analytics Layer

All paths resolved from a `DATASETS` whitelist — no user-supplied Parquet paths.

**Whitelist pattern:**

```python
POSITIONS_PATH = (
    "azure://{container}/portfolio/positions/as_of_date={date}/*.parquet"
)
```

**Key SQL patterns (parameterised):**

```sql
-- Positions with optional account filter
SELECT ticker, security_name, asset_class, quantity, market_value_base
FROM read_parquet(?)
WHERE client_id = ?
  AND (? IS NULL OR account_id = ANY(?))
ORDER BY market_value_base DESC

-- Asset allocation
SELECT
    asset_class,
    SUM(market_value_base) AS value,
    SUM(market_value_base) / SUM(SUM(market_value_base)) OVER () AS weight
FROM read_parquet(?)
WHERE client_id = ?
GROUP BY asset_class
ORDER BY value DESC

-- Transactions date range
SELECT transaction_date, ticker, type, quantity, price, amount
FROM read_parquet(?, hive_partitioning = true)
WHERE client_id = ?
  AND transaction_date BETWEEN ? AND ?
ORDER BY transaction_date DESC
```

---

### Phase 6 — FastAPI Endpoints

**All handlers are synchronous** (DuckDB is CPU-bound/blocking; async would block the event loop).

| Method | Path | Description |
|---|---|---|
| `GET` | `/health` | Liveness probe — always `200 OK` |
| `GET` | `/ready` | Readiness — checks manifest availability |
| `GET` | `/v1/clients/{client_id}/portfolio` | Latest positions; optional `?account_id=` filter |
| `GET` | `/v1/clients/{client_id}/portfolio/summary` | Portfolio totals + asset allocation |
| `GET` | `/v1/clients/{client_id}/portfolio/holdings` | Top holdings; optional `?limit=10` |
| `GET` | `/v1/clients/{client_id}/portfolio/transactions` | Transactions; required `?start_date=&end_date=` |
| `GET` | `/v1/clients/{client_id}/portfolio/performance` | Daily values; required `?start_date=&end_date=` |

**Input validation rules:**

- `end_date >= start_date` (400 if violated)
- `limit` capped at 100
- Date range capped at 365 days
- `client_id` validated against auth token's `allowed_client_ids`

---

### Phase 7 — Auth & Authorization

```
JWT (RS256)
  │
  ▼
get_current_user() → User(user_id, allowed_client_ids)
  │
  ▼
user.can_access_client(client_id) → bool
  │ False
  ▼
403 Forbidden   ← always 403, never 404 (prevents client ID enumeration)
```

---

### Phase 9 — Container Tuning (2 CPU / 4 GB)

```
Container: 2 CPU / 4 GB RAM

DuckDB per connection:
  memory_limit = 1 GB
  threads      = 2

Effective max concurrent DuckDB queries consuming full resources: ~3
(leaving ~1 GB for FastAPI/OS/Python overhead)

Kubernetes:
  resources.requests: cpu=500m, memory=1Gi
  resources.limits:   cpu=2,    memory=4Gi
```

Uvicorn workers: **1 worker per container** — let Kubernetes HPA handle horizontal scaling. Multiple Uvicorn workers inside one container compete for the same 4 GB.

---

## Future Enhancements (Backlog)

> These are explicitly **not** in scope for the current build phases. Add them as future work items.

### Performance & Caching
- [ ] **FE-01** Add an in-process LRU cache for the manifest (short TTL, e.g., 30 s) to avoid a Blob Storage lookup on every request
- [ ] **FE-02** Evaluate DuckDB connection pool (thread-local connections) if profiling shows connection creation is a hot path under sustained load
- [ ] **FE-03** Evaluate Azure CDN or API Management response caching for read-heavy, low-churn endpoints (e.g., `/summary`)
- [ ] **FE-04** Add Parquet row-group statistics and `bloom_filter_columns` on `client_id` to reduce scan I/O

### Data & Analytics
- [ ] **FE-05** Portfolio performance attribution (sector / security-level contribution to return)
- [ ] **FE-06** Benchmark comparison (portfolio return vs index)
- [ ] **FE-07** Risk metrics endpoint (volatility, Sharpe ratio, VaR) — requires historical daily values series
- [ ] **FE-08** Multi-currency normalization endpoint (allow client to specify reporting currency at query time)
- [ ] **FE-09** Account-level drill-down for all endpoints (currently optional filter; promote to first-class route `/accounts/{account_id}/...`)

### Ingestion
- [ ] **FE-10** Switch Snowflake ingestion to Snowflake key-pair authentication (replace password)
- [ ] **FE-11** Add data quality checks post-ingestion (row count deltas, null rate, price staleness alerts)
- [ ] **FE-12** Publish ingestion metrics to Azure Monitor / Event Hubs for alerting
- [ ] **FE-13** Support intraday snapshots (sub-daily partition granularity `as_of_date=YYYY-MM-DD/hour=HH/`)
- [ ] **FE-14** Schema evolution strategy — handle new Snowflake columns without breaking the API

### Security & Compliance
- [ ] **FE-15** Field-level data masking for certain sensitive fields (e.g., `quantity` visible only to authorized roles)
- [ ] **FE-16** Audit log every data access event to Azure Monitor (client_id, user_id, endpoint, timestamp)
- [ ] **FE-17** mTLS between AKS ingress and pod
- [ ] **FE-18** Secrets rotation — integrate Azure Key Vault for Snowflake credentials

### Operational
- [ ] **FE-19** Kubernetes HPA based on CPU / custom request-rate metric from Prometheus
- [ ] **FE-20** Distributed tracing with Azure Application Insights (OpenTelemetry)
- [ ] **FE-21** Canary / blue-green deployment strategy via Argo Rollouts or Flagger
- [ ] **FE-22** Chaos engineering test: verify service degrades gracefully when Blob Storage is unavailable

### Developer Experience
- [ ] **FE-23** OpenAPI spec export and publish to an API portal (Azure API Management)
- [ ] **FE-24** Add a `docker-compose.yml` for local development (Azurite blob emulator, mock Snowflake data)
- [ ] **FE-25** Add contract tests (Pact or similar) between this service and consumer UIs

---

## Quick Reference — Architecture Decisions

| Decision | Choice | Reason |
|---|---|---|
| DuckDB connection lifetime | Per-request `:memory:` | Stateless; no shared mutable state; safe concurrency |
| Snowflake access in API | ❌ None — ETL only | Avoid Snowflake as app serving layer; latency + cost |
| S3 vs Azure Blob | Azure Blob Storage | Platform is AKS on Azure |
| Auth mechanism (Blob) | Azure Workload Identity | No long-lived credentials in the container |
| Uvicorn workers | 1 per container | Let Kubernetes HPA scale horizontally |
| Async endpoints | ❌ Synchronous | DuckDB is synchronous; async blocks the event loop |
| SQL parameterisation | Always `?` placeholders | Prevents SQL injection |
| Parquet partitioning | `as_of_date=YYYY-MM-DD/` | Hive-compatible; DuckDB prunes irrelevant partitions |
| Auth scheme | JWT RS256 | Stateless; no session storage needed |
