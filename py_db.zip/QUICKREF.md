# Quick Reference Guide

## Start Here

1. **First Time?** Read [README.md](./README.md)
2. **Local Development?** Read [docs/DEVELOPER.md](./docs/DEVELOPER.md)
3. **Understanding Architecture?** Read [docs/ARCHITECTURE.md](./docs/ARCHITECTURE.md)
4. **Deploy to Kubernetes?** Read [docs/DEPLOYMENT.md](./docs/DEPLOYMENT.md)
5. **Contributing Code?** Read [docs/CONTRIBUTING.md](./docs/CONTRIBUTING.md)

---

## Common Commands

```bash
# Setup
make install            # Install Python dependencies
cp .env.example .env    # Configure environment

# Development
make dev                # Run dev server (http://localhost:8000)
make test               # Run test suite
make check              # Full check: lint + typecheck + test
make docker-run         # Run in Docker locally

# Code Quality
make format             # Auto-format with black
make lint               # Check with ruff
make typecheck          # Type check with mypy

# Maintenance
make clean              # Remove cache files
make docker-build       # Build Docker image
```

---

## Project Structure at a Glance

```
app/
  ├── main.py           ← 7 REST endpoints
  ├── config.py         ← Settings from .env
  ├── auth.py           ← JWT validation
  ├── duckdb_service.py ← Per-request DB connections
  ├── schemas.py        ← Pydantic models
  └── analytics/        ← SQL queries
      ├── portfolio.py
      ├── transactions.py
      └── performance.py

docs/
  ├── DEVELOPER.md      ← Local setup & testing
  ├── ARCHITECTURE.md   ← Design patterns
  ├── DEPLOYMENT.md     ← Kubernetes
  └── CONTRIBUTING.md   ← Code style & PRs

k8s/                    ← Kubernetes manifests (TODO)
tests/                  ← Pytest suite
Makefile                ← Development tasks
Dockerfile              ← Container image
requirements.txt        ← Python dependencies
PLAN.md                 ← Full 10-phase roadmap
```

---

## API Endpoints

| Method | Path | Status |
|---|---|---|
| `GET` | `/health` | ✅ Liveness |
| `GET` | `/ready` | ✅ Readiness |
| `GET` | `/v1/clients/{id}/portfolio` | ✅ Positions |
| `GET` | `/v1/clients/{id}/portfolio/summary` | ✅ Totals |
| `GET` | `/v1/clients/{id}/portfolio/holdings` | ✅ Top holdings |
| `GET` | `/v1/clients/{id}/portfolio/transactions` | ✅ Transactions |
| `GET` | `/v1/clients/{id}/portfolio/performance` | ✅ Performance |

All endpoints require: `Authorization: Bearer <jwt-token>`

---

## Development Workflow

### Add a New Endpoint

1. Write test in `tests/test_api.py`
2. Define schema in `app/schemas.py`
3. Add analytics query in `app/analytics/*.py`
4. Add handler in `app/main.py`
5. Run `make check`
6. Commit with message: `feat(api): add new-endpoint`

### Fix a Bug

1. Write failing test
2. Fix code
3. Verify: `make test`
4. Commit with message: `fix(module): description`

### Modify a Query

1. Always use parameterised SQL: `con.execute(query, [value1, value2])`
2. Never use f-strings in SQL: ❌ `f"WHERE id = '{user_id}'"`
3. Test with `make test`

---

## Testing

```bash
make test              # Run all tests
make test-coverage     # Coverage report (> 80% goal)
pytest -k test_health  # Run specific test
pytest -v tests/       # Verbose output
```

---

## Environment Variables (.env)

```
AZURE_STORAGE_ACCOUNT=devstorageaccount
AZURE_CONTAINER_NAME=portfolio-data
SNOWFLAKE_ACCOUNT=org-account
SNOWFLAKE_USER=svc_portfolio_reader
SNOWFLAKE_PASSWORD=...
DUCKDB_MEMORY_LIMIT=1GB
DUCKDB_THREADS=2
ENVIRONMENT=development
LOG_LEVEL=DEBUG
JWT_PUBLIC_KEY=...
```

---

## Docker

```bash
# Build image
docker build -t portfolio-api:latest .

# Run locally
docker run -it --rm -p 8000:8000 \
  -e AZURE_STORAGE_ACCOUNT=devstorageaccount \
  -e SNOWFLAKE_ACCOUNT=org-account \
  portfolio-api:latest

# Check logs
docker logs <container-id>
```

---

## Kubernetes Deployment

```bash
# Apply manifests
kubectl apply -f k8s/ -n portfolio

# Check status
kubectl get pods -n portfolio
kubectl logs -n portfolio deployment/portfolio-api

# Port forward
kubectl port-forward -n portfolio svc/portfolio-api 8000:80

# Test
curl http://localhost:8000/health
```

---

## Key Principles

1. **Stateless API** — No local files, no shared state
2. **Ephemeral Compute** — One DuckDB connection per request
3. **External State** — Parquet in Azure Blob Storage
4. **Security First** — Parameterised SQL, 403 not 404
5. **Observable** — Prometheus metrics, structured logs
6. **Testable** — Unit tests, integration tests, fixtures

---

## Build Phases

- ✅ **Phase 1-6:** Scaffold, DuckDB, Schemas, Analytics, FastAPI
- ⏳ **Phase 7-10:** Auth, Observability, Kubernetes, Load Testing
- 📋 **Enhancements:** 25 future items (caching, risk metrics, etc.)

See [PLAN.md](./PLAN.md) for full roadmap.

---

## Troubleshooting

**Config not loading?**
```bash
cp .env.example .env
make check-config
```

**Import errors?**
```bash
make install
python -c "from app.config import settings"
```

**Tests failing?**
```bash
make clean
make test -v
```

**Docker issues?**
```bash
docker build --no-cache -t portfolio-api:latest .
docker run --rm portfolio-api:latest --help
```

---

## Resources

- 📖 [DuckDB Docs](https://duckdb.org/docs/)
- 📖 [FastAPI Docs](https://fastapi.tiangolo.com/)
- 📖 [Kubernetes Docs](https://kubernetes.io/docs/)
- 📖 [Azure SDK](https://docs.microsoft.com/en-us/python/api/overview/azure/)
- 📖 [Snowflake Python Connector](https://docs.snowflake.com/en/developer-guide/snowflake-python-api/)

---

## Quick Links

- **Getting Started:** [README.md](./README.md)
- **Development:** [docs/DEVELOPER.md](./docs/DEVELOPER.md)
- **Architecture:** [docs/ARCHITECTURE.md](./docs/ARCHITECTURE.md)
- **Deployment:** [docs/DEPLOYMENT.md](./docs/DEPLOYMENT.md)
- **Contributing:** [docs/CONTRIBUTING.md](./docs/CONTRIBUTING.md)
- **Build Plan:** [PLAN.md](./PLAN.md)
- **Status:** [IMPLEMENTATION_STATUS.md](./IMPLEMENTATION_STATUS.md)

---

**Questions?** Open an issue or check the docs. Happy coding! 🚀
