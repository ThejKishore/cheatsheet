# Architecture

## High-Level Design

```
                 ┌─────────────────────────┐
                 │   Banking Clients       │
                 │   (UI / External API)   │
                 └────────────┬────────────┘
                              │
                              │ REST (FastAPI)
                              │ +JWT RS256
                              ▼
                 ┌─────────────────────────┐
                 │   FastAPI Application   │
                 │                         │
                 │ - Authentication        │
                 │ - Authorization         │
                 │ - Request validation    │
                 │ - Response formatting   │
                 └────────┬────────────────┘
                          │
                          │ request scoped
                          ▼
              ┌────────────────────────────┐
              │  DuckDB :memory: (req #1)  │
              │  DuckDB :memory: (req #2)  │
              │  DuckDB :memory: (req #N)  │
              │                            │
              │ - Resource limited        │
              │ - Read-only               │
              │ - Ephemeral               │
              │ - 1 per request           │
              └────────┬───────────────────┘
                       │
                       │ read Parquet
                       ▼
        ┌──────────────────────────────────┐
        │   Azure Blob Storage             │
        │                                  │
        │ portfolio/                       │
        │   positions/                     │
        │   ├─ as_of_date=2026-10-01/     │
        │   ├─ as_of_date=2026-10-02/     │
        │   └─ as_of_date=2026-10-07/     │
        │   (Hive partitioned Parquet)     │
        │                                  │
        │ portfolio_values/                │
        │ portfolio/transactions/          │
        │ portfolio/performance/           │
        │                                  │
        │ manifest.json (metadata)         │
        └──────────────────────────────────┘
                       ▲
                       │
                       │ write Parquet
                       │ (nightly/hourly)
        ┌──────────────────────────────────┐
        │   Ingestion ETL (Python)         │
        │                                  │
        │ - Snowflake connector            │
        │ - Arrow batch processing         │
        │ - Parquet writer                 │
        │ - Validation & manifest update   │
        └──────┬───────────────────────────┘
               │
               │ reads
               ▼
        ┌──────────────────────────────────┐
        │   Snowflake                      │
        │   (Source of Truth)              │
        │                                  │
        │ Tables:                          │
        │ - CLIENT, ACCOUNT, POSITION      │
        │ - SECURITY, PRICE, FX_RATE       │
        │ - TRANSACTION                    │
        └──────────────────────────────────┘
```

## Core Principles

### 1. Stateless API Layer

- **No shared state** between requests
- **One connection per request:** `duckdb.connect(":memory:")`
- **Ephemeral compute:** Connection created → used → destroyed per request
- **Horizontal scaling:** Kubernetes replicas don't need state synchronization

### 2. Durable External State

- **Azure Blob Storage** is the single source of truth for analytical data
- **Snowflake** is the source of truth for financial data
- **Parquet files** are immutable snapshots (incremental ingestion tracks state)
- Multiple API instances can safely read same Blob Storage without coordination

### 3. Separation of Concerns

| Layer | Responsibility | Technology |
|---|---|---|
| **Data** | Financial transactions, positions, prices | Snowflake |
| **Analytical State** | Denormalised snapshots (partitioned by date) | Azure Blob (Parquet) |
| **Compute** | SQL aggregation, filtering, analysis | DuckDB |
| **API** | HTTP interface, auth, response formatting | FastAPI |
| **Orchestration** | Kubernetes | AKS |

### 4. Security Model

```
Client Request
    │
    ├─► HTTP Bearer Token (JWT RS256)
    │
    ▼
FastAPI Auth Middleware
    ├─► Validate signature
    ├─► Extract user_id, org_id, allowed_client_ids
    │
    ▼
Authorization Gate
    ├─► Check: allowed_client_ids contains requested client_id
    ├─► Return 403 Forbidden (never 404 — prevents enumeration)
    │
    ▼
Analytics Query (Safe)
    ├─► All SQL values parameterised (? placeholders)
    ├─► No user input in SQL identifiers
    ├─► Whitelisted dataset paths (DATASETS constant)
    │
    ▼
Response
```

### 5. Resource Limits (Container Safety)

Per-request DuckDB configuration (tuned for 2 CPU / 4 GB container):

```python
settings.duckdb_memory_limit = "1GB"      # Max memory per connection
settings.duckdb_threads = 2               # Parallelism per query
```

**Effect:** If 10 concurrent requests arrive, each can use ≤1 GB → total ≤10 GB potential, but Kubernetes container limit is 4 GB → enforces OOM safety at pod level.

**Effective concurrent queries:** ~3-4 (leaving ~1 GB for FastAPI/Python/OS overhead).

---

## Data Flow Example

### Scenario: Client queries portfolio positions

```
1. Client HTTP request
   ┌─────────────────────────────────────┐
   │ GET /v1/clients/ACME-001/portfolio  │
   │ Authorization: Bearer <jwt-token>   │
   │ Accept: application/json            │
   └─────────────────────────────────────┘

2. FastAPI receives request
   ├─► Dependency injection: get_current_user()
   │   └─► Validate JWT RS256 signature
   │       └─► Extract claims: user_id, allowed_client_ids
   │
   ├─► Dependency injection: check_client_access("ACME-001")
   │   └─► Verify "ACME-001" in allowed_client_ids
   │       └─► Return 403 if not authorized
   │
   ├─► Handler: async def get_portfolio(client_id, ...)
   │   └─► Snapshot date defaults to today

3. Create ephemeral DuckDB connection
   ┌─────────────────────────────────────┐
   │ duckdb.connect(":memory:")          │
   │ - INSTALL httpfs, azure extensions  │
   │ - SET memory_limit = '1GB'          │
   │ - SET threads = 2                   │
   └─────────────────────────────────────┘

4. Parameterised SQL query (injection-safe)
   ┌─────────────────────────────────────────────────────┐
   │ query = """                                         │
   │   SELECT ticker, name, quantity, market_value      │
   │   FROM read_parquet(?)                              │
   │   WHERE client_id = ? AND as_of_date = ?           │
   │   ORDER BY market_value DESC                        │
   │ """                                                  │
   │                                                      │
   │ params = [                                           │
   │   "azure://account.blob.core.windows.net/           │
   │    portfolio-data/positions/as_of_date=2026-10-07/*"│
   │   "ACME-001",                                       │
   │   "2026-10-07"                                      │
   │ ]                                                    │
   │                                                      │
   │ result = con.execute(query, params).fetchall()      │
   └─────────────────────────────────────────────────────┘

5. DuckDB processes query
   ├─► Connect to Azure Blob Storage (Workload Identity auth)
   ├─► Scan Parquet in partition as_of_date=2026-10-07/
   ├─► Push down WHERE clauses (client_id, as_of_date)
   ├─► Aggregate, sort, limit results
   └─► Return tuples

6. FastAPI formats response
   ┌─────────────────────────────────────┐
   │ PortfolioPositionsResponse {        │
   │   client_id: "ACME-001",            │
   │   as_of_date: "2026-10-07",         │
   │   positions: [                      │
   │     {                               │
   │       ticker: "AAPL",               │
   │       name: "Apple Inc.",           │
   │       quantity: 500,                │
   │       market_value: 1225000.00,     │
   │       weight: 0.0984                │
   │     },                              │
   │     ...                             │
   │   ],                                │
   │   total_value: 12450320.00          │
   │ }                                   │
   └─────────────────────────────────────┘

7. Close DuckDB connection
   ├─► Release memory (1 GB freed)
   ├─► Close Blob Storage connection
   └─► Connection disappears

8. HTTP 200 response sent
   ├─► JSON body with portfolio data
   ├─► X-Request-ID header (tracing)
   └─► Total request time: ~50-500 ms (depends on data size)
```

---

## Ingestion Pipeline (Separate Process)

Runs on a schedule (nightly or hourly, not in the API pod):

```
Snowflake ETL Job (Python)
│
├─1. Read last successful date from manifest.json
│   │  (e.g., "2026-10-06")
│   │
├─2. Query Snowflake incrementally
│   │
│   └─ SELECT ... FROM positions WHERE as_of_date > "2026-10-06"
│      (Only new/changed data)
│
├─3. Join with metadata tables
│   │
│   ├─ securities (name, asset_class, sector)
│   ├─ prices (price per security, date)
│   ├─ fx_rates (currency conversion)
│   │
│   └─ Result: denormalised portfolio_position view
│
├─4. Stream to Parquet (batch processing)
│   │
│   └─ for batch in snowflake.fetch_arrow_batches():
│        write_temp_parquet(batch)
│
├─5. Validate
│   │
│   ├─ Row count (✓ if > threshold)
│   ├─ Schema (✓ if matches expected)
│   ├─ Null rates (✓ if acceptable)
│   │
│   └─ if validation fails: ROLLBACK
│
├─6. Upload to Blob Storage
│   │
│   └─ cp positions_YYYY-MM-DD.parquet →
│       azure://portfolio-data/positions/as_of_date=2026-10-07/part-000.parquet
│
└─7. Update manifest.json
    │
    └─ {
         "dataset": "portfolio_positions",
         "as_of_date": "2026-10-07",
         "status": "published",
         "published_at": "2026-10-07T06:30:00Z"
       }

Next run:
  read manifest → last_date = "2026-10-07"
  query Snowflake from "2026-10-07"
  (Only new data processed)
```

### Why Incremental Ingestion?

- **Scalability:** Only processes new/changed data
- **Cost:** Reduced Snowflake query time & Parquet upload bandwidth
- **Freshness:** Can run more frequently (hourly vs daily)
- **Reliability:** Manifest tracks progress for recovery

---

## Parquet Layout & Partitioning

### Hive Partitioning Strategy

```
portfolio/positions/
│
├─ as_of_date=2026-10-01/
│  ├─ part-000.parquet     (rows 1-10000)
│  ├─ part-001.parquet     (rows 10001-20000)
│  └─ part-002.parquet     (rows 20001-30000)
│
├─ as_of_date=2026-10-02/
│  ├─ part-000.parquet
│  └─ part-001.parquet
│
├─ as_of_date=2026-10-03/
│  ├─ part-000.parquet
│  └─ part-001.parquet
│
...
```

**Benefits:**

1. **Partition pruning:** DuckDB reads only `as_of_date=2026-10-07/*` if filtering by that date
2. **Parallel I/O:** Multiple parts can be read concurrently
3. **Scalability:** Easy to add new partitions without affecting existing data
4. **Retention:** Can delete old dates by removing directories

### Parquet Optimizations

| Setting | Value | Purpose |
|---|---|---|
| **Compression** | `zstd` | Better compression ratio, reasonable CPU |
| **Row group size** | 10K-50K rows | Enables statistics-based filtering |
| **Bloom filters** | `client_id` | Fast point lookups (bloom_filter_columns in write) |
| **Statistics** | Min/max per column | DuckDB skips unnecessary blocks |

---

## Concurrency Model

### Request Isolation

```
Request #1                Request #2                Request #3
    │                         │                         │
    ├─► DuckDB :mem:1         ├─► DuckDB :mem:2         ├─► DuckDB :mem:3
    │   [1GB limit]           │   [1GB limit]           │   [1GB limit]
    │   [2 threads]           │   [2 threads]           │   [2 threads]
    │                         │                         │
    └─► Query #1              └─► Query #2              └─► Query #3
        (execution)               (execution)               (execution)
        [Fast aggregation]        [Parallel scan]          [Top-N selection]
```

**Guarantees:**

- No connection sharing (✓ thread-safe)
- No memory leak (✓ connections freed after request)
- No query interference (✓ isolated SQL namespaces)
- Resource limits enforced (✓ per-connection limits + Kubernetes pod limits)

### Why Synchronous Handlers?

```
# ❌ WRONG (blocks event loop)
@app.get("/query")
async def query():
    con = duckdb.connect(":memory:")
    result = con.execute(...).fetchall()  # BLOCKS EVENT LOOP!
    return result

# ✅ CORRECT (Uvicorn threads in thread pool)
@app.get("/query")
def query():
    con = duckdb.connect(":memory:")
    result = con.execute(...).fetchall()  # Runs in thread pool
    return result
```

DuckDB Python API is synchronous. Running sync code in `async def` blocks the entire event loop. FastAPI/Starlette automatically runs sync handlers in a thread pool (CPU-bound work, blocking I/O).

---

## Authentication & Authorization

### JWT RS256 Flow

```
1. Client obtains JWT token (external auth system)
   ┌─────────────────────────────────┐
   │ Sub (user_id): "user@example.com│
   │ Org (org_id): "banking-co"      │
   │ Scope: acme-001:reader          │
   │ Iss: "https://auth.example.com" │
   │ Aud: "portfolio-api"            │
   │ Iat: 1696700000                 │
   │ Exp: 1696703600 (1 hour)        │
   │ Sig: RS256(secret_key)          │
   └─────────────────────────────────┘

2. Client includes in request
   GET /v1/clients/ACME-001/portfolio
   Authorization: Bearer eyJhbGciOiJSUzI1NiIs...

3. FastAPI validates
   ├─ Parse Bearer token
   ├─ Fetch issuer's public key
   ├─ Verify RS256 signature
   ├─ Validate exp (not expired)
   ├─ Validate aud (matches "portfolio-api")
   └─ Extract claims: sub, org_id, scope

4. App builds User object
   User {
     user_id: "user@example.com",
     org_id: "banking-co",
     allowed_client_ids: ["ACME-001", "ACME-002"]  # from scope
   }

5. Authorization gate
   ├─ Check: "ACME-001" in allowed_client_ids?
   ├─ Yes  → proceed to analytics query
   └─ No   → return 403 Forbidden (never 404)

6. Query proceeds as authorized user
   SELECT positions WHERE client_id = "ACME-001"
```

### Why 403 vs 404?

- **404 Not Found** suggests resource doesn't exist → allows attackers to enumerate valid client IDs
- **403 Forbidden** says "you don't have permission" → no info leakage

---

## Error Handling

### Request Validation Errors

```
GET /v1/clients/{id}/transactions?end_date=2026-10-01&start_date=2026-10-31
```

**Error:** `end_date < start_date`

**Response (400 Bad Request):**

```json
{
  "error": "HTTP Error",
  "status_code": 400,
  "detail": "end_date must be >= start_date",
  "timestamp": "2026-10-07T22:59:03.786-05:00"
}
```

### Authentication Errors

```
GET /v1/clients/ACME-001/portfolio
```

**Error:** No Bearer token

**Response (401 Unauthorized):**

```json
{
  "error": "HTTP Error",
  "status_code": 401,
  "detail": "Invalid authentication credentials",
  "timestamp": "2026-10-07T22:59:03.786-05:00"
}
```

### Authorization Errors

```
GET /v1/clients/ACME-999/portfolio
Authorization: Bearer <token-for-user-with-access-to-ACME-001-only>
```

**Error:** User not authorized for ACME-999

**Response (403 Forbidden):**

```json
{
  "error": "HTTP Error",
  "status_code": 403,
  "detail": "Access denied",
  "timestamp": "2026-10-07T22:59:03.786-05:00"
}
```

### Query Errors

```
Query times out or Blob Storage is unreachable
```

**Response (500 Internal Server Error):**

```json
{
  "error": "HTTP Error",
  "status_code": 500,
  "detail": "Failed to fetch portfolio positions",
  "timestamp": "2026-10-07T22:59:03.786-05:00"
}
```

All errors include:
- Standard HTTP status code
- Human-readable message
- Timestamp for log correlation
- (Optional) detailed debug info in logs

---

## Performance Characteristics

### Query Latency (Estimated)

| Query | Data Size | Expected Latency |
|---|---|---|
| Get positions (1 client, 1 day) | 10K rows | 50-200 ms |
| Asset allocation (1 client) | 10K rows | 50-200 ms |
| Top holdings (1 client, limit 10) | 10K rows | 50-200 ms |
| Transactions (1 client, 1 year) | 100K rows | 200-500 ms |
| Performance series (1 client, 1 year) | 365 rows | 100-300 ms |

**Factors:**
- **Parquet I/O:** Network latency to Blob Storage + compression overhead
- **DuckDB parallelism:** Scales with thread count (2 threads for this container)
- **Data size:** Larger datasets take longer (predictably)
- **Network:** Azure Blob to AKS node (usually < 50 ms)

### Memory Usage

Per DuckDB connection:
- **Baseline:** ~50-100 MB (Python runtime + DuckDB engine)
- **Query:** 10-100 MB (depends on result set size)
- **Limit:** 1 GB (enforced by `DUCKDB_MEMORY_LIMIT`)

**Safe concurrent queries:** ~3-4 per pod (4 GB total limit)

### CPU Usage

Per query:
- **I/O-bound (Parquet scan):** CPU 20-50% while reading
- **Compute-bound (aggregation):** CPU 50-100% while processing

Uvicorn thread pool ensures requests don't starve each other.

---

## Monitoring & Observability

### Metrics (Prometheus)

```
# Request latency (histogram)
http_request_duration_seconds_bucket{le=0.1, path="/v1/clients/{id}/portfolio"}
http_request_duration_seconds_bucket{le=0.5, path="/v1/clients/{id}/portfolio"}
http_request_duration_seconds_bucket{le=1.0, path="/v1/clients/{id}/portfolio"}

# Request count (counter)
http_requests_total{method="GET", endpoint="/health", status="200"}
http_requests_total{method="GET", endpoint="/v1/clients/{id}/portfolio", status="200"}

# Errors (counter)
http_requests_total{status="401"}
http_requests_total{status="403"}
http_requests_total{status="500"}
```

### Logs (Structured)

```
2026-10-07 22:59:03 INFO Fetched 15 positions for client=ACME-001, date=2026-10-07
2026-10-07 22:59:04 INFO DuckDB connection created: memory=1GB, threads=2
2026-10-07 22:59:05 ERROR Error fetching portfolio: [reason], exc_info=True
```

---

## See Also

- [DEVELOPER.md](./DEVELOPER.md) — Local development setup, testing, debugging
- [DEPLOYMENT.md](./DEPLOYMENT.md) — Kubernetes manifests, scaling, production checklist
- [PLAN.md](../PLAN.md) — Full 10-phase build roadmap + 25 future enhancements
