# Portfolio Explorer Microservice — Developer Guide

## Overview

A **stateless, read-only portfolio analytics microservice** for banking clients to query their portfolio positions, holdings, transactions, and performance metrics.

**Key architecture:**

```
Clients
  │
  ├─► FastAPI (stateless)
  │       │
  │       ├─► DuckDB :memory: (per-request)
  │       │       │
  │       │       └─► Azure Blob Storage (Parquet data)
  │       │
  │       └─► Auth/authz (JWT RS256)
  │
  └─► Snowflake (data source)
        │
        └─► Ingestion ETL (separate process)
```

**Technologies:**
- **Python 3.12** (async-friendly, type-safe)
- **FastAPI** (modern REST API framework)
- **DuckDB** (in-memory analytical SQL engine)
- **Snowflake** (source-of-truth financial data)
- **Azure Blob Storage** (persistent Parquet snapshots)
- **Kubernetes (AKS)** (container orchestration)

**Build Phases:** See [PLAN.md](../PLAN.md) for full 10-phase delivery roadmap with checklists.

---

## Local Development Setup

### Prerequisites

- **Python 3.12+**
- **pip** or **uv** (dependency manager)
- **Docker** (for containerization)
- **Git**

### 1. Clone & Install

```bash
cd portfolio-api
make install
# or: pip install -r requirements.txt
```

### 2. Configure `.env`

```bash
cp .env.example .env
# Edit .env with your local values (see .env.example for keys)
```

**For local development:**
- Use **Azure Azurite** (blob emulator) or real Azure dev storage account
- Snowflake credentials (user/password) — keep secure
- JWT settings can be stubbed for now (see `app/auth.py`)

### 3. Run Dev Server

```bash
make dev
# Starts uvicorn with auto-reload at http://localhost:8000
```

**Quick checks:**
- Health: `curl http://localhost:8000/health`
- API docs: http://localhost:8000/docs (Swagger UI)
- Metrics: http://localhost:8000/metrics (Prometheus)

---

## Project Structure

```
portfolio-api/
├── app/                          # Core FastAPI application
│   ├── __init__.py
│   ├── main.py                   # FastAPI app, 7 endpoints
│   ├── config.py                 # Settings (pydantic-settings)
│   ├── auth.py                   # JWT + authz middleware
│   ├── duckdb_service.py         # :memory: connection context manager
│   ├── schemas.py                # Pydantic models (request/response)
│   └── analytics/
│       ├── __init__.py
│       ├── portfolio.py          # Positions, allocation, holdings queries
│       ├── transactions.py       # Transaction queries
│       └── performance.py        # Daily value series queries
│
├── ingestion/                    # Snowflake → Parquet ETL (separate process)
│   ├── __init__.py
│   ├── snowflake_extractor.py   # Arrow batch iterator from Snowflake
│   ├── parquet_writer.py         # Write batches → temp → validate → upload
│   ├── azure_uploader.py         # Upload to Blob Storage
│   ├── manifest.py               # Metadata tracking (latest snapshot)
│   └── etl_job.py                # Orchestrator (extraction → publication)
│
├── tests/                        # pytest suite
│   ├── fixtures/                 # Sample Parquet files
│   ├── test_api.py               # Integration tests (endpoints)
│   ├── test_analytics.py         # Unit tests (SQL queries)
│   └── test_auth.py              # Auth/authz tests
│
├── k8s/                          # Kubernetes manifests
│   ├── deployment.yaml           # Deployment spec
│   ├── service.yaml              # ClusterIP service
│   ├── configmap.yaml            # Non-secret config
│   └── serviceaccount.yaml       # Workload Identity
│
├── docs/                         # Developer documentation
│   ├── CONTRIBUTING.md
│   ├── ARCHITECTURE.md
│   └── DEPLOYMENT.md
│
├── Makefile                      # Common tasks (install, dev, test, docker)
├── Dockerfile                    # Container image definition
├── requirements.txt              # Python dependencies
├── .env.example                  # Environment template
├── .gitignore
└── PLAN.md                       # Full build plan (10 phases, 25 enhancements)
```

---

## Key Files & Responsibilities

### `app/main.py` — FastAPI Application

The main app file with 7 endpoints:

| Endpoint | Method | Purpose |
|---|---|---|
| `/health` | `GET` | Liveness probe (always 200) |
| `/ready` | `GET` | Readiness probe (checks manifest) |
| `/v1/clients/{client_id}/portfolio` | `GET` | Latest positions (optional account filter) |
| `/v1/clients/{client_id}/portfolio/summary` | `GET` | Totals + asset allocation |
| `/v1/clients/{client_id}/portfolio/holdings` | `GET` | Top holdings (configurable limit) |
| `/v1/clients/{client_id}/portfolio/transactions` | `GET` | Transactions by date range |
| `/v1/clients/{client_id}/portfolio/performance` | `GET` | Daily value series |

**All handlers are synchronous** (DuckDB is blocking; async blocks the event loop).

**All endpoints require authentication:** `Authorization: Bearer <token>`

### `app/config.py` — Configuration

Loads settings from environment variables using `pydantic-settings`:

```python
from app.config import settings

settings.azure_storage_account      # "mystorageaccount"
settings.duckdb_memory_limit        # "1GB"
settings.duckdb_threads             # 2
settings.environment                # "development" or "production"
```

### `app/duckdb_service.py` — Ephemeral DuckDB Connections

Context manager for per-request `:memory:` connections:

```python
from app.duckdb_service import duckdb_connection

with duckdb_connection() as con:
    result = con.execute(
        "SELECT * FROM read_parquet(?) WHERE id = ?",
        ["azure://bucket/data.parquet", "123"]
    ).fetchall()
```

**Key properties:**
- `:memory:` (no local `.duckdb` file)
- Resource limits per connection (memory, threads)
- Azure Blob Storage auth via `httpfs` extension
- Thread-safe (new connection per request)

### `app/auth.py` — Authentication & Authorization

- `get_current_user()` dependency: validates JWT token, extracts user info
- `check_client_access()` dependency: verifies user can access requested client
- Returns **403 Forbidden** (never 404) to prevent client ID enumeration

Currently a stub (development). **Production implementation needed:**
- Validate JWT RS256 with `settings.jwt_public_key`
- Decode JWT claims (sub, org_id, allowed_client_ids)
- See `TODO` comments in `auth.py`

### `app/schemas.py` — Pydantic Models

Request/response models with validation:

```python
from app.schemas import PortfolioPositionsResponse, Position

response = PortfolioPositionsResponse(
    client_id="ACME-001",
    as_of_date=date(2026, 10, 7),
    positions=[Position(...), ...],
    total_value=12450320.0,
)
```

### `app/analytics/*.py` — Analytics Queries

Pure SQL functions (parameterised, injection-safe):

- **`portfolio.py`:**
  - `get_positions(con, client_id, as_of_date, account_ids?)`
  - `get_portfolio_summary(con, client_id, as_of_date)`
  - `get_asset_allocation(con, client_id, as_of_date)`
  - `get_top_holdings(con, client_id, as_of_date, limit?)`

- **`transactions.py`:**
  - `get_transactions(con, client_id, start_date, end_date, account_ids?)`

- **`performance.py`:**
  - `get_performance(con, client_id, start_date, end_date)`

**All use parameterised placeholders (`?`) — never f-string interpolation.**

---

## Development Workflow

### Make Commands

```bash
# Install dependencies
make install

# Run development server (auto-reload)
make dev

# Run tests
make test

# Run tests with coverage
make test-coverage

# Lint (ruff)
make lint

# Format (black)
make format

# Type check (mypy)
make typecheck

# Validate configuration
make check-config

# Build Docker image
make docker-build

# Run container locally
make docker-run

# Full check suite: lint + typecheck + test
make check

# Clean __pycache__, .pytest_cache, etc.
make clean
```

### Example: Add a New Endpoint

1. **Define schema** in `app/schemas.py`
2. **Write analytics query** in `app/analytics/portfolio.py` (or similar)
3. **Add FastAPI handler** in `app/main.py`
4. **Write unit tests** in `tests/test_analytics.py`
5. **Write integration tests** in `tests/test_api.py`
6. **Run `make check`** (lint, typecheck, test)

### Example: Modify a Query

All analytics queries use **parameterised SQL**:

```python
# ✅ GOOD — Injection-safe
query = "SELECT * FROM read_parquet(?) WHERE client_id = ?"
con.execute(query, [path, client_id])

# ❌ BAD — SQL injection risk
query = f"SELECT * FROM read_parquet('{path}') WHERE client_id = '{client_id}'"
con.execute(query)
```

---

## Testing

### Run Tests

```bash
make test              # Run all tests
make test-coverage     # With coverage report
pytest tests/          # Direct pytest
pytest -k test_health  # Run specific test
```

### Writing Tests

**Example integration test** (`tests/test_api.py`):

```python
from httpx import AsyncClient
from app.main import app

@pytest.mark.asyncio
async def test_get_portfolio():
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.get(
            "/v1/clients/ACME-001/portfolio",
            headers={"Authorization": "Bearer test-token"}
        )
        assert response.status_code == 200
        data = response.json()
        assert data["client_id"] == "ACME-001"
        assert "positions" in data
```

**Example unit test** (`tests/test_analytics.py`):

```python
from app.analytics import portfolio
from app.duckdb_service import duckdb_connection

def test_get_positions():
    with duckdb_connection() as con:
        # Use a fixture Parquet file
        positions = portfolio.get_positions(
            con,
            client_id="TEST-001",
            as_of_date=date(2026, 10, 7)
        )
        assert len(positions) > 0
        assert positions[0][0]  # ticker
```

### Fixtures

Store sample Parquet files in `tests/fixtures/`:

```bash
tests/
└── fixtures/
    ├── positions_sample.parquet
    ├── transactions_sample.parquet
    └── performance_sample.parquet
```

---

## Logging & Observability

### Structured Logging

Uses Python's `logging` module:

```python
import logging
logger = logging.getLogger(__name__)

logger.info("Fetched %d positions", len(positions))
logger.error("Error fetching portfolio: %s", str(e), exc_info=True)
```

Log level controlled via `settings.log_level` (default: `INFO`).

### Prometheus Metrics

Endpoint: `http://localhost:8000/metrics`

Automatically instrumented by `prometheus-fastapi-instrumentator`:
- Request count
- Request latency (ms)
- HTTP status codes
- Error rate

Custom metrics can be added:

```python
from prometheus_client import Counter

request_count = Counter("api_requests", "Total requests")
request_count.inc()
```

### Structured Logging (Optional)

For production, consider `structlog`:

```python
import structlog
logger = structlog.get_logger()

logger.info("query_executed", client_id="ACME-001", duration_ms=42)
# Output: {"event": "query_executed", "client_id": "ACME-001", "duration_ms": 42}
```

---

## Azure Blob Storage Integration

### Development (Azurite Emulator)

Use Azurite to emulate Azure Blob Storage locally:

```bash
# Install (npm)
npm install -g azurite

# Run emulator
azurite --silent --location ./data

# Configure .env
AZURE_STORAGE_ACCOUNT=devstoreaccount1
AZURE_STORAGE_CONNECTION_STRING=DefaultEndpointsProtocol=http;AccountName=devstoreaccount1;AccountKey=Eby8vdM02xNOcqFlqUwJPLMiuNHmwx7F0KPZedLrCfsxUKEWYpQ+Jx4VzvMK5xY9/Wvz1NpKdS5xRTMSCH+0Uw==;BlobEndpoint=http://127.0.0.1:10000/devstoreaccount1/;
```

### Production (Azure Workload Identity)

In AKS, use Azure Workload Identity for secure, keyless access:

1. Create Azure Service Account
2. Create AKS Service Account with annotation pointing to Azure Service Account
3. Pod inherits Azure credentials automatically
4. DuckDB uses `SET azure_use_workload_identity = true`

No passwords/keys in container.

---

## Common Tasks

### Debug a Query

```python
# app/debug.py (development helper)
import duckdb
from datetime import date

con = duckdb.connect(":memory:")
con.execute("INSTALL httpfs; LOAD httpfs")

# Simulate Azure Blob path (local Parquet for testing)
path = "tests/fixtures/positions_sample.parquet"

result = con.execute(f"""
    SELECT client_id, ticker, market_value_base
    FROM read_parquet('{path}')
    LIMIT 5
""").fetchall()

print(result)
con.close()
```

Run: `python app/debug.py`

### Profile Query Performance

```python
import time
from app.duckdb_service import duckdb_connection
from app.analytics import portfolio

start = time.time()
with duckdb_connection() as con:
    positions = portfolio.get_positions(con, "ACME-001", date.today())
elapsed = time.time() - start

print(f"Query took {elapsed:.2f}s for {len(positions)} positions")
```

### Inspect Parquet Schema

```bash
python -c "
import pyarrow.parquet as pq
table = pq.read_table('tests/fixtures/positions_sample.parquet')
print(table.schema)
"
```

---

## Docker & Container

### Build Image

```bash
make docker-build
# or: docker build -t portfolio-api:latest .
```

### Run Locally

```bash
make docker-run
# Runs on http://localhost:8000 with dev environment
```

### Push to Registry

```bash
# Tag for Azure Container Registry
docker tag portfolio-api:latest myacr.azurecr.io/portfolio-api:latest

# Push
docker push myacr.azurecr.io/portfolio-api:latest
```

### Image Details

- **Base:** `python:3.12-slim` (~200 MB)
- **User:** `appuser` (non-root, security best practice)
- **Startup:** Uvicorn with 1 worker (scale horizontally via Kubernetes)
- **Health check:** Probes `/health` endpoint every 30s
- **Exposed:** Port 8000

---

## Kubernetes Deployment

See [k8s/deployment.yaml](../k8s/deployment.yaml):

```bash
kubectl apply -f k8s/

# Check deployment
kubectl get deployment portfolio-api
kubectl logs deployment/portfolio-api

# Port forward for local testing
kubectl port-forward svc/portfolio-api 8000:8000
curl http://localhost:8000/health
```

**Key Kubernetes features:**
- Liveness probe: `/health` (30s interval, 3 retries)
- Readiness probe: `/ready` (5s delay, checks manifest)
- Resource requests: CPU 500m, Memory 1Gi
- Resource limits: CPU 2, Memory 4Gi (tuned for 2-CPU/4-GB container)
- Workload Identity for Azure Blob Storage access
- Horizontal Pod Autoscaler (optional; see `FE-19` in PLAN.md)

---

## Troubleshooting

### "ModuleNotFoundError: No module named 'duckdb'"

```bash
make install  # Reinstall dependencies
```

### "AZURE_STORAGE_ACCOUNT not set"

```bash
cp .env.example .env
# Edit .env with your values
make check-config
```

### "JWT token invalid"

Currently stubbed. To enable:
1. Generate RS256 key pair
2. Set `JWT_PUBLIC_KEY` in `.env`
3. Implement JWT validation in `app/auth.py` (see `TODO`)

### "No Parquet data found"

Check:
- Azure Blob connection (connection string or Workload Identity)
- Parquet file path matches `DATASETS` whitelist in `app/analytics/`
- Snowflake ingestion job has run (check `manifest.json` in Blob)

### "DuckDB :memory: out of memory"

Check `DUCKDB_MEMORY_LIMIT` in `.env`. Tune based on data size:
- Small datasets (< 100K rows): 512MB
- Medium (100K-1M rows): 1GB
- Large (> 1M rows): 2GB+

---

## Performance Tuning

### Container Resources

Recommended for 2-CPU / 4-GB Kubernetes container:

```yaml
resources:
  requests:
    cpu: 500m
    memory: 1Gi
  limits:
    cpu: 2
    memory: 4Gi
```

Per-request DuckDB limits:

```python
# app/config.py
duckdb_memory_limit: str = "1GB"  # Per connection
duckdb_threads: int = 2            # Parallelism per query
```

**Effective max concurrent queries:** ~3 (leaving ~1 GB for FastAPI/OS)

### Parquet Optimization

- Use **Hive partitioning** by date: `as_of_date=2026-10-07/`
- **Row-group statistics** enable DuckDB to skip reading unnecessary blocks
- **Columnar compression** (Snappy or Zstandard): reduces file size, I/O
- **Bloom filters** on `client_id` for point lookups

### Query Optimization

- Use **predicates** early: `WHERE client_id = ?` before aggregations
- **Push down** filters to Parquet scan (DuckDB does this automatically)
- **Limit** result sets: `LIMIT 100` instead of fetching all
- **Avoid full table scans:** Partition by query dimensions

---

## Contributing

1. **Branch naming:** `feature/add-endpoint`, `bugfix/fix-auth`, etc.
2. **Commit messages:** `feat: add holdings endpoint`, `fix: SQL injection in query`
3. **PR description:** Explain *what* and *why*
4. **Tests:** All new code must include tests (`make test`)
5. **Linting & formatting:** Run `make check` before pushing
6. **No secrets:** Never commit `.env`, API keys, or credentials

See [CONTRIBUTING.md](./CONTRIBUTING.md) for details.

---

## Next Steps

1. **Complete Phase 1-4:** Scaffold, DuckDB service, Snowflake ingestion, schemas
2. **Implement Phase 5-6:** Analytics layer and FastAPI endpoints (mostly done!)
3. **Add Phase 7:** JWT authentication with production RS256 validation
4. **Set up Phase 9:** Kubernetes manifests and local Docker testing
5. **Load test Phase 10:** Benchmark memory usage, concurrency limits

See [PLAN.md](../PLAN.md) for full build phases and **25 future enhancements** (performance caching, risk metrics, data quality checks, etc.).

---

## Useful Links

- **DuckDB docs:** https://duckdb.org/docs/
- **FastAPI docs:** https://fastapi.tiangolo.com/
- **Snowflake Python SDK:** https://docs.snowflake.com/en/developer-guide/snowflake-python-api/
- **Azure SDK:** https://docs.microsoft.com/en-us/python/api/overview/azure/
- **Pydantic docs:** https://docs.pydantic.dev/
- **Kubernetes docs:** https://kubernetes.io/docs/

---

**Questions?** Refer to the code comments, check `PLAN.md` for architecture rationale, or open an issue.
