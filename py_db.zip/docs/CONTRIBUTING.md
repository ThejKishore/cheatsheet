# Contributing Guide

## Welcome!

We're excited to have you contribute to the **Portfolio Explorer Microservice**. This guide explains how to set up your development environment, make changes, and submit your work.

---

## Code of Conduct

Be respectful, inclusive, and professional. We welcome contributions from everyone.

---

## Getting Started

### 1. Fork & Clone

```bash
git clone https://github.com/your-org/portfolio-api.git
cd portfolio-api
```

### 2. Set Up Development Environment

```bash
make install          # Install Python dependencies
cp .env.example .env  # Configure environment
make check-config     # Verify setup
```

### 3. Run Tests Locally

```bash
make test             # Run test suite
make test-coverage    # Run with coverage report
```

---

## Development Workflow

### Branch Naming

Use descriptive branch names:

- `feature/add-holdings-endpoint` — New feature
- `bugfix/fix-sql-injection` — Bug fix
- `docs/update-readme` — Documentation
- `refactor/simplify-auth` — Code refactor
- `test/add-coverage-for-portfolio` — Test improvements

```bash
git checkout -b feature/your-feature-name
```

### Code Style

We use **Black** (formatter) and **Ruff** (linter).

```bash
make format   # Auto-format code
make lint     # Check for style issues
make check    # Format + lint + typecheck + test (full check)
```

All PRs must pass `make check`.

### Type Annotations

We use **mypy** for static type checking. All new code must be type-safe:

```python
from datetime import date
from typing import Optional

def get_positions(
    client_id: str,
    as_of_date: date,
    account_ids: Optional[list[str]] = None,
) -> list[tuple]:
    """Fetch positions for a client."""
    ...
```

Run type check: `make typecheck`

### Commit Messages

Follow conventional commit format:

```
<type>(<scope>): <subject>

<body>

<footer>
```

**Type:** `feat`, `fix`, `docs`, `test`, `refactor`, `perf`, `chore`

**Scope:** `api`, `auth`, `analytics`, `ingestion`, `k8s`, `docs`

**Subject:** Imperative mood, lowercase, no period (50 chars max)

**Examples:**

```
feat(api): add transactions endpoint with date range filter

Implement GET /v1/clients/{id}/portfolio/transactions
- Parameterised SQL prevents injection
- Validates date range (max 365 days)
- Includes optional account_id filter

Closes #42
```

```
fix(auth): return 403 instead of 404 for unauthorized clients

Prevent client ID enumeration by always returning 403 Forbidden
instead of 404 Not Found when user lacks access.

Reviewed-by: @reviewer
```

```
docs(README): add quickstart section
```

### Pull Request Process

1. **Push to your fork:**

   ```bash
   git push origin feature/your-feature-name
   ```

2. **Open PR on GitHub** with description:

   ```
   ## Description
   
   What does this PR do? Why?
   
   ## Changes
   
   - [ ] Added new endpoint: `GET /portfolio/transactions`
   - [ ] Parameterised all SQL queries
   - [ ] Added 10 integration tests
   
   ## Checklist
   
   - [x] Code formatted (`make format`)
   - [x] Linting passes (`make lint`)
   - [x] Type checking passes (`make typecheck`)
   - [x] Tests pass (`make test`)
   - [x] New tests added for new functionality
   - [x] Documentation updated
   - [x] No secrets committed
   ```

3. **Address review feedback:**

   ```bash
   # Make changes
   git add .
   git commit -m "fix(api): address review comments"
   git push origin feature/your-feature-name
   ```

4. **Maintainer merges** when approved.

---

## Adding a New Feature

### Example: Add a new endpoint

#### 1. Plan (discuss in issue)

Create an issue describing the feature:

```
Title: Add sector allocation endpoint

Description:
GET /v1/clients/{id}/portfolio/sectors
Returns portfolio breakdown by sector (Technology, Healthcare, etc.)

Acceptance criteria:
- Returns sector name, value, and weight
- Supports optional as_of_date parameter
- Requires authentication
- Tests included
```

#### 2. Create branch

```bash
git checkout -b feature/add-sector-endpoint
```

#### 3. Write tests first (TDD)

```python
# tests/test_api.py

import pytest
from httpx import AsyncClient
from app.main import app
from datetime import date

@pytest.mark.asyncio
async def test_get_sector_allocation():
    """Test sector allocation endpoint."""
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.get(
            "/v1/clients/ACME-001/portfolio/sectors",
            params={"as_of_date": "2026-10-07"},
            headers={"Authorization": "Bearer test-token"}
        )
        
        assert response.status_code == 200
        data = response.json()
        
        assert data["client_id"] == "ACME-001"
        assert "sectors" in data
        assert len(data["sectors"]) > 0
        
        # Each sector has required fields
        for sector in data["sectors"]:
            assert "sector_name" in sector
            assert "value" in sector
            assert "weight" in sector
            assert 0 <= sector["weight"] <= 1

@pytest.mark.asyncio
async def test_sector_allocation_unauthorized():
    """Test 403 when user lacks access."""
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.get(
            "/v1/clients/UNKNOWN-999/portfolio/sectors",
            headers={"Authorization": "Bearer test-token"}
        )
        
        assert response.status_code == 403
        data = response.json()
        assert data["detail"] == "Access denied"
```

#### 4. Implement analytics query

```python
# app/analytics/portfolio.py

def get_sector_allocation(
    con: duckdb.DuckDBPyConnection,
    client_id: str,
    as_of_date: date,
) -> list[tuple]:
    """
    Get portfolio breakdown by sector.
    
    Args:
        con: DuckDB connection.
        client_id: Client ID.
        as_of_date: Portfolio date.
    
    Returns:
        List of (sector_name, value, weight) tuples.
    """
    
    path = DATASETS["positions"].replace("{date}", str(as_of_date))
    
    query = """
        SELECT
            sector,
            ROUND(SUM(market_value_base), 2) AS value,
            ROUND(SUM(market_value_base) / SUM(SUM(market_value_base)) OVER (), 4) AS weight
        FROM read_parquet(?)
        WHERE client_id = ?
        GROUP BY sector
        ORDER BY value DESC
    """
    
    try:
        result = con.execute(query, [path, client_id]).fetchall()
        logger.info("Fetched %d sectors for client=%s", len(result), client_id)
        return result
    except Exception as e:
        logger.error("Error fetching sectors: %s", str(e), exc_info=True)
        raise
```

#### 5. Define schema

```python
# app/schemas.py

class SectorAllocation(BaseModel):
    """Sector allocation item."""
    
    sector: str | None
    value: float
    weight: float

class SectorAllocationResponse(BaseModel):
    """Response for sector allocation endpoint."""
    
    client_id: str
    as_of_date: date
    sectors: list[SectorAllocation]
```

#### 6. Add endpoint

```python
# app/main.py

@app.get(
    "/v1/clients/{client_id}/portfolio/sectors",
    response_model=SectorAllocationResponse,
    tags=["portfolio"],
)
async def get_sector_allocation(
    client_id: str,
    as_of_date: date | None = Query(None),
    _authorized_client_id: str = Query(
        dependencies=[check_client_access]
    ),
):
    """
    Fetch portfolio breakdown by sector.
    
    Args:
        client_id: Client ID.
        as_of_date: Portfolio snapshot date (default: latest).
    
    Returns:
        SectorAllocationResponse with sector breakdown.
    """
    
    snapshot_date = as_of_date or date.today()
    
    try:
        with duckdb_connection() as con:
            sectors = portfolio_analytics.get_sector_allocation(
                con, client_id, snapshot_date
            )
            
            return SectorAllocationResponse(
                client_id=client_id,
                as_of_date=snapshot_date,
                sectors=[
                    SectorAllocation(
                        sector=sec[0],
                        value=sec[1],
                        weight=sec[2],
                    )
                    for sec in sectors
                ],
            )
    
    except Exception as e:
        logger.error("Error fetching sectors: %s", str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch sector allocation",
        )
```

#### 7. Run tests

```bash
make test
# Should see your new test pass
```

#### 8. Run checks

```bash
make check
# Lint, typecheck, test all pass
```

#### 9. Commit and push

```bash
git add .
git commit -m "feat(api): add sector allocation endpoint"
git push origin feature/add-sector-endpoint
```

#### 10. Open PR

Open on GitHub with description of changes and link to issue.

---

## Fixing a Bug

### Example: Fix SQL injection vulnerability

#### 1. Create test that fails

```python
# tests/test_security.py

def test_sql_injection_protection():
    """Verify SQL injection is not possible."""
    from app.analytics import portfolio
    from app.duckdb_service import duckdb_connection
    
    malicious_client_id = "ACME-001'; DROP TABLE positions; --"
    
    with duckdb_connection() as con:
        # Should not crash or drop table
        positions = portfolio.get_positions(
            con, malicious_client_id, date.today()
        )
        
        # Should return empty or handle safely
        assert isinstance(positions, list)
```

#### 2. Identify the problem

Review code, find the vulnerability.

#### 3. Fix

Replace any f-string SQL with parameterised queries.

#### 4. Run test again

```bash
make test
# Should now pass
```

#### 5. Commit

```bash
git commit -m "fix(security): prevent SQL injection via parameterised queries"
```

---

## Documentation

### Update DEVELOPER.md

If adding a new concept or feature:

```markdown
### New Feature: Sector Allocation

The sector allocation query breaks down portfolio value by sector:

Query file: `app/analytics/portfolio.py`
Endpoint: `GET /v1/clients/{id}/portfolio/sectors`
Response: `SectorAllocationResponse`

Example:

\`\`\`python
with duckdb_connection() as con:
    sectors = portfolio_analytics.get_sector_allocation(
        con, "ACME-001", date(2026, 10, 7)
    )
\`\`\`
```

### Update ARCHITECTURE.md

If changing architecture:

```markdown
## Sector Partitioning (NEW)

Sectors are now partitioned separately to support sector-level queries:

s3://bucket/portfolio/
├── sectors/
│   └── date=2026-10-07/
│       └── part-000.parquet
```

---

## Testing Guidelines

### Unit Tests

Test analytics functions in isolation:

```python
def test_get_positions_filters_by_account():
    with duckdb_connection() as con:
        positions = portfolio.get_positions(
            con,
            "ACME-001",
            date(2026, 10, 7),
            account_ids=["ACC-001"]
        )
        
        # Verify all positions belong to ACC-001
        # (Would need to inspect actual data)
```

### Integration Tests

Test full request/response cycle:

```python
@pytest.mark.asyncio
async def test_get_portfolio_full_flow():
    async with AsyncClient(app=app, base_url="http://test") as client:
        response = await client.get(
            "/v1/clients/ACME-001/portfolio",
            headers={"Authorization": "Bearer test-token"}
        )
        
        assert response.status_code == 200
        # Verify response structure, data types, values
```

### Coverage

Aim for > 80% coverage:

```bash
make test-coverage
```

Review `htmlcov/index.html` for uncovered lines.

---

## Code Review Checklist

Before requesting review, ensure:

- [ ] Feature is complete and working
- [ ] Tests added (unit + integration)
- [ ] Tests pass: `make test`
- [ ] Code formatted: `make format`
- [ ] Lint passes: `make lint`
- [ ] Type check passes: `make typecheck`
- [ ] Full check passes: `make check`
- [ ] Documentation updated
- [ ] No `print()` statements (use logging)
- [ ] No hardcoded secrets or credentials
- [ ] Commit messages follow convention
- [ ] PR description is clear and linked to issue

---

## Questions?

- **Issues:** Open a GitHub issue
- **Discussions:** Use GitHub Discussions
- **Slack:** Reach out to @maintainers
- **Docs:** Check [DEVELOPER.md](./DEVELOPER.md), [ARCHITECTURE.md](./ARCHITECTURE.md)

---

**Thank you for contributing! 🎉**
