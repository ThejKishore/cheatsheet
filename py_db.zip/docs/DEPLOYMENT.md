# Deployment Guide

## Overview

This guide covers deploying the Portfolio Explorer microservice to Azure Kubernetes Service (AKS) with proper configuration, security, and operational practices.

---

## Prerequisites

- **Azure Account** with AKS cluster (1+ nodes)
- **Container Registry** (Azure Container Registry or Docker Hub)
- **kubectl** configured for your AKS cluster
- **Docker** for building/pushing images
- **Helm** (optional, for advanced deployments)

---

## Build & Push Container Image

### 1. Build Locally

```bash
docker build -t portfolio-api:v0.1.0 .

# Verify
docker images portfolio-api
docker run --rm portfolio-api:v0.1.0 --version
```

### 2. Tag for Registry

```bash
# For Azure Container Registry (replace with your registry name)
ACR_NAME=myacr
ACR_URL="${ACR_NAME}.azurecr.io"

docker tag portfolio-api:v0.1.0 ${ACR_URL}/portfolio-api:v0.1.0
docker tag portfolio-api:v0.1.0 ${ACR_URL}/portfolio-api:latest
```

### 3. Push to Registry

```bash
# Authenticate (if not already done)
az acr login --name ${ACR_NAME}

# Push
docker push ${ACR_URL}/portfolio-api:v0.1.0
docker push ${ACR_URL}/portfolio-api:latest

# Verify
az acr repository show --name ${ACR_NAME} --repository portfolio-api
```

---

## Kubernetes Deployment

### 1. Prepare Secrets

Store sensitive values in Kubernetes secrets (not ConfigMaps):

```bash
# Create namespace
kubectl create namespace portfolio

# Create secret for Snowflake credentials
kubectl create secret generic portfolio-secrets \
  --namespace=portfolio \
  --from-literal=snowflake-password='<password>' \
  --from-literal=jwt-public-key="$(cat public-key.pem)"

# Create secret for Azure Workload Identity (if using key-based auth in dev)
kubectl create secret generic azure-credentials \
  --namespace=portfolio \
  --from-literal=azure-connection-string='<connection-string>'
```

### 2. Create ConfigMap

Store non-secret configuration:

```bash
kubectl apply -f k8s/configmap.yaml --namespace=portfolio
```

**k8s/configmap.yaml:**

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: portfolio-config
  namespace: portfolio
data:
  ENVIRONMENT: "production"
  LOG_LEVEL: "INFO"
  AZURE_STORAGE_ACCOUNT: "mystorageaccount"
  AZURE_CONTAINER_NAME: "portfolio-data"
  SNOWFLAKE_ACCOUNT: "org-account"
  SNOWFLAKE_USER: "svc_portfolio_reader"
  SNOWFLAKE_WAREHOUSE: "ANALYTICS_WH"
  SNOWFLAKE_DATABASE: "ANALYTICS"
  SNOWFLAKE_SCHEMA: "PUBLIC"
  DUCKDB_MEMORY_LIMIT: "1GB"
  DUCKDB_THREADS: "2"
  JWT_ALGORITHM: "RS256"
```

### 3. Set Up Workload Identity (Production)

For **production AKS**, use Azure Workload Identity instead of storing credentials:

```bash
# 1. Create Azure Service Account
az ad sp create-for-rbac \
  --name portfolio-api-svc \
  --role "Storage Blob Data Reader" \
  --scopes "/subscriptions/<subscription-id>/resourceGroups/<rg>/providers/Microsoft.Storage/storageAccounts/<storage-account>"

# 2. Create Kubernetes Service Account with annotation
kubectl apply -f k8s/serviceaccount.yaml --namespace=portfolio

# 3. Establish trust relationship
# (Uses Azure AD integration with AKS OIDC)
# See: https://learn.microsoft.com/en-us/azure/aks/workload-identity-deploy-cluster
```

**k8s/serviceaccount.yaml:**

```yaml
apiVersion: v1
kind: ServiceAccount
metadata:
  name: portfolio-api
  namespace: portfolio
  annotations:
    azure.workload.identity/client-id: "<CLIENT_ID>"
---
apiVersion: v1
kind: ServiceAccount
metadata:
  name: portfolio-ingestion
  namespace: portfolio
  annotations:
    azure.workload.identity/client-id: "<INGESTION_CLIENT_ID>"
```

### 4. Deploy Application

```bash
kubectl apply -f k8s/deployment.yaml --namespace=portfolio
kubectl apply -f k8s/service.yaml --namespace=portfolio
```

**k8s/deployment.yaml (sample):**

```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: portfolio-api
  namespace: portfolio
  labels:
    app: portfolio-api
    version: v0.1.0
spec:
  replicas: 2
  selector:
    matchLabels:
      app: portfolio-api
  template:
    metadata:
      labels:
        app: portfolio-api
      annotations:
        azure.workload.identity/use: "true"
    spec:
      serviceAccountName: portfolio-api
      
      containers:
      - name: portfolio-api
        image: <ACR_URL>/portfolio-api:v0.1.0
        imagePullPolicy: IfNotPresent
        
        ports:
        - name: http
          containerPort: 8000
          protocol: TCP
        
        env:
        # Secrets
        - name: SNOWFLAKE_PASSWORD
          valueFrom:
            secretKeyRef:
              name: portfolio-secrets
              key: snowflake-password
        - name: JWT_PUBLIC_KEY
          valueFrom:
            secretKeyRef:
              name: portfolio-secrets
              key: jwt-public-key
        
        # ConfigMap
        envFrom:
        - configMapRef:
            name: portfolio-config
        
        # Resource limits (tuned for 2 CPU / 4 GB)
        resources:
          requests:
            cpu: 500m
            memory: 1Gi
          limits:
            cpu: 2
            memory: 4Gi
        
        # Health checks
        livenessProbe:
          httpGet:
            path: /health
            port: http
          initialDelaySeconds: 10
          periodSeconds: 30
          timeoutSeconds: 3
          failureThreshold: 3
        
        readinessProbe:
          httpGet:
            path: /ready
            port: http
          initialDelaySeconds: 5
          periodSeconds: 10
          timeoutSeconds: 3
          failureThreshold: 3
        
        # Security context
        securityContext:
          runAsNonRoot: true
          runAsUser: 1000
          readOnlyRootFilesystem: true
          capabilities:
            drop:
            - ALL
      
      # Pod disruption budget (for zero-downtime updates)
      affinity:
        podAntiAffinity:
          preferredDuringSchedulingIgnoredDuringExecution:
          - weight: 100
            podAffinityTerm:
              labelSelector:
                matchExpressions:
                - key: app
                  operator: In
                  values:
                  - portfolio-api
              topologyKey: kubernetes.io/hostname
```

**k8s/service.yaml:**

```yaml
apiVersion: v1
kind: Service
metadata:
  name: portfolio-api
  namespace: portfolio
  labels:
    app: portfolio-api
spec:
  type: ClusterIP
  selector:
    app: portfolio-api
  ports:
  - name: http
    protocol: TCP
    port: 80
    targetPort: 8000
```

### 5. Verify Deployment

```bash
# Check pods
kubectl get pods -n portfolio
kubectl logs -n portfolio deployment/portfolio-api -f

# Check service
kubectl get svc -n portfolio
kubectl describe svc portfolio-api -n portfolio

# Port forward for testing
kubectl port-forward -n portfolio svc/portfolio-api 8000:80

# Test
curl http://localhost:8000/health
curl -H "Authorization: Bearer test-token" \
  http://localhost:8000/v1/clients/ACME-001/portfolio
```

---

## Horizontal Pod Autoscaler (HPA)

Auto-scale based on CPU or custom metrics:

```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: portfolio-api-hpa
  namespace: portfolio
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: portfolio-api
  
  minReplicas: 2
  maxReplicas: 10
  
  metrics:
  # Scale on CPU utilization
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  
  # Scale on memory (if needed)
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
  
  behavior:
    scaleDown:
      stabilizationWindowSeconds: 300
      policies:
      - type: Percent
        value: 50
        periodSeconds: 60
    scaleUp:
      stabilizationWindowSeconds: 0
      policies:
      - type: Percent
        value: 100
        periodSeconds: 30
      - type: Pods
        value: 2
        periodSeconds: 30
      selectPolicy: Max
```

Apply:

```bash
kubectl apply -f k8s/hpa.yaml --namespace=portfolio
kubectl get hpa -n portfolio --watch
```

---

## Ingress & Load Balancer

### Azure Application Gateway (Recommended)

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: portfolio-ingress
  namespace: portfolio
  annotations:
    kubernetes.io/ingress.class: azure/application-gateway
    cert-manager.io/cluster-issuer: letsencrypt-prod
spec:
  tls:
  - hosts:
    - portfolio-api.example.com
    secretName: portfolio-tls
  
  rules:
  - host: portfolio-api.example.com
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: portfolio-api
            port:
              number: 80
```

---

## Monitoring & Observability

### Prometheus Scrape Config

```yaml
apiVersion: v1
kind: ServiceMonitor
metadata:
  name: portfolio-api
  namespace: portfolio
spec:
  selector:
    matchLabels:
      app: portfolio-api
  endpoints:
  - port: http
    path: /metrics
    interval: 30s
```

### Application Insights Integration

```bash
# Create Application Insights resource
az monitor app-insights component create \
  --app portfolio-api \
  --resource-group <rg> \
  --application-type web

# Instrument pods with Application Insights agent
# (Add APPINSIGHTS_INSTRUMENTATION_KEY to secrets)
```

---

## Database Ingestion Job (Separate Deployment)

The ingestion ETL runs separately from the API:

```yaml
apiVersion: batch/v1
kind: CronJob
metadata:
  name: portfolio-ingestion
  namespace: portfolio
spec:
  schedule: "0 6 * * *"  # Run daily at 6 AM
  jobTemplate:
    spec:
      template:
        spec:
          serviceAccountName: portfolio-ingestion
          containers:
          - name: ingestion
            image: <ACR_URL>/portfolio-api:v0.1.0
            imagePullPolicy: IfNotPresent
            command: ["python", "-m", "ingestion.etl_job"]
            env:
            - name: SNOWFLAKE_PASSWORD
              valueFrom:
                secretKeyRef:
                  name: portfolio-secrets
                  key: snowflake-password
            envFrom:
            - configMapRef:
                name: portfolio-config
            resources:
              requests:
                cpu: 500m
                memory: 2Gi
              limits:
                cpu: 2
                memory: 4Gi
          restartPolicy: OnFailure
```

---

## Upgrade & Rollback

### Blue-Green Deployment

Deploy new version alongside old, then switch traffic:

```bash
# 1. Deploy v0.2.0 (with label "canary")
kubectl set image deployment/portfolio-api-canary \
  portfolio-api=<ACR>/portfolio-api:v0.2.0 \
  --namespace=portfolio

# 2. Monitor canary (small % of traffic)
kubectl logs -n portfolio deployment/portfolio-api-canary

# 3. If healthy, promote to stable
kubectl patch service portfolio-api -n portfolio \
  -p '{"spec":{"selector":{"version":"v0.2.0"}}}'

# 4. If issues, rollback
kubectl patch service portfolio-api -n portfolio \
  -p '{"spec":{"selector":{"version":"v0.1.0"}}}'
```

### Rolling Update

Default Kubernetes strategy (zero-downtime):

```bash
kubectl set image deployment/portfolio-api \
  portfolio-api=<ACR>/portfolio-api:v0.2.0 \
  --namespace=portfolio

kubectl rollout status deployment/portfolio-api -n portfolio

# If needed, rollback
kubectl rollout undo deployment/portfolio-api -n portfolio
```

---

## Production Checklist

Before going live:

- [ ] Container image pushed to ACR
- [ ] Kubernetes manifests created (Deployment, Service, ConfigMap, secrets)
- [ ] Workload Identity configured for Blob Storage access
- [ ] Snowflake service account created with appropriate permissions
- [ ] JWT public key provisioned
- [ ] Ingestion job scheduled and tested
- [ ] Health checks (`/health`, `/ready`) responding
- [ ] HPA configured and tested under load
- [ ] Ingress/load balancer configured with TLS
- [ ] Monitoring (Prometheus, Application Insights) enabled
- [ ] Log aggregation configured (e.g., Container Insights)
- [ ] Alerting configured (CPU, memory, error rate)
- [ ] Backup/disaster recovery plan documented
- [ ] Security audit completed (RBAC, network policies)
- [ ] Load testing completed and capacity plan documented

---

## Troubleshooting

### Pod won't start

```bash
kubectl describe pod <pod-name> -n portfolio
kubectl logs <pod-name> -n portfolio
```

Common issues:
- Missing ConfigMap/Secret → apply with `kubectl apply`
- Image not found → check ACR access, image tag
- Resource limits exceeded → increase requests/limits
- Port already in use → check other services

### High latency queries

```bash
kubectl exec -it <pod-name> -n portfolio -- bash
python -c "
import time
from app.duckdb_service import duckdb_connection
from app.analytics import portfolio
from datetime import date

start = time.time()
with duckdb_connection() as con:
    positions = portfolio.get_positions(con, 'TEST-001', date.today())
elapsed = time.time() - start
print(f'Query took {elapsed:.2f}s for {len(positions)} positions')
"
```

Potential issues:
- Parquet files too large → partition by more dimensions
- Network latency to Blob Storage → check network, reduce data size
- DuckDB memory pressure → increase `DUCKDB_MEMORY_LIMIT`

### Out of Memory errors

Check pod logs:

```bash
kubectl logs <pod-name> -n portfolio | grep -i "memory"
```

Solutions:
- Increase container memory limit in Deployment
- Reduce `DUCKDB_MEMORY_LIMIT` to prevent individual queries from consuming all memory
- Optimize Parquet (compression, partitioning)
- Reduce query scope (smaller date ranges, more filters)

---

## Scaling Considerations

| Component | Limit | Tuning |
|---|---|---|
| **Pod replicas** | 1-50 | Set via HPA minReplicas/maxReplicas |
| **Concurrent requests/pod** | ~10-20 | Depends on Uvicorn workers (set to 1 in Dockerfile) |
| **DuckDB per-connection memory** | 1 GB | Tuned for 2 CPU / 4 GB container |
| **Effective concurrent queries/pod** | ~3-4 | 4 GB total limit ÷ 1 GB per query |
| **Network I/O (Blob Storage)** | 1 Gbps | Azure Standard tier; upgrade if needed |

**Example scaling scenario:**

```
Incoming request rate: 100 req/s
Avg query latency: 200 ms
Concurrency: 100 × 0.2 = 20 concurrent requests

Requests per pod: ~15 (Uvicorn threads + DuckDB queue)
Pods needed: 20 ÷ 15 = 2 pods (minimum)

With HPA:
  minReplicas: 2
  maxReplicas: 10
  Target CPU: 70%
  
At 100 req/s with 70% CPU target:
  → HPA scales to ~3-5 pods
```

---

## References

- [Kubernetes Documentation](https://kubernetes.io/docs/)
- [AKS Best Practices](https://learn.microsoft.com/en-us/azure/aks/best-practices)
- [Azure Workload Identity](https://learn.microsoft.com/en-us/azure/aks/workload-identity-deploy-cluster)
- [Application Gateway Ingress](https://learn.microsoft.com/en-us/azure/application-gateway/ingress-controller-overview)

---

See also:
- [DEVELOPER.md](./DEVELOPER.md) — Local development
- [ARCHITECTURE.md](./ARCHITECTURE.md) — Design patterns and data flow
