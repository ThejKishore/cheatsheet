# Portfolio Explorer Microservice

[![Build Status](https://img.shields.io/badge/build-passing-brightgreen)](https://github.com/your-org/portfolio-api)
[![Python 3.12+](https://img.shields.io/badge/python-3.12%2B-blue)](https://www.python.org/)
[![License](https://img.shields.io/badge/license-MIT-green)](LICENSE)

A **stateless, read-only portfolio analytics microservice** for banking clients to query their portfolio positions, holdings, transactions, and performance metrics.

Built with **FastAPI** + **DuckDB** + **Azure Blob Storage** + **Kubernetes**.

---

## Quick Start

### Development (Local)

```bash
# Install dependencies
make install

# Configure environment
cp .env.example .env
# Edit .env with your settings

# Run dev server (auto-reload)
make dev
# Navigate to http://localhost:8000/docs for API docs
```

### With Docker

```bash
make docker-run
# Runs on http://localhost:8000
```

### Production (AKS)

```bash
# Build and push image
docker build -t <registry>/portfolio-api:v0.1.0 .
docker push <registry>/portfolio-api:v0.1.0

# Deploy to Kubernetes
kubectl apply -f k8s/
kubectl get pods -n portfolio

# Check status
kubectl logs -n portfolio deployment/portfolio-api
```

---

## Features

✅ **Stateless API Layer** — Per-request DuckDB connections; no shared state  
✅ **Fast Queries** — Ephemeral in-memory analytics; Parquet file scanning  
✅ **Secure** — JWT RS256 authentication; role-based authorization  
✅ **Production Ready** — Container-based; Kubernetes-native; observable  
✅ **Scalable** — Horizontal scaling via Kubernetes HPA  
✅ **Type Safe** — Python 3.12 with full type annotations  

---

## API Endpoints

| Method | Path | Description |
|---|---|---|
| `GET` | `/health` | Liveness probe |
| `GET` | `/ready` | Readiness probe |
| `GET` | `/v1/clients/{client_id}/portfolio` | Latest positions |
| `GET` | `/v1/clients/{client_id}/portfolio/summary` | Totals + asset allocation |
| `GET` | `/v1/clients/{client_id}/portfolio/holdings` | Top holdings |
| `GET` | `/v1/clients/{client_id}/portfolio/transactions` | Transactions by date range |
| `GET` | `/v1/clients/{client_id}/portfolio/performance` | Daily value series |

**Authentication:** All endpoints require JWT Bearer token in `Authorization` header.

### Example Request

```bash
curl -X GET "http://localhost:8000/v1/clients/ACME-001/portfolio" \
  -H "Authorization: Bearer <jwt-token>" \
  -H "Accept: application/json"
```

**Response:**

```json
{
  "client_id": "ACME-001",
  "as_of_date": "2026-10-07",
  "total_value": 12450320.42,
  "positions": [
    {
      "ticker": "AAPL",
      "security_name": "Apple Inc.",
      "asset_class": "Equity",
      "sector": "Technology",
      "quantity": 500,
      "price": 245.00,
      "market_value": 122500.00,
      "market_value_base": 122500.00,
      "weight": 0.0984
    },
    ...
  ]
}
```

---

## Architecture

```
Clients
  │
  └─► FastAPI (authentication, validation)
        │
        └─► DuckDB :memory: (ephemeral per-request)
              │
              └─► Azure Blob Storage (Parquet snapshots)
                    │
                    └─ Snowflake (source of truth)
```

**Key principles:**
- **No persistent state** in API pod (stateless scaling)
- **Ephemeral compute** (DuckDB connection per request)
- **External state** (Parquet in Azure Blob Storage)
- **Incremental ingestion** (Snowflake → Parquet via scheduled ETL)

See [ARCHITECTURE.md](./docs/ARCHITECTURE.md) for detailed design.

---

## Documentation

- **[DEVELOPER.md](./docs/DEVELOPER.md)** — Local setup, testing, debugging
- **[ARCHITECTURE.md](./docs/ARCHITECTURE.md)** — Design patterns, data flow, security
- **[DEPLOYMENT.md](./docs/DEPLOYMENT.md)** — Kubernetes, scaling, production checklist
- **[CONTRIBUTING.md](./docs/CONTRIBUTING.md)** — Code style, PR process, adding features
- **[PLAN.md](./PLAN.md)** — Full 10-phase build roadmap with checklists

---

## Project Structure

```
portfolio-api/
├── app/                          # FastAPI application
│   ├── main.py                   # 7 REST endpoints
│   ├── config.py                 # Settings (pydantic)
│   ├── auth.py                   # JWT auth/authz
│   ├── duckdb_service.py         # DuckDB connections
│   ├── schemas.py                # Pydantic models
│   └── analytics/
│       ├── portfolio.py          # Positions, allocation queries
│       ├── transactions.py       # Transaction queries
│       └── performance.py        # Performance queries
│
├── ingestion/                    # Snowflake → Parquet ETL
│   ├── snowflake_extractor.py
│   ├── parquet_writer.py
│   ├── azure_uploader.py
│   ├── manifest.py
│   └── etl_job.py
│
├── tests/                        # pytest suite
│   ├── test_api.py
│   ├── test_analytics.py
│   └── test_auth.py
│
├── k8s/                          # Kubernetes manifests
│   ├── deployment.yaml
│   ├── service.yaml
│   ├── configmap.yaml
│   └── serviceaccount.yaml
│
├── docs/                         # Documentation
├── Makefile                      # Common tasks
├── Dockerfile                    # Container image
├── requirements.txt              # Dependencies
└── PLAN.md                       # Build plan
```

---

## Development Commands

```bash
make help           # Show all commands
make install        # Install dependencies
make dev            # Run dev server with auto-reload
make test           # Run pytest
make test-coverage  # Run with coverage report
make lint           # Check code with ruff
make format         # Format code with black
make typecheck      # Type check with mypy
make check          # Full check (lint + typecheck + test)
make docker-build   # Build container image
make docker-run     # Run container locally
make clean          # Remove cache files
```

---

## Configuration

Environment variables (see `.env.example`):

```bash
# Azure Blob Storage
AZURE_STORAGE_ACCOUNT=mystorageaccount
AZURE_CONTAINER_NAME=portfolio-data
AZURE_STORAGE_CONNECTION_STRING=...  # dev only

# Snowflake
SNOWFLAKE_ACCOUNT=org-account
SNOWFLAKE_USER=svc_portfolio_reader
SNOWFLAKE_PASSWORD=...
SNOWFLAKE_WAREHOUSE=ANALYTICS_WH

# DuckDB resource limits (tuned for 2 CPU / 4 GB container)
DUCKDB_MEMORY_LIMIT=1GB
DUCKDB_THREADS=2

# JWT/Auth
JWT_ALGORITHM=RS256
JWT_PUBLIC_KEY=...

# Service
ENVIRONMENT=development
LOG_LEVEL=INFO
```

**Development:** Use `.env` file  
**Production (AKS):** Use Kubernetes Secrets + ConfigMaps + Workload Identity

---

## Testing

```bash
# Run all tests
make test

# Run specific test file
pytest tests/test_api.py -v

# Run with coverage
make test-coverage

# View coverage report
open htmlcov/index.html
```

---

## Performance Characteristics

| Query | Expected Latency |
|---|---|
| Get positions (10K rows) | 50-200 ms |
| Asset allocation (aggregation) | 50-200 ms |
| Top holdings (10-item limit) | 50-200 ms |
| Transactions (1 year, 100K rows) | 200-500 ms |
| Performance series (365 days) | 100-300 ms |

**Resource usage (per pod):**
- CPU: 500m (request) / 2 (limit)
- Memory: 1Gi (request) / 4Gi (limit)
- Concurrent queries: ~3-4
- Network: Standard Azure tier

See [DEPLOYMENT.md](./docs/DEPLOYMENT.md) for scaling guidance.

---

## Technology Stack

- **Python 3.12** — Modern, type-safe
- **FastAPI** — REST API framework
- **DuckDB** — In-memory analytical SQL engine
- **Snowflake** — Source-of-truth data warehouse
- **Azure Blob Storage** — Object storage (Parquet data lake)
- **Pydantic** — Data validation
- **Pytest** — Unit/integration testing
- **Prometheus** — Metrics / monitoring
- **Kubernetes** — Container orchestration
- **Docker** — Containerization

---

## Roadmap

**Current:** Phases 1-6 (scaffold, DuckDB, schemas, FastAPI endpoints)

**Next:** Phases 7-10 (auth, observability, Kubernetes, load testing)

**Future:** 25 enhancements (caching, risk metrics, performance attribution, etc.)

See [PLAN.md](./PLAN.md) for full roadmap and checklists.

---

## Contributing

We welcome contributions! See [CONTRIBUTING.md](./docs/CONTRIBUTING.md) for:

- Branch naming convention
- Code style (Black, Ruff, mypy)
- PR process
- Adding features (with examples)
- Testing guidelines

**TL;DR:**

1. Fork and clone
2. Create feature branch: `git checkout -b feature/your-feature`
3. Make changes and test: `make check`
4. Commit: `git commit -m "feat(scope): description"`
5. Push and open PR

---

## License

This project is licensed under the **MIT License**. See [LICENSE](LICENSE) for details.

---

## Support

- **Issues:** [GitHub Issues](https://github.com/your-org/portfolio-api/issues)
- **Docs:** See `docs/` folder
- **Questions:** Open a discussion or reach out to maintainers

---

## Acknowledgments

- Built with ❤️ for the banking and finance community
- Inspired by best practices in stateless, cloud-native architecture
- Thanks to DuckDB, FastAPI, and Kubernetes communities

---

**Ready to dive in?** Start with [DEVELOPER.md](./docs/DEVELOPER.md)!
