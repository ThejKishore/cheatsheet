## Creating a portfolio explorer for banking.

The objective is to create a microservice that will help the client to fetch their portfolio data. And Also to allow the user to query with date range,filter based on accounts etc.

### Platform

The application would be running in the Azure Kubernetes cluster as container.


### Technology 

* Python
* Fast Api
* duckdb
* Azure api
* snowflake connector
* uvicorn[standard]
* pydantic-settings
  
container has:

```
2 CPU
4 GB RAM
```

If you're building a serious analytics API, I'd settle on this:

```
              ┌───────────────┐
              │    Clients    │
              └───────┬───────┘
                      │
                      ▼
              ┌───────────────┐
              │    FastAPI    │
              └───────┬───────┘
                      │
             one ephemeral DB
                      │
                      ▼
              ┌───────────────┐        ┌───────────────┐
              │    DuckDB     │        |               |
              │   :memory:    │        |               |
              │               │------ >|  snowflakes   |
              │ read-only     │        |               |
              │ analytical    │        |               |
              └───────┬───────┘        └───────┬───────┘
                      │
                      ▼
              ┌───────────────┐
              │    Azure      │
              │  Blob Storage │
              │               │
              │ partitioned   │
              │   Parquet     │
              └───────────────┘
```
