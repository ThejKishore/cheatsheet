"""Pydantic schemas for API requests/responses."""

from datetime import date, datetime
from typing import Optional, List
from pydantic import BaseModel, Field


class Position(BaseModel):
    """A single security position in an account."""

    ticker: str
    security_name: str
    asset_class: str
    sector: Optional[str] = None
    quantity: float
    price: float
    market_value: float
    market_value_base: float
    weight: Optional[float] = None


class PortfolioPositionsResponse(BaseModel):
    """Response for portfolio positions endpoint."""

    client_id: str
    as_of_date: date
    positions: List[Position]
    total_value: float


class AssetAllocation(BaseModel):
    """Asset allocation breakdown."""

    asset_class: str
    value: float
    weight: float


class PortfolioSummary(BaseModel):
    """Portfolio summary: totals and allocation."""

    client_id: str
    as_of_date: date
    total_value: float
    asset_allocation: List[AssetAllocation]


class Holding(BaseModel):
    """Top holding."""

    rank: int
    ticker: str
    security_name: str
    value: float
    weight: float


class TopHoldingsResponse(BaseModel):
    """Response for top holdings endpoint."""

    client_id: str
    as_of_date: date
    holdings: List[Holding]


class Transaction(BaseModel):
    """A single transaction."""

    transaction_id: str
    transaction_date: date
    ticker: str
    security_name: str
    type: str  # BUY, SELL, DIVIDEND, etc.
    quantity: float
    price: float
    amount: float
    account_id: Optional[str] = None


class TransactionsResponse(BaseModel):
    """Response for transactions endpoint."""

    client_id: str
    start_date: date
    end_date: date
    transactions: List[Transaction]
    total_count: int


class DailyValue(BaseModel):
    """Portfolio value snapshot for a single date."""

    date: date
    portfolio_value: float
    equity_value: Optional[float] = None
    fixed_income_value: Optional[float] = None
    cash_value: Optional[float] = None
    alternatives_value: Optional[float] = None


class PortfolioPerformanceResponse(BaseModel):
    """Response for performance endpoint."""

    client_id: str
    start_date: date
    end_date: date
    daily_values: List[DailyValue]
    start_value: float
    end_value: float
    total_return: float


class ErrorResponse(BaseModel):
    """Standard error response."""

    error: str
    status_code: int
    detail: Optional[str] = None
    timestamp: datetime = Field(default_factory=datetime.utcnow)
