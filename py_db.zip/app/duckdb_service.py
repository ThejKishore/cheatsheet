"""DuckDB service layer — per-request ephemeral :memory: connections."""

from contextlib import contextmanager
import logging

import duckdb

from .config import settings

logger = logging.getLogger(__name__)


@contextmanager
def duckdb_connection():
    """
    Context manager for ephemeral DuckDB :memory: connections.

    Creates an isolated, read-only connection for each request.
    - Nothing is persisted locally.
    - DuckDB loads httpfs and azure extensions for Blob Storage access.
    - Resource limits (memory, threads) are set per connection.
    - Connection closes and memory is released when exiting the context.

    Yields:
        duckdb.DuckDBPyConnection: Configured, ready-to-query connection.

    Example:
        with duckdb_connection() as con:
            result = con.execute(
                "SELECT * FROM read_parquet(?) WHERE id = ?",
                ["azure://...", "123"]
            ).fetchall()
    """
    con = duckdb.connect(database=":memory:")

    try:
        # Install extensions
        con.execute("INSTALL httpfs; LOAD httpfs")
        con.execute("INSTALL azure; LOAD azure")

        # Configure Azure Blob Storage access
        if settings.azure_storage_connection_string:
            # Development: explicit connection string
            con.execute(
                f"SET azure_storage_connection_string = "
                f"'{settings.azure_storage_connection_string}'"
            )
            logger.debug("DuckDB configured with Azure connection string")
        else:
            # Production: Workload Identity (AKS)
            con.execute("SET azure_use_workload_identity = true")
            logger.debug("DuckDB configured with Azure Workload Identity")

        # Resource limits — tuned for 2 CPU / 4 GB container
        con.execute(f"SET memory_limit = '{settings.duckdb_memory_limit}'")
        con.execute(f"SET threads = {settings.duckdb_threads}")
        con.execute("SET preserve_insertion_order = false")

        logger.debug(
            "DuckDB connection created: memory=%s, threads=%s",
            settings.duckdb_memory_limit,
            settings.duckdb_threads,
        )

        yield con

    except Exception as e:
        logger.error("DuckDB connection error: %s", str(e), exc_info=True)
        raise

    finally:
        con.close()
        logger.debug("DuckDB connection closed")
