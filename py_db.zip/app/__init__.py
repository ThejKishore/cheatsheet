"""Application initialization."""
