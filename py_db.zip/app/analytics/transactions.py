"""Transaction analytics queries."""

from typing import Optional

import logging
from datetime import date

import duckdb

logger = logging.getLogger(__name__)

DATASETS = {
    "transactions": "azure://{account}.blob.core.windows.net/portfolio-data/transactions/year={year}/month={month}/*.parquet",
}


def get_transactions(
    con: duckdb.DuckDBPyConnection,
    client_id: str,
    start_date: date,
    end_date: date,
    account_ids: Optional[list[str]] = None,
) -> list[tuple]:
    """
    Fetch transactions for a date range.

    Note: This is a stub. In production, transactions are partitioned by year/month,
    so we'd need to dynamically construct the path for each month in the range.

    Args:
        con: DuckDB connection.
        client_id: Client ID.
        start_date: Start date (inclusive).
        end_date: End date (inclusive).
        account_ids: Optional account filter.

    Returns:
        List of transaction tuples.
    """

    # For now, use a simplified read-all path
    # TODO: Partition by year/month and iterate over months in range
    path = "azure://{account}.blob.core.windows.net/portfolio-data/transactions/**/*.parquet"

    where_clause = "WHERE client_id = ? AND transaction_date BETWEEN ? AND ?"
    params = [path, client_id, start_date, end_date]

    if account_ids:
        where_clause += " AND account_id = ANY(?)"
        params.append(account_ids)

    query = f"""
        SELECT
            transaction_id,
            transaction_date,
            ticker,
            security_name,
            type,
            quantity,
            price,
            amount,
            account_id
        FROM read_parquet(?, hive_partitioning = true)
        {where_clause}
        ORDER BY transaction_date DESC
    """

    try:
        result = con.execute(query, params).fetchall()
        logger.info(
            "Fetched %d transactions for client=%s, range=%s to %s",
            len(result),
            client_id,
            start_date,
            end_date,
        )
        return result

    except Exception as e:
        logger.error(
            "Error fetching transactions: %s", str(e), exc_info=True
        )
        raise
