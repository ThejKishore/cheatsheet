"""Portfolio analytics queries."""

from typing import Optional

import logging
from datetime import date

import duckdb

logger = logging.getLogger(__name__)


# Blob Storage dataset paths (whitelist — never accept user-supplied paths)
DATASETS = {
    "positions": "azure://{account}.blob.core.windows.net/portfolio-data/positions/as_of_date={date}/*.parquet",
    "portfolio_values": "azure://{account}.blob.core.windows.net/portfolio-data/portfolio_values/date={date}/*.parquet",
    "transactions": "azure://{account}.blob.core.windows.net/portfolio-data/transactions/year={year}/month={month}/*.parquet",
    "performance": "azure://{account}.blob.core.windows.net/portfolio-data/performance/date={date}/*.parquet",
}


def get_positions(
    con: duckdb.DuckDBPyConnection,
    client_id: str,
    as_of_date: date,
    account_ids: Optional[list[str]] = None,
) -> list[tuple]:
    """
    Fetch positions for a client on a specific date.

    Parameterised SQL prevents injection; account_ids filter is optional.

    Args:
        con: DuckDB connection.
        client_id: Client ID (from auth).
        as_of_date: Portfolio date snapshot.
        account_ids: Optional account filter.

    Returns:
        List of (ticker, name, asset_class, sector, quantity, price, market_value, market_value_base, weight) tuples.
    """

    path = DATASETS["positions"].replace("{date}", str(as_of_date))

    # Build WHERE clause for optional account filter
    where_clause = "WHERE client_id = ?"
    params = [path, client_id, as_of_date]

    if account_ids:
        where_clause += " AND account_id = ANY(?)"
        params.append(account_ids)

    query = f"""
        SELECT
            ticker,
            security_name,
            asset_class,
            sector,
            quantity,
            price,
            market_value,
            market_value_base,
            ROUND(weight, 4) AS weight
        FROM read_parquet(?)
        {where_clause}
        ORDER BY market_value_base DESC
    """

    try:
        result = con.execute(query, params).fetchall()
        logger.info(
            "Fetched %d positions for client=%s, date=%s",
            len(result),
            client_id,
            as_of_date,
        )
        return result

    except Exception as e:
        logger.error("Error fetching positions: %s", str(e), exc_info=True)
        raise


def get_portfolio_summary(
    con: duckdb.DuckDBPyConnection,
    client_id: str,
    as_of_date: date,
) -> tuple:
    """
    Get portfolio total value.

    Args:
        con: DuckDB connection.
        client_id: Client ID.
        as_of_date: Portfolio date.

    Returns:
        (total_value,) tuple.
    """

    path = DATASETS["positions"].replace("{date}", str(as_of_date))

    query = """
        SELECT ROUND(SUM(market_value_base), 2) AS total_value
        FROM read_parquet(?)
        WHERE client_id = ?
    """

    try:
        result = con.execute(query, [path, client_id]).fetchone()
        return result if result else (0.0,)

    except Exception as e:
        logger.error("Error fetching portfolio summary: %s", str(e), exc_info=True)
        raise


def get_asset_allocation(
    con: duckdb.DuckDBPyConnection,
    client_id: str,
    as_of_date: date,
) -> list[tuple]:
    """
    Get asset allocation breakdown.

    Args:
        con: DuckDB connection.
        client_id: Client ID.
        as_of_date: Portfolio date.

    Returns:
        List of (asset_class, value, weight) tuples.
    """

    path = DATASETS["positions"].replace("{date}", str(as_of_date))

    query = """
        SELECT
            asset_class,
            ROUND(SUM(market_value_base), 2) AS value,
            ROUND(SUM(market_value_base) / SUM(SUM(market_value_base)) OVER (), 4) AS weight
        FROM read_parquet(?)
        WHERE client_id = ?
        GROUP BY asset_class
        ORDER BY value DESC
    """

    try:
        result = con.execute(query, [path, client_id]).fetchall()
        return result

    except Exception as e:
        logger.error("Error fetching asset allocation: %s", str(e), exc_info=True)
        raise


def get_top_holdings(
    con: duckdb.DuckDBPyConnection,
    client_id: str,
    as_of_date: date,
    limit: int = 10,
) -> list[tuple]:
    """
    Get top N holdings by market value.

    Args:
        con: DuckDB connection.
        client_id: Client ID.
        as_of_date: Portfolio date.
        limit: Number of holdings to return (default 10, max 100).

    Returns:
        List of (rank, ticker, name, value, weight) tuples.
    """

    # Cap limit to prevent accidental large queries
    limit = min(limit, 100)

    path = DATASETS["positions"].replace("{date}", str(as_of_date))

    query = """
        SELECT
            ROW_NUMBER() OVER (ORDER BY market_value_base DESC) AS rank,
            ticker,
            security_name,
            ROUND(market_value_base, 2) AS value,
            ROUND(weight, 4) AS weight
        FROM read_parquet(?)
        WHERE client_id = ?
        ORDER BY rank
        LIMIT ?
    """

    try:
        result = con.execute(query, [path, client_id, limit]).fetchall()
        return result

    except Exception as e:
        logger.error("Error fetching top holdings: %s", str(e), exc_info=True)
        raise
