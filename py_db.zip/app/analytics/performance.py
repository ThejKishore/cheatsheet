"""Portfolio performance analytics queries."""

from typing import Optional

import logging
from datetime import date

import duckdb

logger = logging.getLogger(__name__)

DATASETS = {
    "performance": "azure://{account}.blob.core.windows.net/portfolio-data/performance/date={date}/*.parquet",
}


def get_performance(
    con: duckdb.DuckDBPyConnection,
    client_id: str,
    start_date: date,
    end_date: date,
) -> list[tuple]:
    """
    Fetch daily portfolio values for a date range.

    Args:
        con: DuckDB connection.
        client_id: Client ID.
        start_date: Start date (inclusive).
        end_date: End date (inclusive).

    Returns:
        List of (date, portfolio_value, equity_value, fixed_income_value, cash_value, alternatives_value) tuples.
    """

    # Use wildcard to read all partitions in the range
    # TODO: Optimize by iterating over specific dates or date ranges
    path = "azure://{account}.blob.core.windows.net/portfolio-data/performance/**/*.parquet"

    query = """
        SELECT
            date,
            ROUND(portfolio_value, 2) AS portfolio_value,
            ROUND(COALESCE(equity_value, 0), 2) AS equity_value,
            ROUND(COALESCE(fixed_income_value, 0), 2) AS fixed_income_value,
            ROUND(COALESCE(cash_value, 0), 2) AS cash_value,
            ROUND(COALESCE(alternatives_value, 0), 2) AS alternatives_value
        FROM read_parquet(?, hive_partitioning = true)
        WHERE client_id = ?
          AND date BETWEEN ? AND ?
        ORDER BY date ASC
    """

    try:
        result = con.execute(
            query, [path, client_id, start_date, end_date]
        ).fetchall()
        logger.info(
            "Fetched %d performance records for client=%s, range=%s to %s",
            len(result),
            client_id,
            start_date,
            end_date,
        )
        return result

    except Exception as e:
        logger.error(
            "Error fetching performance: %s", str(e), exc_info=True
        )
        raise
