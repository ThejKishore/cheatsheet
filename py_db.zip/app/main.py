from typing import Optional

"""FastAPI application — Portfolio Explorer microservice."""

import logging
from contextlib import asynccontextmanager
from datetime import date, datetime, timedelta

from fastapi import FastAPI, HTTPException, Query, status
from fastapi.responses import JSONResponse

from prometheus_fastapi_instrumentator import Instrumentator

from .config import settings
from .duckdb_service import duckdb_connection
from .auth import check_client_access, get_current_user
from .schemas import (
    PortfolioPositionsResponse,
    Position,
    PortfolioSummary,
    AssetAllocation,
    TopHoldingsResponse,
    Holding,
    TransactionsResponse,
    Transaction,
    PortfolioPerformanceResponse,
    DailyValue,
    ErrorResponse,
)
from .analytics import portfolio as portfolio_analytics
from .analytics import transactions as transactions_analytics
from .analytics import performance as performance_analytics

# Configure logging
logging.basicConfig(
    level=getattr(logging, settings.log_level),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan — startup and shutdown."""
    logger.info("Starting Portfolio Explorer microservice")
    yield
    logger.info("Shutting down Portfolio Explorer microservice")


app = FastAPI(
    title="Portfolio Explorer API",
    description="Stateless analytics API for banking portfolio queries",
    version="0.1.0",
    docs_url="/docs",
    openapi_url="/openapi.json",
    lifespan=lifespan,
)

# Add Prometheus instrumentation
Instrumentator().instrument(app).expose(app, endpoint="/metrics")


# ============================================================================
# Health & Readiness
# ============================================================================


@app.get("/health", tags=["operations"])
async def health_check():
    """Liveness probe — always returns 200 OK."""
    return {"status": "ok", "timestamp": datetime.utcnow().isoformat()}


@app.get("/ready", tags=["operations"])
async def readiness_check():
    """
    Readiness probe — checks Blob Storage manifest availability.

    In production, this would verify that the latest portfolio snapshot is available.
    For now, it's a stub that always returns 200.
    """
    # TODO: Implement manifest check in Blob Storage
    return {
        "status": "ready",
        "timestamp": datetime.utcnow().isoformat(),
        "environment": settings.environment,
    }


# ============================================================================
# Portfolio Endpoints
# ============================================================================


@app.get(
    "/v1/clients/{client_id}/portfolio",
    response_model=PortfolioPositionsResponse,
    tags=["portfolio"],
)
async def get_portfolio(
    client_id: str = Query(...),
    account_id: Optional[str] = Query(None),
    as_of_date: Optional[date] = Query(None),
    _authorized_client_id: str = Query(
        dependencies=[check_client_access]
    ),  # Authorization guard
):
    """
    Fetch portfolio positions for a client.

    - Returns the latest positions if `as_of_date` is not specified.
    - Optional `account_id` filter for specific accounts.

    Args:
        client_id: Client ID (from path; validated against auth token).
        account_id: Optional account filter.
        as_of_date: Portfolio snapshot date (default: latest available).

    Returns:
        PortfolioPositionsResponse with positions list and totals.
    """

    # Use today or the most recent past date if not specified
    snapshot_date = as_of_date or date.today()

    try:
        with duckdb_connection() as con:
            positions = portfolio_analytics.get_positions(
                con,
                client_id,
                snapshot_date,
                [account_id] if account_id else None,
            )

            if not positions:
                logger.warning(
                    "No positions found for client=%s, date=%s",
                    client_id,
                    snapshot_date,
                )

            total_value = (
                sum(pos[7] for pos in positions) if positions else 0.0
            )

            return PortfolioPositionsResponse(
                client_id=client_id,
                as_of_date=snapshot_date,
                positions=[
                    Position(
                        ticker=pos[0],
                        security_name=pos[1],
                        asset_class=pos[2],
                        sector=pos[3],
                        quantity=pos[4],
                        price=pos[5],
                        market_value=pos[6],
                        market_value_base=pos[7],
                        weight=pos[8],
                    )
                    for pos in positions
                ],
                total_value=total_value,
            )

    except Exception as e:
        logger.error("Error fetching portfolio: %s", str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch portfolio positions",
        )


@app.get(
    "/v1/clients/{client_id}/portfolio/summary",
    response_model=PortfolioSummary,
    tags=["portfolio"],
)
async def get_portfolio_summary(
    client_id: str,
    as_of_date: Optional[date] = Query(None),
    _authorized_client_id: str = Query(
        dependencies=[check_client_access]
    ),
):
    """
    Fetch portfolio summary (totals and asset allocation).

    Args:
        client_id: Client ID.
        as_of_date: Portfolio snapshot date (default: latest).

    Returns:
        PortfolioSummary with total value and asset allocation.
    """

    snapshot_date = as_of_date or date.today()

    try:
        with duckdb_connection() as con:
            # Get total value
            total_result = portfolio_analytics.get_portfolio_summary(
                con, client_id, snapshot_date
            )
            total_value = total_result[0] if total_result else 0.0

            # Get asset allocation
            allocation = portfolio_analytics.get_asset_allocation(
                con, client_id, snapshot_date
            )

            return PortfolioSummary(
                client_id=client_id,
                as_of_date=snapshot_date,
                total_value=total_value,
                asset_allocation=[
                    AssetAllocation(
                        asset_class=alloc[0],
                        value=alloc[1],
                        weight=alloc[2],
                    )
                    for alloc in allocation
                ],
            )

    except Exception as e:
        logger.error("Error fetching portfolio summary: %s", str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch portfolio summary",
        )


@app.get(
    "/v1/clients/{client_id}/portfolio/holdings",
    response_model=TopHoldingsResponse,
    tags=["portfolio"],
)
async def get_top_holdings(
    client_id: str,
    limit: int = Query(10, ge=1, le=100),
    as_of_date: Optional[date] = Query(None),
    _authorized_client_id: str = Query(
        dependencies=[check_client_access]
    ),
):
    """
    Fetch top holdings by market value.

    Args:
        client_id: Client ID.
        limit: Number of holdings (1-100, default 10).
        as_of_date: Portfolio snapshot date (default: latest).

    Returns:
        TopHoldingsResponse with ranked holdings.
    """

    snapshot_date = as_of_date or date.today()

    try:
        with duckdb_connection() as con:
            holdings = portfolio_analytics.get_top_holdings(
                con, client_id, snapshot_date, limit
            )

            return TopHoldingsResponse(
                client_id=client_id,
                as_of_date=snapshot_date,
                holdings=[
                    Holding(
                        rank=int(holding[0]),
                        ticker=holding[1],
                        security_name=holding[2],
                        value=holding[3],
                        weight=holding[4],
                    )
                    for holding in holdings
                ],
            )

    except Exception as e:
        logger.error("Error fetching top holdings: %s", str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch top holdings",
        )


# ============================================================================
# Transaction Endpoints
# ============================================================================


@app.get(
    "/v1/clients/{client_id}/portfolio/transactions",
    response_model=TransactionsResponse,
    tags=["transactions"],
)
async def get_transactions(
    client_id: str,
    start_date: date = Query(...),
    end_date: date = Query(...),
    account_id: Optional[str] = Query(None),
    _authorized_client_id: str = Query(
        dependencies=[check_client_access]
    ),
):
    """
    Fetch transactions for a date range.

    Args:
        client_id: Client ID.
        start_date: Start date (inclusive, required).
        end_date: End date (inclusive, required).
        account_id: Optional account filter.

    Returns:
        TransactionsResponse with transaction list and count.

    Raises:
        HTTPException 400: If end_date < start_date or range > 365 days.
    """

    # Validation
    if end_date < start_date:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="end_date must be >= start_date",
        )

    delta = (end_date - start_date).days
    if delta > 365:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Date range cannot exceed 365 days",
        )

    try:
        with duckdb_connection() as con:
            transactions = transactions_analytics.get_transactions(
                con,
                client_id,
                start_date,
                end_date,
                [account_id] if account_id else None,
            )

            return TransactionsResponse(
                client_id=client_id,
                start_date=start_date,
                end_date=end_date,
                transactions=[
                    Transaction(
                        transaction_id=txn[0],
                        transaction_date=txn[1],
                        ticker=txn[2],
                        security_name=txn[3],
                        type=txn[4],
                        quantity=txn[5],
                        price=txn[6],
                        amount=txn[7],
                        account_id=txn[8],
                    )
                    for txn in transactions
                ],
                total_count=len(transactions),
            )

    except Exception as e:
        logger.error("Error fetching transactions: %s", str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch transactions",
        )


# ============================================================================
# Performance Endpoints
# ============================================================================


@app.get(
    "/v1/clients/{client_id}/portfolio/performance",
    response_model=PortfolioPerformanceResponse,
    tags=["performance"],
)
async def get_performance(
    client_id: str,
    start_date: date = Query(...),
    end_date: date = Query(...),
    _authorized_client_id: str = Query(
        dependencies=[check_client_access]
    ),
):
    """
    Fetch portfolio performance (daily values) for a date range.

    Args:
        client_id: Client ID.
        start_date: Start date (inclusive, required).
        end_date: End date (inclusive, required).

    Returns:
        PortfolioPerformanceResponse with daily value series and return calculation.

    Raises:
        HTTPException 400: If end_date < start_date or range > 365 days.
    """

    # Validation
    if end_date < start_date:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="end_date must be >= start_date",
        )

    delta = (end_date - start_date).days
    if delta > 365:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Date range cannot exceed 365 days",
        )

    try:
        with duckdb_connection() as con:
            daily_values = performance_analytics.get_performance(
                con, client_id, start_date, end_date
            )

            if not daily_values:
                return PortfolioPerformanceResponse(
                    client_id=client_id,
                    start_date=start_date,
                    end_date=end_date,
                    daily_values=[],
                    start_value=0.0,
                    end_value=0.0,
                    total_return=0.0,
                )

            start_value = daily_values[0][1]
            end_value = daily_values[-1][1]
            total_return = (end_value - start_value) / start_value if start_value > 0 else 0.0

            return PortfolioPerformanceResponse(
                client_id=client_id,
                start_date=start_date,
                end_date=end_date,
                daily_values=[
                    DailyValue(
                        date=dv[0],
                        portfolio_value=dv[1],
                        equity_value=dv[2],
                        fixed_income_value=dv[3],
                        cash_value=dv[4],
                        alternatives_value=dv[5],
                    )
                    for dv in daily_values
                ],
                start_value=start_value,
                end_value=end_value,
                total_return=total_return,
            )

    except Exception as e:
        logger.error("Error fetching performance: %s", str(e), exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch performance data",
        )


# ============================================================================
# Error Handlers
# ============================================================================


@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    """Handle HTTPException with structured error response."""
    return JSONResponse(
        status_code=exc.status_code,
        content={
            "error": "HTTP Error",
            "status_code": exc.status_code,
            "detail": exc.detail,
            "timestamp": datetime.utcnow().isoformat(),
        },
    )


@app.exception_handler(Exception)
async def generic_exception_handler(request, exc):
    """Handle generic exceptions with 500 error."""
    logger.error("Unhandled exception: %s", str(exc), exc_info=True)
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={
            "error": "Internal Server Error",
            "status_code": 500,
            "detail": "An unexpected error occurred",
            "timestamp": datetime.utcnow().isoformat(),
        },
    )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.environment == "development",
    )
