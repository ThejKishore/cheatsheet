"""Authentication and authorization."""

import logging
from typing import Optional

from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

logger = logging.getLogger(__name__)

security = HTTPBearer(auto_error=True)


class User:
    """Authenticated user with access permissions."""

    def __init__(self, user_id: str, org_id: str, allowed_client_ids: list[str]):
        self.user_id = user_id
        self.org_id = org_id
        self.allowed_client_ids = allowed_client_ids

    def can_access_client(self, client_id: str) -> bool:
        """Check if user is authorized to access a client."""
        return client_id in self.allowed_client_ids


async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
) -> User:
    """
    Validate JWT token and extract user info.

    In production, implement JWT validation with RS256 public key.
    For now, this is a stub that expects a Bearer token.

    Args:
        credentials: HTTP Bearer credentials from the request.

    Returns:
        User: Authenticated user with permissions.

    Raises:
        HTTPException: 401 if token is invalid.
    """
    token = credentials.credentials

    # TODO: Implement JWT RS256 validation with settings.jwt_public_key
    # For now, accept any non-empty token (development only)

    if not token or len(token) < 10:
        logger.warning("Invalid or missing token")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid authentication credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )

    # TODO: Parse JWT, extract sub (user_id), org_id, allowed_client_ids
    # Stub: return a test user with all clients
    logger.debug("Token validated (stub implementation)")

    return User(
        user_id="test-user",
        org_id="test-org",
        allowed_client_ids=["ACME-001", "ACME-002", "TEST-001"],  # TODO: from JWT
    )


def check_client_access(
    client_id: str, user: User = Depends(get_current_user)
) -> str:
    """
    Verify user can access a specific client.

    Returns 403 Forbidden (never 404) to prevent client ID enumeration.

    Args:
        client_id: Client ID from the request path.
        user: Authenticated user.

    Returns:
        str: Validated client_id.

    Raises:
        HTTPException: 403 if user is not authorized for this client.
    """
    if not user.can_access_client(client_id):
        logger.warning(
            "Unauthorized client access attempt: user=%s, client=%s",
            user.user_id,
            client_id,
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied",
        )

    return client_id
