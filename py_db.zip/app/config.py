from typing import Optional
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""

    # Azure Blob Storage
    azure_storage_account: str
    azure_container_name: str = "portfolio-data"
    azure_storage_connection_string: Optional[str] = None  # dev only

    # Snowflake
    snowflake_account: str
    snowflake_user: str
    snowflake_password: Optional[str] = None
    snowflake_warehouse: str = "ANALYTICS_WH"
    snowflake_database: str = "ANALYTICS"
    snowflake_schema: str = "PUBLIC"

    # DuckDB resource limits
    duckdb_memory_limit: str = "1GB"
    duckdb_threads: int = 2

    # JWT & Auth
    jwt_algorithm: str = "RS256"
    jwt_public_key: Optional[str] = None

    # Service info
    environment: str = "development"
    log_level: str = "INFO"

    model_config = SettingsConfigDict(
        env_file=".env",
        extra="ignore",
        case_sensitive=False,
    )


settings = Settings()
