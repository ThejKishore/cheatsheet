package com.tk.learn.snowflakedemo.transactions.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class FromAccntsItem{
    @JsonProperty("amnt_debited")
    private BigDecimal amntDebited;

    @JsonProperty("accnt_no")
    private long accntNo;
}