package com.tk.learn.snowflakedemo.transactions;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tk.learn.snowflakedemo.transactions.model.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.simple.JdbcClient;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class TransactionService {

    private static final Logger log = LoggerFactory.getLogger(TransactionService.class);

    private final JdbcClient jdbcClient;
    private final ObjectMapper objectMapper;
    private final String queryById;

    public TransactionService(JdbcClient jdbcClient,
                              ObjectMapper objectMapper,
                              @Value("${app.snowflake.queryByTransactionIdentifier}") String queryById) {
        this.jdbcClient = jdbcClient;
        this.objectMapper = objectMapper;
        this.queryById = queryById;
    }

    /**
     * Fetches transaction_data JSON for the given transaction identifier.
     * Returns Optional.empty() if no row found.
     */
    public Optional<Transaction> getTransactionData(String transactionIdentifier) {
        try {
            Optional<String> jsonTextOpt = jdbcClient
                    .sql(queryById)
                    .param("transactionIdentifier", transactionIdentifier)
                    .query(String.class)
                    .optional();

            if (jsonTextOpt.isEmpty()) {
                return Optional.empty();
            }

            String jsonText = jsonTextOpt.get();
            if (jsonText == null || jsonText.isBlank()) {
                // If the column is NULL or blank, treat as not found/empty
                return Optional.empty();
            }

            // transaction_data in Snowflake VARIANT typically returns a JSON string.
//            JsonNode node = objectMapper.readTree(jsonText);
//            return Optional.ofNullable(node);
            objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
             Transaction transaction = objectMapper.readValue(jsonText, Transaction.class);
             return Optional.of(transaction);

        } catch (Exception e) {
            log.error("Error fetching transaction_data for {}: {}", transactionIdentifier, e.getMessage(), e);
            throw new RuntimeException("Failed to fetch transaction data", e);
        }
    }
}
