package com.tk.learn.snowflakedemo.transactions.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class SenderAccntItem{
    @JsonProperty("amnt_credited")
    private int amntCredited;

    @JsonProperty("accnt_no")
    private int accntNo;
}