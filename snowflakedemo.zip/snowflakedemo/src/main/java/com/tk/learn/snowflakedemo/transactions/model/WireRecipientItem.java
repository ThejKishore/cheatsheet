package com.tk.learn.snowflakedemo.transactions.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class WireRecipientItem{
    @JsonProperty("swift_no")
    private String swiftNo;

    private Address address;

    @JsonProperty("amnt_credited")
    private BigDecimal amntCredited;

    @JsonProperty("wire_accnt_no")
    private int wireAccntNo;

    @JsonProperty("recipient_name")
    private String recipientName;
}