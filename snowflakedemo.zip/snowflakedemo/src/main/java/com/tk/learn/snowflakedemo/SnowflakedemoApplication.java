package com.tk.learn.snowflakedemo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.context.annotation.Bean;
import org.springframework.jdbc.core.simple.JdbcClient;

import java.util.List;
import java.util.Map;

@SpringBootApplication
public class SnowflakedemoApplication {

    private static final Logger log = LoggerFactory.getLogger(SnowflakedemoApplication.class);

    public static void main(String[] args) {
        SpringApplication.run(SnowflakedemoApplication.class, args);
    }

    @Bean
    @ConditionalOnBean(JdbcClient.class)
    CommandLineRunner verifySnowflakeConnection(JdbcClient jdbcClient,
                                                @Value("${spring.datasource.url:}") String url) {
        return args -> {
            if (url == null || url.isBlank()) {
                log.info("Snowflake JDBC URL not configured. Skipping connection test.");
                return;
            }
            try {
                String version = jdbcClient.sql("SELECT CURRENT_VERSION()").query(String.class).single();
                log.info("Connected to Snowflake. CURRENT_VERSION() = {}", version);
            } catch (Exception e) {
                log.warn("Failed to connect to Snowflake using configured DataSource: {}", e.getMessage());
            }
        };
    }

    @Bean
    @ConditionalOnBean(JdbcClient.class)
    CommandLineRunner runConfiguredSnowflakeQuery(
            JdbcClient jdbcClient,
            @Value("${app.snowflake.query:}") String query,
            @Value("${spring.datasource.url:}") String url
    ) {
        return args -> {
            if (url == null || url.isBlank()) {
                log.info("Snowflake JDBC URL not configured. Skipping query execution.");
                return;
            }
            if (query == null || query.isBlank()) {
                log.info("No query configured at 'app.snowflake.query'. Skipping execution.");
                return;
            }
            log.info("Executing configured Snowflake query...\n{}", query);
            try {
                List<Map<String, Object>> rows = jdbcClient.sql(query).query().listOfRows();
                if (rows.isEmpty()) {
                    log.info("Query executed successfully. No rows returned.");
                } else {
                    log.info("Query executed successfully. Returned {} row(s). Printing results:", rows.size());
                    int idx = 1;
                    for (Map<String, Object> row : rows) {
                        log.info("row #{} => {}", idx++, row);
                    }
                }
            } catch (Exception e) {
                log.error("Error executing configured Snowflake query: {}", e.getMessage(), e);
            }
        };
    }
}
