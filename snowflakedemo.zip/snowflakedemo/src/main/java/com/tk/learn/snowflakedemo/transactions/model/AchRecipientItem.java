package com.tk.learn.snowflakedemo.transactions.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

import java.math.BigDecimal;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class AchRecipientItem{
    @JsonProperty("amnt_credited")
    private BigDecimal amntCredited;

    @JsonProperty("ach_routing_no")
    private String achRoutingNo;

    @JsonProperty("ach_accnt_no")
    private long achAccntNo;
}