# Getting Started

### Reference Documentation

For further reference, please consider the following sections:

* [Official Gradle documentation](https://docs.gradle.org)
* [Spring Boot Gradle Plugin Reference Guide](https://docs.spring.io/spring-boot/3.5.4/gradle-plugin)
* [Create an OCI image](https://docs.spring.io/spring-boot/3.5.4/gradle-plugin/packaging-oci-image.html)
* [Spring Web](https://docs.spring.io/spring-boot/3.5.4/reference/web/servlet.html)

### Guides

The following guides illustrate how to use some features concretely:

* [Building a RESTful Web Service](https://spring.io/guides/gs/rest-service/)
* [Serving Web Content with Spring MVC](https://spring.io/guides/gs/serving-web-content/)
* [Building REST services with Spring](https://spring.io/guides/tutorials/rest/)

### Additional Links

These additional references should also help you:

* [Gradle Build Scans – insights for your project's build](https://scans.gradle.com#gradle)

---

### Using a .env file with IntelliJ IDEA

This project reads Snowflake connection settings from environment variables (see `src/main/resources/application.yml`). To simplify local development:

1. Copy `.env.example` to `.env` at the project root.
2. Fill in your Snowflake credentials and settings.
3. Configure IntelliJ to load the `.env` file when running the app:
   - IntelliJ 2023.3+: Run/Debug Configurations > your Spring Boot app > Environment > Load environment variables from: select the `.env` file.
   - Or install the "EnvFile" plugin and add the `.env` file under the EnvFile section.

`.gitignore` is set to ignore your personal `.env` so secrets aren't committed. Keep using `.env.example` for sharing the required variable names with the team.

